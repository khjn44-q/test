# 04. 사내 소스 조사, 원본 대비 분석, 실행 경계 확정

## 1. 첫 세션은 코드 재작성보다 기준선 확인

최초 작업의 산출물은 ‘새 구조로 바꾼 코드’가 아니라 **실제 구조 지도, 모델별 빌드 프로필, 기반 릴리스 대응, 경계 후보, 전체 감사 범위와 대표 Item 검증 계획**이어야 한다. 분석 문서도 신규 작업 영역에 쓴다. 원본과 현재 운영 혼합 코드에는 주석 추가·포맷 변경·파일 이동을 하지 않는다.

사내 LLM은 먼저 제공된 루트와 허용 경로만 읽는다. 경로가 없으면 사용자가 제공해야 하는 필수 입력으로 기록한다. 임의로 네트워크 드라이브 전체를 뒤지거나 외부 저장소로 올리지 않는다.

## 2. 자료 수집 표

| 입력 | 필수 기록 | 없을 때 |
|---|---|---|
| 모델별 Vendor 원본 | 공급 릴리스, 수령일, 아카이브/파일 해시 | 버전 미확인 상태로 보존 |
| 모델별 Mixed 코드 | Git commit 또는 파일 스냅샷, 운영 여부 | 운영 기준선 불명으로 기록 |
| SDK 라이브러리 | 파일명, 아키텍처, 해시, 배포 제약 | 소스만으로 링크 가능 판단 금지 |
| 빌드 체계 | Make/CMake/스크립트, GCC, 링커, sysroot, flags | 우선 텍스트 조사만 |
| 실행 체계 | main, 콜백, Item 발견/등록 방법 | 독립 실행을 가정하지 않음 |
| 매뉴얼 | 문서 ID/버전/사용권 | 코드에 없는 의미는 UNKNOWN |
| 기존 시험 자료 | 설정·Run ID·로그·실제 장비·DUT 정보 | 행동 보존 비교 한계 표시 |
| 규격 | 승인 문서와 적용 개정/ECN | 최신 웹 문서로 대체하지 않음 |
| 안전 지침 | Fixture·PSU·Chamber·DUT별 허용 범위 | 실장비 실행 금지 유지 |

## 3. 빌드 계보를 먼저 복원

컴파일 옵션에 따라 같은 C 파일의 의미가 달라진다. 모델별·빌드 프로필별 실제 Translation Unit, `-D`, include search order, 강제 include, 생성 헤더, 타깃 ABI, GNU 확장, 링커 스크립트를 기록한다.

CMake의 compile database나 기존 빌드에서 수집한 compilation database를 사용한다. CMake 내보내기는 지원 Generator에 한정되며, 기존 GCC 빌드는 Bear가 후보가 된다. Clang 도구는 정확한 컴파일 문맥을 필요로 한다. [S03] · [S04] · [S06]

**주의:** `make`, CMake configure, Vendor code generator는 읽기 도구가 아니다. 스크립트가 장비 연결·파일 생성·네트워크 접속·펌웨어 작업을 할 수 있다. `make -n`도 모든 경우에 완전 무해한 샌드박스로 간주하지 않는다. 먼저 스크립트를 검토하고 승인된 빌드 전용 환경에서 실행한다.

빌드가 불가능해도 목록화는 시작할 수 있다. 단, 이때 결과는 ‘텍스트/심볼 인벤토리’이지 ‘실제 컴파일 의미 분석 완료’가 아니다.

## 4. 추출 수준 3단계

| 수준 | 도구/방법 | 얻는 것 | 얻지 못하는 것 |
|---|---|---|---|
| L1 탐색 | 파일 해시, rg, Universal Ctags | 심볼 위치, 선언 후보, 모델별 차이 | 정확한 부작용/전 경로 의미 |
| L2 문맥 분석 | Clang AST/LibTooling + 실제 build profile | 해석된 타입, 직접 호출, 참조/전처리 정보 | 비공개 내부, 모든 간접 호출·동시성 |
| L3 계약 검증 | 매뉴얼·운영 근거·승인 실험 | 완료 의미, 실패/타이밍/관찰 한계 | 관찰하지 않은 모든 조건의 보장 |

Ctags는 심볼 인덱싱용이며 AST 대체재가 아니다. Doxygen은 문서 출력 도구이고 기능의 정확성을 판정하지 않는다. [S07] · [S08] Clang 해석 실패를 `typedef`/더미 매크로로 억지로 통과시켰다면 그 결과를 생산 ABI의 증거로 쓰지 않는다. [S05]

## 5. 인벤토리의 단위

함수뿐 아니라 아래를 함께 추적한다.

- 함수, 매크로 함수, `static inline`, 조건부 선언, 타입/enum, 필드, 상수.
- 전역변수의 정의·선언·초기화·읽기·쓰기·주소 노출.
- 포인터/캐스트/매크로를 통한 간접 접근과 미해결 alias.
- MMIO/공유 RAM/DMA/호스트 heap/스택 등 주소 공간 후보.
- 콜백 등록, 함수 포인터 테이블, ISR/작업 스레드 후보.
- 실행 진입점, 등록 테이블, 링커 section, 자동 생성 코드.
- SDK 초기화/종료, 타이머, 로그/파일/버퍼 지원.

심볼 키는 `model + sdk_revision + build_profile + linkage/scope + symbol_id`다. 같은 이름의 `static` 함수가 여러 파일에 있거나 모델별 다른 서명을 갖는 것을 충돌로 뭉개지 않는다. 파일/라인은 검색 편의 정보이며 해시·심볼 ID와 함께 보관한다.

## 6. Vendor 원본과 Mixed 코드 비교

가능하면 `Vendor V0 → Mixed M0`, `Vendor V1 → Mixed M1`의 기반 릴리스를 먼저 확인한다. 정확한 기준이 없으면 ‘우리 수정 확정’이 아니라 후보로 분류한다.

| 분류 | 확인할 질문 | 새로운 위치 후보 |
|---|---|---|
| 그대로인 코드 | 필수 실행 요소인가, 참고 예제인가? | boundary 또는 참고 |
| 함수 내부 수정 | 버그 수정인가, 시험 조건 변경인가, workaround인가? | Service/Provider/Item |
| 새 함수 | 공통 의미인가 모델 고유인가? | 공통 모듈 또는 Provider |
| 전역 추가/수정 | 어떤 호출 순서와 수명에 의존하는가? | Context/Resource state |
| 상수/대기 변경 | 표준 요구인가 사내 정책인가 장비 제약인가? | spec/profile/policy |
| 새 구조체/필드 | wire/ABI/semantic/state 중 무엇인가? | 해당 책임 경계 |
| 삭제된 오류 처리 | 의도적 오류 시험인가 누락인가? | 판정 명세 또는 결함 |
| 주석과 코드 불일치 | 어느 쪽이 관측 사실과 맞는가? | 충돌 레지스트리 |

텍스트 Diff, 함수/AST Diff, 호출·상태 영향, 실제 평가 의도 순으로 좁힌다. 오랜 코드의 주석과 함수명은 단서이지 최종 근거가 아니다.

## 7. Vendor 실행 경계 분류

| 등급 | 정의 | 신규 Custom에서의 정책 |
|---|---|---|
| P0 opaque primitive | 내부 비공개, 장비 접근의 최소 제공 인터페이스 | Provider만 호출 |
| P1 required ABI/state | 고정 구조체, 필수 extern, 공유 버퍼/상수 | Provider/Entry Shim만 접근 |
| P2 required runtime | 필수 초기화/종료/등록/콜백 지원 | 근거를 승인하고 좁은 위치에서 사용 |
| H0 readable helper | API들을 조합한 공급 함수 | 분석·참고만, Custom으로 재구현 |
| H1 vendor test item | 공급 평가 시나리오 | 분석·참고만 |
| U0 generic utility | 일반 문자열/수학/파일 도우미 등 | 표준/자체 대체 우선 |
| X0 unresolved | 필수성·내부 동작·대체 가능성 불명 | 막연한 allowlist 편입 금지 |

P2 승인은 Vendor 상위 코드 재사용을 되살리는 우회로가 아니다. 런타임 진입 조건상 대체할 수 없는 요소인지 설명해야 한다. 변경 가능한 소스가 보여도 링커·펌웨어 계약 때문에 바꿀 수 없는 부분이 있을 수 있다.

경계의 allowlist는 함수 심볼뿐 아니라 global/field/memory region/required object를 포함한다. 상위 코드는 이름이 `Vendor_*`가 아니더라도 Vendor 의존성일 수 있다. 정규식 이름 검사만으로 경계 검증을 끝내지 않는다.

## 8. 명세의 근거와 상태

각 주장에 근거 종류를 붙인다: `vendor_document`, `source_observation`, `standard_reference`, `measurement`, `inference`, `unknown`.

`observed`는 특정 구성에서 관찰되었다는 뜻이고 `guaranteed`와 다르다. ‘단일 시험 성공’을 스레드 안전·모든 전압 범위·모든 펌웨어 호환의 보장으로 승격하지 않는다.

상태는 `discovered → drafted → reviewed → validated_for_profile`로 둔다. 마지막 상태도 검증한 모델/SDK/장비 FW/조건에 제한된다. 품질 수치를 표시하려면 분모(대상 심볼, 모델, 빌드 구성, reachable closure)를 같이 적는다.

## 9. 상세 계약에 반드시 들어갈 항목

함수 원형/호출 규약, 인자 단위/범위/의미, 포인터 NULL 허용, 입력·출력 길이, 완료 기준, 반환값, 부작용, 읽고 쓰는 상태, 스레드·재진입·호출 순서, 버퍼 수명, 취소/타임아웃, 반복 호출/재시도 가능성, Reset 뒤 유효성, 지원 프로필, 관측 불가능한 부분, 근거와 검증 ID를 포함한다.

내부 구현을 볼 수 없으면 ‘내부적으로 버퍼를 복사함’이라고 추정하지 않는다. 계약이 불명확하면 Caller 버퍼를 언제 반환할 수 있는지 확정할 수 없으므로 해당 경로의 실사용을 제한한다.

## 10. 전면 조사에 필요한 세부 산출물

| 분석 대상 | 필수 기록 | 상세 검토 항목 |
|---|---|---|
| 모든 파일 | 상대경로·해시·소유권·언어/형식·생성 여부·Git 상태·build profile | 책임·exports/imports·조건부 분기·원본 관계·위험·신규 disposition |
| 모든 함수/API | scope/signature·입출력 타입·선언/정의·caller/callee·조건 | 목적·단위·전후 상태·memory/global 효과·완료/오류·재진입·서명/설명 충돌 |
| 전역/정적 변수 | 정의·초깃값·읽기/쓰기·주소 유출·유효 수명 | slot 선택·세션 공유·Reset·callback/동시성 |
| 인자/지역 변수/필드 | scope·effective type·선언/참조·초기화 | 의미·범위·단위·승격/축소·overflow/underflow·out-of-bounds |
| 타입 | typedef/tag·field·size/alignment/packing·ABI profile | wire/host/vendor 구분·누락/중복·portability |
| 매크로/상수 | 원문 식·effective value·유형·조건·재정의 | 실제 한계인지 정책인지·타입/단위·reserved value |
| 메모리 | 주소 공간·주소/크기/정렬·allocator·accessor·owner | DMA·MMIO 부작용·cache/order·safe release |
| build 파일 | TU/소스 선택·include·flags·linker·생성 명령 | 선택 모델 밖 포함·표준/컴파일러 차이·실행 위험 |
| 등록/콜백 | entry·signature·발견 방식·thread·owner | 재진입·stale callback·종료 책임 |
| 규격/내부 명령 | public/private namespace·revision·field·FW | 장비 제한·SDK 재작성·독립 기대값 |
| UART/로그 | port/route·framing·dialect·clock·sink | 분할입력·echo/로그 혼재·loss·재개 |
| Item | 목적·순서·자원·관측·판정·결함 의심 | 새 요구 retain/redesign/retire/blocked |

함수 목록만 추출하고 ‘상세 분석’이라고 보고하지 않는다. API 호출의 전역/메모리 효과와 인자 의미, 파일 책임, 각 구성에서의 유효 타입을 연결해야 한다. 로컬 변수의 기계 정보는 생성 inventory에 두고 고위험 의미 계약은 review 문서로 보완한다.

## 11. 상태·커버리지·종료 조건

전체 scope의 파일 수/분류 수, profile 수, TU 해석 성공/실패, 심볼 추출 수, 의미 검토 수, 미해결 호출, 미확인 계약, 담당자 답변 대기를 각각 집계한다. 함수 이름 수 하나를 전체 분석율의 분모로 쓰지 않는다. 분석된 구성이 어디까지인지 항상 적는다.

조사 상태는 `NOT_STARTED`, `INVENTORIED`, `PARSED`, `SEMANTIC_REVIEWED`, `CONTRACT_REVIEWED`, `BLOCKED`, `RETIRED_WITH_REASON`, `OPAQUE_NOT_INSPECTABLE` 등을 사용할 수 있다. 기준은 사내에서 고정하고 unsupported parser를 success로 변환하지 않는다.

전면 구조 검토 종료는 모든 제공 파일의 책임과 상태가 정리되고, 알려진 운영 구성/주요 분기/사용·고위험 기능의 의미/의존성/결함/질문이 정리된 때다. 새 구현하려는 경로는 상세 계약이 준비되어야 한다. unused/opaque/inaccessible도 누락이 아닌 명시 상태로 남긴다. 후속 조사 backlog가 있어도 무엇이 설계를 막는지 분명해야 한다.

## 12. 사내 첫 결과 보고의 형태

`분석한 자료 → 실제 구성 지도 → 전체 파일/심볼 inventory → 기능별 의미/부작용 → 원본 대비 delta → 정적분석 findings → 필요한 문의 → 후보 비교 → 승인 후 세부 실행계획` 순서로 제출한다. 원본 소스가 정답이라는 전제를 두지 않고, 이 외부 인계서도 독립적으로 반증한다.

새 아키텍처를 코드로 먼저 만들어 놓고 기존 코드를 그 틀에 억지로 끼우지 않는다. 전면조사 W00~W11과 설계 재검토 W12가 선행하며, 출처·미확인·사용자 질문 절차는 24장을 따른다.

<!-- SOURCE_LINKS_START -->

[S03]: https://cmake.org/cmake/help/latest/variable/CMAKE_EXPORT_COMPILE_COMMANDS.html
[S04]: https://clang.llvm.org/docs/JSONCompilationDatabase.html
[S05]: https://clang.llvm.org/docs/LibTooling.html
[S06]: https://github.com/rizsotto/Bear
[S07]: https://docs.ctags.io/en/latest/
[S08]: https://www.doxygen.nl/manual/output.html
