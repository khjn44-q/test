# 05. NVMe·PCIe·구조체·메모리 계약 설계

## 1. 표준은 의미의 기준, SDK는 실행 수단

NVMe 공식 규격군은 Base, Command Set, Transport 등의 문서를 분리한다. 따라서 ‘NVMe 버전 숫자 하나’만으로 모든 필드와 동작을 확정하지 않는다. [S28] 장비별 SDK 버전과 DUT가 구현한 규격/기능, 우리 파서의 지원 범위를 따로 기록한다.

PCIe도 적용 문서·개정·ECN과 관찰/제어 위치를 고정한다. 본 패키지는 유료/회원 전용 규격 원문을 열람하거나 필드별 조항을 검증하지 않았다. 공식 사이트와 프로젝트 문서는 설계 방향의 근거이며 **필드 offset·비트·예약값의 최종 근거를 대신하지 않는다.** [S29]

## 2. 데이터 표현은 4종으로 분리

| 종류 | 목적 | 원칙 |
|---|---|---|
| Vendor ABI model | 실제 SDK 호출 인자/공유 구조체 | Vendor 선언 그대로, Provider 내부에 제한 |
| Raw/wire view | 받은 바이트·명령 Dword·관측 패킷 보존 | 길이·출처·세대·원시 값 보존 |
| Decoded protocol model | 규격 의미로 해석한 필드 | 정확한 폭·지원/유효성·개정 정보 |
| Evaluation semantic model | 시험에서 쓰는 의미/측정값 | 단위·판정에 필요한 상태를 명시 |

원시 바이트를 semantic struct로 캐스팅하지 않는다. `packed`는 padding 문제 일부를 다루는 수단이지 endian·정렬된 접근·유효 길이·비트필드 배치·alias 문제를 모두 해결하는 장치가 아니다. [S19]

프로토콜 헤더 전체를 수동 관리하는 대신 명세에서 접근 함수를 생성할 수 있지만, 그 생성기의 가정도 검증 대상이다. C 구조체와 YAML과 문서를 모두 손으로 따로 고치게 만들지 않는다.

## 3. 필드 스키마

규격 필드는 안정적인 ID를 가진다. 권고 속성은 다음과 같다.

| 항목 | 내용 |
|---|---|
| 식별 | field_id, logical_name, parent message/log/feature |
| 위치 | byte offset, byte length, bit position/width 또는 동적 위치 규칙 |
| 표현 | endian, signedness, integer width, 배열/가변 길이 |
| 의미 | 단위, scaling, enum/bit 의미, 누적/게이지 구분 |
| 유효성 | 지원 조건, reserved/unavailable 값, truncation 시 처리 |
| 버전 | 추가/변경된 개정, command set, ECN/TP, vendor extension namespace |
| 읽기/쓰기 효과 | read-clear, W1C, 예약비트, latch, snapshot 일관성 |
| 손실 정책 | 반올림, overflow, unknown bits 보존, 원시 값 보존 |
| 근거 | 승인 spec ID, section/table/page, 문서 해시, 검토자 |
| 검증 | 독립 golden vector, 경계값, negative case, fuzz target |

지원 여부를 단순한 `bool valid` 하나로 뭉개지 않는다. `PRESENT`, `UNSUPPORTED`, `UNAVAILABLE`, `TRUNCATED`, `MALFORMED`, `UNKNOWN_REVISION` 등은 구별할 가치가 있다. 정확한 enum은 실제 사용성과 검증 비용을 보고 정하되 `0`이 자동으로 ‘없는 값’이 되지 않게 한다.

큰 카운터를 `double`로 바꿔 저장하지 않는다. 규격이 넓은 정수를 사용하면 raw 폭을 보존하는 표현을 먼저 만들고, 표시용 축약/환산은 별도 함수로 한다. GCC 확장 정수 사용 여부는 플랫폼 계약으로 결정한다. 모든 의미 모델에 임의로 플랫폼 의존 타입을 노출하지 않는다.

## 4. 파서와 Serializer 원칙

파서는 `(bytes, available_length, protocol_profile)`을 받고 검증된 결과를 낸다. 포인터만 받아 구조체 크기를 신뢰하지 않는다. 길이의 덧셈·곱셈 overflow, 잘린 응답, 가변 엔트리 개수, 알 수 없는 확장, 예약값을 시험한다.

원시 접근은 명시적 little/big endian helper와 mask/shift를 사용한다. 로컬 고정 구조체를 쓰는 경우에도 크기·offset 정적 검증과 독립 byte vector 시험을 붙인다. C 비트필드는 wire layout의 유일한 정본으로 삼지 않는다. [S19]

decode와 encode가 같은 잘못된 offset을 공유하면 round-trip 시험은 통과할 수 있다. 따라서 **생성 명세와 독립된 규격 근거/수작업 골든 값**을 일부 핵심 필드에 유지한다. 자동 생성 테스트만으로 규격 일치를 주장하지 않는다.

조회된 Log가 여러 조각으로 나뉘면 chunk 크기·offset·필요 길이뿐 아니라 도중 값 갱신/일관된 snapshot 여부도 계약에 넣는다. 동일 Log ID라도 Controller/Namespace 범위, 선택자, UUID/Command Set, Vendor 확장이 다를 수 있으므로 단일 ID만으로 모든 구조를 결정하지 않는다. 세부 규칙은 실제 적용 규격에서 확정한다.

## 5. NVMe 명령 경계: 관리형과 실험형

### 5.1 관리형 요청

보통의 Item은 명령 의미, command-set/queue class, namespace, 논리적 data/metadata, deadline을 지정한다. Provider/SDK가 CID·큐·DMA mapping을 관리하면 그 책임을 중복 구현하지 않는다. 주소를 채우는 책임을 명확히 하나에 둔다.

명령 builder는 하드웨어에 접근하지 않는 순수 함수로 둔다. Read/Write의 길이·블록 수·규격 필드 인코딩 같은 변환은 한 곳에서 명시적으로 처리하고, raw 필드 단위와 사용자 단위가 같은 숫자라고 가정하지 않는다.

### 5.2 실험형/raw 요청

의도적으로 비정상 opcode·예약비트·경계값을 넣는 평가에는 별도 경로가 필요하다. Raw의 뜻을 ‘Dword를 받는다’ 정도로 정의하지 않는다. 장비별로 **caller 제어 mask, SDK 덮어쓰기 mask, 전달 보장, 관측 가능 필드, 데이터 포인터 소유자**를 명시한다.

보존할 수 없는 비트를 요청한 경우 `UNSUPPORTED`를 반환해야지 조용히 정규화하지 않는다. 단, 프로토콜상 비정상 명령을 허용하는 것과 호스트 포인터/길이/장비 안전 범위를 무검증으로 허용하는 것은 다르다. `strict`, `controlled_negative`, `expert_raw`처럼 목적을 분리하고 안전 검사는 모든 모드에 남긴다.

### 5.3 확인할 항목

CDW 입력 범위, Admin/I/O 경로, SDK가 생성하는 필드, payload direction, metadata, queue/CID 제한, 동기/비동기, 자동 분할/재시도, CQE 전체 또는 일부 반환, abort/reset 효과, 실제 timeout 정의를 모델별로 확인한다.

raw CQE를 받지 못하면 SDK가 제공한 상태/결과 필드와 존재 여부만 보존한다. 누락된 CQE 비트를 0으로 채워 실제 관측이라고 표시하지 않는다.

## 6. 결과는 네 층으로 분리

```text
submission/transport result   : 장비가 요청을 받았나? 전송 실패인가?
completion observation        : DUT가 무엇을 반환했나? 원시 근거가 있나?
decode/measurement validity   : 응답을 올바르게 해석할 수 있나?
test verdict                  : 기대 조건을 충족했나?
```

DUT가 기대한 NVMe 오류를 반환하면 음성 평가에서 PASS가 가능하다. 장비가 전송에 실패하면 동일한 DUT 오류로 대체하지 않는다. Timeout은 DUT 결함일 수도, 장비 오류일 수도, 의도된 시험 관찰일 수도 있다. 판정 근거 없이 한 코드로 합치지 않는다.

최소 Result 후보는 `PASS`, `FAIL`, `ERROR`, `SKIPPED`, `UNSUPPORTED`, `INCONCLUSIVE`, `ABORTED`, `BLOCKED`다. 세부 구분은 사내 결과 체계와 매핑하되 실패 원인을 잃지 않는다.

## 7. 비동기 수명과 Reset

권고 상태 모델은 `CREATED → VALIDATED → SUBMITTED → COMPLETED`이며, `SUBMIT_FAILED`, `CANCEL_REQUESTED`, `TIMED_OUT_PENDING`, `RESET_INVALIDATED`, `EXECUTION_UNKNOWN` 등을 별도로 둔다.

`wait()`가 timeout을 반환했다고 명령이 취소되거나 DMA가 끝났다는 뜻은 아니다. 버퍼는 완료 또는 장비 계약상 안전한 quiesce/reset이 확인될 때까지 유지한다. 해제·재사용은 명령 상태와 별개의 명시적 조건이다.

DUT 교체·Controller Reset·PCIe Reset·Power Cycle 후에는 queue, request, buffer mapping, cached Identify 등의 유효성이 바뀔 수 있다. 세션/자원별 generation을 둬 오래된 handle과 늦은 callback을 식별한다. 모든 reset이 같은 자원을 무효화한다고 단정하지 않고 종류별 계약을 둔다.

재시도는 idempotent 여부, 이미 수행되었을 가능성, 평가 순서 변화, DUT 상태를 고려한다. 데이터 쓰기·전원 차단·오류 주입을 ‘통신 오류니 다시’ 처리하지 않는다.

## 8. 메모리와 주소 공간

각 버퍼에는 owner, allocator, address-space kind, capacity/valid length, alignment, DMA mapping, direction, pinning/sync 필요, lease count, reuse condition, generation을 기록한다.

CPU virtual pointer, CPU physical address, DMA/bus/IOVA, 장비 내부 buffer ID는 다르다. Linux DMA 문서도 주소 공간의 차이를 명시하지만, 그 Linux API를 이 장비에 그대로 적용하라는 뜻은 아니다. 실제 SDK 계약을 확인한다. [S30]

`volatile`은 스레드 동기화나 일반 메모리 순서 보장의 대체물이 아니다. GCC도 volatile 접근이 비휘발성 메모리 접근의 일반 장벽이 되지 않는다고 설명한다. [S20] MMIO/DMA ordering은 SDK·OS·타깃의 승인된 접근 함수로 처리하고 임의 포인터 캐스트로 고치지 않는다.

## 9. PCIe 계약을 나누는 방법

| 기능 | 반드시 명세할 차이 |
|---|---|
| Configuration access | 대상 BDF/function, access width/alignment, 범위, 실패 반환 |
| Capability traversal | 표준/확장 구분, next-pointer 범위, 순환·잘림 처리 |
| MMIO/register | BAR/영역, 폭·endian·읽기/쓰기 부작용, ordering |
| Link control | 요청값/실제 관측값, retrain 완료 의미, timeout |
| Reset | 기능/링크/버스/전원별 범위, 다른 Slot 영향, 재발견 |
| Error reporting | DUT/Root Port/장비 중 관측 위치, sticky/clear 동작 |
| Packet decode | 실제 capture format, protocol mode, truncated/unknown 처리 |
| Packet injection | 임의 필드 제어 범위, 장비 재작성/CRC 처리, trigger 정확도 |
| LTSSM/trace | 관측 가능 상태, 해상도, 샘플 손실, 타임스탬프 출처 |

모든 PCIe 세대·모드의 패킷을 단일 고정 `struct tlp`에 억지로 맞추지 않는다. 실제 장비의 capture representation과 적용 규격을 먼저 고정하고 선택적으로 구현한다. Raw TLP/DLLP 입력 가능 여부는 아직 미확인이다.

레지스터의 read-modify-write는 W1C/read-clear/예약비트 의미를 고려해야 한다. 일반 ‘bit set’ 유틸을 모든 레지스터에 적용하지 않는다. 프로토콜 라이브러리는 비트 의미를 알고, 실제 접근은 Provider가 담당한다.

## 10. 규격·장비·정책의 버전 축

`standard_profile`은 문서/개정/ECN 집합, `provider_profile`은 SDK/장비 FW/ABI, `dut_profile`은 관측된 SSD FW/지원 기능, `item_revision`은 시험 순서·판정, `schema_revision`은 데이터 해석을 식별한다. 한 `version` 필드로 합치지 않는다.

Raw 자료는 가능한 범위에서 보존하고 파서 버전도 기록한다. 후일 새 파서로 재해석한 결과는 원래 실행 결과를 덮어쓰지 않고 별도 분석 결과로 연결한다.

## 11. 장비 지원 한계와 내부 dialect를 분리

표준 profile은 의미의 기준일 뿐 장비가 해당 기능을 전달/관찰한다는 증거가 아니다. SDK macro의 상한은 `declared_limit`, 문서의 보장은 `documented_limit`, 실제 검증 범위는 `verified_limit`로 출처와 함께 기록한다. 셋이 충돌하면 조용히 낮은 값만 택하지 말고 원인/정책을 확인한다.

내부 command는 18장의 독립 namespace/revision/FW 계약으로 작성하고 NVMe/UART 중 실제 전송만 재사용한다. 공용 표준 구조체에 사내 필드를 무분별하게 끼워 넣지 않는다. 확장 parser는 적용 조건·unknown 처리·독립 검증을 가진다.

폼팩터 차이는 protocol field 차이인지 Fixture/전기 배선인지, SDK의 명령 한계인지 구분한다. 폼팩터 문자열만 보고 standard version이나 command set을 자동 설정하지 않는다. 명령/필드별 raw 제어 범위와 negative-test 가능성도 profile별로 검토한다.

<!-- SOURCE_LINKS_START -->

[S19]: https://gcc.gnu.org/onlinedocs/gcc/Structures-unions-enumerations-and-bit-fields-implementation.html
[S20]: https://gcc.gnu.org/onlinedocs/gcc/Volatiles.html
[S28]: https://nvmexpress.org/specifications/
[S29]: https://pcisig.com/specifications
[S30]: https://www.kernel.org/doc/html/latest/core-api/dma-api-howto.html
