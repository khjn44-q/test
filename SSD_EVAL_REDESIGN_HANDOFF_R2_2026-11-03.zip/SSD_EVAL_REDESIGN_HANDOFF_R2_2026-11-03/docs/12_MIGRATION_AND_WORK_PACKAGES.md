# 12. 전면 소스 감사부터 신규 코드 운영까지 — 정밀 작업계획

## 1. 계획의 사용법과 효력

이 계획은 실제 소스가 **사내 실행자에게 제공되었다고 가정**한다. 외부 작성자는 원문을 보지 않았으므로 실제 함수명/라인·안전값·SDK 옵션을 확정하지 않는다. 각 Work의 목적·순서·입출력·반례·완료 조건은 아래에 구체화했으며, 실행자는 해당 Work 시작 전에 실제 저장소에 바인딩한다. 제안 파일경로는 새 산출물의 위치이지 현존 파일이라고 주장하는 것이 아니다.

최초 세션의 범위는 W00~W12다. 전체 자료를 조사하고 중요 질문을 확인하며 후보를 비판적으로 검토한 뒤 구현을 승인한다. W13 이후는 승인된 설계의 구체적 구현·검증 계획이다. 진행이 길다는 이유만으로 앞 단계를 생략하거나, 반대로 무관한 미확인 때문에 모든 순수 작업을 막지 않는다.

모든 작업의 초기 상태는 `NOT_STARTED`이며 이 패키지에서 수행되었다는 뜻이 아니다. 외부 문서·패키지 검사는 제품 작업 실행과 별개다.

## 2. 각 Work의 실제 바인딩 문서

`docs/work/bindings/<work_id>.md`에 다음을 확정한 뒤 실행한다. (W00은 신규 analysis 영역에서 먼저 작성한다.)

| 항목 | 반드시 들어갈 내용 |
|---|---|
| 현재 기준선 | 실제 repo/root/commit/dirty 상태, source/build/profile hash |
| 적용 범위 | 대상 모델/subtype/form factor/Fixture/SDK/FW/dialect, 제외 범위 |
| 읽을 근거 | 실제 파일 경로·심볼·계약/질문/한계 ID와 revision |
| 수정 파일 | Create/Modify/Read-only/Generated를 정확한 경로로 구분 |
| 인터페이스 | 소비·제공하는 실제 C 원형/타입·구조화 schema·owner |
| 세부 행동 | 아래 step ID를 실제 명령/파일/검토 대상에 대응 |
| 검사 명령 | 실제 존재하는 tool/target/preset/suite와 working directory |
| 기대 결과 | 정상·실패·경계별 값/상태와 판정 근거, exit/보고 정책 |
| 권한 | offline/빌드/분석/HIL/배포 각각 허용 여부와 승인 참조 |
| 차단 | unanswered question/CONTRACT_GAP/필수 자료와 진행 불가 범위 |
| 완료 증거 | 실제 명령·도구 버전·exit code·검사 수·raw 결과·hash |

확정하지 못한 필수 항목을 그럴듯한 함수/스크립트로 채우지 않는다. 신규 도구가 필요하면 그 도구를 만드는 Work와 인터페이스/시험을 선행한다. ‘자동 검사 예정’과 실제 구현된 검사 기능을 구별한다.

## 3. 공통 개발/검증 순서

구현 Work는 승인 계약 읽기 → 새 동작을 구별하는 실패/경계 테스트 → 실제 실패 이유 확인 → 최소 새 구현 → 정상/반례/정적/의존성 검사 → docs/한계/검증 업데이트 순서를 따른다. 동일 formatter/schema가 만든 기대값만으로 정확성을 판단하지 않는다. 제품 소스가 없는 현재 문서에는 자동 실행을 가장한 command script를 넣지 않았다.

공통 헤더·schema·build root는 단일 책임자가 통합한다. W04/W05 및 W07~W10의 근거 수집은 입력이 준비된 부분에서 병렬 가능하지만, 같은 파일을 동시 수정하지 않는다. SDK/global 장비 상태는 worktree로 격리되지 않으므로 hardware 동시 실행은 별도 자원 계약이 필요하다.

## 4. 사용할 수 있는 실제 명령 유형과 제한

아래는 사내 경로/툴이 확인된 뒤 command registry에 등록할 **명령 형태**다. 현재 실행한 검사 목록이 아니다. 경로와 preset 이름은 실제 값으로 바인딩한다.

```sh
# Git 읽기 조사 예시. 출력과 파일 내용은 사내에서만 저장한다.
git -C "$SOURCE_ROOT" rev-parse HEAD
git -C "$SOURCE_ROOT" status --porcelain=v1
git -C "$SOURCE_ROOT" ls-files -z
git -C "$SOURCE_ROOT" ls-files --others --exclude-standard -z
# ignored 자료 조사도 권한 범위에 한정한다.
git -C "$SOURCE_ROOT" ls-files --others --ignored --exclude-standard -z

# 실제 프로젝트에서 승인·구현된 preset이 있을 때만 실행한다.
cmake --preset "$CONFIGURE_PRESET"
cmake --build --preset "$BUILD_PRESET"
ctest --preset "$HOST_TEST_PRESET" --output-on-failure
```

CMake/Make는 script를 실행할 수 있으므로 먼저 검토한다. 전처리·AST·정적분석에는 임의 default flags 대신 실제 TU arguments를 사용한다. command array는 shell 문자열로 무검증 재해석하지 않는다. HIL은 별도 runner/권한/Run Plan으로 분리하며 위 host command가 장비를 자동 만지지 않도록 구성한다.

## 5. 단계와 종료 게이트

| 단계 | 작업 | 산출물의 성격 | 다음 단계 조건 |
|---|---|---|---|
| 전면 감사 | W00~W11 | 실제 파일·구성·동작·타입·위험·미확인 근거 | 전체 조사 상태와 중요 경계가 드러남 |
| 설계 선택 | W12 | 후보 반증·질문 답변·승인 범위 | 중대 질문 해결 또는 범위 제외 |
| 기반 재작성 | W13~W20 | docs/타입/코덱/구성/runtime/Fake | 명세·반례·의존성 검사 |
| 모델 연결 | W21~W25 | 실제 binding·Host·승인 계약 HIL | 대상 profile별 근거 |
| 평가·운영성 | W26~W30 | 서비스·Item·HIL·상태·CI | 평가 의미·관찰/한계 검증 |
| 확장 검증 | W31~W34 | 선택 분석 도구·LLM·업데이트·기능 확대 | 필요/불필요 및 실제 결과 구분 |
| 운영·인계 | W35~W36 | 배포/복구·지원범위·소유권 | 명시적 운영 승인 |

W31은 조건부이며 선택하지 않아도 된다. 다만 고위험 분석 공백이 남으면 다른 검증으로 해결하거나 해당 기능을 지원 범위에서 제외해야 한다. HIL Work가 막혀도 관련 없는 Host 작업은 승인된 범위에서 계속할 수 있다.

## 6. 작업 목록


| ID | 작업 | 선행 | 모드 |
|---|---|---|---|
| [W00](#work-w00) | 권한·Git·원본 기준선과 신규 작업 공간 확정 | 없음 | OFFLINE_NO_HARDWARE |
| [W01](#work-w01) | 전체 파일 분류·역할·생성 경로와 분석 분모 확정 | W00 | OFFLINE_NO_HARDWARE |
| [W02](#work-w02) | 모델·세부타입·폼팩터 매크로와 유효 구성 복원 | W01 | OFFLINE_NO_HARDWARE |
| [W03](#work-w03) | 실제 GCC TU·ABI·링크·엔트리·런타임 복원 | W02 | OFFLINE_APPROVED_BUILD_ONLY |
| [W04](#work-w04) | 모든 API·함수의 의미·호출·상태 효과 상세 분석 | W03 | OFFLINE_NO_HARDWARE |
| [W05](#work-w05) | 전역·지역 변수·타입·상수·메모리와 산술 위험 감사 | W03 | OFFLINE_NO_HARDWARE |
| [W06](#work-w06) | Git 계보·Vendor 대비 변경·평가 의도와 폐기 대상 복원 | W04, W05 | OFFLINE_NO_HARDWARE |
| [W07](#work-w07) | NVMe·PCIe 규격 profile과 장비 지원 한계 감사 | W02, W04, W05 | OFFLINE_NO_HARDWARE |
| [W08](#work-w08) | SSD 내부 command dialect·FW·권한·부작용 감사 | W04, W05, W06 | OFFLINE_NO_HARDWARE |
| [W09](#work-w09) | UART·분석 로그·port route·세션 의미 감사 | W04, W05 | OFFLINE_NO_HARDWARE |
| [W10](#work-w10) | Chamber·PSU·Fixture·공유 자원·시간/안전 감사 | W02, W04, W05, W09 | OFFLINE_NO_HARDWARE |
| [W11](#work-w11) | Vendor·혼합 코드 구성별 정적분석 기준선과 결함 검토 | W03, W04, W05 | OFFLINE_APPROVED_ANALYSIS_ONLY |
| [W12](#work-w12) | 전체 자료 재검토·질문 해결·아키텍처 선택 승인 | W06, W07, W08, W09, W10, W11 | OFFLINE_NO_HARDWARE |
| [W13](#work-w13) | Docs·코딩 표준·공개 계약·추적 스키마 기준선 | W12 | OFFLINE_NO_HARDWARE |
| [W14](#work-w14) | 새 Custom 트리·선택 빌드·의존성/Fake 경계 구축 | W13 | OFFLINE_APPROVED_BUILD_ONLY |
| [W15](#work-w15) | 타입·단위·checked arithmetic 기본 모듈 재작성 | W14 | OFFLINE_HOST_TESTS |
| [W16](#work-w16) | 표준 NVMe·PCIe builder/decoder와 필드 스키마 | W15, W07 | OFFLINE_HOST_TESTS |
| [W17](#work-w17) | Private command typed codec·FW/dialect 선택 규칙 | W15, W08, W13 | OFFLINE_HOST_TESTS |
| [W18](#work-w18) | UART framing·세션 분류·offline replay 핵심 구현 | W15, W09, W13 | OFFLINE_HOST_TESTS |
| [W19](#work-w19) | 다축 호환성·Capability·한계 resolver 구현 | W13, W14, W07, W08, W10 | OFFLINE_HOST_TESTS |
| [W20](#work-w20) | 요청·버퍼·세션·자원 runtime과 Fake 최소 관측 | W14, W15, W19 | OFFLINE_HOST_TESTS |
| [W21](#work-w21) | 첫 장비 Provider와 필수 runtime 경계 신규 구현 | W16, W19, W20 | OFFLINE_APPROVED_BUILD_ONLY |
| [W22](#work-w22) | 나머지 모델·세부타입·폼팩터 공통성 조기 검증 | W21 | OFFLINE_APPROVED_BUILD_ONLY |
| [W23](#work-w23) | UART 실제 Provider·단일 수신·명령/로그 연결 | W17, W18, W20, W22 | OFFLINE_APPROVED_BUILD_ONLY |
| [W24](#work-w24) | PCIe·Chamber·PSU·공유 자원 Provider와 정리 정책 | W20, W22, W10 | OFFLINE_APPROVED_BUILD_ONLY |
| [W25](#work-w25) | 승인된 최소 실장비 계약 검증 | W23, W24 | APPROVED_HARDWARE_ONLY |
| [W26](#work-w26) | 평가 판정·데이터 무결성·재사용 서비스 신규 구현 | W16, W17, W20, W19 | OFFLINE_HOST_TESTS |
| [W27](#work-w27) | 대표 다영역 Test Item의 완전 신규 구현과 offline 검증 | W26, W23, W24 | OFFLINE_HOST_TESTS |
| [W28](#work-w28) | 대표 Item의 장비별 HIL·비동등성·관측 검증 | W25, W27 | APPROVED_HARDWARE_ONLY |
| [W29](#work-w29) | 평가 현황·로그 저장·LLM 상태 조회와 재분석 강화 | W20, W23, W27 | OFFLINE_HOST_TESTS |
| [W30](#work-w30) | 정적·문서·명명·구성 matrix CI 게이트 통합 | W22, W27, W29 | OFFLINE_APPROVED_ANALYSIS_ONLY |
| [W31](#work-w31) | 조건부: 사내 분석 도구 확장 필요성과 최소 구현 | W11, W30 | OFFLINE_HOST_TESTS |
| [W32](#work-w32) | LLM Item 추가·수정·재조합 실증과 규칙 검출 | W13, W27, W29, W30 | OFFLINE_HOST_TESTS |
| [W33](#work-w33) | SDK·세부타입·폼팩터·dialect 변경 대응 리허설 | W22, W30, W32 | OFFLINE_WITH_SEPARATELY_APPROVED_HIL |
| [W34](#work-w34) | 선정 전체 기능·Item의 신규 구현 배치 확대 | W28, W30, W32 | OFFLINE_WITH_SEPARATELY_APPROVED_HIL |
| [W35](#work-w35) | 운영 배포·quiescence·복구·보관·신규 코드 전환 | W33, W34, W29 | APPROVED_DEPLOYMENT_AND_HARDWARE_ONLY |
| [W36](#work-w36) | 최종 지원범위 감사·완료 인수인계·후속 소유권 | W35, W32 | OFFLINE_NO_HARDWARE |

<a id="work-w00"></a>

## W00 — 권한·Git·원본 기준선과 신규 작업 공간 확정

**선행:** 없음 · **책임 역할:** 통합 책임자/자료 소유자 · **실행 범위:** `OFFLINE_NO_HARDWARE` · **초기 상태:** NOT_STARTED

### 입력과 제공 산출물

**입력:** 제공된 모델별 Vendor 원본/현재 혼합 코드 루트; 읽기·문서 생성·빌드·장비 실행 권한의 실제 범위

**작성할 산출물/경로 후보:** `analysis/source_manifest.json`, `analysis/access_policy.md`, `analysis/git_baselines.json`, `analysis/source_hashes.json`, `analysis/work_binding/W00.md`. 실제 수정 대상과 소비/제공 인터페이스는 Work binding에 확정한다.

### 세부 실행 단계

- [ ] **W00.01** 허용된 루트와 자료 소유자·보안등급·산출물 경로를 목록화한다. ⇒ 미제공/접근불가를 빈 폴더와 구별한다.
- [ ] **W00.02** 각 Git 저장소의 commit/branch/dirty 상태와 사용자 기존 변경을 읽기 방식으로 기록한다. ⇒ 자동 reset/clean/stage/commit을 수행하지 않는다.
- [ ] **W00.03** Vendor 수령 원본과 mixed 작업본을 구분하고 파일/아카이브 해시와 릴리스 계보 확실성을 기록한다. ⇒ 원본 대응 불명도 명시 상태로 남긴다.
- [ ] **W00.04** tracked/untracked/ignored/generated/외부 SDK/submodule 입력을 조사할 범위를 합의한다. ⇒ 비밀 파일/권한 밖 경로를 자동 탐색하지 않는다.
- [ ] **W00.05** 신규 analysis/docs 영역을 분리하고 build script 실행 여부를 검토한다. ⇒ 기본 모드는 offline_no_hardware, 네트워크·장치 접근 불허다.
- [ ] **W00.06** 정본 인계 경로와 상태 보고 양식을 작성하고 원본 해시를 다시 비교한다. ⇒ 변형 없음 또는 원래 dirty였던 범위가 명확하다.

### 검사와 완료 판단

1. 원본·mixed·신규 output이 식별된다.
2. 모든 제공 모델이 source manifest에 있고 unknown release가 성공으로 채워지지 않는다.
3. 사용자 기존 수정/자료가 손상되지 않았다.

**반례 확인:** 위 단계에서 지정한 실패/unknown/불가 조건이 예상 상태로 검출되는지 검증한다. 성공 사례만으로 종료하지 않는다.

**증거:** 이 Work의 실제 source/profile/tool hash, 실행 command/exit/result, 검토자, 누락/미실행을 verification record에 남긴다. 문서 검토만이면 실행 성공으로 표기하지 않는다.

### 차단과 문의

자료 경로·접근권한을 모르면 읽기 범위 확인부터 요청한다. 빌드/장비 실행 권한은 코드 열람 권한으로 추정하지 않는다. 해결되지 않은 사항은 질문 ID와 영향을 받는 step에 연결하고 담당자의 답변/근거를 기록한다. 독립적으로 수행 가능한 step만 계속한다.

<a id="work-w01"></a>

## W01 — 전체 파일 분류·역할·생성 경로와 분석 분모 확정

**선행:** W00 · **책임 역할:** 소스 조사 담당 · **실행 범위:** `OFFLINE_NO_HARDWARE` · **초기 상태:** NOT_STARTED

### 입력과 제공 산출물

**입력:** source manifest와 Git 상태; 원본/mixed 파일 트리·build scripts

**작성할 산출물/경로 후보:** `analysis/files.jsonl`, `analysis/file_review_index.md`, `analysis/generated_inputs.json`, `analysis/coverage_scope.json`. 실제 수정 대상과 소비/제공 인터페이스는 Work binding에 확정한다.

### 세부 실행 단계

- [ ] **W01.01** 모든 허용 파일에 안정적 file ID, 상대경로, 해시, 원본/mixed/SDK/generated 분류를 부여한다. ⇒ 같은 파일명도 서로 다른 모델/경로로 구별한다.
- [ ] **W01.02** C/header/build/linker/script/config/binary/log/spec 파일 유형을 분류한다. ⇒ binary-only 자료도 목록에서 사라지지 않는다.
- [ ] **W01.03** 각 코드파일의 책임, 공개/정적 심볼, include 의존, 조건부 영역, 등록 기능을 첫 검토한다. ⇒ 파일별 설명과 상태를 남긴다.
- [ ] **W01.04** 생성 C/header의 generator·입력·생성 순서를 추적한다. ⇒ 산출물이 없거나 생성이 실패한 경우 기록한다.
- [ ] **W01.05** 제외/미사용/중복 후보 파일에 이유와 근거를 붙인다. ⇒ 이름만 보고 삭제하지 않는다.
- [ ] **W01.06** 파일 단위 조사 coverage와 미분류/미접근 목록을 계산한다. ⇒ 전체 제공 파일 분모와 후속 담당 Work가 연결된다.

### 검사와 완료 판단

1. 파일 수·분류합·예외가 일치한다.
2. 모든 C/header/build 파일에 책임/상태가 있다.
3. 생성/외부 코드 누락이 숨겨지지 않는다.

**반례 확인:** 위 단계에서 지정한 실패/unknown/불가 조건이 예상 상태로 검출되는지 검증한다. 성공 사례만으로 종료하지 않는다.

**증거:** 이 Work의 실제 source/profile/tool hash, 실행 command/exit/result, 검토자, 누락/미실행을 verification record에 남긴다. 문서 검토만이면 실행 성공으로 표기하지 않는다.

### 차단과 문의

접근불가·암호화·깨진 파일은 source owner에게 자료 확인한다. 해결되지 않은 사항은 질문 ID와 영향을 받는 step에 연결하고 담당자의 답변/근거를 기록한다. 독립적으로 수행 가능한 step만 계속한다.

<a id="work-w02"></a>

## W02 — 모델·세부타입·폼팩터 매크로와 유효 구성 복원

**선행:** W01 · **책임 역할:** 구성/빌드 담당 · **실행 범위:** `OFFLINE_NO_HARDWARE` · **초기 상태:** NOT_STARTED

### 입력과 제공 산출물

**입력:** 전체 파일 inventory; model/subtype/form-factor 관련 조건부 코드·설정

**작성할 산출물/경로 후보:** `analysis/macro_inventory.jsonl`, `analysis/variant_axes.yaml`, `analysis/valid_configurations.yaml`, `analysis/presence_conditions.jsonl`, `analysis/macro_disposition.md`. 실제 수정 대상과 소비/제공 인터페이스는 Work binding에 확정한다.

### 세부 실행 단계

- [ ] **W02.01** define/undef/ifdef/if/elif 및 command-line/강제 include 입력을 수집한다. ⇒ 문자열·함수형·토큰 연결 매크로도 종류를 기록한다.
- [ ] **W02.02** 모델·92k-a/92k-b 같은 subtype·form factor·SDK/FW·디버그·규격 한계 축을 분리한다. ⇒ 실제 값이 제공되지 않으면 UNKNOWN으로 둔다.
- [ ] **W02.03** 각 분기의 포함 파일/심볼/타입/메모리/시퀀스를 연결하고 중첩 presence condition을 보존한다. ⇒ inactive branch도 존재 목록에 남긴다.
- [ ] **W02.04** 알려진 실제 운영/빌드 조합과 금지/불가능/미확인 조합을 분리한다. ⇒ 모든 매크로를 동시에 켜는 분석 구성을 만들지 않는다.
- [ ] **W02.05** 각 macro를 ABI/source-select/profile/capability/policy/debug/quirk/unresolved로 분류한다. ⇒ 상한 숫자의 의미와 owner를 추적한다.
- [ ] **W02.06** 유효 조합 표와 누락 질문을 검토한다. ⇒ defined-zero와 undefined의 차이를 반례로 문서화한다.

### 검사와 완료 판단

1. 조건부 구성 누락/충돌이 드러난다.
2. profile 축이 모델 문자열 하나로 합쳐지지 않는다.
3. 원본 매크로의 유지·이동·폐기·미확정 후보가 연결된다.

**반례 확인:** 위 단계에서 지정한 실패/unknown/불가 조건이 예상 상태로 검출되는지 검증한다. 성공 사례만으로 종료하지 않는다.

**증거:** 이 Work의 실제 source/profile/tool hash, 실행 command/exit/result, 검토자, 누락/미실행을 verification record에 남긴다. 문서 검토만이면 실행 성공으로 표기하지 않는다.

### 차단과 문의

운영 조합을 알 수 없으면 장비/평가 담당자에게 실제 지원 목록을 확인한다. 해결되지 않은 사항은 질문 ID와 영향을 받는 step에 연결하고 담당자의 답변/근거를 기록한다. 독립적으로 수행 가능한 step만 계속한다.

<a id="work-w03"></a>

## W03 — 실제 GCC TU·ABI·링크·엔트리·런타임 복원

**선행:** W02 · **책임 역할:** 빌드/ABI 담당 · **실행 범위:** `OFFLINE_APPROVED_BUILD_ONLY` · **초기 상태:** NOT_STARTED

### 입력과 제공 산출물

**입력:** 유효 구성·build scripts; SDK header/library/linker scripts·툴체인 정보

**작성할 산출물/경로 후보:** `analysis/build_profiles/`, `analysis/compile_databases/`, `analysis/entrypoint_map.md`, `analysis/abi_matrix.yaml`, `analysis/build_failures.md`. 실제 수정 대상과 소비/제공 인터페이스는 Work binding에 확정한다.

### 세부 실행 단계

- [ ] **W03.01** 누가 main/Item 등록/콜백/종료를 소유하는지 source와 link entry에서 추적한다. ⇒ standalone을 가정하지 않는다.
- [ ] **W03.02** 각 구성의 GCC target/version·C mode·include 순서·flags·packing·linker·생성 입력을 기록한다. ⇒ host ABI로 대체하지 않는다.
- [ ] **W03.03** 스크립트의 네트워크/장비/외부 실행 위험을 먼저 읽고 승인된 빌드 전용 환경에서만 명령을 수집한다. ⇒ build permission을 명시한다.
- [ ] **W03.04** CMake export 또는 기존 build 수집 방식으로 TU별 명령과 effective macro를 확보한다. ⇒ 실패·unsupported 옵션은 별도 보고한다.
- [ ] **W03.05** archive/object/source-set과 동명 심볼·등록 section·필수 runtime·동시성 진입을 조사한다. ⇒ 포함과 실행 참조를 구분한다.
- [ ] **W03.06** 모델/subtype/ABI마다 다른 해석 문맥을 저장하고 분석 도구 변환 가정의 diff를 남긴다. ⇒ 생산 flags를 분석 편의로 고치지 않는다.

### 검사와 완료 판단

1. 각 known configuration의 TU/entry 또는 미확보 원인이 있다.
2. 동일 C 파일의 다중 flags를 별개로 다룬다.
3. Vendor required-runtime 후보와 readable-helper 경계가 구별된다.

**반례 확인:** 위 단계에서 지정한 실패/unknown/불가 조건이 예상 상태로 검출되는지 검증한다. 성공 사례만으로 종료하지 않는다.

**증거:** 이 Work의 실제 source/profile/tool hash, 실행 command/exit/result, 검토자, 누락/미실행을 verification record에 남긴다. 문서 검토만이면 실행 성공으로 표기하지 않는다.

### 차단과 문의

툴체인/SDK 누락은 source owner에게 요청한다. build가 장비에 연결될 수 있으면 실행을 차단하고 offline 대안을 선택한다. 해결되지 않은 사항은 질문 ID와 영향을 받는 step에 연결하고 담당자의 답변/근거를 기록한다. 독립적으로 수행 가능한 step만 계속한다.

<a id="work-w04"></a>

## W04 — 모든 API·함수의 의미·호출·상태 효과 상세 분석

**선행:** W03 · **책임 역할:** API/동작 분석 담당 · **실행 범위:** `OFFLINE_NO_HARDWARE` · **초기 상태:** NOT_STARTED

### 입력과 제공 산출물

**입력:** 파일·심볼 후보; 실제 compile context·매뉴얼·원본/mixed 함수 정의

**작성할 산출물/경로 후보:** `analysis/functions.jsonl`, `analysis/call_edges.jsonl`, `analysis/function_contracts/`, `analysis/boundary_registry.yaml`, `analysis/unresolved_calls.yaml`. 실제 수정 대상과 소비/제공 인터페이스는 Work binding에 확정한다.

### 세부 실행 단계

- [ ] **W04.01** 공개/정적/inline/매크로 함수·callback·등록 함수를 scope/profile별로 추출한다. ⇒ 동일 이름을 단일 API로 합치지 않는다.
- [ ] **W04.02** 각 함수의 선언/정의·인자·return·unit·pointer/length·caller/callee를 연결한다. ⇒ indirect call은 후보/미해결로 구별한다.
- [ ] **W04.03** 함수별 목적·전제/후조건·global/memory/resource 효과·오류·완료·시간·재진입을 읽고 명세한다. ⇒ 설명과 source 충돌을 기록한다.
- [ ] **W04.04** opaque primitive/required ABI/runtime/readable helper/vendor Item/utility/unresolved로 분류한다. ⇒ 필수성 근거 없는 allowlist 승격을 금지한다.
- [ ] **W04.05** 사용·고위험 함수 의존 경로의 상세 계약 누락을 찾고 함수마다 검토 상태를 부여한다. ⇒ opaque 내부는 명세 가능 경계와 불가 영역을 분리한다.
- [ ] **W04.06** 모델간 기능 대응표를 입력 의미·효과·완료·실패 후 상태 기준으로 검토한다. ⇒ 이름 유사성만으로 동등 판정하지 않는다.

### 검사와 완료 판단

1. 전체 함수 inventory와 semantic review 상태가 존재한다.
2. 실제 호출 가능한 high-risk 경로에 미확인 계약이 blocker로 연결된다.
3. 필수 Vendor 실행 경계와 참고 상위 코드가 분리된다.

**반례 확인:** 위 단계에서 지정한 실패/unknown/불가 조건이 예상 상태로 검출되는지 검증한다. 성공 사례만으로 종료하지 않는다.

**증거:** 이 Work의 실제 source/profile/tool hash, 실행 command/exit/result, 검토자, 누락/미실행을 verification record에 남긴다. 문서 검토만이면 실행 성공으로 표기하지 않는다.

### 차단과 문의

비공개 함수 완료/소유권이 불명확하면 SDK 담당/장비사에게 확인한다. 해결되지 않은 사항은 질문 ID와 영향을 받는 step에 연결하고 담당자의 답변/근거를 기록한다. 독립적으로 수행 가능한 step만 계속한다.

<a id="work-w05"></a>

## W05 — 전역·지역 변수·타입·상수·메모리와 산술 위험 감사

**선행:** W03 · **책임 역할:** 타입/메모리 안전 담당 · **실행 범위:** `OFFLINE_NO_HARDWARE` · **초기 상태:** NOT_STARTED

### 입력과 제공 산출물

**입력:** GCC ABI/프로필; 전체 선언·참조·메모리 API·수치 계산 코드

**작성할 산출물/경로 후보:** `analysis/variables.jsonl`, `analysis/types_constants.jsonl`, `analysis/memory_regions.yaml`, `analysis/numeric_ranges.yaml`, `analysis/type_and_memory_findings.jsonl`. 실제 수정 대상과 소비/제공 인터페이스는 Work binding에 확정한다.

### 세부 실행 단계

- [ ] **W05.01** 전역/정적/인자/지역/필드/enum/typedef/macro를 scope/profile별로 추출한다. ⇒ 선언 타입과 effective type을 구별한다.
- [ ] **W05.02** 초기화·읽기/쓰기·주소 escape·별칭·callback 참조·수명을 연결한다. ⇒ alias 미해결을 없음으로 처리하지 않는다.
- [ ] **W05.03** 길이/count/LBA/time/전압/온도/status/address 변수의 의미·단위·가능 범위를 복원한다. ⇒ unknown range는 질문으로 남긴다.
- [ ] **W05.04** 산술 승격·narrowing·signedness·shift·count-1·offset+length·곱셈·format을 검토한다. ⇒ 오류 후보에 최소 조건과 사용처를 기록한다.
- [ ] **W05.05** MMIO/DMA/shared RAM/heap/stack을 분리하고 owner·정렬·safe release·Reset/coherency를 명세한다. ⇒ 정수 주소와 CPU pointer를 혼동하지 않는다.
- [ ] **W05.06** ABI 보존 영역과 새 Custom 타입 후보를 나누고 독립 반례/검증 계획을 작성한다. ⇒ 변수명만 바꾸어 해결로 표시하지 않는다.

### 검사와 완료 판단

1. local 변수까지 포함한 분모와 고위험 상세 계약이 존재한다.
2. overflow/underflow 후보마다 실제 타입/구성/영향 근거가 있다.
3. 모든 접근 memory region이 owner/unknown 상태를 가진다.

**반례 확인:** 위 단계에서 지정한 실패/unknown/불가 조건이 예상 상태로 검출되는지 검증한다. 성공 사례만으로 종료하지 않는다.

**증거:** 이 Work의 실제 source/profile/tool hash, 실행 command/exit/result, 검토자, 누락/미실행을 verification record에 남긴다. 문서 검토만이면 실행 성공으로 표기하지 않는다.

### 차단과 문의

HW memory와 lifetime 의미는 source만으로 부족하면 매뉴얼/장비 담당 확인한다. 해결되지 않은 사항은 질문 ID와 영향을 받는 step에 연결하고 담당자의 답변/근거를 기록한다. 독립적으로 수행 가능한 step만 계속한다.

<a id="work-w06"></a>

## W06 — Git 계보·Vendor 대비 변경·평가 의도와 폐기 대상 복원

**선행:** W04, W05 · **책임 역할:** 평가 도메인/계보 담당 · **실행 범위:** `OFFLINE_NO_HARDWARE` · **초기 상태:** NOT_STARTED

### 입력과 제공 산출물

**입력:** 원본/mixed Git 기준선; 함수/변수/파일 분석·실제 운영 Item 목록

**작성할 산출물/경로 후보:** `analysis/lineage_map.md`, `analysis/custom_delta.yaml`, `analysis/evaluation_intent_catalog.yaml`, `analysis/rewrite_disposition.yaml`. 실제 수정 대상과 소비/제공 인터페이스는 Work binding에 확정한다.

### 세부 실행 단계

- [ ] **W06.01** 원본 release와 mixed 기반 commit 대응을 확인하고 확정/추정 계보를 분리한다. ⇒ 모든 diff를 사내 수정으로 간주하지 않는다.
- [ ] **W06.02** 텍스트/함수/타입/매크로/호출·상태 변경을 대응시킨다. ⇒ 코드 이동과 의미 변경을 별도 표시한다.
- [ ] **W06.03** Git log/blame/이슈/운영 자료에서 변경 이유를 복원하되 source of intent를 구분한다. ⇒ commit message만으로 안전성/정확성을 승인하지 않는다.
- [ ] **W06.04** 각 Item의 평가 목적·순서·조건·관측·판정·자원을 명세하고 실제 구현과 비교한다. ⇒ 기존 동작을 정답으로 자동 고정하지 않는다.
- [ ] **W06.05** 각 기능을 retain-intent/rewrite-fix/redesign-policy/retire/unsupported/blocked로 제안한다. ⇒ 기존 파일 구조/함수명 호환은 요구하지 않는다.
- [ ] **W06.06** 평가 책임자 확인이 필요한 정책/의도 충돌을 질문 카드에 연결한다. ⇒ 신규 구현으로 이전할 승인 목표의 후보가 남는다.

### 검사와 완료 판단

1. 기능/Item별 전면 재작성 disposition과 근거가 있다.
2. 기존 결함을 golden oracle로 고정하지 않는다.
3. 보존 snapshot과 신규 runtime 의존성이 구별된다.

**반례 확인:** 위 단계에서 지정한 실패/unknown/불가 조건이 예상 상태로 검출되는지 검증한다. 성공 사례만으로 종료하지 않는다.

**증거:** 이 Work의 실제 source/profile/tool hash, 실행 command/exit/result, 검토자, 누락/미실행을 verification record에 남긴다. 문서 검토만이면 실행 성공으로 표기하지 않는다.

### 차단과 문의

필요 Item/폐기 여부·판정 기준은 실제 소유자 확인이 필요하다. 해결되지 않은 사항은 질문 ID와 영향을 받는 step에 연결하고 담당자의 답변/근거를 기록한다. 독립적으로 수행 가능한 step만 계속한다.

<a id="work-w07"></a>

## W07 — NVMe·PCIe 규격 profile과 장비 지원 한계 감사

**선행:** W02, W04, W05 · **책임 역할:** 프로토콜/계측 담당 · **실행 범위:** `OFFLINE_NO_HARDWARE` · **초기 상태:** NOT_STARTED

### 입력과 제공 산출물

**입력:** 승인 규격/ECN 자료; 장비 macro·API·DUT 지원자료·command 호출

**작성할 산출물/경로 후보:** `specs/standard_profiles.yaml`, `analysis/protocol_field_inventory.jsonl`, `analysis/declared_verified_limits.yaml`, `analysis/raw_fidelity_matrix.yaml`. 실제 수정 대상과 소비/제공 인터페이스는 Work binding에 확정한다.

### 세부 실행 단계

- [ ] **W07.01** 적용 표준 문서·revision·command set/transport·사용권을 목록화한다. ⇒ 공개 최신 버전으로 자동 대체하지 않는다.
- [ ] **W07.02** 현재 사용하는 command/field/log/feature/PCIe access를 실제 호출과 연결한다. ⇒ unused 표준 전체를 구현 필수로 만들지 않는다.
- [ ] **W07.03** SDK 매크로·버퍼·API에서 command/size/queue/field 지원 한계를 추출한다. ⇒ declared와 verified를 분리한다.
- [ ] **W07.04** caller controlled/SDK rewritten/observed field와 CQE coverage·auto retry/split을 명세한다. ⇒ raw라는 이름만으로 bit-exact라고 주장하지 않는다.
- [ ] **W07.05** wire/ABI/decoded/semantic 타입을 구분하고 각 field의 source/validity/unknown 처리를 설계 후보로 정리한다. ⇒ 실제 offset은 승인 자료에서 확인한다.
- [ ] **W07.06** 필요 기능/관측 수준을 장비·DUT·Fixture와 비교해 제한과 문의를 기록한다. ⇒ DUT negative-response 시험을 단순 미지원 차단과 혼동하지 않는다.

### 검사와 완료 판단

1. version 숫자 하나가 아닌 operation별 지원/한계가 존재한다.
2. 규격 field 근거와 장비 능력 근거가 분리된다.
3. 관측 불가능 bit를 0으로 생성하지 않는다.

**반례 확인:** 위 단계에서 지정한 실패/unknown/불가 조건이 예상 상태로 검출되는지 검증한다. 성공 사례만으로 종료하지 않는다.

**증거:** 이 Work의 실제 source/profile/tool hash, 실행 command/exit/result, 검토자, 누락/미실행을 verification record에 남긴다. 문서 검토만이면 실행 성공으로 표기하지 않는다.

### 차단과 문의

규격 해석/SDK field rewrite 충돌은 관련 규격·장비 담당 확인한다. 해결되지 않은 사항은 질문 ID와 영향을 받는 step에 연결하고 담당자의 답변/근거를 기록한다. 독립적으로 수행 가능한 step만 계속한다.

<a id="work-w08"></a>

## W08 — SSD 내부 command dialect·FW·권한·부작용 감사

**선행:** W04, W05, W06 · **책임 역할:** SSD FW/내부 명령 담당 · **실행 범위:** `OFFLINE_NO_HARDWARE` · **초기 상태:** NOT_STARTED

### 입력과 제공 산출물

**입력:** 사내 명령 문서/소스/운영 근거; DUT FW/제품 대응·권한 정책

**작성할 산출물/경로 후보:** `specs/private/dialect_registry.yaml`, `analysis/private_commands.jsonl`, `analysis/private_fw_compatibility.yaml`, `analysis/private_command_questions.md`. 실제 수정 대상과 소비/제공 인터페이스는 Work binding에 확정한다.

### 세부 실행 단계

- [ ] **W08.01** 내부 명령을 transport/opcode/subcommand/namespace로 inventory화한다. ⇒ 표준 command와 섞인 부분을 표시한다.
- [ ] **W08.02** 소유 조직·정본 문서·revision·FW 대응과 실제 선택 방식을 확인한다. ⇒ command ID 숫자만으로 의미를 합치지 않는다.
- [ ] **W08.03** payload 구조/길이/단위/return/필수 state·영속 변화·timeout/retry를 상세 명세한다. ⇒ 비밀값은 참조만 남긴다.
- [ ] **W08.04** 장비의 전달/차단/재작성 한계와 UART/NVMe 공용 내부 상태를 조사한다. ⇒ 전송 가능이 안전 실행 가능을 의미하지 않는다.
- [ ] **W08.05** typed module/schema/opaque envelope 후보를 비교하고 코덱 범위를 나눈다. ⇒ 알려지지 않은 응답을 해석 완료로 표시하지 않는다.
- [ ] **W08.06** 잘못된 FW/dialect 선택의 결과와 차단 정책을 작성하고 미확인 내용을 내부 FW 담당자에게 질문한다. ⇒ 임의 unlock/opcode를 발명하지 않는다.

### 검사와 완료 판단

1. 모든 알려진 내부 command의 정본/적용/상태가 있다.
2. same opcode/different dialect가 분리된다.
3. 영속 효과/권한/재시도 불명 경로가 blocker로 남는다.

**반례 확인:** 위 단계에서 지정한 실패/unknown/불가 조건이 예상 상태로 검출되는지 검증한다. 성공 사례만으로 종료하지 않는다.

**증거:** 이 Work의 실제 source/profile/tool hash, 실행 command/exit/result, 검토자, 누락/미실행을 verification record에 남긴다. 문서 검토만이면 실행 성공으로 표기하지 않는다.

### 차단과 문의

사내 명령 정본·FW 호환·위험·사용권은 담당자 확인 전 확정 금지. 해결되지 않은 사항은 질문 ID와 영향을 받는 step에 연결하고 담당자의 답변/근거를 기록한다. 독립적으로 수행 가능한 step만 계속한다.

<a id="work-w09"></a>

## W09 — UART·분석 로그·port route·세션 의미 감사

**선행:** W04, W05 · **책임 역할:** UART/FW/로그 담당 · **실행 범위:** `OFFLINE_NO_HARDWARE` · **초기 상태:** NOT_STARTED

### 입력과 제공 산출물

**입력:** UART API/OS serial/bridge 관련 코드; 기존 raw logs·Fixture route·명령 dialect

**작성할 산출물/경로 후보:** `analysis/uart_endpoints.yaml`, `analysis/uart_protocols.yaml`, `analysis/uart_log_pipeline.md`, `analysis/clock_domains.yaml`. 실제 수정 대상과 소비/제공 인터페이스는 Work binding에 확정한다.

### 세부 실행 단계

- [ ] **W09.01** 실제 UART 접근 경로와 port/slot/DUT mapping, open/close/control-line 효과를 조사한다. ⇒ OS port 번호를 안정적 DUT ID로 가정하지 않는다.
- [ ] **W09.02** baud/framing/전기 레벨/flow control 자료를 찾고 source 추정과 장비 자료를 구분한다. ⇒ 미확인 수치를 임의 채우지 않는다.
- [ ] **W09.03** text/binary frame, delimiter/length/checksum/echo/prompt/unsolicited log를 분석한다. ⇒ 입력 로그를 실행 지시로 취급하지 않는다.
- [ ] **W09.04** partial read/write·timeout·flush·수신 thread/owner·동시 명령을 조사한다. ⇒ 명령과 logger가 같은 stream을 경쟁 소비하는지 찾는다.
- [ ] **W09.05** Reset/boot/reconnect 때 session epoch·late response·log loss·시각 출처를 명세한다. ⇒ host 수신 시각과 DUT 사건 시각을 구별한다.
- [ ] **W09.06** 포트·framing·session·trace 책임 후보와 필요한 Host corpus/HIL 질문을 정리한다. ⇒ 로그 손실의 판정 영향이 명시된다.

### 검사와 완료 판단

1. UART 명령/로그 책임과 실제 수신 소유권이 설명된다.
2. 분할 frame·echo/log interleave·재부팅 상황의 의미가 정리된다.
3. 배선/수치 미확인이 운영 기본값이 되지 않는다.

**반례 확인:** 위 단계에서 지정한 실패/unknown/불가 조건이 예상 상태로 검출되는지 검증한다. 성공 사례만으로 종료하지 않는다.

**증거:** 이 Work의 실제 source/profile/tool hash, 실행 command/exit/result, 검토자, 누락/미실행을 verification record에 남긴다. 문서 검토만이면 실행 성공으로 표기하지 않는다.

### 차단과 문의

Fixture/전기 조건·FW protocol 정본이 없으면 해당 담당에게 확인. 해결되지 않은 사항은 질문 ID와 영향을 받는 step에 연결하고 담당자의 답변/근거를 기록한다. 독립적으로 수행 가능한 step만 계속한다.

<a id="work-w10"></a>

## W10 — Chamber·PSU·Fixture·공유 자원·시간/안전 감사

**선행:** W02, W04, W05, W09 · **책임 역할:** 설비/자원/시험 안전 담당 · **실행 범위:** `OFFLINE_NO_HARDWARE` · **초기 상태:** NOT_STARTED

### 입력과 제공 산출물

**입력:** 제어 API/전역 상태/Item sequence; 장비/Fixture/안전 매뉴얼·센서/계측 자료

**작성할 산출물/경로 후보:** `profiles/resource_topology.yaml`, `analysis/environment_contracts.md`, `analysis/timing_requirements.yaml`, `analysis/safety_questions.md`. 실제 수정 대상과 소비/제공 인터페이스는 Work binding에 확정한다.

### 세부 실행 단계

- [ ] **W10.01** slot→rail/chamber/reset/UART/port의 실제 영향 범위를 지도화한다. ⇒ 모델·폼팩터만으로 독립성을 추정하지 않는다.
- [ ] **W10.02** setpoint/readback/stable/DUT sensor와 cache/stale/교정 상태를 구분한다. ⇒ 설정 성공을 물리 도달로 바꾸지 않는다.
- [ ] **W10.03** 전압/온도/전류/램프/보호·정리 절차를 승인 자료로 확인한다. ⇒ 이 문서의 일반 예제를 한계값으로 쓰지 않는다.
- [ ] **W10.04** SDK global slot·리소스 lease·동시 실행·lock order·callback 재진입을 추적한다. ⇒ 비동기 완료까지 필요한 소유권 범위를 찾는다.
- [ ] **W10.05** 호스트·장비·UART·계측 clock과 trigger/시퀀스 엔진의 시간 보장을 비교한다. ⇒ sleep 길이를 물리 timing으로 대체하지 않는다.
- [ ] **W10.06** 취소/오류/전원중단/Run 재개 때 필요한 조치와 담당자 질문을 작성한다. ⇒ 언제나 power-off가 안전하다는 가정을 금지한다.

### 검사와 완료 판단

1. 공유 자원 충돌·Reset 범위·폼팩터별 연결이 드러난다.
2. 안전 범위/cleanup의 근거와 미확인이 구별된다.
3. 타이밍 요구가 장비 능력과 비교된다.

**반례 확인:** 위 단계에서 지정한 실패/unknown/불가 조건이 예상 상태로 검출되는지 검증한다. 성공 사례만으로 종료하지 않는다.

**증거:** 이 Work의 실제 source/profile/tool hash, 실행 command/exit/result, 검토자, 누락/미실행을 verification record에 남긴다. 문서 검토만이면 실행 성공으로 표기하지 않는다.

### 차단과 문의

안전/배선/cleanup/관측 정확도는 자료와 담당자 확인 없으면 HIL 금지. 해결되지 않은 사항은 질문 ID와 영향을 받는 step에 연결하고 담당자의 답변/근거를 기록한다. 독립적으로 수행 가능한 step만 계속한다.

<a id="work-w11"></a>

## W11 — Vendor·혼합 코드 구성별 정적분석 기준선과 결함 검토

**선행:** W03, W04, W05 · **책임 역할:** 정적분석/품질 담당 · **실행 범위:** `OFFLINE_APPROVED_ANALYSIS_ONLY` · **초기 상태:** NOT_STARTED

### 입력과 제공 산출물

**입력:** 생산 GCC 프로필·source inventories; 실행 승인된 analyzer 후보·코딩/수치 위험 목록

**작성할 산출물/경로 후보:** `analysis/static_baseline/`, `analysis/findings.jsonl`, `analysis/analyzer_coverage.json`, `analysis/suppressions.yaml`, `analysis/critical_findings.md`. 실제 수정 대상과 소비/제공 인터페이스는 Work binding에 확정한다.

### 세부 실행 단계

- [ ] **W11.01** 도구/version/config/profile/실행 범위를 고정한다. ⇒ vendor/mixed 분석 결과를 분리한다.
- [ ] **W11.02** 승인된 offline 환경에서 GCC 경고/analyzer와 적합한 독립 도구를 실행한다. ⇒ 실제 명령·exit·raw 결과를 보존한다.
- [ ] **W11.03** parse/analysis 실패·unsupported flags·opaque 함수를 누락하지 않고 TU별 coverage를 계산한다. ⇒ 실패를 clean로 표시하지 않는다.
- [ ] **W11.04** 정수/메모리/상태/조건부 분기/ABI 고위험 findings를 source/최소 반례/도메인 계약으로 triage한다. ⇒ Vendor 원본을 고치거나 경고를 일괄 삭제하지 않는다.
- [ ] **W11.05** 확정 결함·의심·의도된 negative/wrap·오탐·분석 불가를 분류하고 보완/한계/업체 문의를 연결한다. ⇒ suppression은 좁은 근거/owner를 갖는다.
- [ ] **W11.06** 새 Custom에서 반드시 방지할 규칙과 도구 공백을 보고한다. ⇒ 도구 개발 필요성은 반복 공백 근거로 평가한다.

### 검사와 완료 판단

1. 모든 분석 결과에 구성·툴·실행 여부·분모가 있다.
2. critical finding의 영향/미확인이 architecture review에 전달된다.
3. 경고 0을 정확성/안전성 증명으로 보고하지 않는다.

**반례 확인:** 위 단계에서 지정한 실패/unknown/불가 조건이 예상 상태로 검출되는지 검증한다. 성공 사례만으로 종료하지 않는다.

**증거:** 이 Work의 실제 source/profile/tool hash, 실행 command/exit/result, 검토자, 누락/미실행을 verification record에 남긴다. 문서 검토만이면 실행 성공으로 표기하지 않는다.

### 차단과 문의

GCC 해석과 analyzer 차이로 고위험 경로 확인 불가 시 대체 검토/문의 필요. 해결되지 않은 사항은 질문 ID와 영향을 받는 step에 연결하고 담당자의 답변/근거를 기록한다. 독립적으로 수행 가능한 step만 계속한다.

<a id="work-w12"></a>

## W12 — 전체 자료 재검토·질문 해결·아키텍처 선택 승인

**선행:** W06, W07, W08, W09, W10, W11 · **책임 역할:** 아키텍트+관련 도메인 책임자 · **실행 범위:** `OFFLINE_NO_HARDWARE` · **초기 상태:** NOT_STARTED

### 입력과 제공 산출물

**입력:** 전체 감사 산출물·사용자 요구·이 외부 후보 문서; critical findings·unknowns·원본/혼합 코드 근거

**작성할 산출물/경로 후보:** `docs/adr/architecture_selection.md`, `docs/architecture/approved_scope.md`, `docs/questions/registry.yaml`, `docs/limitations/INDEX.md`, `docs/work/implementation_baseline.md`. 실제 수정 대상과 소비/제공 인터페이스는 Work binding에 확정한다.

### 세부 실행 단계

- [ ] **W12.01** 전체 파일/구성/함수/변수 검토 coverage와 누락을 검토한다. ⇒ 대표 Item만 읽은 결과를 전체 감사로 승격하지 않는다.
- [ ] **W12.02** 사용자 요구와 이 문서의 임시 선택을 구분하고 A~F/V1~V3를 실제 제약으로 반증한다. ⇒ 채택/기각/보류의 근거를 적는다.
- [ ] **W12.03** 중대한 unknown/conflict를 question 카드로 묶어 source owner/SDK/FW/설비/평가 담당자에게 문의한다. ⇒ 없는 답을 default로 채우지 않는다.
- [ ] **W12.04** 답변·근거·유효 profile·변경 영향과 미해결 제외 범위를 기록한다. ⇒ 막힌 경로와 독립 가능한 작업을 분리한다.
- [ ] **W12.05** 공통 계약·Provider 경계·variant resolution·docs 정본·타입·런타임·분석/검증 구조를 확정 가능한 범위에서 승인받는다. ⇒ 이 문서와 다른 선택도 허용한다.
- [ ] **W12.06** W13 이후를 실제 repo 경로/함수 서명/검사 명령/담당/수용 조건에 바인딩한다. ⇒ 승인 없는 큰 구현을 시작하지 않는다.

### 검사와 완료 판단

1. 설계를 뒤집을 질문이 해결되거나 해당 영역이 명시 제외됐다.
2. 최소 2개 실행 가능한 후보/탈락 이유와 최종 근거가 있다.
3. 새 구현/문서/테스트 경로와 권한 범위가 명확하다.

**반례 확인:** 위 단계에서 지정한 실패/unknown/불가 조건이 예상 상태로 검출되는지 검증한다. 성공 사례만으로 종료하지 않는다.

**증거:** 이 Work의 실제 source/profile/tool hash, 실행 command/exit/result, 검토자, 누락/미실행을 verification record에 남긴다. 문서 검토만이면 실행 성공으로 표기하지 않는다.

### 차단과 문의

설계 핵심 ABI/수명/내부 dialect/지원조합이 불명확하면 관련 구조 확정 보류. 해결되지 않은 사항은 질문 ID와 영향을 받는 step에 연결하고 담당자의 답변/근거를 기록한다. 독립적으로 수행 가능한 step만 계속한다.

<a id="work-w13"></a>

## W13 — Docs·코딩 표준·공개 계약·추적 스키마 기준선

**선행:** W12 · **책임 역할:** 공통 계약/문서 책임자 · **실행 범위:** `OFFLINE_NO_HARDWARE` · **초기 상태:** NOT_STARTED

### 입력과 제공 산출물

**입력:** 승인 아키텍처·질문 답변; C/GCC 제약·naming/type 요구

**작성할 산출물/경로 후보:** `docs/INDEX.md`, `AGENTS.md`, `docs/standards/`, `docs/contracts/`, `specs/registry_schema/`, `docs/work/command_registry.md`. 실제 수정 대상과 소비/제공 인터페이스는 Work binding에 확정한다.

### 세부 실행 단계

- [ ] **W13.01** 프로젝트 접두사·파일/함수/변수/타입/상수·단위·약어·코드 스타일을 결정한다. ⇒ 전체 Custom 적용/ABI 예외 범위를 명시한다.
- [ ] **W13.02** source facts/behavior contract/header/field schema/Item policy/run evidence의 정본 책임을 나눈다. ⇒ 같은 선언을 손으로 세 번 관리하지 않는다.
- [ ] **W13.03** 공개 port/type/error/verdict/수명 API를 실제 서명으로 확정하고 최소 의존 그래프를 정의한다. ⇒ Vendor 타입은 공개 계약에 누출하지 않는다.
- [ ] **W13.04** variant/dialect/UART/limitation/question/verification/Item 문서의 ID·revision·상태·근거 schema를 고정한다. ⇒ draft/null은 운영 사용 불가다.
- [ ] **W13.05** AGENTS 읽기 순서·변경 위험·검증/보고·권한을 연결하고 승인된 검사 명령 registry를 작성한다. ⇒ 없는 도구를 실행됐다고 하지 않는다.
- [ ] **W13.06** 문서 링크/ID·작은 양성/음성 fixture를 검토한다. ⇒ 규칙 변경과 waiver를 승인 이력으로 추적한다.

### 검사와 완료 판단

1. 이름·타입·단위·정본 충돌이 없다.
2. 질문/한계/Item이 profile·근거·검증으로 연결된다.
3. 모든 후속 Work의 contract ID가 실존 문서로 매핑된다.

**반례 확인:** 위 단계에서 지정한 실패/unknown/불가 조건이 예상 상태로 검출되는지 검증한다. 성공 사례만으로 종료하지 않는다.

**증거:** 이 Work의 실제 source/profile/tool hash, 실행 command/exit/result, 검토자, 누락/미실행을 verification record에 남긴다. 문서 검토만이면 실행 성공으로 표기하지 않는다.

### 차단과 문의

공통 계약·명명·언어 모드 변경은 단일 책임자 승인. 해결되지 않은 사항은 질문 ID와 영향을 받는 step에 연결하고 담당자의 답변/근거를 기록한다. 독립적으로 수행 가능한 step만 계속한다.

<a id="work-w14"></a>

## W14 — 새 Custom 트리·선택 빌드·의존성/Fake 경계 구축

**선행:** W13 · **책임 역할:** 빌드/경계 담당 · **실행 범위:** `OFFLINE_APPROVED_BUILD_ONLY` · **초기 상태:** NOT_STARTED

### 입력과 제공 산출물

**입력:** 승인 build/variant profile·계약 헤더; 실제 SDK/엔트리 제약

**작성할 산출물/경로 후보:** `신규 custom 루트와 CMake/Make target`, `providers/fake/`, `실제 build presets/profiles`, `tests/architecture/`. 실제 수정 대상과 소비/제공 인터페이스는 Work binding에 확정한다.

### 세부 실행 단계

- [ ] **W14.01** 기존 운영/원본을 수정하지 않는 새 Custom 루트를 만든다. ⇒ source reference만 연결하고 legacy runtime을 링크하지 않는다.
- [ ] **W14.02** 공통/Provider/Platform/entry target과 PRIVATE SDK include/flags를 구성한다. ⇒ 모델별 source-set을 명시한다.
- [ ] **W14.03** profile ID로 family/subtype/SDK/ABI/폼팩터 관련 빌드 조건을 검사한다. ⇒ unknown/충돌 profile이 configure 실패한다.
- [ ] **W14.04** Fake-only target과 host test runner를 연결한다. ⇒ 실제 SDK/장치 접근이 기본 target에 없다.
- [ ] **W14.05** 금지 include/Vendor 상위 호출/미선택 SDK를 검출하는 최소 체크와 양성·음성 fixture를 만든다. ⇒ 검사 자체가 오염 예제를 검출한다.
- [ ] **W14.06** 승인된 profile별 compile/link manifest와 별도 output tree를 생성한다. ⇒ 분석 DB와 build 입력이 일치한다.

### 검사와 완료 판단

1. 정상 Fake build 성공, 잘못된 profile 실패.
2. 다른 모델 SDK/link input이 제외됨.
3. 공통 코드의 Vendor dependency 오염 fixture가 실패.

**반례 확인:** 위 단계에서 지정한 실패/unknown/불가 조건이 예상 상태로 검출되는지 검증한다. 성공 사례만으로 종료하지 않는다.

**증거:** 이 Work의 실제 source/profile/tool hash, 실행 command/exit/result, 검토자, 누락/미실행을 verification record에 남긴다. 문서 검토만이면 실행 성공으로 표기하지 않는다.

### 차단과 문의

actual build/entry 계약이 확인되어야 구현. 해결되지 않은 사항은 질문 ID와 영향을 받는 step에 연결하고 담당자의 답변/근거를 기록한다. 독립적으로 수행 가능한 step만 계속한다.

<a id="work-w15"></a>

## W15 — 타입·단위·checked arithmetic 기본 모듈 재작성

**선행:** W14 · **책임 역할:** 타입 안전 담당 · **실행 범위:** `OFFLINE_HOST_TESTS` · **초기 상태:** NOT_STARTED

### 입력과 제공 산출물

**입력:** W05 range findings·승인 타입 계약; 정적분석/Host test 환경

**작성할 산출물/경로 후보:** `modules/base/se_checked_arithmetic.c`, `modules/base/공개 타입·단위 헤더`, `tests/base/`, `docs/contracts/numeric_operations.md`. 실제 수정 대상과 소비/제공 인터페이스는 Work binding에 확정한다.

### 세부 실행 단계

- [ ] **W15.01** 필요한 checked add/sub/mul/narrow/단위 변환 범위를 고정한다. ⇒ 모든 수학을 새 프레임워크로 만들지 않는다.
- [ ] **W15.02** 0/최솟값/최댓값/경계±1/중간 타입/unsigned underflow 테스트를 먼저 작성하고 예상 실패를 확인한다. ⇒ 실패 원인이 환경인지 기능인지 구별한다.
- [ ] **W15.03** 지원 GCC builtin 또는 검토된 범위 검사로 구현하고 실패 후 output 계약을 지킨다. ⇒ overflow 값을 다음 단계에 쓰지 않는다.
- [ ] **W15.04** wire/size_t/주소 공간/물리 단위 사이 변환을 명시하고 캐스트로 경고를 숨기지 않는다. ⇒ 근거 없는 saturation 금지.
- [ ] **W15.05** 실제 GCC와 Host sanitizer/정수 검사 지원을 확인해 실행한다. ⇒ undefined 검사만으로 unsigned 검증 완료 주장 금지.
- [ ] **W15.06** 독립 기대값·분석 결과·32/64비트 적용 범위를 기록한다. ⇒ 미시험 타깃은 미시험으로 남긴다.

### 검사와 완료 판단

1. count*size/offset+length/count-1 경계 실패를 검출.
2. 실패 output 사용 금지와 단위 변환 rounding 확인.
3. 승인한 타입 범위에서 수치 계약을 만족.

**반례 확인:** 위 단계에서 지정한 실패/unknown/불가 조건이 예상 상태로 검출되는지 검증한다. 성공 사례만으로 종료하지 않는다.

**증거:** 이 Work의 실제 source/profile/tool hash, 실행 command/exit/result, 검토자, 누락/미실행을 verification record에 남긴다. 문서 검토만이면 실행 성공으로 표기하지 않는다.

### 차단과 문의

도메인 범위/rounding/정밀도 모호 시 계약 문의. 해결되지 않은 사항은 질문 ID와 영향을 받는 step에 연결하고 담당자의 답변/근거를 기록한다. 독립적으로 수행 가능한 step만 계속한다.

<a id="work-w16"></a>

## W16 — 표준 NVMe·PCIe builder/decoder와 필드 스키마

**선행:** W15, W07 · **책임 역할:** 표준 프로토콜 담당 · **실행 범위:** `OFFLINE_HOST_TESTS` · **초기 상태:** NOT_STARTED

### 입력과 제공 산출물

**입력:** 승인 표준 profile·사용 field 범위; 독립 raw vectors·numeric helpers

**작성할 산출물/경로 후보:** `modules/nvme/`, `modules/pcie/순수 encode-decode`, `specs/standard_fields/`, `tests/protocol/`. 실제 수정 대상과 소비/제공 인터페이스는 Work binding에 확정한다.

### 세부 실행 단계

- [ ] **W16.01** 첫 구현 field/command 집합과 적용 revision/validity를 명세한다. ⇒ offset/bit를 기억으로 채우지 않는다.
- [ ] **W16.02** 정상/짧은 버퍼/알 수 없는 개정/변수 길이/예약값 반례와 독립 vector를 먼저 작성한다. ⇒ 생성기와 같은 오류를 공유하지 않는다.
- [ ] **W16.03** byte/endian/bounds 기반 parser/builder를 작성한다. ⇒ Vendor ABI struct cast와 하드웨어 접근 금지.
- [ ] **W16.04** raw/decoded/semantic 모델과 present/unknown/unsupported/truncated 상태를 구현한다. ⇒ 누락을 0으로 유효 표시하지 않는다.
- [ ] **W16.05** PCIe capability walk의 범위/순환·register 부작용 의미 등 대상별 반례를 검증한다. ⇒ generic RMW로 모든 register를 처리하지 않는다.
- [ ] **W16.06** 단위·fuzz/정적·sanitizer 결과와 적용 범위를 남긴다. ⇒ HIL이나 전 규격 구현 완료로 보고하지 않는다.

### 검사와 완료 판단

1. 독립 byte vector와 경계/unknown 파싱이 일치.
2. builder가 실제 command 전송 없이 시험 가능.
3. schema와 구현·docs 연결 및 raw 보존.

**반례 확인:** 위 단계에서 지정한 실패/unknown/불가 조건이 예상 상태로 검출되는지 검증한다. 성공 사례만으로 종료하지 않는다.

**증거:** 이 Work의 실제 source/profile/tool hash, 실행 command/exit/result, 검토자, 누락/미실행을 verification record에 남긴다. 문서 검토만이면 실행 성공으로 표기하지 않는다.

### 차단과 문의

field 근거/개정 해석 미확정이면 해당 field 구현 보류. 해결되지 않은 사항은 질문 ID와 영향을 받는 step에 연결하고 담당자의 답변/근거를 기록한다. 독립적으로 수행 가능한 step만 계속한다.

<a id="work-w17"></a>

## W17 — Private command typed codec·FW/dialect 선택 규칙

**선행:** W15, W08, W13 · **책임 역할:** 내부 protocol 담당 · **실행 범위:** `OFFLINE_HOST_TESTS` · **초기 상태:** NOT_STARTED

### 입력과 제공 산출물

**입력:** 승인 내부 command 계약·FW matrix; 정본 schema·허용 시험 vectors

**작성할 산출물/경로 후보:** `modules/private_commands/<namespace>/`, `specs/private/`, `tests/private_commands/`. 실제 수정 대상과 소비/제공 인터페이스는 Work binding에 확정한다.

### 세부 실행 단계

- [ ] **W17.01** namespace/dialect/revision/transport/command ID 키를 구현 계약으로 고정한다. ⇒ opcode만으로 dispatch하지 않는다.
- [ ] **W17.02** same opcode/different dialect, unknown FW, 잘린 payload, length overflow 반례를 먼저 작성한다. ⇒ 안전 gate 없이 명령을 보내지 않는다.
- [ ] **W17.03** typed request/response와 순수 encode/decode를 구현한다. ⇒ 장비 호출·unlock secret 저장을 넣지 않는다.
- [ ] **W17.04** 허용 profile과 명령 부작용/권한 metadata를 연결한다. ⇒ 미확인 dialect 자동 fallback 금지.
- [ ] **W17.05** raw response/parse error/internal status namespace를 보존하고 실패 output을 시험한다. ⇒ 표준 NVMe status와 혼동하지 않는다.
- [ ] **W17.06** 내부 FW 담당 review와 독립 vector 결과를 기록한다. ⇒ 새 opcode/FW 지원 추가는 별도 변경 명세로 관리한다.

### 검사와 완료 판단

1. wrong dialect/FW가 검출된다.
2. 비공개 상세를 외부 자료로 유출하지 않는다.
3. pure codec Host 시험과 실장비 지원 주장이 분리된다.

**반례 확인:** 위 단계에서 지정한 실패/unknown/불가 조건이 예상 상태로 검출되는지 검증한다. 성공 사례만으로 종료하지 않는다.

**증거:** 이 Work의 실제 source/profile/tool hash, 실행 command/exit/result, 검토자, 누락/미실행을 verification record에 남긴다. 문서 검토만이면 실행 성공으로 표기하지 않는다.

### 차단과 문의

내부 명령 정본·권한·부작용 승인 미완료이면 관련 codec/실행 범위 제한. 해결되지 않은 사항은 질문 ID와 영향을 받는 step에 연결하고 담당자의 답변/근거를 기록한다. 독립적으로 수행 가능한 step만 계속한다.

<a id="work-w18"></a>

## W18 — UART framing·세션 분류·offline replay 핵심 구현

**선행:** W15, W09, W13 · **책임 역할:** UART codec 담당 · **실행 범위:** `OFFLINE_HOST_TESTS` · **초기 상태:** NOT_STARTED

### 입력과 제공 산출물

**입력:** UART/framing/session 명세; 허용 raw corpus·독립 synthetic fixtures

**작성할 산출물/경로 후보:** `modules/uart_protocol/`, `tests/uart/`, `docs/contracts/uart_stream.md`. 실제 수정 대상과 소비/제공 인터페이스는 Work binding에 확정한다.

### 세부 실행 단계

- [ ] **W18.01** 입력 stream·parser state·완성 frame·부분/오류/resync 결과 계약을 확정한다. ⇒ 실제 transport와 분리한다.
- [ ] **W18.02** 모든 의미 있는 분할 경계/여러 frame/길이 오류/NUL/echo/log interleave 테스트를 먼저 작성한다. ⇒ read=frame 가정 금지.
- [ ] **W18.03** bounded parser와 검증된 framing/resync를 구현한다. ⇒ 없는 checksum/escape 규칙을 발명하지 않는다.
- [ ] **W18.04** command response/unsolicited log/boot event 분류와 session epoch를 구현한다. ⇒ 상관관계 미확정 응답을 확정 매칭하지 않는다.
- [ ] **W18.05** 포화/drop/reordered/late-response를 replay하며 상태와 loss marker를 확인한다. ⇒ 손실을 정상 프레임으로 이어붙이지 않는다.
- [ ] **W18.06** 순수 fuzz/정적/정수 검사를 실행하고 known limits를 기록한다. ⇒ 실제 UART 전기/타이밍 검증으로 확대하지 않는다.

### 검사와 완료 판단

1. partial/concat/interleave/resync가 계약대로 처리된다.
2. 경계 밖 읽기·버퍼 무한 증가·stale session 오염이 없다(시험 범위 내).
3. raw 위치와 decoded event가 연결된다.

**반례 확인:** 위 단계에서 지정한 실패/unknown/불가 조건이 예상 상태로 검출되는지 검증한다. 성공 사례만으로 종료하지 않는다.

**증거:** 이 Work의 실제 source/profile/tool hash, 실행 command/exit/result, 검토자, 누락/미실행을 verification record에 남긴다. 문서 검토만이면 실행 성공으로 표기하지 않는다.

### 차단과 문의

framing/응답 대응 의미 불명확 시 FW/통신 담당 확인. 해결되지 않은 사항은 질문 ID와 영향을 받는 step에 연결하고 담당자의 답변/근거를 기록한다. 독립적으로 수행 가능한 step만 계속한다.

<a id="work-w19"></a>

## W19 — 다축 호환성·Capability·한계 resolver 구현

**선행:** W13, W14, W07, W08, W10 · **책임 역할:** 구성/정책 담당 · **실행 범위:** `OFFLINE_HOST_TESTS` · **초기 상태:** NOT_STARTED

### 입력과 제공 산출물

**입력:** variant axes·유효조합·한계 registry; 승인 Item requirements/지원·관측 범위

**작성할 산출물/경로 후보:** `modules/compatibility/`, `profiles/validated/`, `docs/limitations/`, `tests/compatibility/`. 실제 수정 대상과 소비/제공 인터페이스는 Work binding에 확정한다.

### 세부 실행 단계

- [ ] **W19.01** declared/observed/verified/unknown 지원 상태와 profile 해석 우선순위를 고정한다. ⇒ version min 계산만 사용하지 않는다.
- [ ] **W19.02** unknown/null/defined-zero/충돌 subtype/잘못된 Fixture/FW의 반례를 먼저 작성한다. ⇒ 빈 제약이 무제한이 되지 않는다.
- [ ] **W19.03** Item 요구와 장비·DUT·SDK·Fixture·관측·승인을 비교하는 순수 resolver를 구현한다. ⇒ 불가 사유·근거 ID를 반환한다.
- [ ] **W19.04** NOT_IMPLEMENTED/NOT_VERIFIED/UNSUPPORTED/FORBIDDEN과 verdict/비교수준을 별도 표현한다. ⇒ silent downgrade 금지.
- [ ] **W19.05** 승인된 대체 Item variant만 허용하도록 검사하고 profile 생성/로딩 검증을 구현한다. ⇒ draft profile 실행 금지.
- [ ] **W19.06** 장비별 사람이 읽는 limitations 문서와 machine registry의 연결을 검사한다. ⇒ 변경 impact와 revalidation 조건을 기록한다.

### 검사와 완료 판단

1. 유효 구성 허용·불가/미확인 구성 거부.
2. 같은 API/다른 관측 능력을 동등 지원으로 표시하지 않는다.
3. negative DUT unsupported-response 평가의 합법적 요구를 구별한다.

**반례 확인:** 위 단계에서 지정한 실패/unknown/불가 조건이 예상 상태로 검출되는지 검증한다. 성공 사례만으로 종료하지 않는다.

**증거:** 이 Work의 실제 source/profile/tool hash, 실행 command/exit/result, 검토자, 누락/미실행을 verification record에 남긴다. 문서 검토만이면 실행 성공으로 표기하지 않는다.

### 차단과 문의

운영 조합/정책 우선순위 미확정이면 해당 resolver rule 승인 보류. 해결되지 않은 사항은 질문 ID와 영향을 받는 step에 연결하고 담당자의 답변/근거를 기록한다. 독립적으로 수행 가능한 step만 계속한다.

<a id="work-w20"></a>

## W20 — 요청·버퍼·세션·자원 runtime과 Fake 최소 관측

**선행:** W14, W15, W19 · **책임 역할:** runtime/메모리 담당 · **실행 범위:** `OFFLINE_HOST_TESTS` · **초기 상태:** NOT_STARTED

### 입력과 제공 산출물

**입력:** 승인 async/memory/resource 계약; 실제 SDK 제약·Fake 테스트 요구

**작성할 산출물/경로 후보:** `modules/runtime/`, `modules/ports/`, `providers/fake/`, `tests/runtime/`, `specs/events/minimal_run_event.yaml`. 실제 수정 대상과 소비/제공 인터페이스는 Work binding에 확정한다.

### 세부 실행 단계

- [ ] **W20.01** request/session/DUT generation/buffer lease/resource 상태 전이를 명시한다. ⇒ timeout과 취소 완료를 분리한다.
- [ ] **W20.02** late/duplicate completion, reset, cancel, slot 경합, 실패 cleanup 테스트를 먼저 작성한다. ⇒ zero-init verdict는 UNSET이다.
- [ ] **W20.03** 필요 최소 runtime과 lease/lock order·단조시계 포트를 구현한다. ⇒ 거대한 scheduler를 선행 개발하지 않는다.
- [ ] **W20.04** Fake가 성공/부분/미지원/미확정/늦은 이벤트를 재현하도록 만든다. ⇒ always-success mock만 만들지 않는다.
- [ ] **W20.05** 최소 구조화 trace에 run/step/request/resource/generation/timestamp source를 기록한다. ⇒ 이후 상태 logging의 정본으로 쓴다.
- [ ] **W20.06** 상태 transition/ownership/첫 오류와 정리 오류 보존을 검증한다. ⇒ 프로세스 종료가 물리 정지를 보장한다고 하지 않는다.

### 검사와 완료 판단

1. timeout 뒤 버퍼 조기반환 반례 차단.
2. stale generation과 shared resource 충돌 검출.
3. Fake build에 실제 장치 접근 없음.

**반례 확인:** 위 단계에서 지정한 실패/unknown/불가 조건이 예상 상태로 검출되는지 검증한다. 성공 사례만으로 종료하지 않는다.

**증거:** 이 Work의 실제 source/profile/tool hash, 실행 command/exit/result, 검토자, 누락/미실행을 verification record에 남긴다. 문서 검토만이면 실행 성공으로 표기하지 않는다.

### 차단과 문의

필수 memory/async 계약이 미확인인 실제 Provider 연결은 금지. 해결되지 않은 사항은 질문 ID와 영향을 받는 step에 연결하고 담당자의 답변/근거를 기록한다. 독립적으로 수행 가능한 step만 계속한다.

<a id="work-w21"></a>

## W21 — 첫 장비 Provider와 필수 runtime 경계 신규 구현

**선행:** W16, W19, W20 · **책임 역할:** 첫 Provider 담당 · **실행 범위:** `OFFLINE_APPROVED_BUILD_ONLY` · **초기 상태:** NOT_STARTED

### 입력과 제공 산출물

**입력:** 실제 primitive/ABI/runtime allowlist; 승인 첫 profile·실제 SDK header/library

**작성할 산출물/경로 후보:** `providers/<first_profile>/`, `app/entry_shim 또는 standalone`, `tests/provider_first/`, `docs/bindings/first_profile.md`. 실제 수정 대상과 소비/제공 인터페이스는 Work binding에 확정한다.

### 세부 실행 단계

- [ ] **W21.01** SDK 인자/타입/전역/메모리와 Custom 계약 mapping을 문서화한다. ⇒ readable 상위 helper/Item 호출은 배제한다.
- [ ] **W21.02** Host stub로 잘못된 인자/길이/slot/지원밖 field mapping 반례를 먼저 작성한다. ⇒ stub와 실제 header 불일치를 검사한다.
- [ ] **W21.03** 필수 entry/init/submit/observe/cleanup 경계만 구현한다. ⇒ runtime 필수성 증명 없는 예외 금지.
- [ ] **W21.04** SDK raw error/partial CQE/auto retry 한계를 그대로 보존한다. ⇒ 보이지 않는 필드를 성공/0으로 합성하지 않는다.
- [ ] **W21.05** 버퍼 수명·async·SDK 전역 transaction 직렬화와 trace를 연결한다. ⇒ 함수별 잠깐 lock만으로 안전 가정하지 않는다.
- [ ] **W21.06** 실제 GCC build/link/금지 참조/Host tests를 검증한다. ⇒ 여기서는 실장비 실행하지 않고 HOST_ONLY로 보고한다.

### 검사와 완료 판단

1. primitive mapping과 실제 ABI가 일치(빌드/검사 범위).
2. 금지 vendor 상위 호출과 다른 SDK 링크 없음.
3. 실장비 미실행 상태가 명시됨.

**반례 확인:** 위 단계에서 지정한 실패/unknown/불가 조건이 예상 상태로 검출되는지 검증한다. 성공 사례만으로 종료하지 않는다.

**증거:** 이 Work의 실제 source/profile/tool hash, 실행 command/exit/result, 검토자, 누락/미실행을 verification record에 남긴다. 문서 검토만이면 실행 성공으로 표기하지 않는다.

### 차단과 문의

SDK 계약 공백/ABI 충돌은 vendor/SDK 담당 확인 전 관련 코드 확정 보류. 해결되지 않은 사항은 질문 ID와 영향을 받는 step에 연결하고 담당자의 답변/근거를 기록한다. 독립적으로 수행 가능한 step만 계속한다.

<a id="work-w22"></a>

## W22 — 나머지 모델·세부타입·폼팩터 공통성 조기 검증

**선행:** W21 · **책임 역할:** Provider 통합 책임자 · **실행 범위:** `OFFLINE_APPROVED_BUILD_ONLY` · **초기 상태:** NOT_STARTED

### 입력과 제공 산출물

**입력:** 공통 계약·실제 나머지 SDK/profile; V1/V2/V3 선택 근거

**작성할 산출물/경로 후보:** `providers/<other_profiles>/`, `profiles/subtypes_fixtures/`, `tests/provider_matrix/`, `docs/architecture/commonality_review.md`. 실제 수정 대상과 소비/제공 인터페이스는 Work binding에 확정한다.

### 세부 실행 단계

- [ ] **W22.01** B/C 및 운영 대상 subtype/폼팩터 차이를 common contract별 mapping 표로 만든다. ⇒ 약한 장비에 맞추어 의미를 조용히 낮추지 않는다.
- [ ] **W22.02** 데이터 차이는 profile, ABI 차이는 source selection, 동작 차이는 작은 strategy로 배치한다. ⇒ 전역 ifdef 확산 금지.
- [ ] **W22.03** 각 binding을 Host stub/실제 GCC로 만들고 동일 semantic input의 SDK 전달값을 검증한다. ⇒ 실제 불가 기능은 UNSUPPORTED다.
- [ ] **W22.04** 동일 public 타입·lifetime·error semantics가 유지되는지 비교한다. ⇒ 미충족 계약은 limitation과 redesign 후보로 제시한다.
- [ ] **W22.05** 모든 선언 supported build의 source/link manifest와 제외 모델을 검사한다. ⇒ 타깃별 compile DB를 분리한다.
- [ ] **W22.06** 공통화의 실패를 수십 Item 작성 전에 review한다. ⇒ 필요하면 승인 계약 revision을 갱신하고 영향 시험을 재실행한다.

### 검사와 완료 판단

1. 지원 선언 profile별 build/Host 결과와 한계가 있다.
2. Item에 모델/subtype/폼팩터 분기가 새지 않는다.
3. 공통성 실패를 fake-success로 덮지 않는다.

**반례 확인:** 위 단계에서 지정한 실패/unknown/불가 조건이 예상 상태로 검출되는지 검증한다. 성공 사례만으로 종료하지 않는다.

**증거:** 이 Work의 실제 source/profile/tool hash, 실행 command/exit/result, 검토자, 누락/미실행을 verification record에 남긴다. 문서 검토만이면 실행 성공으로 표기하지 않는다.

### 차단과 문의

새 profile이 미확인이면 지원 선언하지 않고 문의/제외. 해결되지 않은 사항은 질문 ID와 영향을 받는 step에 연결하고 담당자의 답변/근거를 기록한다. 독립적으로 수행 가능한 step만 계속한다.

<a id="work-w23"></a>

## W23 — UART 실제 Provider·단일 수신·명령/로그 연결

**선행:** W17, W18, W20, W22 · **책임 역할:** UART integration 담당 · **실행 범위:** `OFFLINE_APPROVED_BUILD_ONLY` · **초기 상태:** NOT_STARTED

### 입력과 제공 산출물

**입력:** 실제 UART 경계 계약·포트 topology; private dialect·runtime trace

**작성할 산출물/경로 후보:** `providers/*/uart binding`, `platform/serial(선택 시)`, `modules/services/uart_session/`, `tests/uart_integration/`. 실제 수정 대상과 소비/제공 인터페이스는 Work binding에 확정한다.

### 세부 실행 단계

- [ ] **W23.01** Vendor UART 또는 OS/bridge 후보를 실제 환경에 맞게 선택한다. ⇒ libserialport 도입은 별도 적합성/라이선스 결정이다.
- [ ] **W23.02** 포트/route identity·exclusive lease·수신 owner·session lifecycle을 구현한다. ⇒ 명령 reader와 logger의 경쟁 소비 금지.
- [ ] **W23.03** 부분 write/read·timeout·실행 미확정·flush/cancel 계약을 mapping한다. ⇒ 무조건 재전송하지 않는다.
- [ ] **W23.04** framing dispatcher를 command/dialect/async trace와 연결하고 boot epoch를 처리한다. ⇒ 이전 응답이 새 요청을 완료시키지 않는다.
- [ ] **W23.05** Fake port/recorded stream으로 backpressure·disconnect·loss·disk failure 반례를 검증한다. ⇒ hardware 접근 기본 비활성.
- [ ] **W23.06** 실제 빌드 증거와 별도 HIL 계획·미확인 전기/baud 항목을 기록한다. ⇒ Host 결과를 실제 통신 성공으로 쓰지 않는다.

### 검사와 완료 판단

1. 한 수신 owner와 명시적 command transaction.
2. partial/late/disconnect가 올바른 상태를 남김.
3. raw/log event의 provenance와 loss 표시.

**반례 확인:** 위 단계에서 지정한 실패/unknown/불가 조건이 예상 상태로 검출되는지 검증한다. 성공 사례만으로 종료하지 않는다.

**증거:** 이 Work의 실제 source/profile/tool hash, 실행 command/exit/result, 검토자, 누락/미실행을 verification record에 남긴다. 문서 검토만이면 실행 성공으로 표기하지 않는다.

### 차단과 문의

전기/route/control-line 효과 불명확하면 실제 port open 금지. 해결되지 않은 사항은 질문 ID와 영향을 받는 step에 연결하고 담당자의 답변/근거를 기록한다. 독립적으로 수행 가능한 step만 계속한다.

<a id="work-w24"></a>

## W24 — PCIe·Chamber·PSU·공유 자원 Provider와 정리 정책

**선행:** W20, W22, W10 · **책임 역할:** 환경/PCIe Provider 담당 · **실행 범위:** `OFFLINE_APPROVED_BUILD_ONLY` · **초기 상태:** NOT_STARTED

### 입력과 제공 산출물

**입력:** 승인 자원/환경/timing 계약; 모델별 실제 capability/제어 API

**작성할 산출물/경로 후보:** `providers/*/pcie_environment bindings`, `modules/services/environment/`, `profiles/resource_topology/`, `tests/resources_environment/`. 실제 수정 대상과 소비/제공 인터페이스는 Work binding에 확정한다.

### 세부 실행 단계

- [ ] **W24.01** 필요 PCIe 접근/reset/link와 환경 setpoint/readback/output 기능을 작은 계약으로 mapping한다. ⇒ 관측과 제어 범위를 구별한다.
- [ ] **W24.02** Fake에서 stale sensor/분해능 밖 값/shared rail/reset blast-radius 반례를 작성한다. ⇒ 자동 clamp/가짜 readback 금지.
- [ ] **W24.03** resource lease와 topology 검사를 연결한다. ⇒ Slot lock만으로 공통 Chamber 충돌을 놓치지 않는다.
- [ ] **W24.04** 승인 cleanup과 최초 오류 보존·수동 조치 필요 상태를 구현한다. ⇒ 무조건 특정 온도/출력으로 복구하지 않는다.
- [ ] **W24.05** 장비 시퀀스/trigger가 필요한 경우 호스트 호출 대체와 의미 차이를 명시한다. ⇒ IPC/sleep으로 정밀성 주장 금지.
- [ ] **W24.06** Host 계약/빌드/한계 docs를 검토하고 실제 물리 시험의 승인 입력을 준비한다. ⇒ 아직 HIL 결과를 생성하지 않는다.

### 검사와 완료 판단

1. setpoint와 측정/안정화 상태 구별.
2. 공유 자원 충돌과 cleanup 실패가 기록됨.
3. 미지원 제어는 명시 거부.

**반례 확인:** 위 단계에서 지정한 실패/unknown/불가 조건이 예상 상태로 검출되는지 검증한다. 성공 사례만으로 종료하지 않는다.

**증거:** 이 Work의 실제 source/profile/tool hash, 실행 command/exit/result, 검토자, 누락/미실행을 verification record에 남긴다. 문서 검토만이면 실행 성공으로 표기하지 않는다.

### 차단과 문의

환경 한계/관측/안전 cleanup이 미확정이면 해당 HIL/운영 경로 차단. 해결되지 않은 사항은 질문 ID와 영향을 받는 step에 연결하고 담당자의 답변/근거를 기록한다. 독립적으로 수행 가능한 step만 계속한다.

<a id="work-w25"></a>

## W25 — 승인된 최소 실장비 계약 검증

**선행:** W23, W24 · **책임 역할:** 실장비 운영자+계약 검증 담당 · **실행 범위:** `APPROVED_HARDWARE_ONLY` · **초기 상태:** NOT_STARTED

### 입력과 제공 산출물

**입력:** 승인된 HIL Run Plan·Fixture/DUT identity·안전/권한; Host 검증된 binary/profile/SDK hashes

**작성할 산출물/경로 후보:** `evidence/hil_contract/<run_id>/`, `docs/bindings/검증범위`, `profiles/verified_capabilities/`. 실제 수정 대상과 소비/제공 인터페이스는 Work binding에 확정한다.

### 세부 실행 단계

- [ ] **W25.01** 실제 장비·subtype·SDK/FW·Fixture·DUT·UART route와 승인 범위를 대조한다. ⇒ 불일치/unknown은 실행 전 차단한다.
- [ ] **W25.02** Run Plan에 allowed operations/영속 영향/stop 조건/timeout/cleanup/관측 장치를 고정한다. ⇒ source 열람 승인을 실행 승인으로 해석하지 않는다.
- [ ] **W25.03** 가장 좁은 승인 계약 시험을 실행하고 raw command/result/상태/time evidence를 수집한다. ⇒ 위험값을 이 문서에서 가져오지 않는다.
- [ ] **W25.04** 실제 반환/관측/lifetime이 문서와 일치하는지 비교하고 충돌을 기록한다. ⇒ Stub 성공으로 불일치를 무시하지 않는다.
- [ ] **W25.05** stop/cleanup 후 출력·pending request·자원 상태를 확인한다. ⇒ 실패/미확정은 운영 담당에게 넘긴다.
- [ ] **W25.06** 검증한 정확한 profile/조건만 verified로 승격하고 나머지는 NOT_RUN으로 남긴다. ⇒ 새 한계와 질문을 반영한다.

### 검사와 완료 판단

1. 실행 승인·identity·hash·원시 증거가 연결됨.
2. 실제 관측이 계약과 충돌하면 관련 지원 승격 안 함.
3. 최종 장비 상태/미완료 처리 기록.

**반례 확인:** 위 단계에서 지정한 실패/unknown/불가 조건이 예상 상태로 검출되는지 검증한다. 성공 사례만으로 종료하지 않는다.

**증거:** 이 Work의 실제 source/profile/tool hash, 실행 command/exit/result, 검토자, 누락/미실행을 verification record에 남긴다. 문서 검토만이면 실행 성공으로 표기하지 않는다.

### 차단과 문의

G-HARDWARE 조건 하나라도 미충족이면 실행 금지. 해결되지 않은 사항은 질문 ID와 영향을 받는 step에 연결하고 담당자의 답변/근거를 기록한다. 독립적으로 수행 가능한 step만 계속한다.

<a id="work-w26"></a>

## W26 — 평가 판정·데이터 무결성·재사용 서비스 신규 구현

**선행:** W16, W17, W20, W19 · **책임 역할:** 평가 서비스 담당 · **실행 범위:** `OFFLINE_HOST_TESTS` · **초기 상태:** NOT_STARTED

### 입력과 제공 산출물

**입력:** 승인 Item/데이터 검증 목적; pure codecs·runtime contracts·patterns

**작성할 산출물/경로 후보:** `modules/services/`, `modules/evaluation/`, `tests/evaluation/`, `docs/contracts/data_integrity.md`. 실제 수정 대상과 소비/제공 인터페이스는 Work binding에 확정한다.

### 세부 실행 단계

- [ ] **W26.01** 제출/완료/검증/영속 기대와 전송/응답/파싱/판정을 구분하는 서비스 계약을 확정한다. ⇒ completion만으로 durability를 가정하지 않는다.
- [ ] **W26.02** seed/algorithm/주소/metadata/iteration 패턴과 expected-write ledger를 명세한다. ⇒ 새 결과를 기대값으로 자동 갱신하지 않는다.
- [ ] **W26.03** 정상/예상 DUT 오류/장비 오류/미확정 write/관측 손실 반례를 먼저 작성한다. ⇒ verdict UNSET부터 시작한다.
- [ ] **W26.04** 모델 독립 service와 순수 evaluator를 구현한다. ⇒ Vendor/dialect 선택 세부는 계약과 resolver에 맡긴다.
- [ ] **W26.05** count/length/timeout/retry·cleanup 변화가 평가 정책과 맞는지 검토한다. ⇒ 최적화가 명령 의미를 바꾸지 않는다.
- [ ] **W26.06** Host/Fake/독립 vectors 결과와 limitation 영향을 기록한다. ⇒ 실제 persistence 검증은 별도 HIL로 남긴다.

### 검사와 완료 판단

1. expected error와 전송 실패 판정이 구별됨.
2. 불명확 데이터/증거를 임의 PASS 처리하지 않음.
3. service에 모델 직접 분기/SDK include 없음.

**반례 확인:** 위 단계에서 지정한 실패/unknown/불가 조건이 예상 상태로 검출되는지 검증한다. 성공 사례만으로 종료하지 않는다.

**증거:** 이 Work의 실제 source/profile/tool hash, 실행 command/exit/result, 검토자, 누락/미실행을 verification record에 남긴다. 문서 검토만이면 실행 성공으로 표기하지 않는다.

### 차단과 문의

평가 목적·데이터 oracle·판정 기준 모호 시 평가 책임자 확인. 해결되지 않은 사항은 질문 ID와 영향을 받는 step에 연결하고 담당자의 답변/근거를 기록한다. 독립적으로 수행 가능한 step만 계속한다.

<a id="work-w27"></a>

## W27 — 대표 다영역 Test Item의 완전 신규 구현과 offline 검증

**선행:** W26, W23, W24 · **책임 역할:** Item 개발 담당 · **실행 범위:** `OFFLINE_HOST_TESTS` · **초기 상태:** NOT_STARTED

### 입력과 제공 산출물

**입력:** 승인 대표 Item 명세·지원 profile; 공통 서비스·private/UART/환경 계약

**작성할 산출물/경로 후보:** `modules/items/<item_id>/`, `docs/items/<item_id>.md`, `tests/items/<item_id>/`, `analysis/representative_delta.md`. 실제 수정 대상과 소비/제공 인터페이스는 Work binding에 확정한다.

### 세부 실행 단계

- [ ] **W27.01** 대표 Item의 목적/입력/요구능력/sequence/관측/판정/stop을 승인 명세로 고정한다. ⇒ 현행 함수 몸체를 기본으로 복사하지 않는다.
- [ ] **W27.02** 정상·의도오류·지원부족·환경미도달·UART손실·timeout 상태 scenario를 먼저 작성한다. ⇒ end-to-end 기대 trace를 명세한다.
- [ ] **W27.03** 공통 service와 typed contract만으로 새 Item을 작성한다. ⇒ 모델/subtype/form factor별 raw 분기를 넣지 않는다.
- [ ] **W27.04** private command/UART/환경 단계의 effect/epoch/resource/한계 정보를 trace에 연결한다. ⇒ 조용한 fallback 금지.
- [ ] **W27.05** Fake replay와 필요한 모든 build에서 실행/검사한다. ⇒ model 실행 여부와 binary build를 구분한다.
- [ ] **W27.06** legacy 대비 의도 보존/버그 수정/정책 변경/폐기/비동등을 설명한다. ⇒ old PASS/FAIL 일치만으로 완료하지 않는다.

### 검사와 완료 판단

1. Item 구현·명세·metadata·반례가 한 단위로 존재.
2. 공통 API 재조합으로 실행하고 변경 이유가 추적됨.
3. offline 결과와 HIL 미실행 구분.

**반례 확인:** 위 단계에서 지정한 실패/unknown/불가 조건이 예상 상태로 검출되는지 검증한다. 성공 사례만으로 종료하지 않는다.

**증거:** 이 Work의 실제 source/profile/tool hash, 실행 command/exit/result, 검토자, 누락/미실행을 verification record에 남긴다. 문서 검토만이면 실행 성공으로 표기하지 않는다.

### 차단과 문의

대표 평가의 물리/판정 요구가 확정되어야 코드 명세 승인. 해결되지 않은 사항은 질문 ID와 영향을 받는 step에 연결하고 담당자의 답변/근거를 기록한다. 독립적으로 수행 가능한 step만 계속한다.

<a id="work-w28"></a>

## W28 — 대표 Item의 장비별 HIL·비동등성·관측 검증

**선행:** W25, W27 · **책임 역할:** 실장비/평가/계측 책임자 · **실행 범위:** `APPROVED_HARDWARE_ONLY` · **초기 상태:** NOT_STARTED

### 입력과 제공 산출물

**입력:** 승인 Item Run Plan·검증된 contracts/profile; 계측/로그/독립 판정 근거

**작성할 산출물/경로 후보:** `evidence/item_hil/`, `docs/limitations/equivalence_matrix.md`, `profiles/item_support/`. 실제 수정 대상과 소비/제공 인터페이스는 Work binding에 확정한다.

### 세부 실행 단계

- [ ] **W28.01** Item 요구와 실제 장비/Fixture/DUT의 검증 능력을 사전 대조한다. ⇒ unsupported/unknown을 시험 강도 하향으로 해결하지 않는다.
- [ ] **W28.02** 승인된 profile/조건별로 실행 순서와 HIL matrix를 고정한다. ⇒ 파괴적 old/new 시험을 같은 DUT에 병렬 실행하지 않는다.
- [ ] **W28.03** command/effect/센서/UART/데이터 검증 증거를 수집한다. ⇒ 로그/계측 추가의 시간 영향도 기록한다.
- [ ] **W28.04** 관측 정확도·timing·loss·분할/재시도·환경 조건 차이를 비교한다. ⇒ 같은 API 성공과 동등성을 분리한다.
- [ ] **W28.05** 판정과 비교 수준을 별도 승인하고 limitation/대체 variant를 명시한다. ⇒ 대체 평가에 원래 ID/PASS를 유지하지 않는다.
- [ ] **W28.06** 정확한 지원 범위와 미실행/재검증 필요 범위를 배포 후보 docs에 반영한다. ⇒ 모든 모델 일반화 금지.

### 검사와 완료 판단

1. 모델별 실제 HIL 근거와 한계가 있다.
2. 필수 관측 불충분 시 INCONCLUSIVE/BLOCKED 정책 적용.
3. 동등성 주장에 비교 범위/근거가 명시됨.

**반례 확인:** 위 단계에서 지정한 실패/unknown/불가 조건이 예상 상태로 검출되는지 검증한다. 성공 사례만으로 종료하지 않는다.

**증거:** 이 Work의 실제 source/profile/tool hash, 실행 command/exit/result, 검토자, 누락/미실행을 verification record에 남긴다. 문서 검토만이면 실행 성공으로 표기하지 않는다.

### 차단과 문의

승인된 안전/측정/영속 영향 조건 미충족 시 실행 금지. 해결되지 않은 사항은 질문 ID와 영향을 받는 step에 연결하고 담당자의 답변/근거를 기록한다. 독립적으로 수행 가능한 step만 계속한다.

<a id="work-w29"></a>

## W29 — 평가 현황·로그 저장·LLM 상태 조회와 재분석 강화

**선행:** W20, W23, W27 · **책임 역할:** 로그/상태/분석 담당 · **실행 범위:** `OFFLINE_HOST_TESTS` · **초기 상태:** NOT_STARTED

### 입력과 제공 산출물

**입력:** 최소 run event·실제 Item 흐름·log requirements; 보안/retention/storage 정책

**작성할 산출물/경로 후보:** `modules/observability/`, `specs/events/`, `docs/operations/run_status.md`, `tests/observability/`. 실제 수정 대상과 소비/제공 인터페이스는 Work binding에 확정한다.

### 세부 실행 단계

- [ ] **W29.01** Run/Item/step/request/resource/epoch event schema와 raw/derived 참조를 확정한다. ⇒ 진행률과 verdict를 분리한다.
- [ ] **W29.02** plan/submitted/completed/verified/unknown 수와 마지막 신뢰 시각을 결정론적으로 projection한다. ⇒ prose 추측으로 현재 상태를 만들지 않는다.
- [ ] **W29.03** bounded queue/drop/disk-full/rotation/partial-file/reconnect 정책을 구현한다. ⇒ 필수 근거 손실 시 판정 영향을 연결한다.
- [ ] **W29.04** schema/dialect/code/profile revision과 raw hash를 기록하고 parser 재분석 결과를 별도 저장한다. ⇒ 원래 run evidence 덮어쓰기 금지.
- [ ] **W29.05** LLM 읽기용 status/근거 인덱스를 만들고 redaction/권한/로그 prompt-injection 경계를 검토한다. ⇒ 읽기 기능에 장비 실행 권한을 넣지 않는다.
- [ ] **W29.06** 중복/순서역전/손실/재시작/unknown state 시험을 수행한다. ⇒ run resume은 별도 자원/장비 상태 확인 없이는 금지한다.

### 검사와 완료 판단

1. 수치/상태가 원시 event와 revision으로 추적됨.
2. 로그 손실·늦은 시각이 숨겨지지 않음.
3. 현재 상태와 과거 분석 결과가 구별됨.

**반례 확인:** 위 단계에서 지정한 실패/unknown/불가 조건이 예상 상태로 검출되는지 검증한다. 성공 사례만으로 종료하지 않는다.

**증거:** 이 Work의 실제 source/profile/tool hash, 실행 command/exit/result, 검토자, 누락/미실행을 verification record에 남긴다. 문서 검토만이면 실행 성공으로 표기하지 않는다.

### 차단과 문의

보관·보안·필수 증거 정책은 사내 승인 필요. 해결되지 않은 사항은 질문 ID와 영향을 받는 step에 연결하고 담당자의 답변/근거를 기록한다. 독립적으로 수행 가능한 step만 계속한다.

<a id="work-w30"></a>

## W30 — 정적·문서·명명·구성 matrix CI 게이트 통합

**선행:** W22, W27, W29 · **책임 역할:** 품질/빌드 통합 담당 · **실행 범위:** `OFFLINE_APPROVED_ANALYSIS_ONLY` · **초기 상태:** NOT_STARTED

### 입력과 제공 산출물

**입력:** 초기 검사 W14·도구 baseline W11; 승인 코딩/docs/프로필 규칙

**작성할 산출물/경로 후보:** `tools/quality/`, `실제 CI 설정`, `docs/verification/quality_gates.md`, `tests/quality_rules/`. 실제 수정 대상과 소비/제공 인터페이스는 Work binding에 확정한다.

### 세부 실행 단계

- [ ] **W30.01** format/naming/include/link/type/analysis/docs/schema/profile 검사 책임과 명령을 고정한다. ⇒ 전부 동일 위험 수준으로 실행하지 않는다.
- [ ] **W30.02** Vendor/legacy/generated/custom 범위를 분리하여 수정·포맷 정책을 적용한다. ⇒ vendor 결함 결과 자체를 숨기지 않는다.
- [ ] **W30.03** 금지 API/잘못된 타입/문서 누락/한계 위반/모델 혼입 seed fixture로 검사가 실제 실패하는지 확인한다. ⇒ 검사 script가 항상 0을 반환하지 않는다.
- [ ] **W30.04** 선택 지원 profile별 build/analysis와 실패 TU/미실행 분모를 보고한다. ⇒ inactive branch 분석 상태를 따로 둔다.
- [ ] **W30.05** waiver/예외에 owner/reason/scope/expiry를 요구하고 새 codegen drift/ID 충돌을 검출한다. ⇒ 광역 suppression 금지.
- [ ] **W30.06** 빠른 변경 검사와 전체/고위험 검사의 실행 기준을 문서화하고 정상·실패 pipeline을 리허설한다. ⇒ CI가 HIL을 무단 호출하지 않는다.

### 검사와 완료 판단

1. 명명/의존성/docs/profile 위반이 실제 검출됨.
2. build/analysis 실패는 깨끗한 결과와 구별됨.
3. 검사 결과와 실제 입력 hash/명령 연결.

**반례 확인:** 위 단계에서 지정한 실패/unknown/불가 조건이 예상 상태로 검출되는지 검증한다. 성공 사례만으로 종료하지 않는다.

**증거:** 이 Work의 실제 source/profile/tool hash, 실행 command/exit/result, 검토자, 누락/미실행을 verification record에 남긴다. 문서 검토만이면 실행 성공으로 표기하지 않는다.

### 차단과 문의

사용 CI/runner 권한·명령은 실제 환경에 바인딩되어야 한다. 해결되지 않은 사항은 질문 ID와 영향을 받는 step에 연결하고 담당자의 답변/근거를 기록한다. 독립적으로 수행 가능한 step만 계속한다.

<a id="work-w31"></a>

## W31 — 조건부: 사내 분석 도구 확장 필요성과 최소 구현

**선행:** W11, W30 · **책임 역할:** 분석 도구 담당 · **실행 범위:** `OFFLINE_HOST_TESTS` · **초기 상태:** NOT_STARTED

**조건부 작업:** 필요성 ADR 승인 후에만 구현한다. 불채택 시 사유를 기록하고 종료한다.

### 입력과 제공 산출물

**입력:** 반복된 실제 분석 공백/비용 자료; A0~A3 후보·기존 도구 기능·라벨 corpus

**작성할 산출물/경로 후보:** `docs/adr/analysis_tool_decision.md`, `tools/analysis/(승인 시)`, `tests/analysis_corpus/`, `docs/analysis/tool_limits.md`. 실제 수정 대상과 소비/제공 인터페이스는 Work binding에 확정한다.

### 세부 실행 단계

- [ ] **W31.01** 기존 도구로 해결되지 않는 구체적 공백을 case/profile/영향으로 목록화한다. ⇒ 도구를 만들고 싶다는 이유만으로 시작하지 않는다.
- [ ] **W31.02** 수집/정규화/결과관리/특화 AST 규칙/새 전문 분석 중 필요한 최소 단계를 비교한다. ⇒ 직접 도입 비용·보안·유지 owner를 검토한다.
- [ ] **W31.03** 도입 여부 ADR을 승인받는다. 불필요하면 NOT_NEEDED_WITH_REASON로 종료한다. ⇒ 필수 경로를 분석 불가로 남긴 채 넘어가지 않는다.
- [ ] **W31.04** 승인한 범위만 구현하고 compiler 기반 사실과 LLM 가설을 구분한다. ⇒ 자체 ad-hoc C parser로 정확한 분석을 주장하지 않는다.
- [ ] **W31.05** known-bad/good·매크로·다중 TU·alias·분기 fixture에서 검출/오탐/실패 보고를 시험한다. ⇒ corpus 한계를 명시한다.
- [ ] **W31.06** tool/config/source/profile hash·캐시 무효화·재현 결과를 검증한다. ⇒ 실제 효과 없으면 범위를 줄이거나 기존 도구로 회귀한다.

### 검사와 완료 판단

1. 필요/불필요 판단 근거가 있다.
2. 채택 시 labelled corpus에 대한 성능/한계가 보고됨.
3. parse 실패를 clean으로 내지 않음.

**반례 확인:** 위 단계에서 지정한 실패/unknown/불가 조건이 예상 상태로 검출되는지 검증한다. 성공 사례만으로 종료하지 않는다.

**증거:** 이 Work의 실제 source/profile/tool hash, 실행 command/exit/result, 검토자, 누락/미실행을 verification record에 남긴다. 문서 검토만이면 실행 성공으로 표기하지 않는다.

### 차단과 문의

범위·유지 owner·보안/라이선스 승인 전 도구 확대 금지. 해결되지 않은 사항은 질문 ID와 영향을 받는 step에 연결하고 담당자의 답변/근거를 기록한다. 독립적으로 수행 가능한 step만 계속한다.

<a id="work-w32"></a>

## W32 — LLM Item 추가·수정·재조합 실증과 규칙 검출

**선행:** W13, W27, W29, W30 · **책임 역할:** LLM workflow/평가 개발 책임자 · **실행 범위:** `OFFLINE_HOST_TESTS` · **초기 상태:** NOT_STARTED

### 입력과 제공 산출물

**입력:** 실제 사내 Harness·승인된 문서 정본; 비교 가능한 Item 추가/수정 과제

**작성할 산출물/경로 후보:** `evidence/llm_workflow/`, `docs/development/llm_item_workflow.md`, `docs/development/context_index.md`. 실제 수정 대상과 소비/제공 인터페이스는 Work binding에 확정한다.

### 세부 실행 단계

- [ ] **W32.01** 기존 대화를 모르는 세션에 AGENTS/INDEX/대상 Item/계약/질문 상태를 제공한다. ⇒ 모든 Vendor 코드를 매번 넣지 않는다.
- [ ] **W32.02** 순수/낮은 위험 Item 추가와 기존 Item 변경 과제를 각 하나 수행한다. ⇒ 사전 승인 범위 밖 장비 실행은 금지한다.
- [ ] **W32.03** 함수 검색/재조합·타입/단위·명세/검증/로그/한계 갱신이 함께 되는지 관찰한다. ⇒ 없는 API는 CONTRACT_GAP으로 처리한다.
- [ ] **W32.04** wrong dialect/모델 분기/잘못된 단위/timeout buffer 해제/문서 누락 변경을 주입해 검사를 확인한다. ⇒ 가상의 의도만으로 성공 주장 금지.
- [ ] **W32.05** 변경 파일·질문·반복 읽기·미검증 범위·검출 실패를 기록한다. ⇒ 생산성 향상률을 근거 없이 제시하지 않는다.
- [ ] **W32.06** 필요 최소 Skill/runbook을 개선하고 같은 과제를 재검증한다. ⇒ 다중 중복 workflow/DB를 만들지 않는다.

### 검사와 완료 판단

1. 실제 신규/변경 Item이 docs/코드/시험/상태를 함께 갱신.
2. 금지/잘못된 변경이 검출되고 미확인을 질문함.
3. 하드웨어 접근 권한이 자동 확대되지 않음.

**반례 확인:** 위 단계에서 지정한 실패/unknown/불가 조건이 예상 상태로 검출되는지 검증한다. 성공 사례만으로 종료하지 않는다.

**증거:** 이 Work의 실제 source/profile/tool hash, 실행 command/exit/result, 검토자, 누락/미실행을 verification record에 남긴다. 문서 검토만이면 실행 성공으로 표기하지 않는다.

### 차단과 문의

사내 Harness 기능/권한/보안 정책 확인 필요. 해결되지 않은 사항은 질문 ID와 영향을 받는 step에 연결하고 담당자의 답변/근거를 기록한다. 독립적으로 수행 가능한 step만 계속한다.

<a id="work-w33"></a>

## W33 — SDK·세부타입·폼팩터·dialect 변경 대응 리허설

**선행:** W22, W30, W32 · **책임 역할:** 업데이트/릴리스 담당 · **실행 범위:** `OFFLINE_WITH_SEPARATELY_APPROVED_HIL` · **초기 상태:** NOT_STARTED

### 입력과 제공 산출물

**입력:** 둘 이상의 승인 Vendor/FW/profile 기준선 또는 제한된 합성 변경 fixture; 변경 영향 그래프·한계·질문 체계

**작성할 산출물/경로 후보:** `evidence/update_rehearsal/`, `docs/development/vendor_profile_upgrade.md`, `docs/limitations/변경 영향`. 실제 수정 대상과 소비/제공 인터페이스는 Work binding에 확정한다.

### 세부 실행 단계

- [ ] **W33.01** 실제 비교 자료 유무를 확인하고 실제/합성 리허설을 구분한다. ⇒ 존재하지 않는 SDK를 실제 업데이트라고 주장하지 않는다.
- [ ] **W33.02** 새 원본의 파일/타입/macro/memory/동작/빌드 차이를 추출한다. ⇒ 서명만 비교하지 않는다.
- [ ] **W33.03** 변경→binding→contract→profile/limitation→Item→검증 경로를 계산한다. ⇒ 기존 unknown은 여전히 unknown이다.
- [ ] **W33.04** 필요한 binding/profile/dialect 변경을 승인 절차로 적용한다. ⇒ 기존 Item 판정을 새 출력에 조용히 맞추지 않는다.
- [ ] **W33.05** 영향 Host/build/analysis·필요 승인 HIL을 선택하고 미실행 범위를 남긴다. ⇒ 테스트 선택 자체와 실제 실행을 구분한다.
- [ ] **W33.06** 업데이트 문서·재검증 trigger·rollback/중단 조건을 검토한다. ⇒ 새 원본 등록이 운영 승격을 자동 수행하지 않는다.

### 검사와 완료 판단

1. 계약/매크로/타입 의미 변경 영향이 추적됨.
2. 비영향 근거와 미확인이 보고됨.
3. 실제/합성/HIL 범위가 분리됨.

**반례 확인:** 위 단계에서 지정한 실패/unknown/불가 조건이 예상 상태로 검출되는지 검증한다. 성공 사례만으로 종료하지 않는다.

**증거:** 이 Work의 실제 source/profile/tool hash, 실행 command/exit/result, 검토자, 누락/미실행을 verification record에 남긴다. 문서 검토만이면 실행 성공으로 표기하지 않는다.

### 차단과 문의

새 source/FW 자료 없으면 합성 범위를 명확히 제한. 해결되지 않은 사항은 질문 ID와 영향을 받는 step에 연결하고 담당자의 답변/근거를 기록한다. 독립적으로 수행 가능한 step만 계속한다.

<a id="work-w34"></a>

## W34 — 선정 전체 기능·Item의 신규 구현 배치 확대

**선행:** W28, W30, W32 · **책임 역할:** 기능별 개발자+통합 책임자 · **실행 범위:** `OFFLINE_WITH_SEPARATELY_APPROVED_HIL` · **초기 상태:** NOT_STARTED

### 입력과 제공 산출물

**입력:** 승인 rewrite disposition·운영 우선순위; 대표 Item에서 검증된 계약/패턴

**작성할 산출물/경로 후보:** `신규 modules/items/services`, `docs/items/전체 대상`, `metadata/product_requirement_coverage.json`, `docs/limitations/최종 지원 후보`. 실제 수정 대상과 소비/제공 인터페이스는 Work binding에 확정한다.

### 세부 실행 단계

- [ ] **W34.01** 전체 기능/Item을 위험·의존·지원 profile별 배치로 나누고 owner를 정한다. ⇒ 미사용 vendor 함수까지 자동 복제하지 않는다.
- [ ] **W34.02** 각 배치의 목표 명세·질문·함수 계약·타입·반례를 확정한다. ⇒ legacy 결함을 보존 요구로 삼지 않는다.
- [ ] **W34.03** 새 Custom 규칙으로 구현하고 공통 기능은 재사용·모델 차이는 Provider로 제한한다. ⇒ 대량 복붙/전체 rewrite script 무검토 금지.
- [ ] **W34.04** 위험에 맞는 Host/정적/build/HIL 검증을 수행하고 평가 의미 차이를 승인받는다. ⇒ 실장비 미검증은 별도 상태다.
- [ ] **W34.05** retire/unsupported/blocked 기능도 이유·영향·대체 여부를 문서화한다. ⇒ 분모에서 숨겨 성공율을 높이지 않는다.
- [ ] **W34.06** 선정 전체 요구의 구현·검증·한계 coverage를 집계하고 다음 배치 범위를 조정한다. ⇒ 공통 계약 변경은 영향 모든 binding을 검토한다.

### 검사와 완료 판단

1. 선정한 전체 기능마다 구현/폐기/한계/차단 근거.
2. 각 지원 profile의 요구 증거와 docs 연결.
3. 공통 naming/type/의존성 규칙이 유지됨.

**반례 확인:** 위 단계에서 지정한 실패/unknown/불가 조건이 예상 상태로 검출되는지 검증한다. 성공 사례만으로 종료하지 않는다.

**증거:** 이 Work의 실제 source/profile/tool hash, 실행 command/exit/result, 검토자, 누락/미실행을 verification record에 남긴다. 문서 검토만이면 실행 성공으로 표기하지 않는다.

### 차단과 문의

배치별 중대 질문·미지원 구현 공백은 해당 범위 진행 차단. 해결되지 않은 사항은 질문 ID와 영향을 받는 step에 연결하고 담당자의 답변/근거를 기록한다. 독립적으로 수행 가능한 step만 계속한다.

<a id="work-w35"></a>

## W35 — 운영 배포·quiescence·복구·보관·신규 코드 전환

**선행:** W33, W34, W29 · **책임 역할:** 운영/릴리스/안전 책임자 · **실행 범위:** `APPROVED_DEPLOYMENT_AND_HARDWARE_ONLY` · **초기 상태:** NOT_STARTED

### 입력과 제공 산출물

**입력:** 승인 release 후보·실제 운영 환경; 안전/복구/보관/중단 정책

**작성할 산출물/경로 후보:** `docs/operations/deployment.md`, `docs/operations/recovery.md`, `release/manifest`, `docs/operations/decommission_legacy.md`. 실제 수정 대상과 소비/제공 인터페이스는 Work binding에 확정한다.

### 세부 실행 단계

- [ ] **W35.01** 운영 지원 profile/Item과 장비 ID/FW/SDK/Fixture 검증 절차를 고정한다. ⇒ 배포 편의를 위해 profile 검사를 끄지 않는다.
- [ ] **W35.02** 진행 중 요청·buffer lease·출력·Chamber·UART 상태를 멈추고 확인하는 quiescence 절차를 리허설한다. ⇒ 프로세스 kill을 물리 정지로 간주하지 않는다.
- [ ] **W35.03** 새 release 설치·로그 schema/설정 호환·권한/네트워크·장치 접근을 검사한다. ⇒ 빌드 계정과 실장비 계정 권한을 분리한다.
- [ ] **W35.04** 실패 시 안전 중단·승인된 이전 신규 release 복원·수동조치 경로를 시험한다. ⇒ SSD/환경 상태가 코드 rollback으로 돌아간다고 가정하지 않는다.
- [ ] **W35.05** legacy reference 보존/최종 runtime 링크 제거와 데이터/규격/로그 retention을 확인한다. ⇒ 기존 혼합 코드 영구 운영을 요구하지 않는다.
- [ ] **W35.06** 운영자 문서와 Run 상태/경고/한계 표시를 확인하고 제한 범위로 승격한다. ⇒ 미검증 범위는 여전히 차단한다.

### 검사와 완료 판단

1. 운영 identity/프로필 검사가 유효.
2. 복구가 실제 효과/미완료를 고려함.
3. legacy는 분석 증거이고 신규 실행 의존성으로 남지 않음(필수 vendor 경계 제외).

**반례 확인:** 위 단계에서 지정한 실패/unknown/불가 조건이 예상 상태로 검출되는지 검증한다. 성공 사례만으로 종료하지 않는다.

**증거:** 이 Work의 실제 source/profile/tool hash, 실행 command/exit/result, 검토자, 누락/미실행을 verification record에 남긴다. 문서 검토만이면 실행 성공으로 표기하지 않는다.

### 차단과 문의

운영·안전·데이터 보관 승인 없으면 배포 승격 금지. 해결되지 않은 사항은 질문 ID와 영향을 받는 step에 연결하고 담당자의 답변/근거를 기록한다. 독립적으로 수행 가능한 step만 계속한다.

<a id="work-w36"></a>

## W36 — 최종 지원범위 감사·완료 인수인계·후속 소유권

**선행:** W35, W32 · **책임 역할:** 최종 통합/운영/검증 책임자 · **실행 범위:** `OFFLINE_NO_HARDWARE` · **초기 상태:** NOT_STARTED

### 입력과 제공 산출물

**입력:** 모든 Work/요구/질문/한계/검증/운영 산출물; W31 채택 여부와 근거

**작성할 산출물/경로 후보:** `docs/FINAL_HANDOFF.md`, `metadata/accepted_support_matrix.json`, `docs/KNOWN_LIMITATIONS.md`, `docs/OPEN_QUESTIONS.md`, `docs/OWNERS_AND_UPDATE_POLICY.md`. 실제 수정 대상과 소비/제공 인터페이스는 Work binding에 확정한다.

### 세부 실행 단계

- [ ] **W36.01** 모든 요구와 선정 기능을 구현·검증·제한·문의 상태에 대응시킨다. ⇒ 문서 존재를 구현 완료로 세지 않는다.
- [ ] **W36.02** 전체 파일/심볼/프로필 감사 분모와 남은 unknown/opaque 부분을 재확인한다. ⇒ ‘전체 분석 100%’의 의미를 명시한다.
- [ ] **W36.03** 운영 지원 matrix와 실제 증거·한계·미실행 범위를 검토한다. ⇒ 한 모델 성공을 모든 subtype/form factor로 확장하지 않는다.
- [ ] **W36.04** coding/docs/spec/업데이트/분석 도구/LLM workflow owner와 변경 절차를 인계한다. ⇒ 후속 세션이 승인 정본을 찾을 수 있다.
- [ ] **W36.05** 남은 질문·알려진 결함·검증 필요·폐기된 기능과 재검토 trigger를 정리한다. ⇒ 종료를 위해 문제를 숨기지 않는다.
- [ ] **W36.06** 최종 보고에 실제 수행/미수행·source/build/evidence hash·승인 범위를 분리한다. ⇒ 사용자와 사내 책임자가 확인한 범위에만 완료를 선언한다.

### 검사와 완료 판단

1. 지원범위와 증거/한계/책임자가 일대일로 연결됨.
2. 소스와 문서·실행 기록의 참조가 유효.
3. 다음 세션이 추측 없이 유지·추가 작업을 시작할 수 있음.

**반례 확인:** 위 단계에서 지정한 실패/unknown/불가 조건이 예상 상태로 검출되는지 검증한다. 성공 사례만으로 종료하지 않는다.

**증거:** 이 Work의 실제 source/profile/tool hash, 실행 command/exit/result, 검토자, 누락/미실행을 verification record에 남긴다. 문서 검토만이면 실행 성공으로 표기하지 않는다.

### 차단과 문의

운영 승인·critical unresolved가 남으면 해당 지원범위 완료 불가. 해결되지 않은 사항은 질문 ID와 영향을 받는 step에 연결하고 담당자의 답변/근거를 기록한다. 독립적으로 수행 가능한 step만 계속한다.

## 7. 진행 관리와 재개 계약

작업 상태는 NOT_STARTED / IN_PROGRESS / BLOCKED / READY_FOR_REVIEW / ACCEPTED_FOR_SCOPE / NOT_NEEDED_WITH_REASON로 관리한다. 증거 없이 DONE으로 바꾸지 않는다. 각 step의 실패가 환경 문제인지 구현 결함인지 요구 미확정인지 분리한다.

세션 종료 때 현재 commit/dirty diff, 변경 파일, 승인 docs revision, 실행한 검사, 열린 질문, 다음 step ID를 남긴다. 다음 세션은 실제 자료를 읽어 상태를 확인하고 완료 조사를 이유 없이 반복하지 않는다. 승인된 설계도 새로운 반증이 있으면 변경 ADR로 수정한다.

작업량을 줄여야 할 때는 지원 범위를 명시적으로 줄이고 미지원/보류를 공개한다. 필수 계약·타입 안전·물리 보호·근거 기록을 몰래 생략하지 않는다. 최종 전체 완료는 **선정된 요구와 선언된 profile 범위**에 한정하며, 모든 가능한 Vendor 내부 동작을 증명했다는 뜻이 아니다.
