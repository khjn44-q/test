# 09. 정적분석과 다층 검증 전략

## 1. 정적분석은 마지막 청소 작업이 아니다

분석하기 쉬운 순수 함수, 좁은 인터페이스, 명시적 길이·소유권·상태, 모델별 build database를 초기부터 설계한다. 반면 도구 수를 늘리는 것 자체를 품질 목표로 삼지 않는다.

기본 후보는 GCC 경고 + GCC `-fanalyzer` + 필요한 Cppcheck 검사 + 규칙 검사 + Host 단위시험이다. Clang 호환성이 확보되면 clang-tidy/Static Analyzer를 추가한다. 특정 critical 모듈에 한해 CBMC/Frama-C를 선택한다.

GCC 공식 문서는 `-fanalyzer`가 오탐·미탐을 가질 수 있는 bug-finding 도구이며 정확성 증명 도구가 아니라고 명시한다. 따라서 경고 0개를 제품 안전 인증으로 취급하지 않는다. [S14]

## 2. GCC 진단 정책

Custom 코드의 후보 기준선:

```text
-Wall -Wextra -Wpedantic
-Wconversion -Wsign-conversion -Wshadow
-Wstrict-prototypes -Wmissing-prototypes
-Wformat=2 -Wundef -Wcast-qual
```

실제 GCC 버전과 코드 성격에서 각각 지원/효과를 시험한 뒤 고정한다. 이 목록은 모든 프로젝트에 무조건 적용된 검증 완료 조합이 아니다. 새 Custom 코드에는 선택한 warning set을 점진적으로 `-Werror` 처리하되, Vendor 원본의 경고와 분리한다. 경고 의미와 옵션은 공식 GCC 문서를 기준으로 확인한다. [S15]

`-fanalyzer`는 별도 분석 프로필로 수행하고 모델별 false positive·분석 한계를 기록한다. 모든 commit에 가장 비싼 분석을 강제하기보다 변경 위험에 따라 실행 범위를 조절한다.

## 3. 도구별 역할

| 도구 | 주된 역할 | 경계 |
|---|---|---|
| GCC 경고 | 타입/포맷/프로토타입 등 생산 컴파일 문맥 진단 | 규격 의미·장비 동작 증명 아님 |
| GCC analyzer | 경로 기반 결함 탐지 | opaque SDK 계약과 동시성 제한 |
| Cppcheck | C 결함 패턴/설정 기반 분석 | 실제 빌드/라이브러리 모델 필요 |
| clang-tidy | 선택 규칙·이름·일부 결함 검사 | GCC 확장 호환성, C 지원 check 선별 |
| Clang Static Analyzer | 경로 기반 분석 | 모든 TU/간접 호출 완전성 보장 아님 |
| Coccinelle | 의미 패턴 찾기/반복 변환 | 변경 결과 리뷰 필요; Vendor 원본 자동 수정 금지 |
| CBMC | 선택 C 함수의 assertion·메모리 속성 확인 | 모델·loop unwinding·환경 가정에 제한 |
| Frama-C Eva/WP | 값 분석/ACSL 계약 검토·증명 | 계약과 외부 함수 모델이 정확해야 함 |

Cppcheck는 compilation database 입력을 지원한다. 명세가 있는 외부 함수에만 적절한 분석 모델을 작성하고, 경고를 없애려고 임의로 ‘이 함수는 항상 성공’이라고 가정하지 않는다. [S16]

CBMC와 Frama-C는 중요 파서, 길이 계산, 상태 전이, 안전 범위 검사처럼 경계가 작은 모듈에 우선 적용할 후보다. 분석 완료 결과는 검증한 속성·가정·bounds와 함께 기록한다. [S31] · [S32] · [S33]

## 4. 빌드/아키텍처 규칙 검사

Custom 공통 모듈에서 Vendor include/extern/매크로 참조, 모델명 분기, 금지 high-level 심볼, global mutable state, 승인되지 않은 동적 할당/장치 API를 검사한다.

빠른 text lint는 초기 피드백, AST/include graph/link 검사는 더 강한 근거다. 함수명 prefix만 검사해서 경계를 통과시켰다고 하지 않는다. 소스가 아니라 binary-only 경계에서 검사할 수 없는 부분을 명시한다.

생성 파일 직접 수정, 스키마 ID 중복, 문서 링크 단절, 규격 근거 누락, Item 메타데이터와 실제 required capability 불일치도 검사 후보다. 실제 사용할 게이트를 구현하기 전에는 존재하는 CI 기능처럼 보고하지 않는다.

## 5. 시험 레벨

| 레벨 | 대상 | 검증 가능 범위 | 검증 불가/제한 |
|---|---|---|---|
| T0 스키마/정적 | 명세·파일·의존성·빌드 | 형식·구조·타입의 일부 | 실제 SDK 의미 |
| T1 Pure unit | byte helper, parser, builder, 판정 | 입력→출력 의미와 경계 | 실제 SSD 응답 |
| T2 Fake contract | submit/timeout/cancel/state/resource | 공통 계약에 맞춘 로직 | Fake 자체의 현실성 |
| T3 Provider host | SDK stub 경계, 인자/타입 매핑 | ABI 선언에 맞는 사용 일부 | 장비 FW/DMA 실제 동작 |
| T4 HIL contract | 실제 모델별 API·상태·버퍼 | 승인 조건의 행동 | 미시험 조건 전체 |
| T5 평가 검증 | 기존/신규 Item의 목적·조건·판정 | 시험 동등성/변경 의도 | 장비 간 미관측 차이 |
| T6 시간/장기 | 타이밍·동시성·soak·성능 | 해당 setup에서의 계측 근거 | 다른 환경 일반화 |

Host 테스트 프레임워크는 Unity를 우선 후보로 하고 필요시 CMock을 추가한다. Ceedling은 이들을 묶는 별도 빌드/시험 관리 후보이며, CMake와 중복된 정본을 만들지 않도록 선택한다. [S22] · [S23] · [S24]

## 6. 반드시 포함할 반례

| 영역 | 반례 | 기대 |
|---|---|---|
| 파서 | 길이가 필드 끝보다 1바이트 짧음 | 읽기 전 거부/부분 유효성 명시 |
| 파서 | 알려지지 않은 규격/확장 | raw 보존, 추측 해석 금지 |
| 길이 계산 | count×size overflow | allocation/읽기 전에 실패 |
| CQE | NVMe 오류가 정상 반환됨 | 전송 오류와 구별 |
| 음성 평가 | 예상 오류 status 수신 | 정책에 따라 PASS 가능 |
| 요청 수명 | timeout 뒤 늦은 completion | double free/다음 요청 오염 방지 |
| Reset | 이전 세대 callback 도착 | generation 확인, stale 처리 |
| 메모리 | 출력 버퍼가 SDK 내부 소유 | 무단 free/장기 참조 금지 |
| 전역 SDK | A 슬롯 제출 중 B 슬롯 선택 | 소유권 범위에서 충돌 차단 |
| Capability | raw 필드 일부가 SDK에 의해 덮임 | bit-exact 시험 실행 차단 |
| Chamber | 설정 성공, 센서 stale | 안정화 성공으로 판정 금지 |
| Voltage | 요청값이 분해능 밖 | 조용한 clamp 금지 |
| 자원 | 두 Item이 같은 Chamber 목표를 다르게 요구 | 예약/충돌 처리 |
| 정리 | 원 오류 후 cleanup도 실패 | 두 오류와 미확정 상태 보존 |
| 측정 | 호스트 timestamp만 존재 | 실제 효과 시각으로 오인 금지 |
| 빌드 | Model A에서 B SDK 포함 | 빌드 증거 검사 실패 |
| 문서 | 구현/스키마가 같은 잘못된 offset 사용 | 독립 golden vector가 검출 |
| LLM | 존재하지 않는 Vendor 함수 호출 추가 | 실제 심볼/allowlist 검사 실패 |

## 7. Sanitizer와 Fuzzing

ASan/UBSan 등 instrumentation은 Host/Fake 파서·상태 로직에서 우선 사용한다. 타깃·SDK 지원과 성능 영향을 별도 검증한다. 기기 DMA나 비계측 바이너리 내부까지 자동 검출한다고 가정하지 않는다. GCC instrumentation 문서와 실제 타깃 지원을 확인한다. [S21]

Fuzz는 우선 순수 decode/validate 함수에 적용한다. libFuzzer는 coverage-guided fuzzing 도구 후보다. 실장비 API를 직접 fuzz하는 작업으로 확대하지 않는다. [S34]

생성 corpus에는 truncated field, 비정상 length, 순환 capability link, 알 수 없는 enum, 최대 카운터, endian 변형, 중복/역순 completion 이벤트를 포함한다. Fuzz가 아무 실패를 못 찾았다는 것이 규격 정확성을 증명하지는 않는다.

## 8. 기존 구현과 비교

Golden-master는 기존의 관찰 행동을 보존하는 데 유용하지만 기존 결함까지 정답으로 만들 수 있다. 따라서 변경마다 `equivalent`, `bug_fix`, `policy_change`, `optimization`, `unsupported`를 기록한다.

동등성 비교는 PASS/FAIL 하나가 아니라 명령 sequence, 의도된 field, 데이터 패턴, timeout/retry, 자원 상태, 관찰값, 판정 이유를 본다. CID·timestamp·물리 주소처럼 달라질 수 있는 값은 근거 있는 normalization만 허용한다.

같은 DUT에 파괴적인 legacy/new 시험을 동시에 실행해 비교하지 않는다. 비파괴 offline replay, 독립된 승인 실행, 승인된 fixture별 시험을 선택한다. Recording/replay는 실제 장비 동작을 증명하는 것이 아니라 상위 해석·판정 재현성의 검증이다.

## 9. 증거 보고

각 검증은 명령, 도구 버전, 코드/config hash, 대상 프로필, exit code, 결과 파일, 실행 여부, skip/unsupported 사유를 남긴다. `NOT_RUN`, `BUILD_ONLY`, `HOST_PASS`, `HIL_PASS_FOR_PROFILE`, `FAILED`, `BLOCKED`를 구분한다.

성공률/커버리지를 적을 때 분모를 명확히 한다. ‘전체 PASS’는 명시된 suite/profiles에만 쓴다. 실행하지 않은 모델과 실장비는 항상 별도 표시한다.

## 10. R2의 전면 baseline과 구성별 분석

W11에서 Vendor와 Mixed 각각의 baseline을 먼저 만든다. Vendor라는 이유로 전체 warning을 버리지 않는다. 소유권별로 findings와 조치 방식을 구분할 뿐이며 opaque 내부 한계는 명시한다. 새 Custom의 품질 기준을 낮추어 기존 결함을 수용하지 않는다.

모델·subtype·폼팩터 관련 TU/매크로 구성을 분석 matrix로 관리한다. current profile 한 개의 clean 결과는 다른 분기의 검증이 아니다. 분석 불가/실패/미실행은 clean과 별도 상태다. analyzer별 결과의 의미·분모·도구 버전·실제 flags를 보존한다.

## 11. 추가 필수 시험 영역

private command의 namespace/FW mismatch, UART partial frame/interleave/loss, profile unknown/충돌, macro defined-zero, unsigned underflow·중간 산술 overflow, disabled branch 타입 변경, fixture route mismatch, evidence 부족인데 PASS가 되는 경우를 시험 목록에 넣는다.

Clang UBSan의 undefined 그룹과 unsigned overflow/일부 변환 검사는 다르므로 옵션을 실제 버전에서 확인한다. [S44] 타입 계약과 독립 경계 시험을 검사 도구로 대체하지 않는다. 자체 분석 도구의 단계별 기준과 라벨링 corpus 시험은 23장에 상세히 정의한다.

<!-- SOURCE_LINKS_START -->

[S14]: https://gcc.gnu.org/onlinedocs/gcc/Static-Analyzer-Options.html
[S15]: https://gcc.gnu.org/onlinedocs/gcc/Warning-Options.html
[S16]: https://cppcheck.sourceforge.io/manual.html
[S21]: https://gcc.gnu.org/onlinedocs/gcc/Instrumentation-Options.html
[S22]: https://github.com/ThrowTheSwitch/Unity
[S23]: https://github.com/ThrowTheSwitch/CMock
[S24]: https://www.throwtheswitch.org/ceedling
[S31]: https://www.cprover.org/cbmc/
[S32]: https://www.frama-c.com/fc-plugins/eva.html
[S33]: https://www.frama-c.com/fc-plugins/wp.html
[S34]: https://llvm.org/docs/LibFuzzer.html
[S44]: https://clang.llvm.org/docs/UndefinedBehaviorSanitizer.html
