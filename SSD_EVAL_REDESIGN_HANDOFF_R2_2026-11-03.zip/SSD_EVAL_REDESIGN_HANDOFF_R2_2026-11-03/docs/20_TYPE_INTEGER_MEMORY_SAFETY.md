# 20. 타입·정수·메모리 안전의 전면 재설계

## 1. 이번 작업은 이름 정리가 아니라 수치 계약 복원

사용자는 현재 코드에 적절하지 않은 변수 타입과 overflow/underflow 문제가 있을 수 있음을 알렸다. 실제 결함 위치를 여기서 확정할 수는 없지만, 이를 재설계의 핵심 조사 축으로 넣어야 한다. `int`를 전부 `uint64_t`로 바꾸거나 캐스트를 추가하는 것은 해결책이 아니다.

변수마다 **도메인 의미 → 필요한 값 범위 → 표현 타입 → 계산 중간 타입 → 경계 변환 → 실패 정책** 순으로 검토한다. 현재 타입은 관찰 사실이고 새로운 타입은 요구와 범위에 의해 정당화되어야 한다.

## 2. 모든 변수의 목록과 상세 검토 우선순위

전역·file-static·함수 인자·지역변수·구조체 필드·enum·매크로 상수·리턴 타입을 inventory에 포함한다. 지역변수는 `file + function + lexical scope + declaration location + build profile`로 구별한다. 자동 생성된 선언/참조 표를 활용하고, 각 단순 루프 변수의 설명을 별도 MD에 수동 복사하는 낭비는 피한다.

그러나 다음 변수는 깊은 의미 검토가 필수다: buffer 길이/offset/count, LBA/namespace size, 시간·deadline·반복수, 전압/전류/온도, FW 전달 값, 포인터/주소/handle 변환, status 반환, wire field 변환, 배열 인덱스, 누적 통계, 다중 thread 상태. 모든 파일에 조사 상태를 남기고 위험 변수가 누락되면 구현을 진행하지 않는다.

## 3. 타입 선택 기준

| 의미 | 권고 후보 | 검토할 함정 |
|---|---|---|
| wire 정수 | 규격에 맞는 fixed-width | host endian과 wire endian 혼동 |
| host object size | `size_t` | 32/64비트 차이, 외부 숫자→size_t narrowing |
| pointer difference | `ptrdiff_t` 등 타깃 적합 타입 | 음수→unsigned 변환 |
| 온도/부호 있는 물리량 | 충분한 signed 정수와 단위 | 음수/최솟값·센서 invalid |
| 카운터/블록 수 | 근거 범위의 unsigned/fixed-width | unsigned wrap이 허용되었다고 안전하지 않음 |
| 넓은 protocol counter | 원시 폭 보존 구조/검증된 넓은 타입 | double로 정밀도 손실 |
| 주소/메모리 handle | 주소 공간별 별도 wrapper | CPU ptr·IOVA·장비 ID 동일시 |
| 다중 상태/판정 | 구분된 enum + unknown/unset | bool 또는 0으로 누락을 성공 취급 |

`uint32_t`가 모든 타깃에서 존재하거나 원하는 접근 정렬을 보장한다고 가정하지 말고 툴체인 계약에서 확인한다. Vendor ABI 타입을 수정하지 않고, 경계에서 범위 확인 후 Custom 타입으로 변환한다. 구조체 layout은 타깃 ABI와 flags에 연결한다. [S19]

## 4. 위험 산술 패턴과 기대 처리

| 패턴 | 위험 | 재설계 기준 |
|---|---|---|
| `count * size` | 결과 할당/복사 크기 overflow | 계산 전 경계 또는 checked multiply |
| `offset + length` | 합 overflow로 bounds 우회 | `offset <= size` 후 `length <= size-offset` 등 검증 |
| `count - 1` | count=0의 underflow | 입력 0 의미를 먼저 결정; field 인코딩 별도 |
| `wide = small * small` | 넓은 변수 대입 전에 좁은 산술 발생 | 중간 연산 타입과 범위를 명시 |
| `signed < unsigned` | 음수가 큰 unsigned로 변환 | 도메인 검증 후 비교 방식 결정 |
| `1 << bit` | 타입 폭/부호/shift 범위 | typed constant와 shift 사전 검증 |
| `-minimum_signed` | 양수로 표현 불가 | 사전 검사/별도 표현 |
| `deadline = now + duration` | 긴 실행 wrap/overflow | clock 범위·checked add·deadline 모델 |
| `value * scale / divisor` | 중간 overflow·0 나눗셈·반올림 | 범위/순서/정밀도/rounding 정책 |
| `length - consumed` | consumed가 큰 경우 underflow | 상태 invariant와 범위 검사 |
| `char`에서 byte decode | signed char에 따른 확장 | byte를 명시 unsigned로 해석 |
| 출력 format과 실제 타입 불일치 | 값 왜곡/정의되지 않은 동작 위험 | inttypes/format 검사·typed formatter |

표는 조사 패턴이지 해당 소스에서 발견한 결함 목록이 아니다. 실제 결함은 구성·재현 입력·영향을 함께 기록한다. 정상적인 modular counter 계산은 요구에 따라 허용할 수 있으나 목적/범위/테스트/정적분석 예외를 남긴다.

## 5. 산술 API 후보

공통 base 모듈에 제한된 `checked_add`, `checked_sub`, `checked_mul`, 검증된 narrowing/단위 변환 helper를 둘 수 있다. 모든 연산을 대형 수치 프레임워크에 넣을 필요는 없다. 외부 입력·메모리 크기·타이밍·판정에 영향을 주는 경계에 우선 적용한다.

GCC는 overflow를 검사하는 산술 builtin을 제공한다. 정확한 컴파일러 지원을 확인하고, 실패 때 계산 결과를 계속 사용하지 않는 Custom 계약으로 감싼다. C23 checked arithmetic을 채택할 수도 있지만 기존 GCC/SDK 지원 확인 없이 기본 언어 요구를 올리지 않는다. [S43]

실패 정책은 `reject/report`를 기본 후보로 한다. saturation, wrapping, clamp는 의미가 정당화된 경우에만 명시한다. 전압 값을 자동 clamp하여 잘못된 시험을 정상 실행으로 숨기지 않는다.

## 6. 정적분석과 동적 검증을 함께 사용

생산 GCC 경고/분석, 실제 ABI 타입/전처리 자료, 필요한 Clang/Cppcheck 검사를 함께 검토한다. 경고를 캐스트나 전역 suppression으로 없애지 않는다. 외부 API 결과는 성공/오류/음수 길이/부분 데이터 같은 실제 계약에 따라 분기한다.

Clang 문서의 `-fsanitize=undefined` 그룹은 unsigned overflow와 일부 implicit conversion 검사를 포함하지 않는다. 별도의 정수 검사 옵션이 필요한지 Host profile에서 확인한다. 이것은 GCC에 같은 옵션이 있다는 주장이 아니다. Sanitizer로 실행하지 않은 경로와 비계측 SDK 내부는 여전히 검증되지 않는다. [S44] [S21]

중요 순수 함수에는 CBMC/Frama-C 등의 좁은 속성 검증을 후보로 둘 수 있다. 가정과 loop bound가 현실과 다르면 증거를 잘못 일반화할 수 있으므로 적용 범위를 기록한다. [S31] [S32] [S33]

## 7. 필수 반례 세트

0, 1, 최솟값, 최댓값, 허용 경계 직전/경계/직후, 출력형 한계, signed↔unsigned, 32비트 size_t, 중간 표현 overflow, 가변 길이 0, 길이 불일치, shift 0/폭-1/폭, 나눗셈 0, 누적 run count 초과, timestamp wrap 조건을 적절한 함수에 배정한다. 테스트 수가 많다는 이유로 무관한 함수에 모든 조합을 기계적으로 생성하지 않는다.

경계값 기대 결과는 **새 구현의 출력에서 자동 채취하지 않는다.** 수학적 계약과 승인 protocol 정의로 산출한다. 과거 코드와 같은 잘못된 값이 나온다고 regression PASS가 되지 않도록 oracle을 분리한다.

## 8. 메모리와 lifetime

배열 bound, 잘못된 `sizeof(pointer)`, flexible array 크기, alignment, endian, strict-aliasing, struct padding, union 해석, double free, use-after-free, scope 종료 후 callback, uninitialized output을 조사한다. `memcpy`를 쓰면 endian/필드 의미가 자동 해결되는 것은 아니다.

DMA buffer는 일반 heap과 수명·coherency 계약이 다를 수 있다. timeout/Reset 이후 해제 가능성을 별도 확인한다. CPU buffer의 sanitizer 성공을 실제 DMA 안전 보증으로 확대하지 않는다. 고정주소가 수치형 macro라면 주소 공간·크기·접근 폭·부작용·정렬을 기록한다.

## 9. 파일·함수·변수 이름 규칙과 연결

`se_nvme_health_decode.c`, `se_uart_frame_decode.c`, `se_checked_arithmetic.c`, `se_variant_resolve.c`는 제안 이름이다. `util.c`, `misc.c`, `common2.c`, `test_new.c`에 서로 다른 책임을 계속 넣지 않는다. 파일명은 domain+책임을 드러내며 OS의 대소문자 차이에도 충돌하지 않아야 한다. 공개 헤더·구현·테스트 이름 관계를 정한다.

함수 반환 status와 시험 verdict는 별개다. 변수 이름의 `_bytes`, `_blocks`, `_uv`, `_mdegc`가 실제 단위 변환과 맞는지 검토한다. 단위 표와 허용 약어 표는 docs 정본으로 관리하고 변경 시 코드·명세·시험을 함께 갱신한다.

## 10. 산출물과 통과 기준

`type_inventory`, `numeric_range_contracts`, `conversion_boundaries`, `integer_findings`, `abi_layout_evidence`, `numeric_test_matrix`가 필요하다. 확정 결함·의심·의도된 wrap·오탐·분석 불가를 나눈다. 새 Custom에는 검토되지 않은 위험 산술/캐스트를 남기지 않고, 예외가 필요하면 근거와 재검토 조건을 연결한다.

<!-- SOURCE_LINKS_START -->

[S19]: https://gcc.gnu.org/onlinedocs/gcc/Structures-unions-enumerations-and-bit-fields-implementation.html
[S21]: https://gcc.gnu.org/onlinedocs/gcc/Instrumentation-Options.html
[S31]: https://www.cprover.org/cbmc/
[S32]: https://www.frama-c.com/fc-plugins/eva.html
[S33]: https://www.frama-c.com/fc-plugins/wp.html
[S43]: https://gcc.gnu.org/onlinedocs/gcc/Integer-Overflow-Builtins.html
[S44]: https://clang.llvm.org/docs/UndefinedBehaviorSanitizer.html
