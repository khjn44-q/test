# 06. Chamber·Voltage·공유 자원·실행 안전·타이밍

## 1. 환경 제어는 단순 util이 아니다

온도/전압은 시험 조건과 안전에 직접 연결된다. 설정 요청, 장비가 받아들인 목표값, 실제 센서 값, DUT 상태, 판정 허용 범위를 분리한다. 안전 한계와 평가 의도에 따른 스트레스 범위도 별개의 정책이다.

숫자 한계를 이 문서에서 임의로 지정하지 않는다. 장비 매뉴얼·Fixture 사양·DUT 평가 승인·사내 안전 지침으로 채워야 한다. 예제 온도/전압을 운영 기본값으로 쓰지 않는다.

## 2. Chamber 계약

| 동작 | 명세 |
|---|---|
| set_target | 단위, 분해능, 허용 범위, 요청 접수의 의미 |
| read_target | 장비가 현재 보유한 설정값인지, 마지막 요청 cache인지 |
| read_sensor | 센서 위치·단위·timestamp·교정/신뢰도·stale 여부 |
| wait_stable | 허용 밴드, 관측 기간, 샘플 간격/손실, 최대 대기, 취소 |
| control_mode | ramp/hold/local/remote 등 실제 제공 모드 |
| stop/safe action | 장비별 승인된 절차와 확인 가능한 결과 |

Chamber 센서 온도, SSD 내부 센서, 보드/Fixture 온도를 동일시하지 않는다. 일정 기간의 측정 샘플이 범위 내였다는 것과 그 사이의 모든 순간이 범위 내였다는 것은 다르다. 관측 빈도가 부족한 시험은 근거 수준을 명시한다.

안정화 목표와 밴드는 Item 정책이고, 장비가 표현 가능한 분해능/범위는 Capability다. 불가능한 값을 입력하면 거부하거나 명시적으로 제안/승인받은 변환을 사용한다. 자동으로 가까운 값에 맞추고 원래 값으로 로그를 남기지 않는다.

## 3. 전원/전압 계약

Rail ID, Slot 매핑, 전원 공급장치 채널, 목표 전압, 실측 전압/전류, current-limit, 출력 enable, ramp/slew 제어 여부, 보호 상태, 타임스탬프를 구분한다.

출력 OFF 명령 성공은 DUT 전압이 기준 이하로 떨어졌다는 직접 증거가 아닐 수 있다. readback이 없거나 계측 지연이 크면 그 한계를 기록한다. 전원 차단 유지 시간은 ‘명령 전송 간격’인지 ‘전압이 특정 범위에 있었던 시간’인지 명세해야 한다.

Power Cycle, brownout, glitch처럼 서로 다른 시험은 하나의 모호한 `reset()`으로 합치지 않는다. 승인된 환경에서는 의도적 비정상 전압을 시험할 수 있지만 설비 보호/하드웨어 인터록을 우회하는 것을 정상 시험 기능으로 만들지 않는다.

## 4. 공유 Resource Topology

논리 자원은 물리 연결을 가진다. 예: 하나의 Chamber에 여러 Slot, 하나의 Rail에 두 Slot, 하나의 Root Port에 여러 Endpoint, 하나의 Vendor 세션에 전체 장비 전역 상태.

**예약 단위는 함수명이 아니라 실제 영향 범위**다. 개별 Slot만 lock해도 공통 Chamber 설정은 충돌한다. PCIe Reset이 같은 하위 버스의 다른 DUT까지 건드리는지 확인한다.

초기에는 복잡한 스케줄러 대신 정적 자원 표, exclusive/shared lease, 정해진 lock 순서, 취소 가능한 대기로 충분할 수 있다. 병렬 성능이 검증되지 않으면 장비 단위 직렬 실행을 명시적으로 선택한다.

Vendor가 전역 `current_slot`을 사용한다면 Context를 여러 개 만들어도 SDK가 reentrant해지지 않는다. 상태 설정부터 비동기 작업 종료까지 유효한 소유권이 필요할 수 있다. Provider 전체 직렬화, 세션 분리, Worker 분리의 비용을 비교한다.

## 5. 실행 상태와 순서

권고 lifecycle은 `preflight → acquire → prepare → execute → observe → evaluate → finalize → release`다. 실장비 코드에서 실행될 필요가 있는 동작과 순수한 사전 검증을 구분한다.

Preflight는 장비 프로필, 실제 연결된 모델/SDK, DUT identity, 허용된 시험, 자원 사용권, 센서 신뢰도, 데이터 소거 영향, 필수 observation을 검사한다. 모델 불일치는 경고 후 계속하지 않고 안전한 중단을 기본으로 한다.

장비 ID를 런타임에서 확인할 수 없다면 어떤 외부 절차로 연결을 보장했는지 기록한다. 검증할 수 없는데 ‘자동 감지 완료’로 표시하지 않는다.

## 6. 취소·오류·정리

취소는 새 동작 제출을 중단하는 것, 이미 제출된 요청을 취소하는 것, 장비를 안전 상태로 만드는 것의 세 문제다. 각각 성공/실패/미확정을 기록한다.

정리에서 기존 오류를 덮어쓰지 않는다. 최초 오류, 정리 중 오류, 마지막으로 관측한 장비 상태, 추가 수동 조치 필요 여부를 보존한다. ‘항상 전원 OFF’나 ‘항상 25도로 복귀’를 보편적인 안전 정책으로 선언하지 않는다. 설비·Fixture·시험별 승인된 정리 절차가 다를 수 있다.

비정상 종료 시 자동 복구는 증거를 잃거나 시험 중단 조건을 변경할 수 있다. 진단 데이터 확보, 안전 조치, 자원 해제 순서와 허용 시간을 미리 정한다. 외부 Watchdog와 하드웨어 인터록은 Custom 코드와 독립된 보호 수단으로 고려한다.

## 7. 타이밍을 계약으로 취급

| 시각 | 의미 |
|---|---|
| requested_at | 호스트가 동작을 요청한 시각 |
| accepted_at | SDK/장비가 접수했다고 확인한 시각 |
| physical_effect_at | 실제 효과를 측정/캡처한 시각, 확보 가능한 경우만 |
| observed_at | 센서/호스트가 값을 얻은 시각 |
| completed_at | 정의된 완료 계약을 충족한 시각 |

서로 다른 Clock Domain 사이의 offset·drift·측정 오차를 관리한다. `sleep_us()` 호출을 했다는 사실만으로 물리적 지연 정밀도를 주장하지 않는다. 로그 추가·계측·sanitizer·debug build는 실행 특성을 바꿀 수 있으므로 타이밍 검증은 실제 배포 프로필과 연결한다.

고속 I/O와 느린 Chamber 제어를 하나의 blocking loop에 넣지 않는다. 단일 스레드에서도 이벤트 진행 또는 장비 시퀀스 엔진을 사용할 수 있으며, 멀티스레드가 항상 답은 아니다. 정확한 trigger가 필요한 Item은 장비의 트리거/시퀀스 기능을 요구해야 한다.

## 8. 기록 구조

Run header에는 code commit, build/config hash, Provider/SDK hash, 장비 모델/FW, DUT 식별·FW, spec profile, Item revision, 자원 매핑, 승인 정보, 시간 기준을 둔다.

Event에는 event ID, Run/Item/step/request/resource ID, 요청값, 적용값, 관측값, 단위, timestamp source, raw reference, 결과 상태를 둔다. 모든 I/O payload를 항상 기록하는 것은 성능·보안·용량 문제이므로 메타데이터/표본/문제 구간 보존 정책을 명시한다.

비동기 이벤트는 correlation ID로 연결한다. 로그를 남겼다는 사실을 실제 하드웨어 효과 관측과 혼동하지 않는다. Log drop·buffer overflow·timestamp 미확정도 기록한다.

## 9. 보안과 실행 승인

개발 에이전트의 기본 모드는 `OFFLINE_NO_HARDWARE`다. Host 단위시험 성공이 장비 실행 권한을 부여하지 않는다. 장비 실행은 별도 운영 계정/프로세스/runner 권한과 승인된 Run Plan으로 통제한다.

Prompt의 ‘위험 작업 금지’만으로는 보호가 되지 않는다. 장치 접근 권한, 네트워크 ACL, 승인된 실행 엔트리, 서명/해시된 Run Plan, 가능한 경우 설비 interlock으로 강제한다. 상세 구현은 사내 시스템에 맞게 선택한다.

외부 스킬 설치와 도구 스크립트도 공급망 검토 대상이다. 소스가 포함된 index·build database·core dump·LLM 대화는 원본만큼 민감할 수 있다. 외부 임베딩/RAG 서비스로 자동 업로드하지 않는다.

## 10. 폼팩터·세부타입·UART가 추가하는 자원 영향

새 자원 그래프에는 Fixture revision, 슬롯 배선, rail 공유, UART multiplexer/port, reset domain, 장비 세부타입의 제어 범위를 포함한다. form factor가 같은 것만으로 동일한 연결/전압을 승인하지 않는다. shared resource 변경은 동작을 요청한 Slot 이외의 DUT에 영향을 줄 수 있다.

UART 명령이 내부 FW 상태를 바꾸면 NVMe/PCIe 동작과 충돌하는지 확인한다. UART를 단순 logging util로 보고 자원 예약에서 제외하지 않는다. 실제로 독립 관측만 가능한 포트라면 read-only capability로 선언한다. 안전값·정리 순서·run resume은 미확인 상태에서 일반적인 기본값을 넣지 않는다.
