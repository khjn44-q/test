# 21. Git 기준선과 전면 신규 구현의 전달 전략

## 1. 보존할 것은 근거이지 기존 구현 구조가 아니다

사용자는 현재 혼합 코드를 유지할 의사가 없으며 이번에 전면 재설계하려 한다. 따라서 기존 함수명·파일 구조·모듈 경계·잘못된 타입·우연한 동작의 호환은 요구하지 않는다. 보존하는 원본/snapshot은 분석·추적·사고 조사 자료다. 최종 Custom 코드에 legacy를 계속 링크하거나 wrapper를 영구 유지해야 한다는 뜻이 아니다.

다만 기존 code와 운영 이력에서 중요한 평가 의도, 모델 예외, 안전 조건이 드러날 수 있다. 이를 복원하여 **승인한 요구만** 새 구조에 옮긴다. 과거 구현과 다르게 동작하는 것은 허용하되 변경 근거·새 기대 결과·검증을 기록한다.

## 2. Git으로도 빠질 수 있는 입력

commit hash는 tracked 파일의 기준을 주지만 dirty working tree, untracked/ignored generated header, 외부 SDK, submodule, LFS 실제 내용, 로컬 설정, linker script, 빌드 환경까지 자동 포함하지 않는다. Git의 tracked/untracked/ignored 조회 기능을 사용하고 실제 build input inventory를 별도로 만든다. [S50]

기록 항목: 저장소 ID, 현재 commit/branch, dirty diff hash, untracked/ignored 조사 범위, submodule commits, 외부 dependency 해시, 생성 입력/도구, source archive와 Vendor release 대응. 민감한 파일 내용은 허용된 사내 영역에만 보관한다. 브랜치 이름만으로 특정 배포를 식별하지 않는다.

## 3. 저장소 구조 후보

| 후보 | 장점 | 비용/조건 |
|---|---|---|
| 같은 repo의 새 루트/branch | 이력·문서·비교가 쉬움 | 기존 빌드/경로와 분리, 불필요한 자동 CI 주의 |
| 별도 새 repo + 원본 해시/참조 | 신규 구조가 가장 명확 | 원본 접근권한·추적 연결·패키지 공급 필요 |
| 같은 repo에서 단계적 디렉터리 교체 | 배포 통합 편의 | legacy 링크가 계속 남는 위험, 경계 게이트 필요 |

**권고 가설:** 새 Custom 루트를 만들고 원본·혼합 코드는 읽기 전용 참조로 둔다. 같은 repo인지 별도 repo인지는 보안/빌드/배포 체계로 선택한다. 장비별 장기 branch를 새 구조의 공통화 수단으로 삼지 않는다. 모델 차이는 한 소스 트리의 Provider/profile로 표현한다.

## 4. 작업 권한과 변경 방지

현재 사용자의 dirty 변경을 자동 stage/commit/삭제하지 않는다. `reset --hard`, `clean`, force push, 기준 태그 이동, 원본 파일 정리 같은 행위는 기본 작업 범위에 없다. 원본 보존은 읽기 전용 권한과 해시 검사로 뒷받침한다. 원본을 보관할 경로도 실제 빌드 상대경로 제약을 고려한다.

Git worktree는 병렬 작업 디렉터리를 나누는 후보다. 저장소 자원 일부를 공유하므로 repo 관리 명령과 hardware/SDK 상태를 격리하는 수단은 아니다. worktree별 build/output/cache 경로를 분리하고 장비 접근 권한은 별도 통제한다. [S49]

## 5. 개발 배치의 의미

전면 재설계는 한번의 거대한 무검증 commit을 요구하지 않는다. docs/계약→반례→순수 모듈→Provider→Item 순으로 새 코드의 검증 단위를 작게 나눈다. **단계적 검증은 기존 코드 유지 의무가 아니다.** 평가 커버리지는 old/new 비교뿐 아니라 승인된 목표 명세 기준으로 판단한다.

공통 헤더·schema·root build에는 단일 변경 소유자를 둔다. 모델별 source audit는 병렬 가능하지만 공통 타입을 여러 Agent가 각자 만들지 않는다. 모든 PR/commit에 요구/계약/결정/검증 ID를 연결하는 방식을 검토한다. 실제 사내 Git 호스팅과 승인 프로세스에 맞추고 여기서 특정 서비스를 가정하지 않는다.

## 6. Vendor 업데이트

새 Vendor 원본을 독립 기준선으로 추가하고 모든 관련 파일·타입·macro·memory·binary/FW 제약 차이를 조사한다. 과거 혼합 patch를 자동으로 새 Vendor에 적용하지 않는다. 신규 Custom은 변경된 boundary binding과 capability 검증을 통해 적응한다.

원형이 같아도 semantics/auto retry/초기값이 바뀔 수 있다. 변경이 없어 보이는데 실제 장비 FW가 바뀌었다면 계약 검증 대상이 될 수 있다. 신규 원본 보관과 운영 승격은 별도 승인이다.

## 7. 배포·중단·되돌림

이전 버전 rollback이 SSD 상태·온도·전압·FW·진행 중 DMA를 되돌린다는 보장은 없다. 배포 전 quiescence, 장비 상태 확인, profile identity, log schema 호환, 진행 중 run의 처리 규칙을 정한다. rollback 대상은 승인된 새 framework의 이전 release일 수 있으며, 사용자 의사와 무관하게 기존 혼합 코드를 영구 운영 fallback으로 강제하지 않는다.

운영 승격은 지원된 프로필/Item 목록과 한계를 함께 릴리스한다. 폐기한 Item·기능은 이유와 대체 여부를 기록한다. 소스 삭제는 별도 보존 정책을 따른다.

<!-- SOURCE_LINKS_START -->

[S49]: https://git-scm.com/docs/git-worktree
[S50]: https://git-scm.com/docs/git-ls-files
