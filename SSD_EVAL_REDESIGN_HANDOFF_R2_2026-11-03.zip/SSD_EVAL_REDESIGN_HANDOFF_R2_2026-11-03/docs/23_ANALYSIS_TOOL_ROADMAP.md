# 23. 정적분석 체계와 전용 분석 도구의 단계적 검토

## 1. 지금 필요한 것은 종합 감사이며, 도구 개발은 그 다음 판단이다

Vendor 원본과 현재 혼합 코드 모두 조사·정적분석 대상이다. Vendor 경고가 많다는 이유로 전체 제외하지 않는다. **수정할 수 없는 코드도 위험을 알아야 하는 코드**다. 결과는 vendor/mixed/new-custom로 구분하고, 결함의 출처·영향·회피 가능성·업체 문의 필요성을 기록한다.

새 Custom은 높은 기준으로 작성하지만 wrapper 하나로 opaque SDK 내부 결함을 모두 고칠 수는 없다. 특정 경로를 차단하거나 입력 범위를 제한해야 할 수 있으며, 이 제한은 22장의 한계로 연결한다.

## 2. 기본 분석 파이프라인 후보

`입력 manifest → build/config 문맥 → 파일/심볼/타입/분기 inventory → 도구별 분석 → 사실/진단 정규화 → 검토/반례 → 계약·질문·한계 → 변경 영향 → 증거 보고`.

GCC `-fanalyzer`는 결함 탐지 도구이며 오탐·미탐을 가질 수 있다. Clang/Cppcheck도 실제 flags와 SDK 모델의 제약을 보고해야 한다. ‘경고 0 = 안전’이라는 gate를 만들지 않는다. [S14] [S16] [S17]

## 3. 도입 후보 4단계

| 단계 | 무엇을 만드는가 | 채택 조건 | 하지 않을 일 |
|---|---|---|---|
| A0 기존 도구 실행 기준선 | pinned commands/config/results | 최초 필수 | 새 parser/분석 엔진 개발 |
| A1 얇은 수집·정규화·보고 도구 | inventory, refs, coverage, findings merge | 반복 실행·프로필 관리 필요 | LLM 설명을 확정 사실로 저장 |
| A2 프로젝트 특화 규칙 | Vendor 경계·타입 변환·profile·단위 패턴 | 반복 결함과 규칙의 유효성 확인 | 도구 오탐을 고치려고 소스 의미 변조 |
| A3 작은 전문 분석 확장 | 선택 data-flow/state/sequence 모델 | A0~A2의 구체적 공백과 이득 입증 | ‘전체 C 안전 증명’ 프로젝트로 확대 |

A1부터 CodeChecker 같은 기존 기반을 비교할 수 있다. SARIF는 결과 교환의 한 후보이지 도구의 진단 의미나 정확도를 통일하는 규격은 아니다. 사내 저장 형식과 원시 결과 보존을 함께 설계한다. [S51] [S52]

## 4. 분석 도구 자체의 데이터 계약

입력에는 source/SDK/tool hash, profile, 실제 compiler args, 원본/전처리 경로, 분석 대상 범위와 권한이 들어간다. 출력에는 fact/diagnostic/LLM hypothesis를 분리하고, 각각 source span, symbol key, presence condition, evidence, tool rule, confidence의 정의, 상태와 미분석 이유를 둔다.

`INVENTORIED`, `PARSED`, `ANALYZED`, `REVIEWED`, `MEASURED`는 단계별 상태다. 분석 실행 실패를 빈 findings로 출력하지 않는다. 일부 TU 파싱 실패가 있어도 나머지 결과는 보존하되 총분모와 미완료 범위를 드러낸다. 해시/프로필이 달라지면 cache 재사용 근거를 다시 확인한다.

## 5. 프로젝트 특화 규칙 후보

공통 코드의 Vendor include/extern/high-level 호출, schema 없는 protocol magic offset, uint64_t 대입 전 좁은 산술, unknown→supported 기본값, setpoint→measured로 사용, timeout 후 lease 반환, stale generation, UART frame 길이 무검증, subtype/form-factor 분기 누출, private opcode namespace 누락, read-clear register의 무분별한 RMW, 실패 결과 미사용 등을 후보로 둔다.

일부는 text lint로 빠르게 찾을 수 있지만 이름이 다르거나 alias가 있으면 놓친다. 의미가 필요한 규칙은 Clang AST/검증된 compiler 기반 모델을 사용한다. 사내 컴파일러와 해석이 다르면 한계를 표시한다. LLM에게 C parser와 alias 분석기를 즉흥적으로 새로 작성시키는 것은 기본안이 아니다. [S05]

## 6. SDK/외부 함수 모델링

불명확한 SDK 함수에 `always_success`, `no_side_effect`, `takes_ownership` 같은 가정을 넣어 analyzer 경고를 없애면 안 된다. 모델은 실제 계약 근거와 검증 범위를 가진다. unknown 외부 효과는 보수적인 상태/보고로 표현한다.

일반 동시성 도구가 장비 DMA·별도 FW·전역 슬롯을 모두 이해한다고 가정하지 않는다. 분석 모델과 실제 계약시험이 어디에서 보완되는지 명시한다. Device API stub가 실제 ABI/헤더를 가리지 않게 분리한다.

## 7. 분석 도구 품질 시험

규칙마다 known-bad와 known-good fixture를 작성한다. 한 줄 패턴뿐 아니라 함수 포인터, macro, 여러 TU, 구성별 타입 차이, generated source, alias, inactive branch, timeout cleanup 등의 변형을 포함한다. vendor 원본을 수정하여 fixture를 만들지 않고 합법적으로 재현한 최소 사례를 사용한다.

검출/오탐 수는 라벨링한 corpus에 대해서만 보고한다. 전체 실제 결함 수를 모르므로 일반적인 false-negative rate를 정확히 안다고 주장하지 않는다. 규칙이 의도된 modular arithmetic이나 negative command를 부당하게 막지 않는지 확인한다. suppression에는 rule/profile/span/reason/owner/expiry를 남긴다.

## 8. 자체 도구 개발로 넘어갈 결정 기준

반복 분석 비용, 누락되는 프로필/규칙, 검증 가능한 개선 목표, 유지보수 담당자, 언어/SDK 호환성, 오프라인 설치/라이선스, 결과 재현성을 비교한 ADR을 작성한다. 단순 HTML 보고서가 필요한데 범용 graph platform을 만드는 것은 피한다. 검색도 manifest/ID/rg/symbol index로 해결되는지 먼저 측정한다.

도구 개발은 별도 작업 W31로 분리하고 승인 없이는 제품 재설계의 필수 선행으로 만들지 않는다. 단, 확인된 분석 공백이 고위험 경로를 막으면 그 경로는 다른 신뢰할 검증 또는 도구 보완 전까지 차단한다.

<!-- SOURCE_LINKS_START -->

[S05]: https://clang.llvm.org/docs/LibTooling.html
[S14]: https://gcc.gnu.org/onlinedocs/gcc/Static-Analyzer-Options.html
[S16]: https://cppcheck.sourceforge.io/manual.html
[S17]: https://clang.llvm.org/extra/clang-tidy/
[S51]: https://codechecker.readthedocs.io/en/latest/
[S52]: https://docs.oasis-open.org/sarif/sarif/v2.1.0/sarif-v2.1.0.html
