# 22. 장비 한계·비동등성·실행 가능성의 명시적 관리

## 1. 공통 인터페이스는 동일한 물리 능력의 증명이 아니다

같은 Item이 세 모델에서 컴파일되는 것, 명령을 보낼 수 있는 것, 같은 조건을 만들 수 있는 것, 같은 수준으로 관찰하고 판정할 수 있는 것은 다르다. 장비별로 피할 수 없는 차이는 없애는 척하지 않고 **구조화된 제한 + 사람이 읽는 한계 문서**로 남긴다.

최소 파일 후보는 `docs/limitations/INDEX.md`, profile별 한계 문서, `profiles/limitations/*.yaml`, Item 영향 목록이다. 한계 registry는 build/preflight/report에 연결하고 단순 부록으로 버리지 않는다.

## 2. 한계의 분류

| 구분 | 의미 | 처리 |
|---|---|---|
| PHYSICALLY_UNSUPPORTED | 하드웨어 능력 없음이 확인됨 | 해당 평가 차단 또는 승인된 다른 평가 |
| SDK_UNSUPPORTED | SDK 인터페이스로 표현/관찰 불가 | 요청 불가 범위 명시·업체 문의 |
| NOT_IMPLEMENTED | 가능성은 있으나 새 코드 미구현 | 구현 backlog; hardware 부족으로 오인 금지 |
| NOT_VERIFIED | 사용 가능 주장 있으나 필요한 증거 없음 | 검증 작업/실행 제한 |
| UNKNOWN | 정보 자체 부족 | 질문/조사 blocker |
| FORBIDDEN | 안전·권한·라이선스 정책상 금지 | 승인 없는 우회 금지 |
| KNOWN_DEFECT | 확인된 오류/비정상 | quarantine/보완/제한 범위 |
| OBSERVABILITY_LIMIT | 효과는 만들 수 있으나 필요한 관측 부족 | 판정 근거 제한 |
| NON_EQUIVALENT | 다른 모델과 의미/조건이 다름 | 비교 가능 범위·별도 variant |

위 enum은 제안이며 조직 용어로 조정할 수 있다. 그러나 미지원과 미확인을 같은 bool로 합치지 않는다. `NOT_APPLICABLE`은 해당 시험 목적이 대상에 적용되지 않는다는 별도 판정으로 정당화해야 한다.

## 3. 한계 카드의 필수 필드

ID, 적용 family/subtype/HW/SDK/FW/Fixture/DUT/dialect/build profile, operation/field, 조건식, 원인, 근거, 확인 상태, 영향 Item, 실행 허용 여부, verdict/evidence 영향, 대안, 대안의 비동등점, 책임자, 재검토 trigger, 만료/재검증 조건을 기록한다.

예를 들어 ‘A 모델 raw 명령 가능’ 대신 ‘해당 SDK profile에서 이 명령의 특정 bit는 보존을 확인하지 못했고, 이 bit를 검증하는 Item은 BLOCKED’라고 쓴다. 실제 제한값과 모델 특성은 소스/실험 확인 전 채우지 않는다.

## 4. 실행 결과와 비교 수준을 두 축으로

실행/판정 상태는 PASS/FAIL/ERROR/BLOCKED/UNSUPPORTED/INCONCLUSIVE 등을 가진다. 별도로 비교 근거 상태는 `EQUIVALENCE_ESTABLISHED_FOR_SCOPE`, `PARTIAL_COMPARABILITY`, `NON_EQUIVALENT`, `NOT_ASSESSED` 등을 가질 수 있다.

어떤 모델의 자체 조건에서 PASS했다고 다른 모델과 동등한 평가를 했다는 뜻은 아니다. 낮은 queue depth, 느린 trigger, 다른 센서 위치, coarse voltage step, UART 로그 손실 등이 평가 의미에 영향을 주는지 Item별로 판단한다. 실행 가능성과 비교 가능성을 한 필드로 합치지 않는다.

## 5. 대체 실행 정책

기능이 없으면 보통 `BLOCKED/UNSUPPORTED`로 종료한다. 에뮬레이션/다운그레이드를 허용하려면 별도 Item variant/revision, 목적의 변경, 적용 조건, 다른 결과 라벨, 승인·검증을 요구한다. 원래 조건을 기록하고 실제로는 낮춘 조건으로 실행하는 것은 금지한다.

설비 보호 때문에 허용 범위가 더 좁다면 사용자에게 승인된 선택지를 제시하되 자동으로 clamp하지 않는다. 안전 제한과 시험 목표가 충돌하면 실행을 중단한다. 제한을 늘리기 위해 Vendor 검사나 hardware interlock을 무력화하지 않는다.

## 6. 업데이트와 영향 추적

SDK, 장비 FW, Fixture, private dialect, parser, Item policy가 바뀌면 어떤 한계가 재검토되어야 하는지 연결한다. 기존 한계가 해결되었다는 증거 없이 상태를 supported로 바꾸지 않는다. 반대로 한 번 실패한 관측을 모든 FW/모델의 영구 불가능으로 일반화하지 않는다.

## 7. 검증

Capability resolver는 지원/미지원/미확인/권한없음의 결과와 이유를 결정론적으로 내야 한다. unknown이 true처럼 동작하거나 빈 범위가 무제한으로 해석되는 반례를 시험한다. 배포 manifest의 profile hash와 실행 시 실제 상태가 맞는지 확인한다. report는 실행하지 않은 모델을 비교 결과에 포함하지 않는다.
