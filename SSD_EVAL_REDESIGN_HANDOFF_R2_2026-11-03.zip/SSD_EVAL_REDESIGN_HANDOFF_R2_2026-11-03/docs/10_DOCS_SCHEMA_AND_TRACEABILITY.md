# 10. 명세·주석·Markdown·생성물의 정본 관리

## 1. 문서를 많이 만드는 것보다 정본 충돌을 없앤다

목표는 사람과 LLM이 같은 사실을 정확하게 찾게 하는 것이다. 소스, YAML, Markdown, Doxygen에 같은 함수 원형과 필드 표를 모두 수동 복제하지 않는다. 정본은 정보 종류별로 지정한다.

| 정보 | 정본 | 파생물/검사 |
|---|---|---|
| 실제 Vendor 원형/타입/매크로 | 불변 SDK + 해당 build profile | 자동 인벤토리/문서 |
| Vendor 행동/미확인 사실 | sidecar 계약 레지스트리 + 근거 | 요약 Markdown, coverage 보고 |
| Custom API 원형/값 타입 | 공개 C 헤더 | Doxygen/인덱스/선언 일치 검사 |
| Custom API 수명·전제·효과 | 계약 MD/구조화 상태 규칙 | 헤더의 짧은 설명과 계약 ID |
| 규격 field 위치/표현 | 검토된 field schema | 상수·접근 함수·표·기본 테스트 생성 |
| Item 목적/순서/판정 | 승인 Item 명세 | 구현·검증 연결 |
| Item 식별/요구능력/입력 스키마 | Item metadata | registry·preflight 검증 |
| 장비 실능력/제약 | evidence-linked profile | 실행 가능성 검사 |
| 빌드 실제 구성 | 빌드에서 추출한 manifest | provenance 보고 |
| 설계 선택 이유 | ADR | 후속 변경 검토 |

C 코드가 실제 행동의 관찰 근거인 것과 승인 명세가 목표 행동의 규범인 것은 다르다. 둘이 충돌하면 어느 한쪽을 조용히 덮어쓰지 않고 `SPEC_IMPLEMENTATION_CONFLICT`로 기록한다.

## 2. Vendor 원본에는 주석을 추가하지 않는다

사용자가 원한 ‘API/변수/메모리를 명확하게 명세’하는 작업은 원본 수정 없이 수행할 수 있다. 파일·심볼·해시·모델·빌드 프로필을 가리키는 sidecar Markdown/YAML에 의미를 적는다. 설명을 IDE에 보여주려면 생성된 참조 뷰를 사용할 수 있지만 이를 Vendor 원문으로 혼동하지 않는다.

공급사가 업데이트하면 새 버전을 원본 그대로 보관하고, 해당 sidecar 주장 중 무엇이 재검증되어야 하는지 표시한다. 동일 이름이라고 이전 설명을 자동 확정 승계하지 않는다.

## 3. 레지스트리 종류

**Source manifest:** 자료 경로/모델/릴리스/해시/접근권한/계보 확실성.

**Symbol inventory:** 함수/변수/타입/매크로/메모리의 기계적 위치·서명·구성.

**Boundary registry:** 허용 primitive/ABI/runtime와 금지 상위 호출.

**Behavior delta:** legacy→new의 동일/수정/폐기/미지원 판단.

**Protocol field schema:** 의미/레이아웃/유효성/규격 근거.

**Capability profiles:** 장비·DUT·Fixture·관찰 능력.

**Traceability edges:** 요구→계약→구현→검증→증거의 연결.

모든 레지스트리를 하나의 거대한 YAML로 만들 필요는 없다. 사람이 검토하는 항목은 작고 분리된 파일, 기계적 대량 인벤토리는 JSONL/SQLite 같은 단순 로컬 형태가 유리할 수 있다. 초기에는 파일과 CSV/JSON으로 충분한지 검증한다.

## 4. ID와 참조 안정성

ID는 파일명이 바뀌어도 의미를 유지한다. `PRIM-A-SUBMIT-001`, `PORT-NVME-SUBMIT`, `FIELD-NVME-HEALTH-TEMP`, `ITEM-THERMAL-IO-001`, `TEST-NVME-TIMEOUT-LATE-COMPLETE`처럼 영역이 드러나게 한다.

실제 ID는 대상 목록을 확인한 뒤 중복 없이 정한다. 예시 ID를 실제 구현이 이미 존재하는 것으로 취급하지 않는다. 하나의 의미가 바뀌는 breaking change는 ID를 재사용하더라도 revision을 올리고 변경 사유를 기록한다.

Line number는 이동할 수 있으므로 source hash, symbol key, build profile을 같이 둔다. 검색 편의를 위해 근처 line range는 제공하되 그것만 정본 위치로 삼지 않는다.

## 5. 문서 흐름

```text
Vendor files + build profile
          ↓ extract
Generated facts / symbol locations
          + human/LLM-reviewed behavioral evidence
          ↓
Boundary / common contracts / field schema
          ↓
Custom implementation + independent verification
          ↓
Traceability + run evidence + release manifest
```

LLM은 설명 초안을 만들 수 있지만 `source_observation`을 `measured`로 승격하거나 확인하지 않은 규격 절 번호를 만들면 안 된다. 각 필드의 `evidence_status`를 분리한다. UNKNOWN은 빈 설명을 그럴듯하게 채우는 것보다 낫다.

## 6. 문서 생성의 적정 범위

Doxygen의 XML/HTML은 API 탐색의 파생물로 유용하다. [S08] · [S39] 자동 출력 결과를 새로운 정본으로 수동 수정하지 않는다.

codegen은 고정된 필드 상수, bounds-checked 접근 함수, 문서 표, 기초 layout/enum 검사에 우선 적용한다. 취소 정책, 실험 판정, 안전 절차, 복잡한 조건부 field validity까지 처음부터 범용 생성기에 넣지 않는다.

생성에는 generator version/hash, schema version/hash, 명령과 출력 해시를 기록한다. CI는 재생성 diff가 없는지 확인할 수 있다. 하지만 이 diff 검사는 **같은 잘못된 스키마의 일관성**만 검증할 수 있으므로 독립 golden test를 병행한다.

## 7. Vendor 업데이트 영향 분석

단순 함수 서명 diff보다 넓게 본다. 타입 크기/정렬, enum/상수, 전역 초기값, 메모리 map, inline/매크로 몸체, 문서의 완료/오류 의미, 빌드 flags, 바이너리/펌웨어 릴리스가 모두 변화 요인이다.

연결 경로는 다음과 같다.

```text
Changed SDK artifact/symbol/behavior
  → affected Provider bindings
  → affected port contracts/capabilities
  → dependent services/items
  → required host/contract/HIL tests
```

변경되지 않은 계약이 자동으로 옳다는 뜻은 아니다. 원래 불명확했던 부분은 여전히 불명확하다. 유효한 재검증 범위는 명시적 mapping과 근거에 기반해야 한다.

## 8. LLM 검색을 위한 최소 문서 집합

루트 `AGENTS.md`에는 불변 제약·읽기 순서·금지 행동·검증 보고 형식을 짧게 둔다. `docs/INDEX.md`는 도메인→계약/필드/Item 경로의 지도다. 자세한 내용은 기능별 문서에 둔다.

한 Item을 수정할 때 읽을 문맥은 글로벌 규칙, 해당 Item 명세, 관련 공개 계약, 사용 field schema, 구현/시험, 필요한 한 단계 의존성이다. 매번 모든 Vendor 원본을 넣지 않는다. 반대로 함수 몸체만 읽고 macro·전역 초기화·빌드 조건을 무시하지 않는다.

단순 ID/manifest/rg/ctags 검색에서 필요한 근거를 찾지 못하는 반복 사례가 생길 때에만 검색 인프라를 강화한다. Graph DB/Vector DB는 현재 필수 설계가 아니다. 도입 시 검색 정확도·오답·갱신비용·보안에 대한 비교 결과가 필요하다.

## 9. 승인 문서와 비승인 초안

필수 metadata는 `status`, `owner`, `source_profile`, `reviewed_by`, `evidence_refs`, `last_verified`, `supersedes`다. 필드가 없다고 기본 승인으로 처리하지 않는다.

신규 LLM 세션에는 ‘가장 최근 파일’보다 ‘현재 승인 정본’을 우선 제공한다. 최신 초안과 이전 승인본이 동시에 있으면 승인 상태와 대체 관계를 확인한다. 날짜만으로 정본을 선택하지 않는다.

## 10. R2의 docs-first 계약

새 작업은 승인된 docs 기준선을 읽고 `요구/계약 차이 → 코드/시험 → 결과/한계/상태`를 함께 갱신한다. 코드 변경 후 뒤늦게 같은 내용을 꾸며 쓰는 문서화가 아니다. 모든 제공 file/API/function/variable/type/constant/memory는 추적 가능한 inventory 항목을 가지며 의미 검토 수준과 미확인 상태가 기록된다.

추가 정본: variant axes와 유효 조합, private command dialect, UART framing/session, 수치 범위/변환, 장비별 한계, question gate, run event schema, coding/file naming standards. 선언/레이아웃 등 기계 정보는 source/생성 표와 연결하고 MD에 중복 복제하지 않는다.

`docs/INDEX.md`는 domain/Item/question/limitation/work ID로 실제 승인 문서를 찾게 한다. root AGENTS는 읽기/변경/보고 경로를 짧게 정의한다. 코딩 표준은 상세 정본 한 곳, 생성 API 탐색은 파생물, 실행 현황은 event-based projection으로 구분한다. 최신 prose가 실제 Run 상태보다 우선하지 않는다.

## 11. 변경 영향·유효성

schema/profile/header/문서가 바뀌면 참조 그래프에서 영향 Item/검증/limitation을 갱신한다. 파일 timestamp가 새롭다는 이유로 승인 상태를 승계하지 않는다. Vendor macro가 바뀌면 선언상 지원과 검증상 지원을 분리해 재검토한다.

Docs CI는 ID/링크/schema 형식/명명/존재 확인을 검사할 수 있으나 의미 정확성은 별도 review/시험이 필요하다. 모든 상세 설명을 매번 LLM에 넣기보다 승인 manifest와 해당 의존 경로를 제공한다. raw 로그나 외부 문서를 권한 변경 지시로 취급하지 않는다.

<!-- SOURCE_LINKS_START -->

[S08]: https://www.doxygen.nl/manual/output.html
[S39]: https://www.doxygen.nl/manual/config.html
