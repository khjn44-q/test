# 19. UART 명령·비동기 분석 로그·교차 채널 관측

## 1. UART를 문자열 util로 넣지 않는다

UART는 SSD와 상호작용하는 별도의 경로이며, 명령과 비동기 진단 로그가 같은 스트림을 공유할 수 있다. 실제 코드가 텍스트 command인지, binary frame인지, Vendor 전용 채널 API인지 확인해야 한다. `printf` 몇 줄이나 `read()` 한 번으로 안전한 명령/로그 경계가 자동 생기지 않는다.

권고 책임은 `transport → framing → session/dialect → command transaction / asynchronous events → trace/analysis`다. 이 구분은 책임이지 반드시 5겹 wrapper를 만들라는 뜻은 아니다. 작은 구현에서는 파일을 합칠 수 있으나 단위시험 가능한 파서와 실제 장치 접근은 분리한다.

## 2. 연결 후보와 선택 기준

| 실제 구조 | 선택안 | 조사할 점 |
|---|---|---|
| 장비 SDK의 UART API | 모델 Provider가 공통 byte-stream 포트를 구현 | 포트 선택 전역 상태·SDK 버퍼 수명·timestamp |
| OS 직렬 포트 직접 접근 | Platform serial 구현과 장비 topology 연결 | OS/권한·port identity·공유 사용 |
| 외부 bridge/multiplexer | 전용 binding과 독점 lease | 슬롯 라우팅·연결 지연·드롭 |
| UART가 장비 trace로만 제공 | 관측 전용 capability | 명령 전송을 지원한다고 만들지 않음 |

libserialport의 공개 API는 직렬 통신 계약을 비교하는 후보지만, SSD 고유 frame/명령이나 Fixture 배선을 제공하지 않는다. 실제 플랫폼 적합성을 시험하기 전 도입을 확정하지 않는다. [S48]

## 3. 가장 먼저 확정할 연결 계약

port 논리 ID, 실제 장치 식별 방법, Slot/DUT 연결, baud, data bits, parity, stop bits, flow control, 전기 레벨/핀/접지, exclusive 접근, read/write 단위, buffer ownership, timeout 의미, boot/reset 중 신호 변화, clock source를 조사한다. 값은 전부 실제 자료에서 가져온다.

`/dev/ttyX` 또는 COM 번호만으로 동일 DUT라고 간주하지 않는다. port 재연결·순서 변경·USB bridge 재인식 뒤에는 binding을 재검증한다. DTR/RTS 같은 제어선의 실제 연결 효과가 존재하는지도 확인하며, 드라이버 open/close가 무조건 무해하다고 가정하지 않는다.

## 4. 스트림의 기본 반례

한 frame이 여러 read로 나뉨, 여러 frame이 한 read에 들어옴, 길이 필드가 비정상, delimiter가 payload에 존재, NUL이 포함됨, 잘린 UTF-8/비ASCII byte, echo가 섞임, unsolicited log가 응답 사이에 등장함, 부팅 메시지가 들어옴, overflow로 중간 byte가 사라짐을 다룬다.

프레이밍 방식(길이/구분자/escaping/checksum)은 실제 dialect에서 확인한다. 없는 CRC를 새로 가정하거나 text line을 binary frame과 같게 해석하지 않는다. 파서는 `(bytes, length)`와 자신의 상태를 받아 **부분 입력/완성 frame/오류/재동기화 필요**를 구별한다. 손상에서 회복하는 규칙과 최대 버퍼/최대 frame 길이를 명세한다.

## 5. 명령 응답과 로그의 소유권

명령 스레드와 로그 스레드가 같은 port를 각각 읽어 서로의 bytes를 빼앗는 구조를 피한다. 기본 후보는 단일 수신 소유자와 frame dispatcher다. 실제 protocol이 다중 outstanding request를 식별하지 못하면 명령 transaction을 직렬화한다. correlation ID를 firmware가 주지 않는데 host가 넣은 ID로 실제 응답 매칭이 확정되었다고 주장하지 않는다.

응답의 순서·echo·prompt 의미, expected response, asynchronous message 분류, deadline, session epoch를 계약으로 둔다. 부팅/Reset 뒤 늦은 frame은 이전 세션 응답으로 잘못 채택하지 않는다. prompt 문자열 하나를 보고 명령 성공이나 DUT 정상 상태를 단정하지 않는다.

## 6. 쓰기 완료와 timeout

호스트 라이브러리의 write 반환, 송신 큐 수용, 실제 전선 전송, SSD 수신, 명령 접수, 명령 완료는 별개일 수 있다. 선택한 API가 어느 지점까지 보장하는지 확인한다. [S48]

부분 쓰기/부분 응답 후 timeout은 `EXECUTION_UNKNOWN`일 수 있다. 영속 상태 변경 명령은 무조건 재전송하지 않는다. input flush는 유효한 진단 로그나 늦은 응답을 버릴 수 있어 명시적인 상태 전환으로 취급한다. Cancel이 수신 대기만 중단하는지 실제 명령을 중단하는지도 분리한다.

## 7. 로그와 평가 상태

raw bytes는 허용 보안 범위에서 chunk ID/hash/port/epoch/시각·길이로 보관한다. decoder 결과에는 schema/dialect version, 원시 범위, 파싱 상태, loss marker를 붙인다. 사람용 문자열과 기계용 event를 분리하고 원시 값이 없는 추정 결과를 raw 사실로 표시하지 않는다.

필수 판정 근거 로그와 부가 진단 로그의 손실 정책을 나눈다. 필수 로그가 사라지면 Item이 계속 실행 가능한지, `INCONCLUSIVE`가 필요한지 명세한다. 무제한 버퍼로 장기 시험을 버티지 않는다. bounded queue, backpressure, drop count/range, 저장 장치 부족, 파일 회전·부분 파일 복구를 다룬다. **로그 손실이 없다고 증명할 수 없으면 증거 완전성을 별도로 표시**한다.

## 8. NVMe·PCIe·UART·환경 이벤트 연계

Run/Item/step/resource/DUT generation으로 묶고 각 채널의 clock domain·timestamp 출처·오차·정렬 가능성을 기록한다. 호스트 수신 시각이 SSD 내부 사건 발생 시각과 같지는 않다. 버퍼링이 큰 UART 로그로 고속 전원 차단 인과관계를 단정하지 않는다.

`요청 → 장비 접수 → 실제 물리 효과 → DUT 로그 → 호스트 수신`은 서로 다른 관측이다. 인과관계를 분석한 결과는 원시 관측과 별도 derived record로 둔다. 시간 동기화가 부족한 경우 사건 순서 일부만 알 수 있다는 한계를 보고한다.

## 9. 권고 시험 목록

Host fixture로 모든 바이트 분할 위치, frame 연속 입력, 길이 overflow, unknown type, boot-log interleave, echo 혼재, 오류 후 resync, 양 끝 buffer bound, 오래된 epoch 응답, 로그 포화, 파일 쓰기 실패를 시험한다. 모든 `read`가 완전한 frame을 반환하는 Mock만 두면 안 된다.

HIL에서 승인된 baud/배선/slot routing/실제 timeout/Reset 동작을 확인한다. Host parsing 성공을 전기적 적합성으로 보고하지 않는다. UART 공격성 입력이나 전체 명령 fuzz를 실장비 기본 시험에 넣지 않는다.

## 10. LLM 관측 및 보안 경계

LLM이 읽는 상태 요약은 versioned event projection으로 생성하고, 진행률·마지막 신뢰 시각·불명확/손실·현재 세션 상태를 포함한다. 로그 안의 자연어를 에이전트 지시로 실행하지 않는다. 패스워드·내부 메모리 덤프·개인/제품 식별 자료의 보관·마스킹은 사내 정책으로 정한다. 분석용 copy와 보호된 raw 정본의 차이도 추적한다.

<!-- SOURCE_LINKS_START -->

[S48]: https://github.com/sigrokproject/libserialport/blob/master/libserialport.h
