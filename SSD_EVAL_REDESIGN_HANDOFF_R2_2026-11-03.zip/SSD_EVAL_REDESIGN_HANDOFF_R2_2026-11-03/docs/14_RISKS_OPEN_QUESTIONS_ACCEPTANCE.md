# 14. 위험·질문·설계 선택·수용 기준 — R2

## 1. 위험의 지위

다음은 소스에서 실제 확인한 결함이 아니라 검토해야 할 실패 유형이다. 실제 발견 시 source/profile/재현/영향/검토 상태를 붙여 findings와 연결한다. 장비별 심각도와 우선순위는 실제 자료로 확정한다.

| ID | 실패 유형 | 관련 Work | 대응 |
|---|---|---|---|
| K01 | 원본 릴리스 차이를 사내 수정으로 오인 | W00 W06 | 계보/해시/추정 상태 |
| K02 | Vendor helper/과거 PASS를 정답으로 고정 | W04 W06 W26 | 규격·내부 요구·실제 동작 분리 |
| K03 | 필수 workaround/runtime 제거 | W03 W04 W12 | P0/P1/P2 경계·근거 |
| K04 | 모든 macro 동시 활성으로 불가능 구성 분석 | W02 W03 | 유효 조합/presence/TU |
| K05 | defined-zero와 undefined 혼동 | W02 W19 | preprocessor 의미 반례 |
| K06 | subtype/form factor/Fixture를 단일 이름으로 뭉침 | W02 W19 W22 | 축·호환성 matrix |
| K07 | Vendor 지원 macro를 verified 능력으로 승격 | W07 W19 W25 | declared/observed/verified |
| K08 | raw CDW 일부 재작성을 놓침 | W07 W21 | 제어/재작성/관측 mask |
| K09 | private opcode 충돌/FW dialect 오선택 | W08 W17 W19 | namespace/revision/FW gate |
| K10 | UART stream을 완전 frame으로 가정 | W09 W18 | partial/concat/interleave tests |
| K11 | UART logger/command가 경쟁 수신 | W09 W23 | 단일 소유/dispatcher |
| K12 | Reset 뒤 늦은 응답/콜백 오매칭 | W18 W20 W23 | epoch/generation |
| K13 | timeout 후 DMA buffer 해제 | W05 W20 W21 | lease/확정 quiescence |
| K14 | Context만 만들고 SDK 전역 경합 유지 | W04 W20 W22 | transaction 소유권 |
| K15 | 단순 uint64_t 변경으로 중간 overflow 방치 | W05 W15 | 승격/checked arithmetic |
| K16 | size_t narrowing/음수→unsigned 길이 | W05 W15 W16 | domain range/변환 계약 |
| K17 | packed/cast로 ABI/wire/endian 혼합 | W05 W16 W21 | 4종 데이터 모델 |
| K18 | schema와 자동 시험이 같은 offset 오류 공유 | W16 W17 | 독립 golden 근거 |
| K19 | 필수 readback 없는 설정을 도달로 판단 | W10 W24 | setpoint/measured/stable |
| K20 | 공유 rail/chamber/reset/UART 영향 누락 | W10 W20 W24 | 토폴로지와 lease |
| K21 | 폼팩터 이름으로 전압/핀값 선택 | W02 W10 W19 | Fixture revision/승인 배선 |
| K22 | 로그 손실을 정상 평가 데이터로 사용 | W18 W23 W29 | loss marker/판정 영향 |
| K23 | host 수신 시간을 물리 사건 시각으로 오인 | W09 W10 W28 | clock domain/오차 |
| K24 | 내부 명령 timeout 무조건 재시도 | W08 W17 W23 | 영속 영향/미확정 상태 |
| K25 | unsupported를 조용한 downgrade로 실행 | W19 W28 | 별도 variant/한계 docs |
| K26 | 분석 실패 TU를 clean에 포함 | W03 W11 W30 | coverage 분모/실패 상태 |
| K27 | vendor 경고를 전체 suppression | W11 W30 | 영역별 findings와 조치 |
| K28 | LLM이 없는 API/규격/안전값 생성 | W12 W13 W32 | 정본/질문/존재 검사 |
| K29 | Git commit만으로 전체 빌드 근거라 주장 | W00 W01 W03 | dirty/generated/SDK manifest |
| K30 | 원본/사용자 dirty 변경을 정리 중 삭제 | W00 W14 | read-only/hash/쓰기 범위 |
| K31 | worktree를 hardware 격리로 오인 | W00 W35 | 별도 권한·자원 예약 |
| K32 | 코드 rollback이 실제 DUT 상태 rollback이라 오인 | W35 | quiescence/미확정/복구 |
| K33 | docs 최신 파일을 승인 정본으로 선택 | W13 W32 | status/supersedes/revision |
| K34 | LLM 상태 요약을 실제 Run 증거로 간주 | W29 W32 | event projection/freshness |
| K35 | 전체 분석 도구 개발이 주목표로 변질 | W31 | A0~A3 gap/이득/owner |
| K36 | 프로토콜 negative test를 안전 검사 해제로 구현 | W16 W17 W27 | 입력 의미/메모리·설비 보호 분리 |
| K37 | 공통 Item 성공을 모든 구성으로 일반화 | W22 W28 W36 | 지원 matrix/한계 |
| K38 | 기존 구현 유지 의무로 전면 재설계 축소 | W06 W12 W34 | 의도/근거만 보존·새 코드 |
| K39 | 모든 상세 분석을 대표 한 함수로 대체 | W01 W04 W05 W12 | 전체 파일/심볼·위험 경로 coverage |
| K40 | 미확인 중대 질문을 기본값으로 통과 | W12 W25 W36 | question owner/gate |
| K41 | 로그/규격/내부 명령 정보를 외부로 유출 | W00 W13 W29 | 사내 권한/보관·secret 참조 |
| K42 | completion을 영속성/데이터 검증으로 오인 | W26 W28 | write state/독립 oracle |
| K43 | 계측/최적화로 평가 timing 변경 | W24 W28 | 배포 프로필 계측 |
| K44 | 상세 문서가 중복 정본으로 서로 충돌 | W13 W30 | source/header/schema/contract 분리 |

## 2. 질문의 소유와 진행 경계

24장 질문카드를 사용한다. 실제 자료에서 먼저 답을 찾고, ABI·메모리·내부 dialect·배선/안전·평가 정책·관측 정확도·지원 구성의 중대한 공백은 해당 담당자에게 문의한다. 이 문서의 제안으로 답변을 대체하지 않는다. 답변은 적용 profile과 근거를 갖고, 영향을 받는 Work를 해제한다.

## 3. 설계 결정 기록

A/B 정적 연결, C vendor-host, D worker, E sequencer, F 외부 framework를 실제 source 조건으로 비교한다. V1/V2/V3는 subtype/profile의 별도 축이다. 후보 간 비교에는 의미 정확성, 가독성, 정적분석성, 변경 영향, 검증 가능성, 보안·타이밍·운영 비용을 넣는다. 숫자 점수를 임의로 부여하여 객관적 평가인 것처럼 보이게 하지 않는다.

## 4. 최종 수용 기준

| Gate | 필요한 증거 | 실패 시 |
|---|---|---|
| G0 자료/권한 | 실제 source/Git/SDK 기준선·해시·쓰기/실행 범위 | 해당 자료 처리 중단 |
| G1 전면 감사 | 전체 파일/심볼/타입/macro/config inventory·의미검토·coverage·findings | 미분석 범위와 설계 영향 명시 |
| G2 질문/설계 | 중대 질문 답변·후보 반증·승인 ADR·제외 범위 | 관련 설계/구현 차단 |
| G3 docs/규칙 | naming/type/unit/file 규칙·정본·공개 계약·추적 IDs | 새 Custom 변경 미승인 |
| G4 빌드/변형 | profile 검증·타깃/ABI·실제 compile/link·미선택 제외 | 해당 build 미지원 |
| G5 수치/메모리 | 범위·산술·변환·lifetime·독립 반례·도구 한계 | 해당 경로 차단 |
| G6 프로토콜/내부 명령 | field/dialect/FW 명세·raw fidelity·독립 vectors | 미확인 기능 사용 금지 |
| G7 UART/로그 | framing/partial/epoch/route·loss/clock·보안 | 관측/명령 제한 표시 |
| G8 환경/자원 | Fixture·shared resource·readback·안전/cleanup 승인 | HIL 차단 |
| G9 품질/도구 | 구성별 warnings/analysis·실패 TU·규칙 양성/음성 시험·waiver | clean 주장 금지/중대결함 차단 |
| G10 평가 의미 | 새 명세 oracle·기존 delta·데이터/영속 기대·판정 | 해당 Item 미승인 |
| G11 HIL/동등성 | profile별 실행 증거·관찰 한계·비동등/미실행 | 지원 범위를 축소 |
| G12 LLM workflow | 실제 Item 추가/수정·규칙 위반 검출·docs와 상태 연결 | 자동화 한계 명시 |
| G13 운영 | 업데이트/배포/복구·release manifest·owner·retention | 운영 승격 보류 |

## 5. 완료의 의미

요구마다 구현됨/폐기승인/미지원/미검증/차단을 분리한다. 선정 범위의 증거가 있을 때만 그 범위 완료를 말한다. 문서/Host 성공을 장비 전체 안전성으로 바꾸지 않는다. 현재 R2는 위 제품 Gate를 통과한 결과가 아니라 그 수행 가이드다.
