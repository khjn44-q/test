# 26. 데이터 무결성·평가 현황·근거 재현성의 추가 보강

## 1. 신뢰성 평가에서 따로 정의할 상태

I/O 요청 생성, 제출 접수, DUT completion, 데이터 검증, persistence/durability 기대는 별개다. 완료가 있었다는 사실만으로 시험이 요구한 영속성까지 보장됐다고 추정하지 않는다. 실제 적용 규격/내부 평가 기준에서 flush/FUA/cache/reset의 의미를 확인하고 Item의 기대 데이터 집합을 정의한다.

Power loss 중 어떤 write가 완료/미완료/미확정인지 모르면 그 불확실성 자체를 데이터 검증 정책에 반영한다. 모든 block이 새 패턴이어야 한다고 단정하거나, 오류가 생겼다는 이유로 기대 데이터를 다시 현재 내용으로 갱신해 PASS시키지 않는다.

## 2. 데이터 패턴과 재현

패턴 알고리즘/버전/seed, namespace/주소 범위, logical block size, metadata 포함 여부, offset 의미, iteration/generation, expected write ledger를 명세한다. 병렬 실행에서 PRNG 호출 순서가 바뀌어 같은 seed가 다른 패턴을 만들 수 있는지 확인한다. 주소 기반 재현 또는 명시적인 stream 분할을 후보로 두되 보안/성능/기존 평가 의도를 검토한다.

bytes/blocks/zero-based encoded field 변환은 타입·범위 검사로 한 곳에 모은다. 가변 block size, 경계 LBA, 부분 전송/완료, metadata, 장비 최대 payload, 자동 split 여부를 다룬다. 새 helper로 분할한 전송이 원래 평가의 단일 명령과 같다고 자동 인정하지 않는다.

## 3. 실행 현황의 정본

LLM용 상태는 자유서술 작업 메모만으로 만들지 않는다. Run/Item/step/request/resource/DUT epoch ID가 연결된 구조화 이벤트를 정본으로 두고, 사람이 읽는 보고서와 LLM 요약은 이로부터 생성하는 후보를 권고한다.

상태 뷰에는 계획 revision, code/build/profile hash, 현재 단계, completed/failed/pending/unknown 수, 마지막 신뢰 가능한 관측 시각, cancellation state, 로그 손실, 미완료 명령, 제한 사항, 다음 허용 행동을 포함한다. 오래된 이벤트로 현재 장비 상태를 보장하지 않는다. 요약에 포함된 모든 수치의 분모와 시점을 명시한다.

## 4. 진행률과 판정

계획 횟수, 실제 제출수, 완료수, 검증수, 성공수는 서로 다르다. 진행률 100%가 모든 판정 PASS를 의미하지 않는다. 추정 진행률과 관찰된 진행률을 구분하고, 장비 내부 시퀀스의 실제 위치를 알 수 없으면 unknown을 표시한다.

`Run state`와 `Test verdict`를 분리한다. 취소/설비 오류/관찰 손실을 DUT FAIL로 단순 매핑하지 않는다. 검증하지 않은 조건을 PASS로 채우지 않는다. 내부 결과를 기존 사내 보고 형식으로 바꾸더라도 원래 원인·증거는 보존한다.

## 5. 근거 저장과 복구

Run manifest는 source commit뿐 아니라 dirty status, 실제 compiler/link flags, SDK/binary/FW, selected profile, Fixture, DUT identity, schema/dialect/Item revision, 승인 및 clock/교정 정보를 담는다. Raw 자료와 derived 결과는 hash/참조로 연결한다. 대용량 raw는 Git에 무조건 넣지 않고 승인 artifact 저장소와 retention 정책을 검토한다.

이벤트 중복/순서 역전/중간 파일 손상/디스크 가득 참/프로세스 중단에 대한 정책을 정한다. 영속화 완료가 필요한 사건과 best-effort 진단을 구분한다. 파일 기록 성공이 실제 DUT 효과를 증명하는 것은 아니다. 교정 만료·센서 위치·관측 오차도 필요한 경우 verdict evidence에 반영한다.

## 6. 재분석과 재실행 구분

새 decoder/평가 기준으로 raw log를 재해석할 수 있지만 원래 결과를 덮어쓰지 않는다. `derived_from_run`, analysis code/schema/policy revision, 바뀐 판정 이유를 별도 기록한다. Offline replay는 파서/판정 재현을 검증하며 실제 장비 명령 timing을 재현했다고 주장하지 않는다.

코딩 세션 재개는 Git/docs를 읽으면 가능할 수 있다. 실장비 Run 재개는 미완료 요청·DUT/Chamber/Rail/로그 연속성 확인이 추가로 필요하다. 저장한 반복 카운터만 복원해 위험한 단계부터 이어 가지 않는다.

## 7. 필요한 시험

쓰기 완료 순서 역전, 일부 응답 누락, Reset 경계에서 미확정 write, 패턴 생성 알고리즘 변경, 동일 seed/다른 병렬 순서, log drop과 판정 근거 부족, disk-full, duplicated event, schema mismatch, unknown dialect, 손상된 raw reference를 Host/Fake 시험에 넣는다. 실제 persistence/전원 timing은 승인된 HIL로 별도 검증한다.

## 8. 유지보수 효과를 확인하는 지표

새 Item 추가 때 수정한 모듈 수, 모델 추가 시 공통 Item 변경량, 명세 없는 호출 수, 질문 재발, 미검증 profile 수, 정적분석 재현 실패율, 분석 불가 TU 비율, evidence 누락, 원인 불명 판정, 로그 손실, 실제 재작업 원인을 측정한다. 목표 수치와 속도 향상률은 실제 기준선 없이 발명하지 않는다.
