# 08. GCC 모델 선택 빌드와 의존성 강제

## 1. 기본 결정

하나의 공통 제품 소스 트리에서 모든 모델 소스를 관리하되(원본 증거 저장소의 분리는 21장 후보로 결정), **한 빌드 트리에는 하나의 확정 equipment build profile(계열/세부타입/SDK/ABI/source-set)**을 고정한다. 다른 모델을 같은 디렉터리에서 옵션만 바꿔 덮어쓰지 않는다. `build/<equipment_profile_id>/<build_mode>/`처럼 분리한다.

프로덕션 컴파일러는 실제 공급 GCC/툴체인을 유지한다. CMake는 선택·의존성·검증을 조직하는 후보이며 Vendor 빌드를 반드시 즉시 대체할 필요는 없다. Makefile을 유지하고 CMake/상위 스크립트가 검증된 SDK 라이브러리를 가져오는 혼합 구조도 가능하다.

CMake는 타깃 사이의 의존성을 표현할 수 있고 Presets로 공용/개인 설정을 나눌 수 있다. 이 프로젝트에서는 공용 profile은 저장소에, 개인 SDK 절대경로는 로컬 설정에 둔다. [S01] · [S02]

## 2. 빌드 프로필의 최소 내용

계열/세부타입/HW revision, SDK 릴리스/해시, 장비 FW/FPGA 호환 범위, 필요한 폼팩터/Fixture 및 dialect 제약, GCC/링커와 타깃, sysroot, ABI flags, 링크 방식, 생성 헤더 입력, 선택된 Item 세트, 표준/Capability profile, 안전 실행 모드, 툴 버전을 기록한다.

`A=true, B=true, C=false` 같은 독립 Boolean 집합 대신 승인된 profile ID를 정본 선택 키로 사용한다. `SE_MODEL`은 계열만 다루는 축약 예시이며 실제 R2 선택은 subtype/SDK/ABI 제약도 검사한다. 알 수 없는 값이나 복수 선택은 configure 단계에서 실패시킨다. 모델 D를 추가할 때 파일과 build profile을 추가하되 공통 Item 수정이 필요하지 않아야 한다.

## 3. 타깃별 책임

| 타깃 후보 | 포함 | 비고 |
|---|---|---|
| `se_base` | 값 타입/오류/바이트 유틸 | 순수 C |
| `se_protocol` | NVMe/PCIe encode/decode | Vendor 헤더 접근 없음 |
| `se_private_commands` / `se_uart_protocol` | 내부 dialect와 stream 해석 | transport 호출과 분리 |
| `se_compatibility` | profile/한계 제약 검사 | hardware 없이 결정론적 검사 |
| `se_ports` | 공통 계약 헤더/필요한 façade | Vendor 타입 없음 |
| `se_services` | 공통 기능 조합 | 모델명 모름 |
| `se_runtime` | 실행/자원/Trace | 직접 Vendor include 없음 |
| `se_items` | 선택된 Item들 | 공통 계약만 사용 |
| `se_provider` | 선택 모델 구현 1개 | private SDK include |
| `se_vendor_boundary` | 승인 SDK/필수 support 객체 | 원본 빌드 flags 유지 |
| `se_entry` | standalone 또는 Vendor callback shim | 구성 연결 책임 |
| `se_host_tests` | Fake와 순수 모듈 검증 | 실제 SDK/장치 접근 없음 |

작은 프로젝트에서는 타깃 일부를 합칠 수 있다. 의존성 차단이 유지되는지가 기준이다.

## 4. 선택 방식 예시

아래는 계열 선택 원리만 보여주는 **축약 설계 예시**다. R2 제품에서는 profile resolver가 세부타입/폼팩터/SDK/ABI/허용 조합을 먼저 검증한 뒤 해당 target을 선택해야 한다. 이 패키지에 실제 SDK/제품 소스가 없으므로 그대로 실행 가능한 CMake 프로젝트는 아니다.

```cmake
set(SE_MODEL "" CACHE STRING "Selected equipment model")
set_property(CACHE SE_MODEL PROPERTY STRINGS model_a model_b model_c fake)

if(SE_MODEL STREQUAL "model_a")
    add_subdirectory(providers/model_a)
elseif(SE_MODEL STREQUAL "model_b")
    add_subdirectory(providers/model_b)
elseif(SE_MODEL STREQUAL "model_c")
    add_subdirectory(providers/model_c)
elseif(SE_MODEL STREQUAL "fake")
    add_subdirectory(providers/fake)
else()
    message(FATAL_ERROR "An explicit supported SE_MODEL is required")
endif()
```

각 하위 구성은 `se_provider`라는 계약된 타깃을 하나만 제공한다. 더 커지면 검증된 모델 registry에서 경로를 선택할 수 있지만 사용자 문자열을 검증 없이 소스 경로로 사용하지 않는다.

모든 소스를 `GLOB_RECURSE`로 수집한 뒤 `#ifdef`로 쳐내는 방식보다 선택 타깃의 명시적 소스 목록이 추적에 유리하다는 것이 이 설계의 판단이다. 자동 목록 생성이 필요하면 생성 규칙과 결과 diff를 검토한다.

## 5. include·컴파일 옵션의 범위

Vendor include path, 매크로, 경고 예외는 Provider/SDK 타깃에 한정한다. 디렉터리 전체 `include_directories()`와 전역 flags에 Vendor 설정을 퍼뜨리지 않는다. `PRIVATE/PUBLIC/INTERFACE` 범위를 이용해 전파를 관리한다. [S40]

Custom 경고를 없애기 위해 전체 프로젝트에 `-w`를 넣지 않는다. Vendor header를 `SYSTEM`으로 다루더라도 이는 경고 제어 수단이지 안전성 승인이나 의존성 차단 수단이 아니다. 공개 헤더 자체에서 Vendor 타입이 누출되는지 따로 검사한다.

`#define VendorFoo se_foo` 같은 심볼 치환은 금지한다. 같은 이름을 의도적으로 제공하는 모델 구현 방식 A는 **선택된 Custom 구현 하나만 링크**한다는 계약이다. Vendor 심볼을 덮어쓰는 것이 아니다.

## 6. 정적 링크와 실제 포함 검증

‘사용하지 않으면 링커가 알아서 제거하겠지’에 의존하지 않는다. 먼저 빌드 소스/라이브러리 목록에서 미선택 모델을 제외한다. 최종 산출물의 link map, 입력 객체/라이브러리, 심볼을 함께 확인한다. GNU ld는 Map/trace/cross-reference 등의 진단 기능을 제공한다. [S41]

검증 항목은 (1) compilation database에 미선택 모델 TU가 없는가, (2) 링크 입력에 미선택 SDK가 없는가, (3) public ABI가 Vendor 타입을 노출하지 않는가, (4) Custom이 금지된 Vendor high-level 함수/전역을 참조하는가다.

`nm` 문자열 검색만으로 금지 호출이 없음을 증명하지 않는다. inline/매크로/함수 포인터/stripped binary/opaque library가 한계다. 원본 바이너리 내부에서 무엇을 호출하는지는 별도 Vendor 정보 없이는 완전 검증할 수 없다.

API와 high-level 코드가 같은 객체에 묶였으면 ‘심볼이 바이너리에 존재함’과 ‘Custom 실행 경로가 그것을 호출함’을 구분한다. 안전한 분리가 불가능하면 packaging 제약을 기록하고, SDK 내부 함수가 전부 제거됐다고 주장하지 않는다. `--whole-archive`와 등록용 section도 조사한다.

## 7. 모델별 compilation database

CMake Make/Ninja 환경에서는 `CMAKE_EXPORT_COMPILE_COMMANDS`로 생성할 수 있다. 동일 파일이 다른 매크로로 컴파일되면 각 프로필을 별개 분석 대상으로 취급한다. [S03] · [S04]

Vendor GCC 옵션을 Clang이 받지 못할 때 분석용 변환 레이어를 둘 수 있으나 원본 flags와 변환 이력·미지원 옵션을 보존한다. 생산 빌드의 flags를 분석 도구 편의 때문에 바꾸지 않는다. 분석 가능한 TU 비율과 실패 원인을 보고한다.

## 8. Preset 후보와 실행 통제

`host-fake-debug`, `host-fake-sanitize`, `model-a-release`, `model-a-analysis`, `model-b-release`, `model-c-release`처럼 목적을 나눈다. 실제 이름·툴 버전은 도입 시 고정한다.

일반 `ctest`에 실장비 시험을 섞지 않는다. HIL은 별도 빌드/runner/권한/승인된 plan으로 실행하며, 단순 label만으로 완전 격리를 보장했다고 말하지 않는다. 기본 구성에서 HIL 등록을 꺼 두는 것을 권고한다.

## 9. 오프라인 공급망

빌드 중 자동 `FetchContent`, 패키지 최신 업데이트, 외부 Git 접근을 기본으로 사용하지 않는다. 승인된 mirror 또는 사내 패키지와 lock/hash를 사용한다. 다운로드 가능한 개발 도구와 제품에 링크되는 라이브러리는 라이선스·보안 영향이 다르므로 별도 목록으로 관리한다.

최종 Build Manifest는 실제 빌드에서 만들어야 한다. 사람이 YAML에 적은 기대값만으로 사용 SDK/컴파일러를 증명하지 않는다. reproducible build는 목표로 두되 실제 재빌드 해시 비교 없이 달성했다고 표시하지 않는다.

## 10. 다축 구성의 실제 빌드 계약

최종 build profile은 family/subtype/SDK/ABI/source-set/허용 protocol codec/Item set/analysis mode를 고정한다. form factor/Fixture가 ABI나 source selection을 바꾸면 이 축도 빌드에 포함한다. 같은 바이너리에서 안전하게 바꿀 수 있는 값만 검증된 runtime profile에 남긴다.

알 수 없는 ID, 불가능한 subtype 조합, 지원 밖 SDK/FW, 빠진 필수 macro, 충돌하는 source-set은 configure 단계에서 실패시킨다. profile override 우선순위를 암묵적으로 두지 않는다. 설정 스키마 검증과 실제 compile/link 확인은 둘 다 필요하다.

각 승인 구성별 compilation database를 분리한다. 하나의 `.c`가 서로 다른 macro로 빌드되면 다른 분석 단위다. 미활성 조건부 코드가 자동 분석됐다고 보고하지 않는다. 매크로 정의/해제/강제 include 문맥은 [S45], TU database 의미는 [S04]를 참조한다.

## 11. 증거와 반례

대표 정상 구성 외에 잘못된 subtype, 연결되지 않는 Fixture, 잘못된 dialect, 분석 전용 profile의 운영 실행 시도, mixed SDK, private header 누출, inactive branch의 타입 차이를 검증한다. source selection이 올바라도 archive 안에 다른 함수가 들어 있을 수 있으므로 객체 포함과 호출 허용 경계를 구분한다.

build manifest에는 resolved profile hash, 명령별 실제 매크로/flags, source/dependency hash, generator inputs를 기록한다. 실제 값이 기록되지 않은 hand-written YAML만으로 재현 가능한 빌드라고 하지 않는다.

<!-- SOURCE_LINKS_START -->

[S01]: https://cmake.org/cmake/help/latest/manual/cmake-buildsystem.7.html
[S02]: https://cmake.org/cmake/help/latest/manual/cmake-presets.7.html
[S03]: https://cmake.org/cmake/help/latest/variable/CMAKE_EXPORT_COMPILE_COMMANDS.html
[S04]: https://clang.llvm.org/docs/JSONCompilationDatabase.html
[S40]: https://cmake.org/cmake/help/latest/command/target_include_directories.html
[S41]: https://sourceware.org/binutils/docs/ld/Options.html
[S45]: https://gcc.gnu.org/onlinedocs/gcc/Preprocessor-Options.html
