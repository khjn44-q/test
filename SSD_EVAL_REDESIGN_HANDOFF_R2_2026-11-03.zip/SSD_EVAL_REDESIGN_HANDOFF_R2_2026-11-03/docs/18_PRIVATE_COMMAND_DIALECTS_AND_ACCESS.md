# 18. 표준 외 SSD 내부 검증 명령과 독립 dialect

## 1. 공식 규격만으로 재설계하지 않는다

사용자가 확인한 사내 명령은 정당한 내부 개발/평가 기능이다. 이를 ‘NVMe spec 위반이므로 삭제할 코드’로 취급해서는 안 된다. 반대로 vendor-specific 범위라는 이유로 어떤 값이든 허용하거나, 사용 중인 숫자만 보고 의미를 만들어서는 안 된다. 공개 규격, SSD 개발사 내부 명령 문서, 실제 FW 구현/운영 근거를 구분한다.

`internal command set`이 NVMe의 표준 Command Set Identifier와 같은 개념인지도 미확인이다. 본 문서에서는 혼동을 피하려고 **dialect**라는 별도 개념을 쓴다. 실제 사내 명명법으로 치환 가능하다.

## 2. 명령의 안정적 키

명령 키는 opcode만으로 만들지 않는다. 제안 키는 `authority/developer_namespace + dialect_id + dialect_revision + transport + command_id`이며, 적용 DUT 계열/FW 범위·Queue/세션 범위·subcommand·payload 구조를 별도 명시한다. 같은 opcode가 다른 FW에서 다른 동작을 할 수 있는지 실제 자료를 조사한다. 값이 같다는 이유로 같은 serializer/parser를 재사용하지 않는다.

표준 command의 vendor extension, 완전히 내부용 command, UART shell/binary command를 구분한다. 표준과 내부 명령의 상태 코드를 한 enum에 의미 충돌하도록 넣지 않는다. 공통 결과 envelope 안에 응답의 namespace와 raw 값을 보존할 수 있다.

## 3. 가능한 구조 후보

| 후보 | 적합한 경우 | 주의 |
|---|---|---|
| 별도 C module + typed request/response | 명령 수가 제한적이고 의미가 중요 | 가장 단순한 우선 후보 |
| 작은 schema에서 필드 접근 코드 생성 | 반복적인 레이아웃이 많고 문서가 안정 | 생성기와 독립 vector 필요 |
| opaque transport envelope + 외부 decoder | 원문/구조 일부가 비공개이거나 분석만 필요 | 의미 미확인 영역을 typed-known처럼 표시 금지 |

공통 NVMe 전송 또는 UART 포트는 재사용할 수 있다. **공통 전송과 공통 명령 의미는 다르다.** Internal 명령을 Provider에 모두 숨기면 테스트 정책이 장비 모델별 코드에 들어가므로, dialect codec은 가능하면 하드웨어와 무관한 모듈로 둔다. 장비가 특정 명령을 차단/수정하면 Provider Capability 제한을 별도로 기록한다.

## 4. 명령 계약의 필수 항목

명령명/목적, 소유 조직, 문서 ID/revision/해시, 적용 FW/제품, 선택 조건, payload 입력·출력 길이, byte order, 단위, 필드 유효성, 임시/영구 부작용, 요구 privilege/session, 허용 상태, 완료·timeout·재시도, Reset/전원 중단 영향, 관측 가능한 응답, 데이터 보존/보안 등급, 승인·테스트 근거가 필요하다.

인증 키·잠금 해제 비밀·내부 접근 자격은 일반 docs나 테스트 벡터에 저장하지 않는다. 필요 시 사내 승인 secret reference를 기록한다. 이 문서는 실제 opcode, unlock 시퀀스, 전압, 보안 우회 방법을 가정하지 않는다. 사용권한과 장비 운영 통제는 기존 조직 정책을 따른다.

## 5. 선택과 실패 원칙

DUT family/FW/dialect의 대응이 모호하면 자동 ‘가장 가까운 버전’ fallback을 하지 않는다. 가능하면 상태 변경 없는 승인된 식별 절차로 확인하되, 이름이 Identify/Read라는 이유만으로 안전한 명령이라고 추정하지 않는다. 미확인 장비와 DUT에 명령을 보내 dialect를 시험해 보는 행위는 기본 discovery 작업에 포함하지 않는다.

Firmware 교체, 재부팅, bootloader 진입 이후에는 이전 dialect binding이 유효한지 재확인한다. 해석 불가능한 응답은 raw+unknown으로 보존한다. `0` 반환이나 `OK` 문자열의 의미를 공통 성공으로 자동 번역하지 않는다.

## 6. 일반/부정 입력 검증의 경계

유효한 내부 명령과 의도적으로 잘못된 내부 명령 시험을 별도 메타데이터로 선언한다. 비정상 protocol field를 허용하는 시험이어도 CPU 버퍼 경계·주소 유효성·장비 보호·승인 검사는 유지한다. 내부 상태를 바꾸는 명령은 timeout 후 재전송 가능성보다 **이미 수행되었을 가능성**을 먼저 판단한다.

미지원 장비에서 동일 결과를 얻기 위해 다른 내부 명령을 몰래 호출하지 않는다. 대체 시나리오가 필요하면 Item revision/variant와 비동등 이유, 검증 범위를 명시한다.

## 7. 문서와 시험

`specs/private/<namespace>/<dialect_revision>/`는 제안 경로다. 명령별 registry, response-field schema, firmware compatibility matrix, raw reference corpus, redaction policy, negative cases를 연결한다. 내부 규격을 사외 출처 목록에 넣거나 원문을 외부 LLM에 전달하지 않는다.

Host 시험은 동일 opcode/다른 dialect, 알려지지 않은 revision, 짧은/긴 payload, 잘못된 길이, 별개 status namespace, 초기화되지 않은 output, timeout 후 늦은 응답을 다룬다. 값 자체는 승인 내부 명세에서 가져온다. HIL은 대상 DUT 식별과 실행 승인 뒤 별도 수행한다.

## 8. 반드시 확인할 질문

명령 정본은 어디이며 누가 승인하는가? FW와 명령 개정 대응이 실제로 보장되는가? Vendor SDK가 command를 검사·변경하는가? 응답에 revision/length가 있는가? 위험·영속 변화·재시도 불가 명령은 무엇인가? UART와 NVMe가 같은 내부 상태를 공유하는가? 답이 없는 부분은 QUESTION/CONTRACT_GAP으로 남기고 해당 구현·실행을 차단한다.
