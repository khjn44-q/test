# 07. Custom C 전역 코딩 표준

## 1. 적용 범위와 기본 방침

**모든 새 Custom 코드에 적용한다.** Vendor 원본, 보존 중인 legacy, 외부 OSS 원본, 자동 생성물에는 직접 포맷/이름 변경을 하지 않는다. 생성물은 생성 규칙을 바꾼 뒤 재생성하고, 외부 타입/콜백 서명을 유지해야 하는 경계 예외는 문서화한다.

기본 언어 후보는 C17이며 실제 GCC·SDK 제약을 확인한 뒤 고정한다. C11까지 낮춰야 할 근거가 있으면 ADR로 결정한다. GCC로 빌드한다는 이유만으로 최신 언어 모드나 모든 GNU 확장을 사용할 수 있다고 가정하지 않는다. 공통 코드는 가능한 표준 C, 타깃 확장은 Provider/Platform에 집중한다.

이 표준의 수치(예: 줄 길이)는 팀 선택안이지 외부 규격의 강제 요구가 아니다. 처음 채택할 때 합의하되, 파일별 취향으로 변경하지 않는다.

## 2. 이름의 전역 문법

| 대상 | 규칙 | 좋은 예 |
|---|---|---|
| 프로젝트 접두사 | Custom 외부 심볼은 `se_` | `se_nvme_build_identify` |
| 함수 | `se_<domain>_<action>_<object>`를 기본으로 lower_snake_case | `se_psu_read_voltage` |
| 변수·인자·필드 | lower_snake_case, 의미와 단위 포함 | `transfer_bytes`, `deadline_ns` |
| 파일 정적 함수 | `static`, 영역 의미가 드러나는 `se_` 이름 | `se_pcie_check_next_offset` |
| struct/enum tag | `se_<domain>_<concept>` | `struct se_nvme_completion` |
| 타입 alias | 필요한 경우에만 `se_...`; 포인터를 숨기지 않음 | `se_trace_callback` |
| enum 상수/매크로 | `SE_<DOMAIN>_<MEANING>` | `SE_VERDICT_INCONCLUSIVE` |
| 파일 | domain과 책임이 드러나는 lower_snake_case | `se_nvme_health_decode.c` |
| 헤더 가드 | `SE_<PATH>_<FILE>_H` | `SE_NVME_HEALTH_H` |
| 단위시험 | `se_test_<unit>_<condition>_<expected>` | `se_test_health_short_buffer_rejected` |
| 스키마 ID | 안정적인 의미 기반 ID, 이름 변경과 분리 | `FIELD-NVME-HEALTH-TEMP` |

외부 ABI의 이름은 그대로 두되 Provider 안에서 Custom 용어로 변환한다. 표준에서 널리 쓰는 `nvme`, `pcie`, `sqe`, `cqe`, `nsid`, `lba`, `dma`, `bdf`, `psu`는 glossary에 정의하고 허용한다. `foo`, `data2`, `func1`, `tmpbuf2`, `my_*`, `new_*`, `old_*`, `do_test`, `handle_everything`은 의미 있는 이름으로 바꾼다.

루프 인덱스 `i`는 짧고 명확한 범위에서 허용하되 중첩 루프나 도메인 의미가 있는 인덱스는 `slot_index`, `entry_index`를 쓴다. 모든 이름을 극단적으로 길게 만들어 가독성을 해치는 것도 피한다.

구현 예약 식별자와 충돌하지 않도록 leading underscore와 이중 underscore를 프로젝트 이름에 쓰지 않는다. CERT의 예약 식별자 및 구별 가능한 이름 지침을 참고한다. [S35] · [S36] 자체 typedef의 `_t` 접미사는 이 프로젝트에서는 보수적으로 사용하지 않는 선택안이다. 이것을 모든 C 환경에서 일괄 금지된다는 주장으로 해석하지 않는다.

## 3. 동사는 실행 의미를 드러내야 한다

| 동사 | 계약 |
|---|---|
| `build` / `encode` | 요청/바이트 생성; 하드웨어 효과 없음 |
| `decode` / `parse` | 입력 해석; 길이·유효성 검증 |
| `submit` | 요청 제출; 완료를 의미하지 않음 |
| `poll` | 현재 상태 확인; blocking 여부를 명확히 제한 |
| `wait` | 정해진 완료/기한/취소 규칙에 따라 대기 |
| `read` | 실제 대상에서 조회; 캐시이면 이름/계약에 표시 |
| `get_cached` | 저장된 값 읽기, freshness 제공 |
| `set_target` | 목표값 요청; 실제 도달과 구분 |
| `acquire` / `release` | 자원·수명 소유권 획득/반환 |
| `cancel` | 취소 요청; 취소 완료가 아닐 수 있음 |
| `evaluate` | 관측값과 정책으로 판정, 장비 제어 없음 |

`reset()` 하나로 Controller Reset, PCIe 링크 Reset, Power Cycle을 모두 처리하지 않는다. 중요한 차이를 enum 인자로 표현할 수도 있지만 이름과 계약에서 범위가 분명해야 한다.

## 4. 단위와 값의 표현

기본 단위 표를 저장소 정본으로 둔다. 제안: 바이트 `_bytes`, 지속시간 `_ns`/`_us`/`_ms` 중 경계별 명시, 목표/측정 전압 `_uv`, 전류 `_ua`, 온도 `_mdegc`, raw 규격 온도 `_kelvin` 등.

`temperature_mdegc`는 섭씨 1/1000 단위의 정수라는 뜻을 glossary에 정의한다. 음수 온도를 표현할 수 있어야 한다. 전압의 signedness는 장비가 음전압을 다루는지까지 확인한 뒤 정한다. 값의 단위와 허용 범위는 별개다.

시간에는 `duration_ns`와 `deadline_ns`를 구분한다. Wall-clock timestamp와 monotonic timestamp는 별도 타입/필드로 둔다. Clock Domain도 기록한다. 숫자 이름에 `_ms`를 붙였다는 이유만으로 잘못된 변환이 방지되는 것은 아니므로 경계 helper와 시험을 둔다.

혼동 위험이 높은 handle·주소 공간·단위에는 작은 wrapper struct를 고려한다. 모든 정수에 새 타입을 만들어 함수 호출이 과도하게 복잡해지게 하지는 않는다.

## 5. 타입·정수·길이

규격상 고정 폭은 `<stdint.h>` 타입으로 표현하고, 로컬 메모리 길이/인덱스는 `size_t`를 우선 검토한다. `unsigned long`을 wire 필드 크기 표현에 사용하지 않는다. `bool`은 참/거짓에 쓰며 다중 상태/오류를 숨기지 않는다.

signed/unsigned 변환, 덧셈·곱셈 overflow, shift 폭, narrowing, 포인터 차이, 배열 인덱스는 명시적으로 검사한다. 길이 계산 후 검사보다 **계산 전에 표현 가능한지 검사**한다. 부호 없는 값의 wrap을 이용할 경우에는 그 목적과 증명이 필요하다.

예를 들어 총 길이 산출에서는 `count * element_size`가 overflow하는지 먼저 검사한다. 부적절한 캐스트를 추가해서 경고만 없애지 않는다. 검증 결과를 반영해 변환한다.

VLA, `alloca`, 무제한 재귀는 기본 금지 후보다. 성능 민감 루프의 heap 할당은 피하고 준비 단계의 buffer pool/명시적 수명을 우선한다. 불가피한 동적 할당은 failure·상한·해제 책임이 명확해야 한다.

## 6. 함수 인터페이스

함수는 하나의 명확한 책임을 가진다. 반환값은 상태, 실제 결과는 typed output으로 분리하는 것을 기본으로 한다. 단순한 순수 값 계산이나 predicate까지 억지로 상태 코드를 강제하지 않는다.

포인터 인자는 읽기 전용이면 `const`를 사용한다. 배열/버퍼는 길이를 같이 받는다. Output의 실패 시 상태(변경 없음, 초기화됨, 부분 결과 유효)를 API 계약에 고정한다. 서로 다른 함수가 제각각 동작하게 두지 않는다.

호출 계약 예시 — 실제 SDK API가 아니라 Custom 인터페이스의 형태 제안:

```c
struct se_bytes_view {
    const uint8_t *data;
    size_t length_bytes;
};

enum se_status se_nvme_decode_health(
    struct se_bytes_view input,
    const struct se_protocol_profile *profile,
    struct se_nvme_health *out_health);
```

해당 선언의 타입·상태 정의와 구현은 사내 설계에서 확정해야 한다. 이 패키지는 컴파일 가능한 제품 헤더를 제공했다고 주장하지 않는다.

인자가 너무 많으면 논리적으로 응집된 request struct를 사용한다. 반대로 모든 인자를 `void *config`로 감추거나 불필요한 setter 10개로 나누지 않는다. Boolean 인자 여러 개보다 의미가 분명한 enum 또는 config 필드가 낫다.

## 7. 오류와 판정

`SE_STATUS_OK = 0` 같은 상태 convention은 가능하지만, 결과 구조체가 zero-init되었다고 시험 PASS가 되면 안 된다. `SE_VERDICT_UNSET = 0` 또는 동등한 초기 미판정 상태를 둔다.

일반 성공/실패와 raw Vendor 오류, NVMe completion status, 관측 유효성, 시험 판정을 각각 보존한다. 오류를 문자열만으로 전달하지 않는다. 사람이 읽는 메시지는 구조화된 코드·request ID·원시 근거를 보조한다.

하위 계층은 로그를 과도하게 출력하기보다 오류 정보를 반환하고, 소유 계층이 한 번의 주 이벤트로 기록한다. 진단상 필요한 하위 Trace는 별도 레벨로 둔다. ‘같은 오류가 5개 레이어에서 중복 출력’되는 구조를 피한다.

C의 단일 cleanup 경로를 위한 제한적인 `goto cleanup`은 허용할 수 있다. 성공 경로/오류 경로/해제 순서를 명료하게 만드는지가 기준이다. `goto` 금지 자체를 목표로 삼지 않는다.

## 8. 상태·전역·동시성

Custom mutable file/global state는 기본 금지하고, 명시적 Context에 둔다. 예외는 불변 lookup table, 초기화 이후 불변 registry, 승인된 단일 장비 런타임 연결 등이다. 예외마다 owner·수명·동시성·시험 방법을 기록한다.

Vendor extern은 Provider 내부에서만 접근한다. `extern` 선언을 공통 헤더에 재노출하지 않는다. `volatile`을 추가하여 데이터 경합을 해결했다고 주장하지 않는다. [S20]

lock 소유권, lock order, 콜백 실행 thread, blocking 금지 영역, cancel signal 전달 방식을 문서화한다. lock을 잡은 상태로 장비 API/콜백을 호출하는 경우 재진입과 deadlock 가능성을 검토한다. 콜백에서 받은 포인터를 장기 보관하려면 별도 수명 계약이 있어야 한다.

## 9. 헤더와 모듈

공개 헤더는 필요한 표준 타입과 공통 타입만 포함한다. Vendor·운영체제 전용 include를 누출하지 않는다. 자체 헤더를 `.c`의 첫 include로 두는 규칙을 검토하여 누락 의존성을 발견한다.

구현 세부 구조체는 opaque handle로 감출 수 있지만 단순 값 객체까지 모두 opaque로 만들어 분석성을 낮추지 않는다. 외부 API/내부 헤더를 나누고 불필요한 심볼은 `static`으로 제한한다.

순환 의존성을 해결하려고 공통 거대 헤더에 모든 타입을 넣지 않는다. 모듈 공통 타입은 해당 도메인에 두고 상호 의존이 생긴 이유를 먼저 검토한다. 단순 두 함수 때문에 새 레이어·새 인터페이스를 무조건 만드는 것도 피한다.

## 10. 매크로와 전처리

헤더 가드, 컴파일러/타깃 적응, 검증된 상수·mask 정의에는 매크로를 쓸 수 있다. 일반 로직은 `static inline` 또는 함수로 우선 구현한다. 인자를 여러 번 평가하는 매크로, 복잡한 statement-expression 매크로, 함수명 전역 치환은 피한다.

모델 선택 `#if`는 Build/Bootstrap/Provider 경계로 제한한다. Custom 공통 Item에 `MODEL_A` 분기를 넣지 않는다. 프로토콜/컴파일러 능력에 따른 compile-time 분기는 별도 ADR과 시험 범위를 가진다.

## 11. 주석과 API 문서

‘한 줄마다 영어 번역’ 같은 주석은 필요 없다. 이유, 전제·후조건, 단위, ownership, 위험, 규격/계약 ID, workaround의 근거를 적는다. 공개 API는 최소한 인자·반환·오류 후 상태·스레드/수명 규칙을 설명한다.

```c
/**
 * Requests a new target voltage; does not imply measured stabilization.
 * Contract: PORT-PSU-SET-TARGET
 * Ownership: caller retains the request; provider must not retain it.
 * Failure: no claimed physical rollback; inspect returned effect state.
 */
```

식별자는 ASCII 영어를 권고한다. 설명은 팀이 유지 가능한 언어로 일관되게 작성한다. 한국어 설명 자체를 LLM 비친화적이라고 가정하지 않는다. 의미 있는 한 언어의 정본을 유지하고 불필요한 한영 중복 문서를 만들지 않는다.

## 12. 포맷과 검사

제안 기준은 공백 4칸, 한 줄 100자 목표, 중괄호 스타일 통일, 행 끝 공백 제거, UTF-8/LF다. 긴 규격 링크·표·시험 벡터는 예외를 허용한다. `.clang-format`은 버전을 고정해 사용한다. [S42]

`clang-tidy`의 naming check로 이름 규칙 일부를 검사할 수 있지만 함수 이름의 의미나 단위 정확성까지 보증하지 않는다. [S17] · [S18] 접두사·Vendor include·모델 분기·전역변수·금지 API는 추가 빌드/AST/스크립트 검사로 보완한다.

함수 길이/복잡도 기준은 리뷰 알림으로 사용하고 자동 PASS/FAIL의 유일한 근거로 삼지 않는다. 단순 switch 표를 억지로 여러 함수로 쪼개거나, 짧게 보이려고 매크로에 복잡성을 숨기지 않는다.

## 13. 코드 리뷰 질문

이 함수는 어떤 장비 효과를 내는가? 완료와 요청 접수를 구별하는가? 입력 길이/단위/소유권이 드러나는가? 오류 후 버퍼/자원 상태가 알려지는가? 의도된 비정상 명령을 바꾸지 않는가? 새로운 전역·Vendor 의존이 새었는가? 명명 규칙과 실제 의미가 일치하는가? 독립적인 실패 시험이 있는가?

이 질문에 답하기 어려우면 ‘가독성이 좋은 코드’라고 보기 어렵다. 포맷만 깔끔한 것은 충분하지 않다.

## 14. R2 필수 강화 — 파일명·타입·반례를 규칙 정본으로

모든 새 `.c/.h`, 테스트, schema ID, generated output 이름에 적용할 파일 명명 규칙을 `docs/standards/file_and_symbol_naming.md`에 고정한다. domain+책임을 기준으로 하고 `utils/misc/common2` 같은 의미 불명 모음집을 만들지 않는다. 폼팩터/모델명을 공통 파일명에 넣어 복제를 정당화하지 않는다. 실제 모델별 구현에만 해당 식별자를 사용한다.

선언 타입뿐 아니라 연산 중간 타입·단위·범위·narrowing의 근거를 문서화한다. 20장의 위험 산술 표와 검증을 필수 review 기준으로 연결한다. 이름에 단위를 붙이는 것만으로 타입 안전이 확보되었다고 하지 않는다. `memcpy`/cast/packed를 만능 수정책으로 사용하지 않는다.

기존 Vendor나 legacy의 스타일을 새 Custom 규칙으로 자동 승계하지 않는다. 반면 ABI에 필요한 원본 이름/레이아웃은 경계에서 유지한다. 예외 문서는 rule ID, 이유, 범위, owner, 승인, 시험과 만료 조건을 포함한다. 생성 코드는 생성 규칙에서 수정한다.

<!-- SOURCE_LINKS_START -->

[S17]: https://clang.llvm.org/extra/clang-tidy/
[S18]: https://clang.llvm.org/extra/clang-tidy/checks/readability/identifier-naming.html
[S20]: https://gcc.gnu.org/onlinedocs/gcc/Volatiles.html
[S35]: https://cmu-sei.github.io/secure-coding-standards/sei-cert-c-coding-standard/rules/declarations-and-initialization-dcl/dcl37-c/
[S36]: https://cmu-sei.github.io/secure-coding-standards/sei-cert-c-coding-standard/recommendations/declarations-and-initialization-dcl/dcl02-c/
[S42]: https://clang.llvm.org/docs/ClangFormatStyleOptions.html
