# 03. 목표 코드 구조와 의존성 계약

## 1. 권고 구조

아래는 최종 폴더명이 아니라 책임 구분의 기준이다. 기능 중심 모듈 안에 공개 헤더·구현·단위시험·설명을 함께 둘 수 있다. ‘모든 헤더는 한 폴더, 모든 소스는 한 폴더’가 필수는 아니다.

```text
ssd-eval/
  vendor/                         # 모델/릴리스별 불변 공급 원본
  reference/legacy/               # 분석용 동결 사본; 신규 제품 링크 금지
  app/                            # standalone 또는 vendor_host 진입점
  platform/                       # OS 시간/스레드/파일; 장비 모델과 별도
  modules/
    base/                         # 상태 코드, 바이트 접근, 단위/ID
    nvme/                         # 명령/응답/필드: 하드웨어 접근 없음
    pcie/                         # 레지스터/패킷/필드: 지원 범위별
    private_commands/             # 내부 dialect별 순수 codec/계약
    uart_protocol/                # framing/세션 해석; 실제 port 접근과 분리
    compatibility/                # 다축 profile·기능·제약 검증
    ports/                        # 전송·환경·전원·자원에 대한 계약
    services/                     # 장비 독립 기능 조합
    runtime/                      # 실행 상태, 취소, 관측, 자원 소유
    items/
      <item_id>/                  # item.c, item.h, item.yaml, tests/, README.md
  providers/
    model_a/<sdk_binding>/        # Vendor 타입/전역/메모리 접근의 전용 영역
    model_b/<sdk_binding>/
    model_c/<sdk_binding>/
    fake/                         # Host 검증용; 실제 모델을 가장하지 않음
  profiles/                       # family/subtype/SDK/FW/Fixture/form factor/dialect
  docs/limitations/               # 구조화 제한과 사람용 설명의 연결
  specs/                          # 승인된 규격 프로필, 필드 스키마
  docs/                           # 설계·계약·ADR·작업 안내
  generated/                      # 생성물, 수동 편집 금지
  tests/                          # 통합·계약·golden vector·HIL 계획
  tools/                          # 추출·검사·생성; 승인된 오프라인 도구
  cmake/                          # 타깃·툴체인·프로필 선택
```

Vendor 패키지가 원래 내부 상대경로를 전제한다면 원본 구조를 보존한다. `vendor/` 아래에 원본을 이동하는 것 자체가 빌드에 영향을 줄 수 있으므로 SDK 아카이브의 보관 위치와 빌드 작업 사본 위치를 구분할 수 있다. 작업 사본을 수정할 권한을 기본으로 주지 않는다.

## 2. 의존성 그래프

```text
Entry/Bootstrap ──> Item Registry ──> Test Items
                                        │
                              Services / Assertions
                                │               │
                      Pure protocol code     Runtime ports
                                │               │
                          Common types / Contracts
                                                ▲
                                  Selected Model Provider
                                                │
                                 Vendor approved boundary

Platform implementations ──implement──> Clock / Files / Threads ports
Fake implementations ──implement──> Same contracts for host tests
```

공통 코드가 의존하는 것은 Provider 구현이 아니라 공통 계약이다. 실제 실행 호출은 Provider로 향하더라도, 소스 의존성의 방향은 ‘Provider가 계약을 구현’하는 구조다. 이전 대화의 ‘위에서 아래로만 의존’이라는 표현보다 이 구분이 정확하다.

## 3. 영역별 책임과 금지 사항

| 영역 | 소유 책임 | 금지 |
|---|---|---|
| `base` | 오류/단위/ID/바이트 유틸 | 장비 접근, 파일 전역 상태 |
| `nvme`, `pcie`, `private_commands`, `uart_protocol` | 순수 명령 구성·해석·필드 의미 | Vendor include, sleep, 장비 동작 |
| `ports` | 전제·후조건·소유권·관찰성 계약 | Vendor 타입 공개 |
| `providers` | ABI 변환, 실제 제출, SDK 오류/상태 접근 | 평가 PASS/FAIL 판정, 숨은 재시도 |
| `services` | 여러 기능을 재사용 가능한 의미로 조합 | 모델별 `if/ifdef`, 실험 기준을 임의 변경 |
| `runtime` | 세션, 자원 예약, 단계 진행, 취소, 기록 | 프로토콜의 모든 필드 의미를 중앙에 집어넣기 |
| `items` | 평가 목적·조건·순서·기대 결과·판정 | Vendor/OS 직접 호출, 임의 메모리 접근 |
| `platform` | 단조 시계, 스레드, 파일 등 환경 구현 | SSD 평가 정책 |
| `app` | Provider/Profile 선택 및 수명 연결 | 평가 로직 중복 |

평가 정책이 필요한 ‘재시도’는 Item/Service에 명시한다. Provider가 장비 API의 불가피한 내부 동작을 숨길 수 없다면 그 사실을 Capability와 Trace에 기록한다.

## 4. Context는 분리하되 만능 구조체를 만들지 않는다

권고하는 소유 단위는 다음과 같다.

| 객체 | 수명 | 내용 |
|---|---|---|
| Equipment Session | SDK 연결~안전 종료 | 모델/SDK/관측 능력/Provider private state |
| Resource Handle | 세션 내 | Chamber, Rail, Slot, PCIe Port의 논리 ID |
| DUT Session | DUT 인식~Reset/교체 | 컨트롤러/Namespace/세대 번호 |
| Run Context | 평가 실행 1회 | 설정 스냅샷, Run ID, 취소, Trace writer |
| Item State | Item 인스턴스 | 단계·반복 진행·기대값·부분 결과 |
| Request | 명령 수명 | 요청 ID, 버퍼 lease, deadline, 완료 상태 |
| Buffer Handle | 할당~안전 반환 | capacity, 유효 길이, owner, 주소 공간/세대 |

모든 함수에 거대한 `TestContext*`를 주기보다 필요한 좁은 계약과 불변 설정을 전달한다. Item에는 Run Context를 허용하되 내부 모듈에서 무관한 다른 기능을 꺼내 쓰는 Service Locator로 변질시키지 않는다.

## 5. 기능 포트의 후보

초기 구현은 사용되는 것만 만든다.

- NVMe submission/completion: 관리형·비동기·raw 필드 보존 수준을 명시.
- PCIe config/MMIO/link/reset/packet-observation/injection: 별개 능력으로 구분.
- Chamber target/readback/stability evidence.
- PSU rail target/readback/output/protection.
- UART byte stream/session route/비동기 trace: 실제 framing/dialect는 별도.
- Buffer allocation/mapping/sync/lifetime.
- Monotonic clock, cancellable wait, trace event.
- Resource acquisition and release.

기능을 하나의 `execute(opcode, void *payload)`로 통합하지 않는다. 타입 검사를 잃고 이름/단위/길이 오류가 런타임으로 이동한다. 외부 ABI가 범용 명령 테이블이더라도 Custom 포트는 typed façade를 제공한다.

## 6. 공통 동작과 모델별 동작의 판정 기준

‘같은 이름’, ‘비슷한 코드’, ‘같은 NVMe opcode’는 공통화의 충분조건이 아니다. 입력 의미, 완료 의미, 자원 범위, 실패 후 상태, 시간 보장, 데이터 보존, 재시도, 관측 능력이 맞아야 한다.

공통 계약을 충족하도록 변환 가능한 차이는 Provider에 둔다. 계약을 약화해야만 맞출 수 있는 차이는 Capability 제약으로 둔다. 평가 순서나 기대 결과가 실제로 다르면 Item의 별도 시나리오/정책으로 표현하며 모델명 분기 대신 **요구 능력과 평가 프로필**로 선언한다.

## 7. 같은 Item을 여러 모델에서 실행할 때의 조건

실행 전 Item 요구와 장비 검증 능력·DUT 특성·Fixture/자원 연결·허용 안전 범위를 제약식으로 비교한다. 일반 정상 명령에는 DUT 기능 지원이 필요할 수 있지만, 미지원 응답을 기대하는 음성 평가는 DUT 미지원 자체가 목적일 수 있다. 해당 Item이 요구하는 전달/관측 조건이 충족되지 않거나 증거 수준이 부족하면 `UNSUPPORTED/BLOCKED/INCONCLUSIVE`를 선택한다. 단순히 모든 조건을 기본값으로 채워 실행하지 않는다.

지원되지 않는 raw 패킷 주입을 관리형 NVMe 명령으로 흉내내거나, 비동기 테스트를 QD=1 동기식으로 낮추는 것은 별도 승인된 시험 변형이다. 원래 Item과 같은 ID/동일 판정이라고 보고하면 안 된다.

## 8. 확장 순서

첫 기능은 정확한 코드 확인 후 정한다. 대표 기준은 ‘현재 세 모델에서 공통으로 쓰이고, 바이트 파싱·버퍼·실제 호출 경계를 확인할 수 있으며, 실장비 위험이 비교적 낮은 기능’이다. 승인된 환경에서는 Identify/Log 조회가 후보지만 **조회도 완전히 무해하다고 보증하지 않는다**. Host 골든 데이터 검증을 먼저 한다.

그다음 명시적인 I/O, Reset/Power, 환경 제어, 공유 자원, 타이밍 민감 평가 순으로 범위를 늘린다. 실제 사내 우선순위가 다르면 순서를 바꿀 수 있지만 위험 수준과 증거 게이트는 유지한다.

## 9. R2의 추가 의존성 규칙

Internal command 의미는 SSD 개발사 dialect 모듈이, 실제 UART/NVMe 전송은 port/provider가 소유한다. UART raw 수신과 command/log demultiplexing은 명시적 세션 소유권을 갖는다. 표준 규격 상수와 Vendor의 지원 상한은 같은 namespace에 넣지 않는다.

`compatibility`는 승인된 profile/limitation 데이터를 받아 실행 전 요구 충족 여부와 이유를 판정하는 순수 부분을 가진다. 실제 identity 조회는 별도 port로 수행한다. profile resolver가 파일/장비를 몰래 탐색하거나 unknown 값을 자동 선택하지 않는다.

Feature 중심 폴더를 우선하되 모듈 경계는 코드 복잡도에 맞춘다. `se_uart_frame_decode.c`와 해당 tests/docs처럼 함께 바뀌는 것을 찾기 쉽게 배치한다. 파일명·공개 API·설명 ID의 관계는 naming manifest로 고정한다. 여기의 경로는 후보이며 실제 repo layout을 확인한 후 ADR로 채택한다.

## 10. 단일 Provider의 의미

빌드별 단일 Provider 권고는 주로 서로 충돌하는 장비 SDK 계열/binding을 하나 선택한다는 뜻이다. 별도 UART/Chamber/PSU 자원에 독립 Provider가 필요하면 기능별 포트에 함께 연결할 수 있다. 모든 주변기기를 거대한 장비 ops 하나에 강제로 넣지 않는다. 구체적 연결 수와 생명주기는 실제 topology와 소유권으로 결정한다.
