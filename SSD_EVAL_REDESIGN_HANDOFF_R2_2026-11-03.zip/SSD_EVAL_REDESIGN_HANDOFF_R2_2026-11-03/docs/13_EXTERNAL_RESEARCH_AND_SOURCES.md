# 13. 외부 조사 결과와 도입 판단

## 1. 조사 범위와 한계

확인일은 **2026-11-03**이다. 프로젝트의 공식 저장소, 제작자 문서, GCC/LLVM/CMake 공식 문서, NVM Express/PCI-SIG 공식 페이지를 우선 확인했다. 앞선 대화의 출처 표기를 그대로 신뢰하지 않고 공개 원문을 다시 확인했다.

이번에 도구를 사내 코드에 설치·실행하거나 비교 벤치마크하지 않았다. 별점/다운로드/최근 커밋 수를 품질 보증으로 사용하지 않았다. `latest`, `main`, `master` URL은 움직이므로 사내 채택 시 **승인한 release/commit과 파일별 라이선스**를 다시 고정해야 한다.

이 문서의 ‘추천’은 이 프로젝트 상황에 대한 설계 판단이다. 외부 프로젝트가 이 SSD 평가 장비 3종을 지원한다는 사실이나 성능 개선률을 확인한 것은 아니다.

## 2. 최소 스택 권고

**기본:** 기존 GCC 유지, CMake 또는 기존 Make의 타깃별 선택 빌드, compile database, rg/Ctags, 필요한 명세/헤더, GCC 진단, Host 단위시험.

**두 번째:** Doxygen, Clang 기반 의미 분석, Cppcheck, clang-tidy, 선택적인 CMock. 실제 문제와 반복 작업이 확인된 부분에 추가한다.

**조건부:** OpenSpec 등 하나의 변경 관리 방식, Coccinelle, CBMC/Frama-C, fuzzing, xNVMe/기타 외부 런타임 도입.

‘최고의 도구를 다 설치’하기보다 **분석 정본 하나, 빌드 정본 하나, 변경 명세 정본 하나**를 유지하는 구성이 목적이다.

## 3. 도구별 적용 판단

| 후보 | 공식적으로 확인한 성격 | 이 프로젝트 적용 | 우선도/주의 |
|---|---|---|---|
| CMake | 타깃 중심 빌드/의존성, Presets | 모델 선택과 include/flags 범위 관리 | 우선; 기존 SDK 빌드 대체는 별도 검증 [S01] · [S02] |
| compilation database | TU별 컴파일 문맥 표현 | 모델/SDK/매크로별 분석 근거 | 필수에 가까움; 실제 build와 일치 [S03] · [S04] |
| Bear | 기존 빌드의 compile command 수집 | 직접 export가 안 될 때 | 조건부; 실제 플랫폼/빌드 방식 확인 [S06] |
| Clang LibTooling | C/C++ 소스 분석 도구 기반 | 타입/참조/호출 추출 | 우선 검토; GCC 확장 완전 호환 가정 금지 [S05] |
| Universal Ctags | 심볼 인덱스 | 정확한 함수 위치 탐색 | 가볍게 시작; 의미 분석과 구분 [S07] |
| Doxygen | 소스 문서/여러 출력 형식 | Custom API 탐색, XML 기반 연계 | 자동 문서가 검증된 동작 명세는 아님 [S08] · [S39] |
| Coccinelle | C 의미 패턴/변환 | 금지 패턴 탐지, 반복 Custom 변경 | 대량 rewrite 전 dry diff/리뷰 [S09] |
| GCC analyzer | C 경로 기반 결함 탐지 | 생산 툴체인과 가까운 검사 | 증명 도구 아님 [S14] |
| Cppcheck | C/C++ 정적 검사 | 독립적인 결함 탐지 보완 | build/SDK 모델·오탐 관리 [S16] |
| clang-tidy | 규칙 기반 분석/리팩터링 검사 | 명명·일부 결함·코딩 표준 | 모든 check가 C에 유효한 것 아님 [S17] · [S18] |
| Unity | C 단위시험 | Pure/Fake tests | 기본 후보 [S22] |
| CMock | C 헤더 기반 mock/stub 생성 | 포트 오류 경로 시험 | 과도한 mock 결합도 주의 [S23] |
| Ceedling | Unity/CMock 및 C 시험 빌드 관리 | 이미 쓰거나 시험 중심 환경일 때 | CMake와 이중 빌드 정본 방지 [S24] |
| CBMC | bounded model checking | 길이/상태/핵심 안전 검사 | 가정·unwind 범위 명시 [S31] |
| Frama-C Eva/WP | 값 분석, ACSL 계약 검증 | 선택 핵심 모듈의 강한 검토 | 전체 SDK 자동 증명 목표 금지 [S32] · [S33] |
| libFuzzer | coverage-guided fuzzing | parser/decoder/Fake 이벤트 | 실장비 직접 fuzz 금지 [S34] |
| clang-format | 코드 포맷 자동화 | Custom 스타일 일관성 | 버전 고정, Vendor/생성물 제외 [S42] |

## 4. NVMe/PCIe 관련 외부 구현

### 4.1 libnvme

NVMe 구조체·enum·필드, 명령 구성/전달/해석, Linux 장치 관리 기능을 제공하는 실제 C 라이브러리다. 프로젝트는 규격과 충돌할 때 공개 규격을 기준으로 삼으라고 명시한다. [S26]

여기서는 field 목록·설계·교차 검토에 유용한 참고다. Linux 장치 접근을 전제로 하는 기능이 Vendor 장비 경계와 맞는지는 별도 문제다. 라이선스는 저장소 기본 안내에 LGPL-2.1-or-later가 명시되어 있으므로 일부 코드를 복사하거나 정적으로 링크하는 결정을 단순한 ‘무료 재사용’으로 처리하지 않는다. 실제 파일과 배포 방식은 사내 검토 대상으로 둔다.

### 4.2 xNVMe

Backend별 구현을 연결하는 구조와 명령 Context 설계는 이 프로젝트와 비교할 가치가 있다. [S25] 다만 직접 도입을 권고하기 전에 Vendor 버퍼·비동기·명령 필드 보존·SDK 제약이 그 인터페이스와 맞는지 확인해야 한다.

외부 프레임워크를 넣기 위해 Vendor SDK가 가진 타이밍/시퀀스 능력을 잃거나, Chamber/PSU를 억지로 NVMe Backend 안에 넣지 않는다. 초기에는 경계 설계 참고, 그다음 작은 통합 실험 순서가 적절하다.

### 4.3 SPDK

사용자 공간 NVMe 드라이버와 raw command 경로 등의 공식 API가 있다. [S27] 명령/완료/queue/buffer 책임을 비교하는 참고 가치가 있지만, Vendor SDK가 관리하는 장치를 SPDK로 다시 소유하게 만드는 것은 별도 큰 아키텍처 변화다.

따라서 ‘NVMe니까 SPDK를 붙이면 해결’이라고 권고하지 않는다. 장비의 FPGA/펌웨어/SDK 의존 경계와 직접 PCIe 장치 접근 권한이 다르면 대체재가 아니다.

### 4.4 Kaitai Struct

구조화된 binary format 명세와 parser 생성 접근의 참고 후보다. 공식 문서의 C++ 출력과 순수 C 출력은 같은 것이 아니다. 현재 조사만으로 이 프로젝트의 순수 C parser 생성기로 적합하다고 확인하지 않았다. [S38]

초기에는 수동 명시 파서 + 제한적 schema 생성으로 시작하고, 외부 생성기를 채택하려면 target language, allocation, error/lifetime 모델, 라이선스, 생성물 가독성, 추적성부터 검증한다.

## 5. 스킬·명세 중심 개발 후보

| 후보 | 사용할 수 있는 역할 | 해결하지 않는 문제 | 채택 판단 |
|---|---|---|---|
| OpenSpec | 명세·변경 artifacts·AI workflow | C ABI, 장비 API 의미, 실제 타이밍 | 기본 명세 도구 후보 [S10] |
| Superpowers | 설계/TDD/디버깅/검증 진행 규칙 | 장비 도메인 사실과 안전 권한 | 기존 Harness와 맞으면 절차 활용 [S11] |
| Spec Kit | 구조화된 개발 프로세스·템플릿 | Vendor 계약 자동 복원 | OpenSpec 대안; 중복 도입 지양 [S12] |
| code-index Skill | Ctags 기반 symbol-range 탐색 | preprocessor/alias/부작용 완전 분석 | 가벼운 탐색 보조 [S13] |
| Agent Skills 형식 | 역할 지침과 참조/스크립트 묶음 | 자동 실행 보장·권한 집행 | 사내 Harness에서 실제 지원 확인 [S37] |

공개 스킬의 자동 실행·다운로드·외부 네트워크 동작을 검토하고 필요한 부분만 가져온다. 프로젝트별 custom role은 실제 LLM 작업 사례로 시험해야 하며, Markdown 파일을 만들었다고 안정적으로 작동한다고 주장하지 않는다.

## 6. 표준과 라이선스·AI 사용 조건

NVM Express 공식 페이지는 규격군과 보관본/변경 자료의 접근 경로를 제공한다. 최신 문서를 발견했더라도 실제 DUT 평가 기준은 사내 승인 profile로 고정해야 한다. [S28]

PCI-SIG 공식 페이지는 회원의 규격 접근과 비회원 구매 경로를 설명하며, 상용 AI 시스템에 관한 별도 사용 제한과 **내부 이용/내부 이용 개발을 구분하는 문구**를 함께 둔다. [S29]

이 문구만으로 모든 사내 LLM 이용이 금지되었다고 말하는 것도, 모든 클라우드 LLM 업로드가 허용되었다고 말하는 것도 부정확하다. 실제 회사의 문서 취득 권한, 적용 계약, 외부 서비스 이용 형태, 데이터 보존/학습 조건을 담당 부서와 확인한다. 허용된 범위에서 내부 근거 ID와 문서 위치를 관리한다. 이 패키지는 규격 원문을 복제·배포하지 않는다.

## 7. 도입 전 공통 체크

도구마다 승인 버전/commit/hash, license/notice, dependency 목록, 설치 위치, offline 동작, telemetry/network 여부, 입력 소스의 보관 범위, 지원 OS/ABI, rollback, owner를 확인한다.

개발 중 실행하는 도구와 제품 바이너리에 들어가는 라이브러리를 구별한다. 공개 소스라는 이유로 코드 복사·생성물 배포·규격 원문의 LLM 입력 조건을 같게 취급하지 않는다.

## 8. R2 추가 조사와 채택 경계

GCC 전처리 문서는 실제 TU의 macro 문맥 복원에, checked arithmetic 자료는 수치 경계 구현 후보에 연결한다. Clang UBSan의 검사 그룹은 unsigned/implicit 변환 검증의 별도 필요성을 확인하는 근거다. 표준 옵션 이름이 비슷하다고 GCC/Clang에서 동일 지원이라고 가정하지 않는다. [S43] [S44] [S45]

Kconfig는 복잡한 조합의 제약을 표현하는 조건부 후보다. CMake 타깃 선택·런타임 identity·물리 안전을 대신하지 않는다. 실제 매크로 복잡성과 필요성이 확인되기 전 도입하지 않는다. [S46] [S47]

libserialport의 API 계약은 UART transport 설계 비교에 유용하지만 장비/SSD의 자체 dialect, 핀, 전기·baud, timing은 내부 자료로 확인한다. 실제 라이브러리 도입과 설계 참고는 구분한다. [S48]

Git worktree/ls-files는 작업 트리·입력 기준선 관리에 참고한다. 기존 Git hosting이 무엇인지는 미확인이며 원격 저장소에 접근하거나 변경하지 않았다. CodeChecker/SARIF는 반복 분석 결과 관리 후보이고 현재 제품에 설치한 도구가 아니다. [S49] [S50] [S51] [S52]

기존 42개 자료와 R2 추가 10개 자료의 역할·한계를 공식 원문에서 확인했다. `latest/main/master` 문서는 변할 수 있으므로 채택 때 사내 승인 release/commit/hash를 고정한다. 이 문서의 52개 출처가 52개 도구를 도입하라는 뜻은 아니다. 규격 원문 field별 해석, 내부 소스 적합성, 실제 도구 성능은 검증하지 않았다.

## 9. 원문 출처 레지스트리

공식 문서/저장소의 기능 범위만 확인한 목록이다. 사내 계약/보안/라이선스·실제 toolchain 적용 여부는 별도 검토한다. 공개 링크는 이 문서의 주장을 뒷받침하는 자료이지 내부 규격을 대체하지 않는다.

| ID | 공식 원문 | 확인 범위 | 한계 |
|---|---|---|---|
| S01 | [CMake buildsystem](https://cmake.org/cmake/help/latest/manual/cmake-buildsystem.7.html) | 타깃과 의존성 모델 | SDK의 실제 빌드 호환성은 미검증 |
| S02 | [CMake Presets](https://cmake.org/cmake/help/latest/manual/cmake-presets.7.html) | 공용/개인 configure·build·test 설정 | 사내 도입 버전과 preset schema를 고정해야 함 |
| S03 | [CMake compile command export](https://cmake.org/cmake/help/latest/variable/CMAKE_EXPORT_COMPILE_COMMANDS.html) | compile_commands.json 생성과 Generator 제약 | 전용 Vendor build에서는 별도 방법이 필요할 수 있음 |
| S04 | [Clang compilation database format](https://clang.llvm.org/docs/JSONCompilationDatabase.html) | TU별 arguments/directory/file 문맥 | 분석 데이터가 실제 생산 build와 같아야 함 |
| S05 | [Clang LibTooling](https://clang.llvm.org/docs/LibTooling.html) | 소스 분석 도구 기반 | 비공개 API 의미·모든 간접 호출 자동 복원 도구 아님 |
| S06 | [Bear](https://github.com/rizsotto/Bear) | 기존 빌드의 compiler invocation 수집 | 실제 플랫폼/빌드 방식에서 수집 가능 여부 미시험 |
| S07 | [Universal Ctags](https://docs.ctags.io/en/latest/) | 심볼 위치와 인덱스 | 타입/alias/부작용의 완전한 의미 분석 아님 |
| S08 | [Doxygen output formats](https://www.doxygen.nl/manual/output.html) | HTML/XML 등 출력 지원 | 자동 생성 문서는 의미 검증과 다름 |
| S09 | [Coccinelle](https://coccinelle.gitlabpages.inria.fr/website/) | SmPL 기반 C 패턴/변환 | 자동 수정의 정확성은 별도 검증 |
| S10 | [OpenSpec](https://github.com/Fission-AI/OpenSpec) | AI 명세 중심 변경 관리 | 장비 분석 엔진 아님; 설치/버전 적합성 미시험 |
| S11 | [Superpowers](https://github.com/obra/superpowers) | 조합 가능한 개발 절차/스킬 | Hardware 권한 집행/도메인 사실 검증 대체 아님 |
| S12 | [Spec Kit](https://github.com/github/spec-kit) | 구조화 개발 프로세스/템플릿 | OpenSpec과 기능 중복을 사내에서 판단 |
| S13 | [Code-indexing Skill](https://github.com/kcem/code-index/blob/main/plugins/code-index/skills/code-indexing/SKILL.md) | Ctags와 symbol-range 읽기 절차 | 코드 의미/장비 기능을 자동 확정하지 않음 |
| S14 | [GCC Static Analyzer](https://gcc.gnu.org/onlinedocs/gcc/Static-Analyzer-Options.html) | -fanalyzer, 오탐·미탐 한계 | 정확성 증명 도구가 아님 |
| S15 | [GCC Warning Options](https://gcc.gnu.org/onlinedocs/gcc/Warning-Options.html) | 경고·Werror·선택 진단 옵션 | 실제 GCC release별 지원을 확인해야 함 |
| S16 | [Cppcheck manual](https://cppcheck.sourceforge.io/manual.html) | compile database 입력과 정적 검사 구성 | SDK 모델·분석 설정·진단 품질은 미시험 |
| S17 | [Clang-Tidy](https://clang.llvm.org/extra/clang-tidy/) | 규칙 기반 코드 검사 | C/GCC 코드 호환성과 check 선택 필요 |
| S18 | [Identifier naming check](https://clang.llvm.org/extra/clang-tidy/checks/readability/identifier-naming.html) | 식별자 규칙 설정 | 이름의 도메인 의미까지 검증하지 않음 |
| S19 | [GCC structure/bit-field ABI](https://gcc.gnu.org/onlinedocs/gcc/Structures-unions-enumerations-and-bit-fields-implementation.html) | 비트필드 순서와 구조체 정렬 등의 ABI 의존성 | 장비 ABI를 이 문서만으로 확정할 수 없음 |
| S20 | [GCC volatile semantics](https://gcc.gnu.org/onlinedocs/gcc/Volatiles.html) | volatile 접근 의미·일반 장벽과의 구분 | 실제 MMIO/DMA 순서는 타깃 계약 필요 |
| S21 | [GCC instrumentation](https://gcc.gnu.org/onlinedocs/gcc/Instrumentation-Options.html) | instrumentation/sanitizer 관련 옵션 | Vendor 바이너리·DMA·실시간 타깃 지원 미검증 |
| S22 | [Unity](https://github.com/ThrowTheSwitch/Unity) | C 단위시험 | 실장비 시험 프레임워크로 검증한 것이 아님 |
| S23 | [CMock](https://github.com/ThrowTheSwitch/CMock) | C header 기반 mock/stub 생성 | Mock은 실제 SDK의 정확성 증거가 아님 |
| S24 | [Ceedling](https://www.throwtheswitch.org/ceedling) | Unity/CMock 기반 C 시험 build 관리 | CMake와의 정본 중복 방지 필요 |
| S25 | [xNVMe Backend Interface](https://xnvme.io/background/backends/common/interface/index.html) | backend/command/memory 역할 비교 | 해당 Vendor 장비의 backend 지원은 확인하지 않음 |
| S26 | [libnvme](https://github.com/linux-nvme/libnvme) | C 규격 타입·명령·Linux 관리, 기본 LGPL 안내 | 정적 링크/코드 복사/개별 파일 사용권은 사내 검토 필요 |
| S27 | [SPDK NVMe driver](https://spdk.io/doc/nvme.html) | NVMe driver/raw command 경로 | Vendor 장치 소유권을 대체할 수 있다고 확인하지 않음 |
| S28 | [NVM Express specifications](https://nvmexpress.org/specifications/) | Base/Command Set/Transport 등 규격군 구조 | 이번 조사에서 규격 원문 필드별 검증은 하지 않음 |
| S29 | [PCI-SIG specifications](https://pcisig.com/specifications) | 규격 접근/구매와 AI 이용 관련 공개 안내 | 유료/회원 규격 원문 미열람; 회사 계약 검토 필요 |
| S30 | [Linux DMA mapping guide](https://www.kernel.org/doc/html/latest/core-api/dma-api-howto.html) | CPU virtual/physical와 bus/DMA address 구분 | Linux DMA API를 Vendor SDK에 바로 적용하라는 뜻 아님 |
| S31 | [CBMC](https://www.cprover.org/cbmc/) | C/C++ bounded model checking, assertion/메모리 속성 | 환경 모델·unwinding·가정의 타당성이 필요 |
| S32 | [Frama-C Eva](https://www.frama-c.com/fc-plugins/eva.html) | 값 분석 | 특수 SDK의 모델링 적합성 미시험 |
| S33 | [Frama-C WP](https://www.frama-c.com/fc-plugins/wp.html) | ACSL 계약의 deductive verification | 계약/환경 가정/증명 의무를 명시해야 함 |
| S34 | [libFuzzer](https://llvm.org/docs/LibFuzzer.html) | coverage-guided fuzzing | 실장비 fuzzing은 이번 제안 범위 아님 |
| S35 | [CERT C reserved identifiers](https://cmu-sei.github.io/secure-coding-standards/sei-cert-c-coding-standard/rules/declarations-and-initialization-dcl/dcl37-c/) | 예약 식별자 지침 | 프로젝트 코딩 규칙의 일부 근거이며 인증 아님 |
| S36 | [CERT C distinct identifiers](https://cmu-sei.github.io/secure-coding-standards/sei-cert-c-coding-standard/recommendations/declarations-and-initialization-dcl/dcl02-c/) | 구별 가능하고 의미 있는 이름 지침 | 도메인 명명 사전은 자체 설계 필요 |
| S37 | [Agent Skills specification](https://agentskills.io/specification) | SKILL.md와 references/scripts 구조 | Harness별 발견·실행·권한 지원을 검증해야 함 |
| S38 | [Kaitai Struct user guide](https://doc.kaitai.io/user_guide.html) | binary-format 명세/생성 접근 | 순수 C 런타임 채택은 이 조사에서 검증되지 않음 |
| S39 | [Doxygen configuration](https://www.doxygen.nl/manual/config.html) | 문서/전처리/출력 설정 | 실제 build의 macro 문맥 재현은 별도 검토 |
| S40 | [CMake target include scope](https://cmake.org/cmake/help/latest/command/target_include_directories.html) | PRIVATE/PUBLIC/INTERFACE와 SYSTEM | SYSTEM은 보안 경계가 아님 |
| S41 | [GNU ld options](https://sourceware.org/binutils/docs/ld/Options.html) | link map/trace/archive 관련 진단 | binary-only 내부 행동의 완전 검증은 아님 |
| S42 | [Clang-Format options](https://clang.llvm.org/docs/ClangFormatStyleOptions.html) | 코드 포맷 설정 | 제공 template의 사내 버전 적합성은 미시험 |
| S43 | [GCC overflow builtins](https://gcc.gnu.org/onlinedocs/gcc/Integer-Overflow-Builtins.html) | 오버플로 검사 산술 내장 함수의 반환·출력 의미 | 실제 GCC 버전과 타깃 지원 확인 필요; 결과 오버플로 발생 시 출력 사용 금지 계약 별도 |
| S44 | [Clang UBSan checks](https://clang.llvm.org/docs/UndefinedBehaviorSanitizer.html) | undefined 그룹과 unsigned/implicit-conversion 검사의 구분 | Host 검사 범위에 한정; 전체 장비 동작이나 비계측 SDK를 증명하지 않음 |
| S45 | [GCC preprocessor options](https://gcc.gnu.org/onlinedocs/gcc/Preprocessor-Options.html) | -D/-U 순서, 강제 include, 전처리와 매크로 출력 | 실제 TU 조건 전체가 필요; 하나의 dump로 전체 구성 복원 불가 |
| S46 | [Kconfig language](https://kernel.org/doc/html/latest/kbuild/kconfig-language.html) | 구성 심볼·의존 조건 표현 | 선택적 후보; 물리 호환성·런타임 권한을 자동 증명하지 않음 |
| S47 | [Zephyr Kconfig tips](https://docs.zephyrproject.org/latest/build/kconfig/tips.html) | 구성 의존성 관리와 select 사용 주의 | Zephyr 전체 도입 권고가 아니며 사내 C/GCC 구조 적합성 미시험 |
| S48 | [libserialport API header](https://github.com/sigrokproject/libserialport/blob/master/libserialport.h) | 직렬 통신 읽기/쓰기/시간제한·버퍼 관련 공개 API 계약 | 실제 UART baud/framing/전기 조건/SSD dialect는 제공하지 않음 |
| S49 | [Git worktree](https://git-scm.com/docs/git-worktree) | 한 저장소의 여러 작업 트리와 공유/별도 상태 | 장비·프로세스·SDK 전역 상태를 격리하는 보안 기능이 아님 |
| S50 | [Git ls-files](https://git-scm.com/docs/git-ls-files) | 추적·비추적·무시 파일 조회 옵션 | Git 목록과 실제 배포/외부 SDK 입력 전체가 일치한다는 보장은 없음 |
| S51 | [CodeChecker](https://codechecker.readthedocs.io/en/latest/) | 정적분석 실행·결과 관리 기반 | C/GCC SDK 호환성·검출 품질 미시험; 독립 검증 필요 |
| S52 | [OASIS SARIF 2.1.0](https://docs.oasis-open.org/sarif/sarif/v2.1.0/sarif-v2.1.0.html) | 정적분석 결과 교환 형식 | 동일 포맷이 도구별 의미·정확도·범위 일치를 보장하지 않음 |

<!-- SOURCE_LINKS_START -->

[S01]: https://cmake.org/cmake/help/latest/manual/cmake-buildsystem.7.html
[S02]: https://cmake.org/cmake/help/latest/manual/cmake-presets.7.html
[S03]: https://cmake.org/cmake/help/latest/variable/CMAKE_EXPORT_COMPILE_COMMANDS.html
[S04]: https://clang.llvm.org/docs/JSONCompilationDatabase.html
[S05]: https://clang.llvm.org/docs/LibTooling.html
[S06]: https://github.com/rizsotto/Bear
[S07]: https://docs.ctags.io/en/latest/
[S08]: https://www.doxygen.nl/manual/output.html
[S09]: https://coccinelle.gitlabpages.inria.fr/website/
[S10]: https://github.com/Fission-AI/OpenSpec
[S11]: https://github.com/obra/superpowers
[S12]: https://github.com/github/spec-kit
[S13]: https://github.com/kcem/code-index/blob/main/plugins/code-index/skills/code-indexing/SKILL.md
[S14]: https://gcc.gnu.org/onlinedocs/gcc/Static-Analyzer-Options.html
[S16]: https://cppcheck.sourceforge.io/manual.html
[S17]: https://clang.llvm.org/extra/clang-tidy/
[S18]: https://clang.llvm.org/extra/clang-tidy/checks/readability/identifier-naming.html
[S22]: https://github.com/ThrowTheSwitch/Unity
[S23]: https://github.com/ThrowTheSwitch/CMock
[S24]: https://www.throwtheswitch.org/ceedling
[S25]: https://xnvme.io/background/backends/common/interface/index.html
[S26]: https://github.com/linux-nvme/libnvme
[S27]: https://spdk.io/doc/nvme.html
[S28]: https://nvmexpress.org/specifications/
[S29]: https://pcisig.com/specifications
[S31]: https://www.cprover.org/cbmc/
[S32]: https://www.frama-c.com/fc-plugins/eva.html
[S33]: https://www.frama-c.com/fc-plugins/wp.html
[S34]: https://llvm.org/docs/LibFuzzer.html
[S37]: https://agentskills.io/specification
[S38]: https://doc.kaitai.io/user_guide.html
[S39]: https://www.doxygen.nl/manual/config.html
[S42]: https://clang.llvm.org/docs/ClangFormatStyleOptions.html
[S43]: https://gcc.gnu.org/onlinedocs/gcc/Integer-Overflow-Builtins.html
[S44]: https://clang.llvm.org/docs/UndefinedBehaviorSanitizer.html
[S45]: https://gcc.gnu.org/onlinedocs/gcc/Preprocessor-Options.html
[S46]: https://kernel.org/doc/html/latest/kbuild/kconfig-language.html
[S47]: https://docs.zephyrproject.org/latest/build/kconfig/tips.html
[S48]: https://github.com/sigrokproject/libserialport/blob/master/libserialport.h
[S49]: https://git-scm.com/docs/git-worktree
[S50]: https://git-scm.com/docs/git-ls-files
[S51]: https://codechecker.readthedocs.io/en/latest/
[S52]: https://docs.oasis-open.org/sarif/sarif/v2.1.0/sarif-v2.1.0.html
