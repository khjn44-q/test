# 17. 모델·세부타입·폼팩터·규격 한계의 다축 구성

## 1. 이번 개정에서 가장 큰 설계 변화

장비 모델 A/B/C만 선택하는 설계로는 부족하다. 사용자가 확인한 차이는 장비 세부타입(예: `92k-a`, `92k-b`), SSD 폼팩터, 장비가 지원하는 규격/명령 한계, 내부 명령 체계까지 포함한다. 위 제품명은 사용자 예시이며 실제 사양·배선·차이를 이 문서에서 아는 것이 아니다.

권고는 **변형 축을 분리하고, 실제로 허용된 조합만 조립하는 구조**다. 모든 조합을 상속 계층이나 `MODEL_A_M2_REV2_FW3` 같은 거대한 enum으로 만들지 않는다. 반대로 서로 독립적이지 않은 옵션을 자유롭게 조합하도록 열어 놓지도 않는다. 변경되는 값의 소유자와 적용 시점을 먼저 밝혀야 한다.

## 2. 분리할 축과 소유 정보

| 축 | 예시 정보 | 기본 결정 위치 | 확인 근거 |
|---|---|---|---|
| 장비 계열 | API/드라이버/실행 호스트 | 빌드 Provider 선택 | SDK·진입점 |
| 장비 세부타입 | 지원 포트·채널·미세 시퀀스 차이 | Provider 내부 구현 또는 불변 subtype profile | 매크로·소스·장비 자료 |
| 장비 HW revision | 배선·레지스터·workaround | Binding/profile | PCB/FW/공급 자료 |
| SDK/ABI | 타입 크기·함수 서명·호출 규약 | 컴파일/링크 | 헤더·라이브러리·툴체인 |
| 장비 FW/FPGA | 지원 기능·실행·관측 한계 | 호환성 검사 | 버전 응답·릴리스·시험 |
| SSD 폼팩터 | 물리 형상 식별, 연결 요구 | DUT/Fixture profile | 승인 제품/Fixture 자료 |
| Fixture/Slot | Rail·핀·UART 경로·공유 Reset | 토폴로지/profile | 실제 배선·확인 기록 |
| DUT 계열/FW | 기능 구현·사내 dialect | 실행 시 검증된 identity/profile | Identify·내부 자료 |
| 규격 profile | 문서 집합·개정·기능·필드 | 공통 protocol 코드와 metadata | 승인 규격 |
| 사내 command dialect | 내부 명령/응답 해석 개정 | 선택된 codec와 실행 허용 profile | 내부 명령 소유자 |
| 평가 policy | 반복·허용 범위·판정 | Item 명세/설정 | 시험 책임자 승인 |
| 실행 환경 | OS·CPU·GCC·ABI | Platform/툴체인 | 실제 build context |

폼팩터는 **안전 전압·UART 핀·Reset 범위를 자동 결정하는 정보가 아니다.** 폼팩터 이름이 같아도 Fixture/제품 세대가 다를 수 있다. 상위 Item이 폼팩터별 소스 분기를 직접 가질지보다 실제 차이가 프로토콜 의미인지, 연결 방식인지, 평가 조건인지 먼저 분류한다.

## 3. 기존 `#define` 조사 방법

모든 파일의 조건부 분기를 목록화하고 다음을 기록한다: 매크로 정의 위치, 선언값/표현식, `-D/-U` 순서, 강제 include, 헤더에서의 재정의, `#if/#ifdef/#elif` 조건식, 해당 분기에 포함되는 함수·필드·코드, 실제 선택된 build profile, 선택되지 않은 분기의 상태.

GCC는 명령행 `-D/-U` 순서를 보존하고 강제 매크로/include를 이후에 처리한다. 따라서 최종 값은 단순히 프로젝트 전체에서 처음 보이는 `#define` 한 줄로 판단할 수 없다. [S45]

`#ifdef FEATURE`와 `#if FEATURE`는 다르다. `FEATURE=0`이 전자를 비활성화한다고 가정하면 안 된다. Undefined, defined-zero, defined-nonzero, expression-valued, redefined를 구분한다. 문자열 매크로와 토큰 연결·함수형 매크로도 별도 기록한다.

분석은 **원시 분기 지도 + 실제 TU 전처리 결과 + 구성 제약**을 함께 사용한다. `gcc -E`/매크로 dump는 승인된 실제 TU 인자로 실행할 후보이며, 경로·flags·생성 헤더를 실제 환경에서 바인딩해야 한다. `.c` 한 개를 기본 flags로 전처리하고 전체 제품의 진실로 삼지 않는다. 모든 매크로를 동시에 켜는 방식은 불가능한 제품을 분석할 수 있으므로 금지한다.

## 4. 각 분기의 새 위치를 결정하는 규칙

| 분기의 의미 | 권고 이동 위치 | 검증 |
|---|---|---|
| 타입/ABI/함수 서명 차이 | 타깃 선택 소스와 SDK binding | size/offset/원형·link 검사 |
| 장비별 실제 제어 순서 차이 | 작은 subtype strategy/Provider 구현 | 호출 순서·효과·반례 |
| 채널 번호·배선 매핑 | 검토된 Fixture/Topology 데이터 | 연결 확인·영향 자원 검증 |
| 규격/명령 지원 상한 | Capability 주장 + 검증된 제한 | 경계값·미지원 이유 |
| DUT 내부 명령 개정 | dialect codec/profile | FW identity·독립 vectors |
| 사내 평가 조건 | Item policy | 요구·판정 변경 승인 |
| 컴파일러 적응 | Platform/컴파일 어댑터 | 대상 GCC/ABI |
| 디버그/계측 | 별도 build profile | 배포 바이너리 포함 검사 |
| 의심 workaround | 원인 조사 후 명시적 quirk | 적용/제거 조건·만료 검토 |

원본의 매크로가 어느 계층에 있어야 하는지 알려주는 것은 아니다. `SPEC_MAX`라는 이름도 소프트웨어 버퍼 크기인지 장비 한계인지, 과거 예제의 임의 제한인지 확인해야 한다. **관찰한 값과 검증된 하드웨어 능력은 다르다.**

## 5. 구현 후보 세 가지와 조합

### V1 — 세부타입별 별도 소스 선택

ABI, 필수 초기화, 호출 순서가 달라지면 별도 binding 구현이 가장 명료할 수 있다. 공통 Item에는 영향이 없어야 한다. 단점은 거의 같은 코드의 중복이며, 실제 공통 동작은 Provider 내부 공유 helper로 추출한다. 함수 수가 조금 다르다는 이유만으로 모든 파일을 복제하지 않는다.

### V2 — 공통 Provider + 검토된 불변 profile

차이가 채널/상한/주소 표현 등 검증 가능한 데이터에 한정될 때 적합하다. 프로필은 자료형과 단위, 허용 조합, 원본 근거를 가지며 초기 검증 이후 불변으로 취급한다. 주소나 함수 선택을 임의 문자열로 받아 실행하지 않는다. 프로필 데이터가 안전 시퀀스나 코드 제어 흐름을 무제한 표현하는 숨은 DSL이 되면 V1/V3를 검토한다.

### V3 — 공통 Provider + 소수의 역할별 strategy

같은 ABI이나 특정 전원/Reset/시퀀스 동작만 다를 때 사용하는 절충안이다. 고정된 함수 테이블 또는 빌드 선택 함수를 통해 차이를 제한한다. 어디서나 `if subtype`을 쓰거나 수백 개 bool 옵션을 나열하는 것보다 명세가 명확한지 검토한다.

**추천 가설:** V2로 안전하게 표현되는 데이터는 V2, 동작이 다르면 V1/V3. 실제 코드가 보여주는 차이가 우선이다. Runtime에서 subtype을 바꾸는 기능은 기본 요구가 아니며, 호환 ABI·자원 재초기화·식별 검증이 있을 때만 별도 승인한다.

## 6. 빌드와 런타임의 역할 분리

빌드가 결정할 것: SDK/ABI, 컴파일 가능한 Provider/subtype 구현, 허용 dialect codec, 기본 실행 모드, 포함 Item 세트. Runtime이 결정할 수 있는 것: 검증된 자원 ID, 실제 DUT identity, 승인된 Fixture profile, 실행 파라미터. 같은 바이너리가 여러 폼팩터를 처리할지는 **코드 호환성 확인 후** 결정한다.

빌드 입력 예시는 `equipment_profile_id` 하나를 정본 선택 키로 쓰고 그 안에 family/subtype/SDK/ABI/source-set을 고정하는 것이다. `family=A`, `subtype=B_only`처럼 상충한 개별 override는 거부한다. 개발자가 값 우선순위로 우연히 맞추게 하지 않는다. 공용 Preset과 개인 SDK 경로는 구분한다. [S02]

실행 시에는 빌드에 포함된 지원 집합과 실제 연결 정보를 대조한다. 장비 식별 API가 없으면 승인된 외부 binding 기록을 요구하고 `AUTODETECTED`로 표시하지 않는다. 예제 profile의 `UNKNOWN/null`을 기본 장비로 해석하지 않는다.

## 7. 규격 지원은 숫자 하나가 아니라 기능 계약

다음 네 상태를 분리한다: `declared`(매크로/문서 주장), `observed`(한 조건의 관찰), `verified_for_profile`(정해진 범위의 검증), `unknown`(근거 부족). 매크로에서 발견한 상한은 최초에는 declared evidence다.

실행 가능성은 `Item 요구 + DUT 기능 + SDK/장비 기능 + binding 구현 + Fixture/자원 + 승인/관측 수준`을 제약 조건으로 검사한다. 단순 `min(NVMe version)`은 명령·필드·큐 깊이·payload·metadata·negative-test bit 보존 능력을 설명하지 못한다. 기능별 지원 범위와 제한을 적용한다.

일반 기능 미지원과 실제 **대상 DUT의 미지원 응답을 검증하려는 평가**도 구분한다. 후자는 장비가 명령 전달/응답 관측을 지원해야 하며, DUT 미지원이 바로 실행 금지는 아닐 수 있다. Item 명세가 기대한 오류를 판정한다.

## 8. 구성 폭발과 검사 범위

지원 대상으로 선언한 프로필 목록을 유한하게 고정하고, 불가능 조합과 미확인 조합을 따로 관리한다. 전체 소스 분기 목록, 빌드에 등장한 분기, 분석된 TU, 실제 HIL한 조합의 분모를 각각 보고한다.

pairwise 등 조합 축소는 개발 효율을 위한 후보이지 복잡한 상호작용의 증명이 아니다. ABI 분기, 전원/배선, 내부 명령 개정, 알려진 다축 결함 조합은 명시적으로 시험한다. 규모가 커지면 Kconfig류 제약 기술을 검토할 수 있으나 구성 언어가 실제 물리 호환성을 알아내지는 않는다. `select`류 강제 설정의 의존성 효과도 검토한다. [S46] [S47]

## 9. 필수 문서·종료 조건

`variant_axes`, `macro_inventory`, `valid_configuration_matrix`, `profile_resolution_rules`, `declared_vs_verified_capabilities`, `unsupported_combinations`, `configuration_coverage`가 필요하다. 기존 `#define` 각각에 유지/소스선택/profile/정책/폐기/미확정 disposition을 붙인다.

새 장비/세부타입 추가 시 공통 Item을 바꾸지 않는 것이 목표지만, 새로운 평가 의미 자체가 생기면 계약/Item 변경을 허용하고 이유를 기록한다. ‘기존 공통 코드 수정 0줄’을 절대화하여 부정확한 추상화를 유지하지 않는다.

<!-- SOURCE_LINKS_START -->

[S02]: https://cmake.org/cmake/help/latest/manual/cmake-presets.7.html
[S45]: https://gcc.gnu.org/onlinedocs/gcc/Preprocessor-Options.html
[S46]: https://kernel.org/doc/html/latest/kbuild/kconfig-language.html
[S47]: https://docs.zephyrproject.org/latest/build/kconfig/tips.html
