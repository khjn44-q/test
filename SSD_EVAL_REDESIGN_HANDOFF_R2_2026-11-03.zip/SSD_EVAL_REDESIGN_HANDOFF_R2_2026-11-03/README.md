# SSD 평가 코드 전면 재설계 인수인계 — R2

**작성일:** 2026-11-03 · **형태:** 방법론/후보/추천/정밀 작업계획 · **제품 검증:** 미수행

## 가장 중요한 전제

**이 자료는 원문 소스를 보지 못한 외부 검토자가 만든 설계 후보이며 정답이 아니다.** 사내 LLM/개발자가 실제 소스·SDK·FW·규격·배선을 전면 재검토하고 중대한 미확인을 담당자에게 문의한 뒤 설계를 확정해야 한다. 기존 코드 구현은 유지 목표가 아니며 snapshot은 근거로만 보존한다.

R2는 모델/subtype·폼팩터·지원규격 한계·내부 command·UART·Git·타입/overflow·docs-first·장비 한계·전면 분석·실행 가능한 단계별 계획을 본문과 prompt 전반에 반영한다. R1 원본은 별도로 보존했다.

## 전달 순서

사내 세션에는 [최초 인수인계 프롬프트](START_HERE_PROMPT_KO.md)와 실제 허용 source root를 제공한다. 하나의 문서가 편하면 [통합 보고서](SSD_EVAL_REDESIGN_FULL_REPORT_KO.md)를 전달한다. 전체 실행 계획만 별도로 읽을 때는 [정밀 작업계획](FULL_WORK_PLAN_KO.md)을 사용한다.

최초 범위는 W00~W12 전면 감사/문의/설계 선택이다. W13~W36은 승인 뒤 새 코드를 만드는 전체 계획이다. 모든 단계는 현재 NOT_STARTED이며, 계획 문서 존재가 작업 완료를 의미하지 않는다.

## 핵심 파일

| 파일 | 목적 |
|---|---|
| [통합 보고서](SSD_EVAL_REDESIGN_FULL_REPORT_KO.md) | 26장 + 최초 prompt + 40개 양식 원문 + 출처를 한 파일로 전달 |
| [정밀 작업계획](FULL_WORK_PLAN_KO.md) | 37개 Work/222개 단계, 입력·출력·검사·문의·실행 범위 |
| [최초 prompt](START_HERE_PROMPT_KO.md) | 과거 대화 없는 사내 세션의 출발 지침 |
| [추가사항 반영표](docs/25_USER_ADDITIONS_COVERAGE.md) | 16개 사용자 추가항목과 요구/문서/Work 연결 |
| [작업계획 JSON](metadata/work_plan.json) | 의존성/상태/steps의 구조화된 정본 표현 |
| [요구사항](metadata/requirements.json) | 기존·추가 72개 요구의 문서/Work 대응 |
| [출처 목록](metadata/source_catalog.json) | 공식 원문 52건의 확인 범위와 한계 |
| [템플릿 안내](templates/README.md) | 실제 소스로 채울 분석·계약·상태·작업 양식 |
| [패키지 검증](metadata/package_validation.json) | 형식/참조/계획/해시/ZIP 검사, 제품 검증과 별도 |

## 장별 찾아보기

| 장 | 내용 |
|---|---|
| 01 | [01. R2 배경·사용자 요구·설계의 지위](docs/01_BACKGROUND_AND_REQUIREMENTS.md) |
| 02 | [02. 전체 재검토와 구조별 설계 후보](docs/02_REVIEW_AND_ARCHITECTURE_OPTIONS.md) |
| 03 | [03. 목표 코드 구조와 의존성 계약](docs/03_TARGET_ARCHITECTURE.md) |
| 04 | [04. 사내 소스 조사, 원본 대비 분석, 실행 경계 확정](docs/04_SOURCE_DISCOVERY_AND_VENDOR_BOUNDARY.md) |
| 05 | [05. NVMe·PCIe·구조체·메모리 계약 설계](docs/05_PROTOCOL_DATA_AND_MEMORY_CONTRACTS.md) |
| 06 | [06. Chamber·Voltage·공유 자원·실행 안전·타이밍](docs/06_ENVIRONMENT_RESOURCES_AND_EXECUTION.md) |
| 07 | [07. Custom C 전역 코딩 표준](docs/07_C_CODING_STANDARD.md) |
| 08 | [08. GCC 모델 선택 빌드와 의존성 강제](docs/08_BUILD_AND_DEPENDENCY_RULES.md) |
| 09 | [09. 정적분석과 다층 검증 전략](docs/09_VERIFICATION_AND_STATIC_ANALYSIS.md) |
| 10 | [10. 명세·주석·Markdown·생성물의 정본 관리](docs/10_DOCS_SCHEMA_AND_TRACEABILITY.md) |
| 11 | [11. 바이브코딩을 안전하고 일관된 Item 개발로 연결하는 방식](docs/11_LLM_WORKFLOW_AND_SKILLS.md) |
| 12 | [12. 전면 소스 감사부터 신규 코드 운영까지 — 정밀 작업계획](docs/12_MIGRATION_AND_WORK_PACKAGES.md) |
| 13 | [13. 외부 조사 결과와 도입 판단](docs/13_EXTERNAL_RESEARCH_AND_SOURCES.md) |
| 14 | [14. 위험·질문·설계 선택·수용 기준 — R2](docs/14_RISKS_OPEN_QUESTIONS_ACCEPTANCE.md) |
| 15 | [15. 적용 예시와 사내 첫 세션의 구체적인 진행 방식](docs/15_WORKED_EXAMPLES_AND_FIRST_SESSION.md) |
| 16 | [16. R2 자체 검토·우선순위·수행하지 않은 검증](docs/16_SELF_REVIEW_AND_LIMITATIONS.md) |
| 17 | [17. 모델·세부타입·폼팩터·규격 한계의 다축 구성](docs/17_VARIANT_FORM_FACTOR_AND_COMPATIBILITY.md) |
| 18 | [18. 표준 외 SSD 내부 검증 명령과 독립 dialect](docs/18_PRIVATE_COMMAND_DIALECTS_AND_ACCESS.md) |
| 19 | [19. UART 명령·비동기 분석 로그·교차 채널 관측](docs/19_UART_AND_CROSS_CHANNEL_OBSERVABILITY.md) |
| 20 | [20. 타입·정수·메모리 안전의 전면 재설계](docs/20_TYPE_INTEGER_MEMORY_SAFETY.md) |
| 21 | [21. Git 기준선과 전면 신규 구현의 전달 전략](docs/21_GIT_BASELINES_AND_REWRITE_DELIVERY.md) |
| 22 | [22. 장비 한계·비동등성·실행 가능성의 명시적 관리](docs/22_EQUIPMENT_LIMITATIONS_AND_EQUIVALENCE.md) |
| 23 | [23. 정적분석 체계와 전용 분석 도구의 단계적 검토](docs/23_ANALYSIS_TOOL_ROADMAP.md) |
| 24 | [24. 미확인 사항의 확인·문의·설계 승인 게이트](docs/24_QUESTION_GATE_AND_EVIDENCE.md) |
| 25 | [25. 사용자 추가사항 반영표와 R1→R2 변경 검토](docs/25_USER_ADDITIONS_COVERAGE.md) |
| 26 | [26. 데이터 무결성·평가 현황·근거 재현성의 추가 보강](docs/26_DATA_INTEGRITY_AND_RUN_EVIDENCE.md) |

## 편집과 정본

개별 docs와 templates 및 metadata가 편집 원천이며 통합 보고서/독립 작업계획은 전달용 파생본이다. 제품 개발 시 사내 승인 ADR/계약/규칙이 정본이 된다. 외부 인계서는 증거 참조로 보존하고 실제 설계 변경을 명시한다.

## 하지 않은 검증

사내 source/SDK/FW 열람, 실제 Git 조작, 제품 GCC 빌드/정적분석/Host·HIL 시험, 도구 설치/호환성 시험, 실제 NVMe/PCIe/UART 명령, 온도/전압/Reset 변경은 하지 않았다. 예시 타입/함수/경로·profile·템플릿은 승인된 실행 설정이 아니다.

## 무결성

`SHA256SUMS.txt`는 checksum 파일 자신을 제외한 모든 패키지 파일을 포함한다. ZIP CRC와 엔트리별 해시를 생성 후 확인한다. 문서 문법/링크 PASS가 장비 적합성을 증명하는 것은 아니다. R1 참조 해시는 `metadata/r1_provenance.json`에 있다.
