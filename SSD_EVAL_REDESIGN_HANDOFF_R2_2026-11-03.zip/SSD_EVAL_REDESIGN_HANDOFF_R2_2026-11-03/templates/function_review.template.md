# FUNCTION-REVIEW — Vendor/혼합 함수의 상세 의미 복원

상태: DRAFT / 실제 함수 아님

## 식별
symbol ID, file/function scope, prototype from source, declaration/definition refs, build/presence condition, Vendor release/commit/hash.

## 입력/출력
각 인자·반환의 effective type, 단위, 범위, NULL/길이, 성공/실패 후 출력, caller 소유권/수명. locals/types inventory도 연결한다.

## 동작
목적, 전제/후조건, 실제 호출 순서, direct/indirect callees, global/memory read/write, slot/queue/resource 선택, callback/reentry/thread.

## 실패·시간·수명
접수/완료 구분, timeout/abort/Reset/partial effect, safe retry, buffer 반환 시점, cleanup, 관측 불가능 영역.

## 근거·모델 차이
문서/소스/측정/추론을 구분하고 같은 이름의 다른 모델 함수와 의미 차이를 기록한다. opaque 내부는 unknown.

## 새 구현 방향
P0/P1/P2/H0/H1/U0/X0 분류, 공통 계약/Provider/profile/dialect/폐기 후보, 의도 보존/bug fix/정책 변경, 검증과 질문.
