# FILE-REVIEW — 코드파일 상세 분석

상태: DRAFT / 실제 분석 결과 아님

## 식별·구성
file ID, 원본/mixed/custom 분류, 상대경로/해시, Git commit/dirty, 생성 여부·입력, 모델/subtype/form factor/SDK/build profile.

## 책임과 구성
파일 목적, public/static exports, includes/imports, registration/entry, 전처리 조건과 비활성 분기, 다른 파일과의 책임 중복.

## 내용 인덱스
함수/API, 전역·지역 변수/필드, 타입/enum/macro/상수, memory region의 inventory ID를 연결한다. 미추출/해석 실패를 기록한다.

## 의미·효과·위험
하드웨어/상태/메모리/시간 효과, critical 산술/변환/alias, 내부 명령/UART 관련, Vendor 원본 대비 변경, 주석 충돌.

## 신규 설계 disposition
참고만/필수 Vendor 경계/새 공통 모듈/Provider/profile/폐기/미확정; 이유와 영향 Item/규칙/한계.

## 조사 상태·문의·검증
분석 수준, 확인한 profile, 미확인 source span, 질문 owner/ID, 실제 검사/미실행, 검토자.
