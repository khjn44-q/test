# 프로젝트 C 파일·심볼·타입·단위 규칙 채택서

상태: PROPOSED / 현재 조직 규칙이 아님

## 채택할 전역 규칙
Custom prefix(제안 `se_`), file domain+responsibility, function 동사, variable unit suffix, struct/enum 방식, constants/guards, test 이름, 허용 약어·용어를 실제 값으로 확정한다.

## 적용 범위
모든 신규 Custom `.c/.h`, tests, generator 입력/출력 규칙. Vendor ABI/원본·동결 reference와 외부 OSS는 직접 변경하지 않는다. generated code는 원천을 변경한다.

## 타입·수치 계약
wire width, host size, signed 물리량, 주소 공간, status/verdict, 중간 연산/변환/rounding, overflow/underflow 처리 원칙을 20장과 연결한다.

## 집행
format/naming/AST/빌드 검사의 실제 tool version·명령·owner; good/bad fixture; semantic review와 자동 검사 차이.

## 예외
rule ID/scope/reason/owner/approval/test/expiry를 지정한다. 이름만 바꾸거나 캐스트로 경고를 숨기지 않는다.
