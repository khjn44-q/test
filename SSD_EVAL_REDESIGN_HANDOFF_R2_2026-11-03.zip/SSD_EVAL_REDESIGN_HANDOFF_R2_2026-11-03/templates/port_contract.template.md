# PORT-TEMPLATE — Custom 공개 계약 템플릿

상태: DRAFT / 실제 API 아님 / 운영 사용 금지

## 목적과 범위
호출이 어떤 의미를 제공하며 무엇을 제공하지 않는지 적는다.

## 공개 선언
정본 헤더 경로와 심볼을 연결한다. 존재하지 않으면 미정으로 기록한다.

## 입력·출력
타입, 단위, 범위, NULL, 길이, alias 허용, 실패 시 출력 상태를 적는다.

## 전제·후조건
상태와 자원 소유권을 포함한다. 요청 접수와 완료를 구분한다.

## 효과와 관찰
물리 효과, 읽고 쓰는 상태, 지원/정확도/타이밍, 관측 불가 부분을 적는다.

## 수명·동시성
입력/출력/콜백/버퍼의 보관 가능 시간, 재진입, lock 범위를 적는다.

## 오류·타임아웃·취소·Reset
미확정 실행을 표현하고 안전한 재시도/해제 조건을 명시한다.

## 모델별 Mapping
실제 primitive ID와 evidence를 연결한다. 모델 기능을 추측하지 않는다.

## 검증
정상·경계·실패·late completion·미지원·관찰 부족 반례를 적는다.

## 승인과 변경
owner, reviewer, revision, breaking change 여부, supersedes를 기록한다.

## R2 필수 추가 연결
모델 계열/subtype/HW/SDK/FW, form factor/Fixture, private dialect/UART 계약, type/range/overflow 검토, limitation/question ID, 실제 profile별 검증 범위를 연결한다. 기존 구현을 보존할 의무는 없으며 승인된 목표 의미와 변경 이유를 기록한다.
