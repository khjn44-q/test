# WORK-TEMPLATE — 세션 중단·재개 인수인계

## 승인 목표와 범위
현재 Work ID, 완료 조건, 금지 범위, 실장비 승인 상태.

## 정본
branch/commit, 설계 ADR, Item/contract/schema revision, build profile.

## 실제 변경
변경한 파일과 변경 이유. 운영 원본/legacy hash 유지 여부.

## 실제 검증
명령, 도구 버전, 코드/config hash, exit status, 결과 파일. NOT_RUN과 PASS를 구분.

## 미확인과 차단
질문, 영향, 확인할 자료/실험, 담당자. 추정값을 기본값으로 승격하지 않음.

## 다음 한 단위
구체적인 입력·작업·예상 검사·종료 조건. 완료된 조사를 반복하지 않음.

## 실장비 상태
실행하지 않았다면 NOT_RUN. 실행했다면 DUT/Chamber/Rail/요청/버퍼/안전 상태와 재개 승인 조건을 기록. 소프트웨어 작업 재개와 장비 Run 재개를 혼동하지 않음.

## R2 필수 추가 연결
모델 계열/subtype/HW/SDK/FW, form factor/Fixture, private dialect/UART 계약, type/range/overflow 검토, limitation/question ID, 실제 profile별 검증 범위를 연결한다. 기존 구현을 보존할 의무는 없으며 승인된 목표 의미와 변경 이유를 기록한다.
