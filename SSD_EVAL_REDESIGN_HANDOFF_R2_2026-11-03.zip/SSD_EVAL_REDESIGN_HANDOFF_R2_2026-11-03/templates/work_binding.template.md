# WORK-BINDING — 실제 저장소 실행 바인딩

상태: DRAFT / 구현·장비 실행 승인 아님

## Work와 입력
Work/step ID, 승인 목표와 결정 ID, 실제 repo/root/commit/dirty/profile/SDK hash, 사전 완료 evidence.

## 읽을 자료와 수정 범위
실제 파일·심볼·계약·schema·질문/한계 ID; Create/Modify/Read-only/Generated 파일 구분; 소유자와 충돌 금지 범위.

## 인터페이스
소비/제공할 실제 C 원형·타입·수명·오류/단위 계약. 아직 없다면 선행 작업과 구현 차단 이유.

## 세부 단계
| Step ID | 실제 파일/명령 | 기대 산출물 | 확인할 반례/상태 | 권한 |
|---|---|---|---|---|
| 미바인딩 | 실행하지 않음 | 미확정 | 미확정 | 없음 |

## 검사
실제 설치된 tool/version, working directory, 명령 arguments, expected exit/결과, suite/profile 분모, 미실행 HIL.

## 질문과 승인
담당자에게 확인할 사실, blocked step, 독립 가능 범위, 응답/근거/적용 profile, implementation/HIL 승인 참조.

## 완료·재개
변경 diff/hash, 실제 실행 결과, 누락/실패, 다음 step, 현재 장비 상태(미실행이면 NOT_RUN).
