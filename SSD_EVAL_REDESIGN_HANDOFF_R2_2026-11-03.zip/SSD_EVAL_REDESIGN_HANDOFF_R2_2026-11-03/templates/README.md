# 명세·분석·작업 템플릿 — R2

모든 양식은 DRAFT다. 실제 source/profile/근거와 사내 승인으로 채우기 전 실행 설정으로 사용하지 않는다. YAML 문법 유효성과 operational schema/하드웨어 안전은 다르다. `null`, UNKNOWN, 비어 있는 목록은 허용/성공/무제한을 뜻하지 않는다.

| 파일 | 형식 |
|---|---|
| [ADR.template.md](ADR.template.md) | md |
| [AGENTS.template.md](AGENTS.template.md) | md |
| [analysis_finding.template.yaml](analysis_finding.template.yaml) | yaml |
| [analysis_tool_rule.template.yaml](analysis_tool_rule.template.yaml) | yaml |
| [behavior_delta.template.yaml](behavior_delta.template.yaml) | yaml |
| [change_request.template.md](change_request.template.md) | md |
| [clang_format.template.yaml](clang_format.template.yaml) | yaml |
| [clang_tidy.template.yaml](clang_tidy.template.yaml) | yaml |
| [configuration_matrix.template.yaml](configuration_matrix.template.yaml) | yaml |
| [coverage_report.template.yaml](coverage_report.template.yaml) | yaml |
| [data_integrity.template.yaml](data_integrity.template.yaml) | yaml |
| [evaluation_status.template.yaml](evaluation_status.template.yaml) | yaml |
| [file_review.template.md](file_review.template.md) | md |
| [function_review.template.md](function_review.template.md) | md |
| [git_baseline.template.yaml](git_baseline.template.yaml) | yaml |
| [global_state.template.yaml](global_state.template.yaml) | yaml |
| [glossary.template.yaml](glossary.template.yaml) | yaml |
| [item_spec.template.md](item_spec.template.md) | md |
| [limitation.template.yaml](limitation.template.yaml) | yaml |
| [macro_inventory_entry.template.yaml](macro_inventory_entry.template.yaml) | yaml |
| [memory_region.template.yaml](memory_region.template.yaml) | yaml |
| [model_profile.template.yaml](model_profile.template.yaml) | yaml |
| [naming_rules.template.md](naming_rules.template.md) | md |
| [port_contract.template.md](port_contract.template.md) | md |
| [private_command.template.yaml](private_command.template.yaml) | yaml |
| [protocol_field.template.yaml](protocol_field.template.yaml) | yaml |
| [question.template.yaml](question.template.yaml) | yaml |
| [release_recovery.template.md](release_recovery.template.md) | md |
| [run_event.template.yaml](run_event.template.yaml) | yaml |
| [source_manifest.template.yaml](source_manifest.template.yaml) | yaml |
| [test_item.template.yaml](test_item.template.yaml) | yaml |
| [traceability.template.yaml](traceability.template.yaml) | yaml |
| [uart_contract.template.yaml](uart_contract.template.yaml) | yaml |
| [variable_type_range.template.yaml](variable_type_range.template.yaml) | yaml |
| [variant_profile.template.yaml](variant_profile.template.yaml) | yaml |
| [vendor_primitive.template.yaml](vendor_primitive.template.yaml) | yaml |
| [vendor_type_constant.template.yaml](vendor_type_constant.template.yaml) | yaml |
| [verification_record.template.yaml](verification_record.template.yaml) | yaml |
| [work_binding.template.md](work_binding.template.md) | md |
| [work_handoff.template.md](work_handoff.template.md) | md |
