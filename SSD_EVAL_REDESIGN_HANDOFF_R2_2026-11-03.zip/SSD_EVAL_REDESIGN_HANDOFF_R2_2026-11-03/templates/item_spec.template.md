# ITEM-TEMPLATE — 평가 Item 명세 템플릿

상태: DRAFT / 실제 Item 아님 / 실장비 실행 미승인

## 평가 목적
어떤 SSD 동작/신뢰성 조건을 확인하는가? 제외하는 것은 무엇인가?

## 근거와 대상
규격 profile, 사내 평가 기준, DUT/Fixture/장비 범위를 적는다.

## 입력과 사전 조건
단위·값 범위·지원 기능·관찰 정확도·리소스 예약·승인 조건을 적는다.

## 단계별 행동
각 단계에 명령 의미, 시작/완료 조건, 시간 기준, buffer 수명, 기대 관측을 적는다.

## 기대 결과와 판정
정상/기대한 오류/장비 오류/관찰 부족/취소/미지원의 판정을 구분한다.

## 상태·복구·정리
부분 실행과 미완료 요청, 최초 오류, cleanup 오류, 수동 조치를 포함한다.

## Legacy 대비 차이
동등/결함 수정/정책 변경/최적화/폐기의 이유와 근거를 연결한다.

## 검증 계획
Pure/Fake/Provider/실장비/타이밍별 범위와 독립적인 기대값을 적는다.

## 실행 증거와 승인
Run ID, code/config/SDK/profile hash, 결과 경로, 승인자를 연결한다.

## R2 필수 추가 연결
모델 계열/subtype/HW/SDK/FW, form factor/Fixture, private dialect/UART 계약, type/range/overflow 검토, limitation/question ID, 실제 profile별 검증 범위를 연결한다. 기존 구현을 보존할 의무는 없으며 승인된 목표 의미와 변경 이유를 기록한다.
