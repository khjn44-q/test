# RELEASE-RECOVERY — 전면 신규 코드 운영 전환

상태: DRAFT / 실장비 배포 계획 미승인

## 대상
지원 장비/subtype/HW/SDK/FW/Fixture/form factor/dialect/Item, release code/build/profile hash, 승인·제한 목록.

## 사전 상태
pending request/buffer lease, output/Chamber/DUT/UART, 로그 영속화, 자원 소유권, quiescence 검증 조건.

## 배포·검증
실제 설치 경로/권한/identity 체크/호환 schema/지원 Item, 승인된 최소 확인 및 stop 조건.

## 오류·복구
안전 조치·수동 담당, 코드 rollback과 물리 상태 복구의 차이, 승인된 이전 신규 release, legacy 영구 운영 강제 없음.

## 보관·인계
원본/mixed 증거 보존, raw/derived 로그 retention, secret/redaction, 미확인·제약·다음 Work.
