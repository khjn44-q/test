from pathlib import Path
import json, hashlib
ROOT=Path(__file__).resolve().parents[1]

def obj(props, required=None):
    return {'type':'object','properties':props,'required':list(props) if required is None else required,'additionalProperties':False}
def arr(items, **kw): return {'type':'array','items':items,**kw}
def enum(*values): return {'type':'string','enum':list(values)}
text={'type':'string','minLength':1}
integer={'type':'integer','minimum':0}
stringlist=arr(text,uniqueItems=True)
ref=lambda x: {'$ref':'#/$defs/'+x}
D={}
D['SourceRef']=obj({
 'host_id':text,'repo_id':text,'object_format':enum('sha1','sha256'),
 'commit_oid':{'type':'string','pattern':'^(?:[a-f0-9]{40}|[a-f0-9]{64})$'},
 'blob_oid':{'type':'string','pattern':'^(?:[a-f0-9]{40}|[a-f0-9]{64})$'},
 'path':text,'content_sha256':{'type':'string','pattern':'^[a-f0-9]{64}$'},
 'byte_start':integer,'byte_end':integer,
 'line_start':{'type':'integer','minimum':1},'line_end':{'type':'integer','minimum':1},
 'encoding':text,'line_ending':enum('lf','crlf','mixed','none'),'extractor_fingerprint':text})
D['SourceRef']['allOf']=[{'if':{'properties':{'object_format':{'const':'sha1'}}},
 'then':{'properties':{'commit_oid':{'maxLength':40},'blob_oid':{'maxLength':40}}},
 'else':{'properties':{'commit_oid':{'minLength':64},'blob_oid':{'minLength':64}}}}]
D['SearchRequest']=obj({
 'schema_version':{'const':'1.0'},'query':{'type':'string','minLength':1,'maxLength':12000},
 'depth':enum('fast','verified','deep'),'breadth':enum('ranked','all'),
 'freshness':enum('indexed','require_current'),
 'requested_scope':stringlist,'page_size':{'type':'integer','minimum':1,'maximum':100},
 'session_id':text,'cursor':text},['schema_version','query','depth','breadth','freshness','page_size'])
D['Coverage']=obj({'scope_scan_complete':{'type':'boolean'},'judgment_complete':{'type':'boolean'},
 'semantic_completeness':{'const':'not_proven'},'eligible_files':{'type':['integer','null'],'minimum':0},
 'scanned_files':integer,'pending_repo_ids':stringlist})
D['SearchCandidate']=obj({'asset_id':text,'version_id':text,
 'lane':enum('repository','capability','knowledge','source'),
 'evidence_ids':arr(text,minItems=1,uniqueItems=True),'why_relevant':text,'semantic_verified':{'type':'boolean'}})
D['Freshness']=obj({'checked_at':{'type':['string','null'],'format':'date-time'},
 'remote_current':enum('current_at_check','stale','unknown')})
D['SearchResponse']=obj({'schema_version':{'const':'1.0'},'request_id':text,'session_id':text,'manifest_id':text,
 'status':enum('ok','no_match','partial','failed'),'depth':enum('fast','verified','deep'),'breadth':enum('ranked','all'),
 'freshness':ref('Freshness'),'results':arr(ref('SearchCandidate')),'coverage':ref('Coverage'),
 'warnings':arr({'type':'string'}),'next_cursor':{'type':['string','null']}})
D['Evidence']=obj({'schema_version':{'const':'1.0'},'evidence_id':text,'manifest_id':text,'source':ref('SourceRef'),
 'excerpt':{'type':'string'},'verification':enum('located','bytes_verified','unavailable','revoked'),
 'required_scopes':arr(text,minItems=1,uniqueItems=True)})
D['UpdateRequest']=obj({'schema_version':{'const':'1.0'},'mode':enum('incremental','rebuild'),
 'scope':{'oneOf':[obj({'all':{'const':True}}),obj({'repo_ids':arr(text,minItems=1,uniqueItems=True)})]},
 'plan_only':{'type':'boolean'}})
D['ReusePlan']=obj({'schema_version':{'const':'1.0'},'asset_id':text,'recipe_id':text,
 'readiness':enum('ready','needs_setup','needs_verification','reference_only','deprecated','unavailable'),
 'missing_conditions':arr(text),'effects':arr(text),'tool_ref':{'type':['string','null']},
 'evidence_ids':arr(text,minItems=1,uniqueItems=True),'execution_performed':{'const':False}})
schema={'$schema':'https://json-schema.org/draft/2020-12/schema',
 '$id':'urn:refs:contracts:1.0','title':'REFS v1 wire contracts','$defs':D,
 'description':'Use a named $defs schema. Cross-field range, permissions and provenance checks require application services.'}
(ROOT/'contracts/refs.schema.json').write_text(json.dumps(schema,ensure_ascii=False,indent=2)+'\n')
examples={
 'search-request':('SearchRequest',{'schema_version':'1.0','query':'Jira API 사용하는 프로젝트를 전부 찾아 이슈 대시보드에 활용하고 싶어',
 'depth':'verified','breadth':'all','freshness':'indexed','page_size':50}),
 'search-response':('SearchResponse',{'schema_version':'1.0','request_id':'req-synthetic','session_id':'session-synthetic',
 'manifest_id':'manifest-synthetic','status':'partial','depth':'verified','breadth':'all',
 'freshness':{'checked_at':None,'remote_current':'unknown'},
 'results':[{'asset_id':'asset-issue-search','version_id':'v-synthetic','lane':'source','evidence_ids':['evidence-synthetic'],
 'why_relevant':'합성 fixture의 JQL 호출; 실제 사내 결과가 아님','semantic_verified':False}],
 'coverage':{'scope_scan_complete':False,'judgment_complete':False,'semantic_completeness':'not_proven',
 'eligible_files':None,'scanned_files':2,'pending_repo_ids':['repo-unavailable-example']},
 'warnings':['합성 응답 예시. 실제 검색 실행 결과가 아님'],'next_cursor':None}),
 'update-request':('UpdateRequest',{'schema_version':'1.0','mode':'incremental','scope':{'all':True},'plan_only':False}),
 'reuse-plan':('ReusePlan',{'schema_version':'1.0','asset_id':'asset-issue-search','recipe_id':'recipe-synthetic',
 'readiness':'needs_verification','missing_conditions':['실제 Jira 배포 버전과 사용자 권한 확인'],
 'effects':['조회 요청이 감사 로그에 남을 수 있음'],'tool_ref':None,'evidence_ids':['evidence-synthetic'],'execution_performed':False})}
blob=(ROOT/'examples/fixtures/thermal_model.py').read_bytes()
examples['evidence']=('Evidence',{'schema_version':'1.0','evidence_id':'evidence-synthetic','manifest_id':'manifest-synthetic',
 'source':{'host_id':'example','repo_id':'repo-thermal-fixture','object_format':'sha1','commit_oid':'a'*40,'blob_oid':'b'*40,
 'path':'examples/fixtures/thermal_model.py','content_sha256':hashlib.sha256(blob).hexdigest(),
 'byte_start':0,'byte_end':len(blob),'line_start':1,'line_end':len(blob.splitlines()),
 'encoding':'utf-8','line_ending':'lf','extractor_fingerprint':'fixture-v1'},
 'excerpt':blob.decode(),'verification':'located','required_scopes':['repo:repo-thermal-fixture']})
# Commit/blob in this EXAMPLE are deliberate sentinel IDs, never claimed verified.
manifest={}
for name,(definition,payload) in examples.items():
 filename=f'{name}.json';manifest[filename]=definition
 (ROOT/'examples'/filename).write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n')
(ROOT/'examples/contract-examples.json').write_text(json.dumps(manifest,indent=2)+'\n')
