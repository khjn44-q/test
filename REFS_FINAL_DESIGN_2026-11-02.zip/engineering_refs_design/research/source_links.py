"""Idempotent conversion of compact source labels to Markdown source-atlas links."""
import re
BARE_SOURCE_RE = re.compile(r'\[(S\d{2}[S0-9,\s–-]*)\](?!\()')
def expand_source_links(text):
    def replace(match):
        ids=[]
        for item in re.split(r',\s*',match[1]):
            m=re.fullmatch(r'\s*S(\d{2})(?:\s*[–-]\s*S?(\d{2}))?\s*',item)
            if not m: raise ValueError(match[1])
            first,last=int(m[1]),int(m[2] or m[1])
            ids.extend(f'S{x:02}' for x in range(first,last+1))
        return ' · '.join(f'[{x}](14_SOURCE_ATLAS.md#{x.lower()})' for x in ids)
    return BARE_SOURCE_RE.sub(replace,text)
