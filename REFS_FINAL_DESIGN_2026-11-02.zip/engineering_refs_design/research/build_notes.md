# 작성 중 검토 메모

- 요청 범위: 설계/조사/인수인계/범용 참조 구현. 사내 연결·제품 설치·Git 변경 없음.
- 기준일: 2026-11-02. 원문 기술 사실은 공개 1차 자료, 제품 수치는 설계 목표.
- 본 대화에 제공된 기존 설계와 잘린 마스터 프롬프트 및 Phase 기준을 통합한다. 기존 ChatGPT Space 페이지를 별도 재열람했다고 주장하지 않는다.
- 별도 Work 전환/백그라운드 작업 없음.
- 기본값: TypeScript, Git CLI first, catalog SQLite, QMD semantic adapter, exact Git search, local stdio optional; Windows native first.
- 중요한 개선: breadth와 depth 분리; 업데이트 P0; Hit@5와 Recall@5 구분; code/knowledge 최소 기능 첫 실사용 버전에 포함; QMD 메타데이터를 ACL로 취급하지 않음; SSOT와 재생성 불가한 인간 annotation 구분.
- 외부 소스 git clone/raw 다운로드: 컨테이너 DNS 불가. web로 문서/원문 코드를 열람함. 외부 라이브러리 설치 또는 전체 실행 검증은 하지 않음.
