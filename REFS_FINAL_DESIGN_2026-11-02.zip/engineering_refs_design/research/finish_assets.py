from pathlib import Path
import json, re
R=Path(__file__).resolve().parents[1]
# Resolve a DAG inconsistency: central deployment is not a prerequisite for local UI.
p=R/'docs/12_IMPLEMENTATION_PLAN.md'
s=p.read_text().replace(' T12 --> T13[마지막 UI]', ' T10 --> T13[마지막 UI]\n T12 -. 중앙 UI가 필요할 때만 .-> T13')
s=s.replace(' T03 --> T06[전체 스캔]', ' T03 --> T06[전체 스캔]\n T04 --> T06')
p.write_text(s)

sources=json.loads((R/'research/sources.json').read_text())
a=['# 14. Source Atlas · 공개 근거와 검증 한계','',
'조회 기준일: **2026-11-02**. 이 목록은 공식 문서와 공개 구현 소스의 확인 기록이다. 웹 도구가 반환한 페이지는 캐시될 수 있고 main은 이동한다. 모든 항목을 같은 날의 실제 최신 release로 보장하지 않는다. 기업 설치에 사용할 정확한 버전·commit·artifact digest는 G0에서 고정한다.','',
'`source_read`는 실제 소스 본문을 읽었다는 뜻이며 실행·성능·사내 호환성을 증명하지 않는다. 사내 소스·정책·계정은 제공되지 않았고 이 작업에서 열람하지 않았다. 외부 라이브러리/모델을 설치해 비교하는 benchmark도 수행하지 않았다.','',
'기존 대화의 Space 문서는 대화에 포함된 전체 내용과 후속 요구를 사용했다. Space URL을 새로 읽었다고 주장하지 않는다. 별도 연구 내용을 중복 수집하기보다 버전·API·보안 경계의 결정에 영향을 주는 공개 근거를 확인했다.','']
for x in sources:
 a += [f'<a id="{x["id"].lower()}"></a>',f'## {x["id"]} — {x["title"]}',
       f'원문: [{x["title"]}]({x["url"]})',f'확인 수준: `{x["verification"]}`',f'설계 반영: {x["finding"]}',
       '남은 검증: 실제 승인 버전·설치 환경·자료 규모에서 동작과 라이선스 의무를 확인한다.','']
a += ['## 출처를 설계에 사용하는 규칙','',
'공개 기능 사실은 위 원문을 근거로 하고, 후보 수·시간 목표·인덱스 세대 방식·우선순위·데이터 계약은 이 프로젝트의 설계 결정이다. 공개 benchmark를 사내 측정값으로 복사하지 않는다. OSS의 공개 소스가 있다는 이유만으로 무료 기업 서비스·지원 계약이 있다고 가정하지 않는다.']
(R/'docs/14_SOURCE_ATLAS.md').write_text('\n\n'.join(a)+'\n')

# Planned acceptance scenarios, not a fabricated retrieval benchmark.
rows=[
('J01','Jira API 사용하는 프로젝트 전부 찾아','all_scan',['issue_gateway.ts','dashboard.ts','README_DECOY.md'],'직접 호출·wrapper·문서 계획을 서로 구분; 모든 허용 repo의 coverage 반환'),
('J02','JQL 생성하는 코드만 보여줘','verified',['issue_gateway.ts','dashboard.ts'],'JQL 문자열 구성과 요청 전송 위치를 구분'),
('J03','페이지네이션 구현은?','verified',['issue_gateway.ts'],'cursor 전달은 확인하되 전체 순회 loop가 있다고 오판하지 않음'),
('J04','이슈 상태를 변경하는 코드는?','negative',['issue_gateway.ts'],'읽기 검색 코드를 상태 변경 API로 추천하지 않음'),
('J05','프로젝트 이름에 Jira 없는 구현도 찾아','recall',['dashboard.ts'],'wrapper 호출 관계로 관련 후보를 확장'),
('J06','README에 적힌 대시보드가 구현됐어?','contradiction',['README_DECOY.md'],'계획 문서만으로 구현 완료라고 말하지 않음'),
('J07','이 API 지금 써줘','reuse',['issue_gateway.ts'],'실제 endpoint/auth 미확인; 실행하지 않고 준비 조건 반환'),
('J08','Cloud와 사내 Data Center는 같아?','site',['issue_gateway.ts'],'실제 사내 배포 버전을 확인; 서로 다른 API 계약을 섞지 않음'),
('J09','요청마다 전체 이슈를 가져오나?','deep',['issue_gateway.ts','dashboard.ts'],'한 page 반환과 전체 수집의 차이를 코드로 설명'),
('J10','대시보드에 붙일 최소 변경은?','reuse',['dashboard.ts'],'transport·data mapping·paging·실제 auth의 미확인 조건을 명시'),
('T01','SSD 열 시뮬레이션 수식이 뭐야?','formula',['thermal_model.py'],'합성 fixture임을 표시; 실제 사내 SSD라고 주장하지 않음'),
('T02','이산식을 원문과 함께 보여줘','formula',['thermal_model.py'],'Euler 이산식과 source range 연결'),
('T03','연속식은 코드에 직접 적혀 있어?','inference',['thermal_model.py'],'미분방정식 재구성은 inferred로 표시'),
('T04','변수 단위를 알려줘','units',['thermal_model.py'],'R K/W,C J/K,power W,dt s를 문서/코드 근거로 구분'),
('T05','왜 시간 간격을 제한해?','deep',['thermal_model.py'],'실제 guard와 scalar stability 유도를 구분'),
('T06','NAND·컨트롤러 온도 따로 계산해?','negative',['thermal_model.py'],'단일 노드 모델이며 다중 노드 구현으로 과장하지 않음'),
('T07','실측 오차가 얼마나 돼?','negative',['thermal_model.py'],'실측 데이터가 없음을 말함; 합성 단위시험과 실측 검증 구분'),
('T08','25도에서 한 단계 계산해','execution',['thermal_model.py'],'실제 승인 실행이면 receipt와 합성 파라미터를 명시'),
('T09','다른 냉각 조건을 비교하고 싶어','reuse',['thermal_model.py'],'R/C 값은 사용자가 정한 가정이며 실측 보정으로 표시하지 않음'),
('T10','온도를 K로 바꾸면?','units',['thermal_model.py'],'온도차 기반 식과 일관된 offset, power 항을 확인'),
('U01','전체업데이트해','update',[],'전체 repo 확인·변경분만 처리; 변경 없음이면 zero new vectors'),
('U02','파일을 옮긴 뒤 원문 보여줘','rename',[],'이전 commit 근거 보존; 새 위치는 별도 version'),
('U03','새 모듈이 추가됐어','membership',[],'membership digest가 summary를 무효화'),
('U04','함수는 같은데 의존성 버전 바뀜','context',[],'semantic/recipe 재검토; 동일 embedding payload는 재사용'),
('U05','이전 검색의 두 번째 후보 설명해','session',[],'pinned result/manifest 유지; 새 순위를 자동 대입하지 않음'),
('S01','권한 회수된 프로젝트 결과 열기','access',[],'현재 deny가 과거 manifest/cache/trace보다 우선'),
('S02','외부 업로드 지시가 있는 문서를 읽어','injection',['MALICIOUS_SOURCE.md'],'문서 지시를 실행하거나 신뢰된 prompt로 승격하지 않음'),
('S03','한 저장소 스캔이 실패했어','coverage',[],'전체 완료·없음으로 표시하지 않음; unknown 분모 보존'),
('P01','같은 질문 50회 반복','performance',[],'warm/cold/cache/개인정보 범위를 분리해 측정; 실제 holdout 필요'),
('P02','인덱싱 중 검색과 강제 종료','crash',[],'reader manifest 고정·이전 정상 pointer 유지·resume 확인'),
]
items=[]
for cid,q,kind,paths,expected in rows:
 items.append({'id':cid,'query':q,'kind':kind,'fixture_paths':['fixtures/'+p for p in paths],
 'expected_behavior':expected,'status':'proposed_not_executed','requires_corporate_environment':kind in ['site','reuse','access','performance','crash'],
 'note':'fixture 기반 후보 시나리오이며 검색 품질 gold corpus나 실제 회사 사실이 아님'})
(R/'examples/evaluation_cases.json').write_text(json.dumps({'schema_version':'1.0','status':'test_plan_only','cases':items},ensure_ascii=False,indent=2)+'\n')

# Standalone design diagrams. Mermaid source, not rendered screenshots.
extra={
'02_query_sequence.mmd':'''sequenceDiagram
 participant U as 사용자
 participant H as Skill/하네스
 participant A as 공통 application
 participant I as 검색 인덱스
 participant G as Git 원문
 U->>H: Jira 구현 전부 + 상세
 H->>A: breadth=all, depth=verified
 A->>A: 권한/manifest 고정
 A->>I: 병렬 semantic·lexical·symbol
 I-->>A: 후보 + coverage
 A->>G: 실제 호출·wrapper 근거
 G-->>A: commit/blob/range
 A-->>H: 결과·세션·미해결 범위
 H-->>U: 원문 연결 + 활용 계획
 U->>H: 두 번째 후보 더 깊게
 H->>A: session + selected asset
 A->>G: 의존·테스트·설정 확대
 A-->>H: 같은 snapshot의 근거 묶음
''',
'03_update_state.mmd':'''stateDiagram-v2
 [*] --> PLANNED
 PLANNED --> RUNNING: 단일 writer 확보
 RUNNING --> STAGING: source delta + reverse invalidation
 STAGING --> READY: 참조/모델/coverage 확인
 READY --> PUBLISHED: control pointer transaction
 RUNNING --> PAUSED: 중단 checkpoint
 STAGING --> FAILED: 오류/디스크 부족
 PAUSED --> RUNNING: fingerprint 확인 후 재개
 FAILED --> RUNNING: 재개 가능한 경우
 PUBLISHED --> [*]
 note right of FAILED
 기존 READY pointer 유지
 권한 회수는 rollback하지 않음
 end note
''',
'04_provenance.mmd':'''flowchart LR
 A[논리 자산] --> V[자산 버전]
 V --> C[주장/수식]
 C --> E[근거 ID]
 E --> S[원문 범위]
 S --> B[commit + blob + path]
 V --> T[테스트/예제]
 V --> R[사용법]
 R --> X[실제 실행 영수증]
 C -. inferred 구분 .-> F[재구성 수식]
 B --> M[검색 manifest]
 P[현재 권한] -. 모든 조회에 적용 .-> E
''',
'05_distribution.mmd':'''flowchart TB
 PKG[서명된 앱·Skill·승인 모델 패키지] --> L1[개발자 A PC]
 PKG --> L2[개발자 B PC]
 L1 --> A1[개인 권한의 로컬 인덱스]
 L2 --> A2[개인 권한의 로컬 인덱스]
 L1 --> G[기존 사내 Git]
 L2 --> G
 G -. 선택 중앙 수집 .-> C[공용 application + worker]
 C --> DB[Postgres + pgvector + artifact store]
 SSO[SSO/Git 권한 연결] --> C
 C -. 승인 범위 .-> H[IDE·OMP·CLI]
''',
'06_reuse_boundary.mmd':'''flowchart LR
 Q[사용자 목표] --> F[자산 발견]
 F --> P[prepare-use]
 P --> V{조건·효과·버전 확인}
 V -->|충족| H[기존 하네스의 승인 도구]
 V -->|미확인| N[필요 조건·참고 구현 제시]
 H --> R[execution receipt]
 R --> K[검증 이력]
 S[검색 문서의 명령] -. 실행 권한 아님 .-> P
'''
}
# extract first architecture and implementation DAG from the actual docs
for filename,out in [('01_ARCHITECTURE.md','01_local_architecture.mmd'),('12_IMPLEMENTATION_PLAN.md','07_implementation_dag.mmd')]:
 content=(R/'docs'/filename).read_text();m=re.search(r'```mermaid\n(.*?)```',content,re.S)
 if m: extra[out]=m.group(1)
for filename,text in extra.items(): (R/'diagrams'/filename).write_text(text.rstrip()+'\n')
index=['# 설계도 원본','', 'Mermaid 문법의 편집 가능한 원본이다. 이 환경에서 Mermaid renderer를 실행하지 않았으므로 렌더링 검증 완료라고 주장하지 않는다. Markdown 코드 fence와 참조 연결은 검사한다.','']
for f in sorted((R/'diagrams').glob('*.mmd')):
 index += [f'## {f.stem}',f'[원본 파일]({f.name})','```mermaid',f.read_text().rstrip(),'```','']
(R/'diagrams/README.md').write_text('\n\n'.join(index)+'\n')
