from pathlib import Path
import re
R=Path(__file__).resolve().parents[1]
# Idempotent conversion; existing Markdown source links are left intact.
from source_links import expand_source_links
for path in (R/'docs').glob('*.md'):
    path.write_text(expand_source_links(path.read_text()))
files=sorted((R/'docs').glob('*.md'))
parts=['# REFS 최종 설계서',
'## 사내 Git 기반 기술 지식·코드 발견·원문 드릴다운·재사용 플랫폼',
'**설계 기준일 2026-11-02 · Local-first · UI 마지막 · 사내 구현 인수인계용**',
'이 문서는 이전 프롬프트를 실행한 최종 설계 결과다. 제품 전체 개발 완료 보고서가 아니다. 상세 결정·계약·수직 구현 계획·완료 기준을 제공하고, 별도 폴더에는 실제 시험한 제한된 참조 코어와 기계 검증 계약을 담았다.',
'**먼저 읽을 결론:** 개인/팀 설치형에는 별도 서버를 요구하지 않는다. Git 원본 + 로컬 provenance catalog + QMD adapter + exact source scan + Skill/하네스 연결을 사용한다. 모든 사실은 특정 snapshot의 근거로 내려가며, 전체 탐색 범위와 분석 깊이는 별도로 제어한다. 수동 증분 갱신은 P0, Jira 전체 탐색과 SSD 수식·원문은 첫 실사용의 필수 시나리오다.',
'**검증의 한계:** 외부 공식 문서와 공개 코드는 확인했지만 사내 Git/모델/검색 엔진/OMP를 설치하거나 실제 회사 환경에서 실행하지 않았다. 정확한 설치 버전과 모델 digest는 G0에서 고정한다. 속도·Recall 수치는 목표다. 합성 예시를 사내 발견물로 해석하지 않는다.',
'## 목차']
for f in files:
 title=f.read_text().splitlines()[0].lstrip('# ')
 parts.append(f'- [{title}](#part-{f.name[:2]})')
parts += ['- [설계도 모음](#diagrams)', '- [부록 A: 핵심 TypeScript port](#appendix-ports)',
 '- [부록 B: 파생 catalog SQL](#appendix-catalog)', '- [부록 C: control/운영 SQL](#appendix-control)',
 '- [검증 보고서와 실행 코드](verification/REPORT.md)',
'## 읽는 순서',
'전체 방향은 00~01, 구현자는 02~08과 12~13, 기업 배포 검토자는 09~11과 15를 읽는다. 16의 인수인계로 사내 구현을 시작하고 실제 증거를 붙여 Gate를 닫는다. 문서 안에서 상대 코드 경로를 설명하는 부분은 패키지 기준 경로와 함께 해석한다.']
for f in files:
 text=f.read_text()
 text=re.sub(r'\]\(14_SOURCE_ATLAS.md#(s\d{2})\)',r'](#\1)',text)
 # Actual markdown relative links only; code literals remain as source-module references.
 text=re.sub(r'\]\(\.\./([^)]*)\)',r'](\1)',text)
 text=re.sub(r'\]\((\d{2}_[A-Z_]+\.md)\)',r'](docs/\1)',text)
 parts += ['---',f'<a id="part-{f.name[:2]}"></a>',text]
parts += ['---','<a id="diagrams"></a>','## 설계도 모음',
'Mermaid 원본이다. 해당 렌더러를 지원하는 Markdown 도구에서 볼 수 있다. 이 환경에서는 렌더링을 실행하지 않았다. 원본 파일은 `diagrams/`에 있다.']
for d in sorted((R/'diagrams').glob('*.mmd')):
 parts += [f'### {d.stem}', '```mermaid\n'+d.read_text().rstrip()+'\n```']
for anchor,title,filename,lang in [('ports','부록 A. Application ports','ports.ts','typescript'),
 ('catalog','부록 B. Generation catalog 초기 DDL','catalog.sql','sql'),
 ('control','부록 C. Mutable control 초기 DDL','control.sql','sql')]:
 parts += ['---',f'<a id="appendix-{anchor}"></a>',f'## {title}',
 '아래 계약은 참조 구현의 시작점이며 production migration/전체 제품 구현을 대신하지 않는다. wire schema는 snake_case, application port는 camelCase로 boundary에서 매핑한다.',
 '```'+lang+'\n'+(R/'contracts'/filename).read_text().rstrip()+'\n```']
parts += ['---','## 검증·인수인계 파일',
'[실제 검증 보고서](verification/REPORT.md) · [실행 가능한 참조 코어](reference-core/README.md) · [기계 검증 계약](contracts/README.md) · [사내 구현 시작 문서](docs/16_CORPORATE_HANDOFF.md)',
'**최종 상태:** 아키텍처와 실행 계획은 Designed, 제한된 참조 알고리즘·Git reader·합성 수식·계약은 별도 검증 범위다. REFS 전체가 Implemented/Verified/Accepted라고 표시하지 않는다.']
(R/'MASTER_DESIGN.md').write_text('\n\n'.join(parts)+'\n')
