# REFS — 사내 Git Engineering Intelligence & Code Reuse

**최종 설계·구현 인수인계 패키지 | 2026-11-02 | UI 후순위 · Local-first**

사내 Git에서 코드·API·SDK·수식·전문 지식을 발견하고, 특정 커밋의 원문으로 드릴다운하며, 기존 개발 하네스에서 실제 재사용으로 연결하는 제품 설계다. 개인용과 팀 설치형에는 별도 웹/DB 서버가 필요 없다. 중앙 공용 서비스는 별도의 기업 배포 선택지다.

## 시작할 파일

- [통합 최종 설계서](MASTER_DESIGN.md): 전체 결정·설계도·검색/갱신/근거/지식/재사용·배포·우선순위·완료 기준, 주요 계약 부록.
- [사내 구현 시작·중단/재개 인수인계](docs/16_CORPORATE_HANDOFF.md): 회사 작업 세션에 전달할 실행 지시.
- [구현 계획 T00–T13](docs/12_IMPLEMENTATION_PLAN.md)와 [요구사항 R01–R44](docs/13_ACCEPTANCE_MATRIX.md).
- [검증 보고서](verification/REPORT.md): 실제 수행한 것과 하지 않은 것.

## 포함한 것

`docs/`는 분리된 상세 설계, `diagrams/`는 Mermaid 설계도, `contracts/`는 SQL/JSON Schema/TypeScript port, `reference-core/`는 실제 시험한 작은 코어, `examples/`는 합성 Jira·thermal 코드와 설정/질의 사례다. `skills/`는 호스트 동작 시험 전의 설치 초안이며 `research/`는 공개 근거 기록이다.

## 중요한 상태 구분

**설계는 구현 가능한 수준으로 작성했고 일부 범용 코어를 시험했다. 전체 REFS 제품은 구현·설치된 상태가 아니다.** 사내 저장소, 실제 Jira/SSD 데이터, 회사 PC, 모델·검색 엔진·OMP 연결은 이 환경에서 검증하지 않았다. 문서의 응답 시간과 품질 수치는 목표이며 측정 결과가 아니다.

아직 실행할 수 없는 제품 전체 CLI 명령은 설계 계약으로 표시했다. 실제 실행 가능한 부분은 `reference-core`의 테스트와 `examples`의 합성 수식 fixture, 계약 검증이다. `release-lock.example.json`은 미확정 항목을 null로 남긴 예시이며 운영 배포에 사용하면 안 된다.

## 사내 적용 경로

T00에서 승인된 런타임·Git 접근·모델·QMD public API를 좁게 검증한다. 통과하면 T01/T02의 source/evidence 계약을 만들고 search→evidence→update 수직 기능을 완성한다. Jira 전체 탐색, SSD 수식 원문, 재사용, Skill 연속성을 붙여 G10의 개인형 acceptance를 통과시킨다. 팀 패키지와 중앙형은 그 뒤에 진행한다. 추가 전사 포털이나 범용 Agent 플랫폼은 선행 조건이 아니다.
