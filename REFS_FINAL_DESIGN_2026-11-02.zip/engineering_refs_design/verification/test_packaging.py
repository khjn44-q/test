import sys
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'research'))
from source_links import expand_source_links
class SourceLinkTests(unittest.TestCase):
    def test_existing_link_is_not_rewritten(self):
        text='[S18](14_SOURCE_ATLAS.md#s18)'
        self.assertEqual(expand_source_links(text),text)
    def test_repeated_assembly_is_idempotent(self):
        once=expand_source_links('문장 [S02, S03]')
        self.assertEqual(expand_source_links(once),once)
    def test_range_expands_to_each_source(self):
        self.assertEqual(expand_source_links('[S01–S03]'),
            ' · '.join(f'[S{x:02}](14_SOURCE_ATLAS.md#s{x:02})' for x in range(1,4)))
if __name__=='__main__':unittest.main()
