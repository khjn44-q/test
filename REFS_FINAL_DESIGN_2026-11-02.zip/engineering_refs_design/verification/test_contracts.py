"""Artifact contract checks, not product integration/benchmark tests."""
import copy
import json
import sqlite3
import unittest
from pathlib import Path
from jsonschema import Draft202012Validator, FormatChecker

ROOT=Path(__file__).resolve().parents[1]
SCHEMA=json.loads((ROOT/'contracts/refs.schema.json').read_text())

def validator(name):
    return Draft202012Validator({'$schema':SCHEMA['$schema'],'$defs':SCHEMA['$defs'],'$ref':'#/$defs/'+name},format_checker=FormatChecker())
def example(name): return json.loads((ROOT/'examples'/f'{name}.json').read_text())
def database(name):
    c=sqlite3.connect(':memory:');c.executescript((ROOT/'contracts'/name).read_text());return c

def seed_catalog(c):
    c.execute("INSERT INTO repository VALUES(?,?,?,?,?,?,?)",('repo','host','https://git.example.invalid/r','sha1','[\"refs/heads/main\"]','policy',0))
    c.execute("INSERT INTO snapshot VALUES(?,?,?,?,?,?)",('snap','repo','refs/heads/main','a'*40,'2026-11-02T00:00:00Z','inventory'))

class ContractTests(unittest.TestCase):
    def test_schema_is_valid_draft202012(self): Draft202012Validator.check_schema(SCHEMA)
    def test_all_contract_examples_validate(self):
        for filename,definition in json.loads((ROOT/'examples/contract-examples.json').read_text()).items():
            with self.subTest(filename=filename): validator(definition).validate(json.loads((ROOT/'examples'/filename).read_text()))
    def test_invalid_depth_is_rejected(self):
        x=example('search-request');x['depth']='exhaustive'
        self.assertTrue(list(validator('SearchRequest').iter_errors(x)))
    def test_all_breadth_is_not_page_size(self):
        x=example('search-request');x['page_size']=5;x['breadth']='all'
        validator('SearchRequest').validate(x)
    def test_input_cannot_self_declare_principal(self):
        x=example('search-request');x['principal_id']='admin'
        self.assertTrue(list(validator('SearchRequest').iter_errors(x)))
    def test_sha256_format_requires_64_character_oid(self):
        x=example('evidence');x['source']['object_format']='sha256'
        self.assertTrue(list(validator('Evidence').iter_errors(x)))
    def test_update_scope_cannot_mix_all_and_repo_ids(self):
        x=example('update-request');x['scope']['repo_ids']=['repo']
        self.assertTrue(list(validator('UpdateRequest').iter_errors(x)))
    def test_prepare_plan_never_claims_execution(self):
        x=example('reuse-plan');x['execution_performed']=True
        self.assertTrue(list(validator('ReusePlan').iter_errors(x)))
    def test_catalog_sql_and_fk_check(self):
        c=database('catalog.sql');seed_catalog(c)
        self.assertEqual(c.execute('PRAGMA foreign_keys').fetchone()[0],1)
        self.assertEqual(c.execute('PRAGMA foreign_key_check').fetchall(),[])
        self.assertGreaterEqual(c.execute("SELECT count(*) FROM sqlite_master WHERE type='table'").fetchone()[0],15)
    def test_evidence_requires_an_existing_source(self):
        c=database('catalog.sql')
        with self.assertRaises(sqlite3.IntegrityError):
            c.execute('INSERT INTO evidence VALUES(?,?,?,?,?,?)',('e','missing',None,'{}','c'*64,'bytes_verified'))
    def test_coverage_cannot_exceed_known_eligible_count(self):
        c=database('catalog.sql');seed_catalog(c)
        c.execute('INSERT INTO generation VALUES(?,?,?,?,?,?,?)',('g','now','m','p','a','READY','g/index.db'))
        with self.assertRaises(sqlite3.IntegrityError):
            c.execute('INSERT INTO coverage VALUES(?,?,?,?,?,?,?)',('g','repo','scope_scan',2,3,'complete','[]'))
    def test_control_allows_only_one_running_writer_per_profile(self):
        c=database('control.sql');c.execute('INSERT INTO publication VALUES(?,?,?,?)',('profile',None,None,0))
        c.execute('INSERT INTO job VALUES(?,?,?,?,?,?,?)',('j1','profile','p','f1','RUNNING','{}','now'))
        with self.assertRaises(sqlite3.IntegrityError):
            c.execute('INSERT INTO job VALUES(?,?,?,?,?,?,?)',('j2','profile','p','f2','RUNNING','{}','now'))
    def test_operations_survive_independent_generation_creation(self):
        c=database('control.sql');c.execute('INSERT INTO publication VALUES(?,?,?,?)',('profile','g1','g1',1))
        c.execute('INSERT INTO human_override VALUES(?,?,?,?,?,?)',('o','a','person','{}','[]','now'))
        generated=database('catalog.sql');generated.close()
        self.assertEqual(c.execute('SELECT count(*) FROM human_override').fetchone()[0],1)

if __name__=='__main__': unittest.main()
