"""Validate package syntax and internal references. No network and no product claims."""
from pathlib import Path
from urllib.parse import unquote
import json, re, sys
import yaml
from markdown_it import MarkdownIt
R=Path(__file__).resolve().parents[1]
errors=[]; checks=0
files=[p for p in R.rglob('*') if p.is_file() and '__pycache__' not in str(p)]
for p in files:
 if p.suffix=='.json':
  checks+=1
  try: json.loads(p.read_text())
  except Exception as e: errors.append(f'{p.relative_to(R)}: JSON {e}')
 if p.suffix in ('.yaml','.yml'):
  checks+=1
  try: yaml.safe_load(p.read_text())
  except Exception as e: errors.append(f'{p.relative_to(R)}: YAML {e}')
 if p.suffix=='.md':
  text=p.read_text();checks+=1
  fences=re.findall(r'^\s*```',text,re.M)
  if len(fences)%2: errors.append(f'{p.relative_to(R)}: unbalanced code fences')
  for tok in MarkdownIt().parse(text):
   for child in tok.children or []:
    if child.type!='link_open': continue
    href=child.attrGet('href') or ''
    if re.match(r'^[a-zA-Z][a-zA-Z0-9+.-]*:',href): continue
    path,_,anchor=href.partition('#')
    target=(p.parent/unquote(path)).resolve() if path else p
    checks+=1
    if not target.exists(): errors.append(f'{p.relative_to(R)}: missing link {href}')
    elif anchor and target.suffix=='.md':
     content=target.read_text()
     if f'id="{anchor}"' not in content and f"id='{anchor}'" not in content:
      # Project authored links use explicit anchors. Flag any missing one.
      errors.append(f'{p.relative_to(R)}: missing explicit anchor {href}')
  if re.search(r'\[(S\d{2}[S0-9,\s–-]*)\](?!\()',text): errors.append(f'{p.relative_to(R)}: unresolved source reference')
cases=json.loads((R/'examples/evaluation_cases.json').read_text())['cases']
checks+=1
if len(cases)!=30: errors.append('Expected 30 proposed evaluation scenarios')
for case in cases:
 for f in case['fixture_paths']:
  checks+=1
  if not (R/'examples'/f).exists():errors.append(f'missing evaluation fixture: {f}')
text=(R/'docs/13_ACCEPTANCE_MATRIX.md').read_text()
ids=re.findall(r'^\| (R\d+) \|',text,re.M)
checks+=1
if ids!=[f'R{x:02}' for x in range(1,45)]: errors.append('Requirement matrix is not exactly R01..R44')
for task in re.findall(r'T\d{2}',text):
 checks+=1
 if not re.search(r'^## '+task+r' ',(R/'docs/12_IMPLEMENTATION_PLAN.md').read_text(),re.M):errors.append(f'missing implementation task: {task}')
skill=(R/'skills/internal-reuse/SKILL.md').read_text();checks+=1
fm=yaml.safe_load(skill.split('---',2)[1])
if fm.get('name')!='internal-reuse' or not fm.get('description'): errors.append('Invalid Skill frontmatter')
result={'status':'passed' if not errors else 'failed','checks':checks,'file_count':len(files),'errors':errors,
 'mermaid_rendered':False,'product_integration_tested':False}
(R/'verification/artifact-checks.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False,indent=2))
sys.exit(1 if errors else 0)
