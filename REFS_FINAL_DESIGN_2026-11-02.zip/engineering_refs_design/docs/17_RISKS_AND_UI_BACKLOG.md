# 17. 남은 위험·추후 UI

## 1. 현장 미검증 목록

QMD의 실제 회사 Windows 환경 지원, 정확한 release/모델 양자화 조합, 회사 proxy/CA, corpus 규모, local model 승인, 특정 language grammar/SCIP indexer, Jira instance API·권한, 실제 SSD 수식·실측 데이터는 확인하지 않았다. 알려진 입력이 없다는 이유로 전체 설계는 멈추지 않았고 해당 값은 adapter/config/acceptance로 분리했다.

## 2. 설계 위험과 대응

| 위험 | 현재 결정 | 확대 조건 |
|---|---|---|
| 전체 원문 embedding의 초기 비용 | selective LLM extraction, batch/resume, 명시 partial coverage | 실제 chunk 수/처리율이 한도를 넘으면 budgeted profile |
| QMD 변경·native 의존 | 공개 adapter·release pin·capability probe | 핵심 계약 불충족이면 명시 native fallback |
| 한국어/전문용어 누락 | alias+raw source retrieval+모델 A/B | holdout 개선이 입증된 용어사전/모델만 추가 |
| 과도한 지식 생성·환각 | source-first claims, inference 구분, targeted review | 중요한 실패 유형에만 심화 validation |
| 무제한 graph traversal | depth/node/time budget, missing relation 표시 | 측정된 graph query 병목에서만 graph DB 비교 |
| ‘전부’의 과대 주장 | declared scope+scanned coverage+unresolved 판단 | known-gold test에서만 완전성 검증 |
| 운영 API 위험 | recipe/intent/current binding/receipt | 승인된 use case부터 operation별 확장 |
| 인덱스 snapshot 복사 I/O | 수동 batch로 coalesce, 재임베딩과 분리 측정 | 비용 지배 시 generation-aware native backend |
| 유지보수 부담 | 한 package/한 core/한 provider 우선 | 추가 provider마다 명확한 문제와 통과 기준 |

## 3. 새 구성 요소를 넣기 위한 최소 ADR

해결할 관찰된 문제, 기존 구성으로 해결하지 못한 근거, 추가 개발·운영 비용, 기대 품질/속도 이득, 검증 실험, 실패 시 제거 방법을 한 페이지에 적는다. 사용하지 않는 기능을 미리 일반화하지 않는다. 외부 기술 트렌드를 따라가기 위해 이미 검증된 core를 매번 다시 만들지 않는다.

## 4. UI는 마지막이다

우선순위는 P4다. 초기 UI 요구는 search results, source pane, evidence/relationship list, usage plan, update/job status뿐이다. 무거운 지식 그래프 시각화나 대시보드 편집기를 먼저 만들지 않는다. UI는 search/inspect/evidence/trace/prepare-use API를 소비하며 별도 검색·권한 로직을 갖지 않는다. CLI와 Skill에서 이미 성립하는 경험을 편하게 보여 주는 범위로 시작한다.
