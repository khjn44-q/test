# 01. 아키텍처·프로세스·책임 경계

## 1. 로컬 기준 구조

```mermaid
flowchart LR
  U[개발 요청] --> H[OMP 또는 기존 하네스]
  H --> S[internal-reuse Skill]
  H --> X[자동 탐색 어댑터]
  S --> C[REFS 공통 코어]
  X --> C
  CLI[refs CLI] --> C
  MCP[선택적 stdio MCP] --> C
  C --> CAT[SQLite 카탈로그]
  C --> Q[QMD 검색 어댑터]
  Q --> IDX[로컬 검색 인덱스]
  C --> G[Git 원문 어댑터]
  G --> REM[기존 사내 Git]
  G --> CACHE[읽기용 객체 캐시]
  W[수동 update 작업] --> CAT
  W --> IDX
  W --> G
  H --> USE[기존 승인 API SDK CLI 실행]
```

논리적 모듈은 분리하지만 독립 서비스로 모두 나누지 않는다. CLI는 실행 후 종료한다. OMP에서 사용 중에는 확장/stdio 자식 프로세스가 모델 핸들을 유지할 수 있다. 이것은 사용자가 운영하는 24시간 웹 서버가 아니다. 프로세스가 꺼지면 작업이 계속된다고 말하지 않는다.

로컬 인덱싱은 단일 writer 프로세스로 수행한다. 조회 프로세스는 게시된 generation만 읽는다. 모델 메모리를 중복 점유하지 않도록 온라인 세션과 대량 embed 작업을 겹치지 않는 것이 기본이다. 추후 동시 작업이 필요할 때만 호스트 내 worker를 분리한다. GPU를 쓰지 못하면 CPU 경로로 명시 전환하고 성능을 재측정한다.

## 2. 최소 모듈

| 모듈 | 소유 책임 | 하지 않는 일 |
|---|---|---|
| `inventory` | 허용 repo/ref, 스냅샷 manifest, 범위 통계 | 검색 스니펫의 사실 판단 |
| `sources` | Git 객체·API 읽기, 원문 좌표, diff | 사용자 작업 트리 변경, 임의 URL 접근 |
| `catalog` | 버전별 자산·근거·관계·사용법 | 임베딩 모델 실행 |
| `indexing` | parse/chunk/card/extract/embed, 게시·취소 | 매 질문마다 전체 재분석 |
| `retrieval` | lexical/dense/identifier 결합, 전체 스캔, coverage | 자연어 점수를 사실 확률로 변환 |
| `analysis` | 질문별 context pack·미해결 항목 | 새 범용 에이전트 런타임 |
| `reuse` | 현재 조건과 recipe를 조합한 사용 계획 | 자격 증명 보관·운영 실행의 독자 승인 |
| `interfaces` | CLI/stdio MCP/OMP 계약 변환 | 검색 로직 중복 구현 |
| `policy` | 사용자·데이터 처리·출력 경계 | 모델에게 권한 판단을 위임 |

세 가지 외부 port만 먼저 구현한다: `SourceProvider`, `RetrievalProvider`, `ExecutionBridge`. 중앙 배포용 포괄적 plugin framework는 만들지 않는다. 모델과 권한 정책은 소규모 구성 인터페이스로 두되 한 구현을 먼저 완성한다.

## 3. 사용자 요청의 처리

1. 기존 하네스가 질문의 개발 목적과 필요한 범위를 정한다. 짧은 명시적 검색은 분류 모델 없이 명령으로 바로 처리한다.
2. 코어가 현재 권한/캐시 정책과 `snapshot_manifest_id`를 확정한다.
3. 검색 도구가 구조화된 후보와 근거 ID를 반환한다. FAST에서도 생성된 주장은 코드 확인 상태와 구분한다.
4. 하네스는 질문에 필요한 근거만 읽고 설명한다. 사용자에게 논문식 전체 보고서를 매번 강요하지 않는다.
5. ‘전부’ 요청은 별도 inventory-wide scanner로 전체 판정을 수집하고 페이지화한다. 후보 5개로 잘라 완료하지 않는다.
6. 분석/사용 요청이 이어지면 같은 session과 고정된 source snapshot을 유지한다.
7. 실제 실행은 승인된 기존 도구로 넘긴다. 새 지식은 검증된 source ID와 함께 후보로 저장한다.

## 4. Git 캐시의 현실적인 설계

소스가 Git에 있어도 매번 원격에서 모든 파일을 읽으면 빠른 전수 탐색과 오프라인 원문 확인이 어려워진다. 따라서 기본은 **정본이 아닌, 선택한 저장소의 읽기용 Git 객체 캐시**다. 이미 있는 clone을 읽기만 할 수도 있으나 dirty working tree는 정본으로 섞지 않는다.

초기 fetch는 지정 ref와 필요한 객체만 가져온다. partial/shallow clone 지원 여부는 탐지한다. 서버가 filter를 지원하지 않으면 동작을 숨기지 않고 해당 ref의 제한된 clone으로 대체한다. 일반 파일을 보려고 checkout할 필요는 없다. API-only 모드도 제공하되 raw blob의 지연·rate limit·보존 제약을 coverage에 반영한다.

실제 수정/실행은 별도 작업 디렉터리 또는 사용자가 지정한 프로젝트에서 수행한다. 읽기 캐시를 개발용으로 바꾸지 않는다. submodule과 LFS는 별도 원본/권한/용량을 가진 자산이며 자동으로 다 내려받지 않는다.

## 5. 초기 지원과 미지원 동작

기본 파일 검색은 텍스트 언어 전반에서 지원한다. 정밀 구문 분할은 사내 주언어 2~3개부터 등록하되 TS/JS·Python·C/C++를 첫 후보로 둔다. 나머지는 명시적 텍스트 fallback이다. Notebook은 cell ID와 source map을 가진 별도 reader로 도입하고 raw JSON 전체를 코드인 것처럼 해석하지 않는다. PDF·이미지에만 있는 수식은 이번 기본 코드 경로에서 누락 상태로 표시하고 승인된 문서 extractor 확장 대상으로 둔다.

## 6. 환경별 변경 지점

개인/팀 설치형은 같은 패키지를 각자 설치하며 별도 서버가 없다. 중앙형에서는 SourceProvider의 서비스 계정 수집 권한과 사용자별 query 권한을 분리하고 catalog를 PostgreSQL로 교체한다. UI·HTTP는 공통 코어의 외부 어댑터일 뿐이다. 사내 Sourcegraph가 이미 있다면 검색과 정밀 navigation을 provider로 재사용한다. [S18](14_SOURCE_ATLAS.md#s18)
