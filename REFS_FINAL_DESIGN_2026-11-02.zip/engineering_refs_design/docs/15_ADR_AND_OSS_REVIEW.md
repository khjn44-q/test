# 15. OSS 비교·선정·탈락 근거·ADR

## 1. 근거 수준

이 비교는 공식 문서와 일부 실제 구현 코드를 읽은 **구조 적합성 검토**다. 외부 라이브러리를 이 환경에 설치해 동일 corpus로 실행한 benchmark가 아니다. 최신 release를 고정하려면 설치 시 공식 release와 digest를 확인하고 승인 lock을 만든다. 인기·별 개수로 성능을 추정하지 않는다. 공개 main/cached 문서의 시점이 다르면 해당 주장은 version-dependent로 남긴다.

## 2. 검색·저장·코드 탐색 후보

| 후보 | 확인한 역할 | 장점/적합점 | 한계·추가 책임 | 결정/근거 |
|---|---|---|---|---|
| QMD | local hybrid·SDK·모델 실행 | 이미 있는 검색 pipeline을 빠르게 재사용 | provenance/coverage/ACL/기업 identity 없음, native/model 호환 검사 | 개인형 semantic 기본 adapter [S01](14_SOURCE_ATLAS.md#s01) · [S02](14_SOURCE_ATLAS.md#s02) · [S03](14_SOURCE_ATLAS.md#s03) · [S04](14_SOURCE_ATLAS.md#s04) |
| Zoekt | trigram·substring·regex code search | 큰 코드 집합 exact scan·다중 repo에 적합 | semantic/지식/recipe 별도, Go/ctags/index 운영 | exact 검색 병목 시 추가 [S05](14_SOURCE_ATLAS.md#s05) · [S06](14_SOURCE_ATLAS.md#s06) |
| Sourcegraph | Enterprise 검색/navigation/MCP | 사내 기도입이면 중복 개발 최소 | 계약·설치·권한 sync 조건, 무료 OSS 제품처럼 가정 불가 | 기도입 환경 우선 provider [S18](14_SOURCE_ATLAS.md#s18) · [S19](14_SOURCE_ATLAS.md#s19) |
| ripgrep | 파일 regex 탐색 | 작은 corpus·검증 scan 도구 | 기본 ignore/binary/hidden 처리와 snapshot 범위 관리 필요 | 승인된 staged tracked files의 보조 [S07](14_SOURCE_ATLAS.md#s07) |
| SQLite FTS5 | embedded full-text/BM25 | 별도 서버 없음, 제어 쉬움 | tokenizer/검색 orchestration/모델은 직접 연결 | QMD 실패 시 native fallback의 lexical [S08](14_SOURCE_ATLAS.md#s08) |
| sqlite-vec | embedded vector extension | 작은 배포, SQL, local | pre-v1 breaking-change 경고, ANN 대규모 가정 금지 | native fallback, 버전 고정 [S09](14_SOURCE_ATLAS.md#s09) |
| LanceDB | local vector/FTS hybrid | 큰 columnar corpus·hybrid 후보 | 새로운 adapter/운영 결정 필요, 원문 관계 별도 | local 규모 실험에서 필요 시 비교 [S10](14_SOURCE_ATLAS.md#s10) |
| PostgreSQL+pgvector | 중앙 metadata/vector | 다중 사용자 운영·RLS 연계 | DB 운영, ANN filtering recall 검증 | 신규 중앙형 기본 [S11](14_SOURCE_ATLAS.md#s11) · [S33](14_SOURCE_ATLAS.md#s33) |
| Tree-sitter | syntax tree | lightweight structural chunks·language grammar | type/call/runtime 완전성 없음 | 구문 추출 기본 [S12](14_SOURCE_ATLAS.md#s12) |
| SCIP | precise navigation index protocol | 이미 생성된 index 재사용 | 언어별 indexer·build/dep 조건, stale 처리 | 선택적 import; protocol과 indexer 구분 [S13](14_SOURCE_ATLAS.md#s13) |
| LSP | language-server navigation | 개발 PC가 이미 가진 해석 기능 사용 | 서버 실행·환경·성능·지원 차이 | local deep 분석에서 활용 [S14](14_SOURCE_ATLAS.md#s14) |
| GitLab Search/MCP | 기존 Git 호스트 도구 | Git 접근·검색 재사용 | 플랜/ref/index/tool 버전 조건 | 설치 능력 탐지 후 보조 provider [S15](14_SOURCE_ATLAS.md#s15) · [S16](14_SOURCE_ATLAS.md#s16) · [S17](14_SOURCE_ATLAS.md#s17) |
| Code graph/RAG frameworks | 관계·추론 orchestration | 일부 cross-repo 분석에 도움 가능 | 별도 runtime/schema/갱신/ACL 복잡도 | 첫 버전 도입 안 함, relation table로 시작 |

Sourcegraph structural search는 공식 문서가 기본 비활성과 적극 개발되지 않음을 설명하므로 새 핵심 의존으로 삼지 않는다. 제품의 다른 search/navigation 기능과 혼동하지 않는다. [S20](14_SOURCE_ATLAS.md#s20)

## 3. 모델 비교

| 후보 | 공식 자료로 확인한 범위 | 이 설계에서의 판단 |
|---|---|---|
| Qwen3-Embedding-0.6B | 100+ 언어, 최대 1024차원, 작은 계열, Apache-2.0 표기 | 초기 기본 후보. query/doc formatting과 양자화 runtime을 검증 [S21](14_SOURCE_ATLAS.md#s21) |
| Qwen3-Reranker-0.6B | instruction-aware reranking과 사용 예 | 상위 후보 제한 적용. 모든 질의에 강제하지 않음 [S22](14_SOURCE_ATLAS.md#s22) |
| BGE-M3 | multilingual, dense/sparse/multi-vector, 1024차원, 8192 길이, MIT 표기 | dense 비교 기준 후보. multi-vector까지 첫 버전에 도입하지 않음 [S23](14_SOURCE_ATLAS.md#s23) |
| EmbeddingGemma-300M | 100+ 언어·코드/기술 문서 학습, 768차원 축소 옵션, Gemma terms | 저자원 비교 후보. ‘영어 전용’ 탈락 근거 사용 금지 [S24](14_SOURCE_ATLAS.md#s24) |
| 큰 embedding/코드 특화 모델 | 정확한 선택/반입 조건은 추가 검증 필요 | 작은 모델이 숨은 코드 질의를 놓치는 경우만 후속 비교 |

parameter 수만으로 RAM·latency·한국어 정확도 우열을 계산하지 않는다. GPU 필요 여부와 CPU 처리율은 선택한 artifact/runtime/context/batch에 따라 측정한다. 양자화 weight의 memory 절감과 vector index 차원 절감은 다른 최적화다. 전문 수식의 의미 정확성은 embedding만으로 보장되지 않으므로 source 검증이 필수다.

## 4. 라이선스·유지보수 판단

QMD manifest는 MIT, SCIP repository는 Apache-2.0 표기를 확인했다. 모델의 조건은 위 model card에 따로 명시했다. 그 외 transitive dependency와 기업 제품 계약은 승인 release의 LICENSE/NOTICE/SBOM을 확인한다. 법률 자문을 대신하는 결론을 내리지 않는다.

현재 문서·소스가 존재하고 제공하는 기능을 확인한 것과 장기 유지보수 보장은 다르다. 인수인계자는 release cadence, unresolved crash/security issue, Windows native artifact, migration notes를 설치 시 점검한다. 모든 후보의 별 수/개발자 수를 수집하는 작업은 제품 선택의 필수조건이 아니다.

## 5. ADR

**ADR-01 Local-first modular package.** 별도 서버는 초기 필수 아님. 중앙형은 사용자별 권한·공유 비용이 실제로 필요할 때 선택한다.

**ADR-02 QMD adapter, not QMD-shaped product.** source/evidence/recipe 계약은 REFS 소유. QMD 공개 SDK만 의존한다. docid/line/context를 원문 ID로 오인하지 않는다.

**ADR-03 Exact paths separate from semantic discovery.** semantic similarity는 존재 증명도 전수 증명도 아니다. 모든 허용 tracked source의 exact 탐색 경로를 보장한다.

**ADR-04 Breadth and depth orthogonal.** top-k와 ALL, fast/verified/deep을 내부적으로 조합한다.

**ADR-05 Commit-level provenance and mutable policy.** 코드 snapshot은 고정하지만 권한 회수는 모든 snapshot에 즉시 우선 적용한다.

**ADR-06 Incremental from day one.** update/rebuild, source delta, dependency invalidation, atomic publish를 P0에 둔다.

**ADR-07 Complete embedding is not complete understanding.** 적격 원문 embedding을 기본으로 하되 semantic LLM extraction은 선택적이다. coverage 차원을 분리한다.

**ADR-08 No new execution plane.** 기존 하네스를 쓰며 ref 도구는 실행 계획·근거를 제공한다.

**ADR-09 Human records are not disposable cache.** overrides·feedback·실행 receipts는 별도 backup한다.

**ADR-10 UI last.** API/CLI 모든 기능이 먼저 동작해야 한다.

## 6. QMD 현장 Gate 실패 시 선택표

| 실패 | 조치 |
|---|---|
| Windows native/model 실행 불가, 허용 runtime 대체도 불가 | 같은 contracts를 유지하여 SQLite FTS5+sqlite-vec+승인 embedding provider로 adapter 교체 |
| QMD 공개 API가 원하는 scope/result mapping을 지원 못 함 | source/manifest mapping은 catalog에서 처리; 내부 DB patch로 해결하지 말고 부족이 핵심이면 native fallback |
| 반출 정책 때문에 로컬/승인 embedding 모델 없음 | lexical-only pilot, semantic 기능 미달 표시. 승인 전 자동 외부 API 사용 금지 |
| corpus 규모에서 vector latency/DB 사본 비용 과다 | exact lane부터 Zoekt 또는 중앙 provider로 전환하고 dense 대안 A/B. 전체 architecture 재작성 금지 |
| 사내 Sourcegraph가 이미 완전한 검색 제공 | 원문·navigation provider 재사용, QMD는 카드 의미검색 필요가 남을 때만 유지 |

fallback은 동시에 모두 구현할 플러그인 요구가 아니다. G0에서 선택한 한 경로를 먼저 완성한다.
