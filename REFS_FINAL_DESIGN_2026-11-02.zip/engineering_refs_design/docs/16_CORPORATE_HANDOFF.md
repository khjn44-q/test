# 16. 사내 바이브코딩 시작 프롬프트·환경 입력

## 1. 먼저 알아야 할 범위

이 패키지는 설계, 기계 계약, 합성 사례, 일부 검증한 범용 참조 코드를 제공한다. Git 인증/사내 실제 repo/QMD binary/임베딩 모델/OMP 설치는 이 환경에서 연결하지 않았다. 사내에서는 이 경계만 구성하고, 구현 계획의 순서대로 제품을 완성한다.

아래 입력은 회사만 알 수 있는 환경값이다. 미리 토큰이나 비밀을 외부 대화에 붙이지 않는다.

| 입력 | 확보 위치/처리 |
|---|---|
| Git 목록·기본/릴리스 ref | 현재 보유 목록, import schema로 정규화 |
| 인증 | 기존 Git helper/SSH/승인 API credential binding |
| 모델 허용 | 로컬 artifact 또는 승인 internal endpoint |
| PC | OS/arch/CPU/RAM/GPU/disk, Node/Git 설치 여부 |
| 사내 정책 | cache 보존, 외부 model 차단, 실행 경로 |
| 주요 언어 | manifest sampling으로 자동 확인, 첫 parser 2~3개 선택 |
| 패키지 배포 | 사내 registry/zip/서명 프로세스 |
| 실제 평가 질문 | Jira/SSD 포함 사용자와 정답 코드 아는 사람이 선정 |

## 2. 그대로 전달할 시작 지시

```text
이 작업은 REFS 사내 Git 기술 지식·코드 재사용 도구의 현장 구현이다.
README.md → docs/00_DECISIONS_AND_SCOPE.md → docs/12_IMPLEMENTATION_PLAN.md →
docs/13_ACCEPTANCE_MATRIX.md → verification/REPORT.md 순서로 읽어라.
작업할 Task의 상세 spec과 contracts도 읽어라. 문서를 처음부터 재조사하지 마라.

목표는 서버 없는 개인형 P0+P1 완료다. UI/중앙 서버/그래프 DB/새 워크플로 엔진은 제외한다.
기존 Git 원본과 사용자 작업 트리는 수정하지 않는다. 실제 비밀은 기존 helper/binding을 쓴다.
현재 제공된 reference-core는 일부 결정론적 계약의 참조 구현이지 제품 전체가 아니다.
범용 core 시험 통과를 QMD/모델/OMP/기업 성능 검증이라고 보고하지 마라.

T00의 좁은 현장 capability probe로 승인 런타임과 exact release/model digest를 고정하라.
이미 가능한 Git 접근을 다시 사용자에게 물어보지 말고, 읽기 검사를 먼저 수행하라.
작업 전체를 멈출 필요가 없는 환경값은 설정에 분리하고 fixture로 진행하라.
현장 정책·자격 증명처럼 진짜 필요한 항목만 한 번에 정리하라.

각 Task에서 경계 실패를 먼저 재현하고 최소 구현 후 관련 검사와 전체 통합 검사를 실행하라.
단일 기능의 완료를 검증하고 다음 Task로 이동하라. 이미 완료한 기능을 재작성하지 마라.
source identity/catalog schema/publisher는 단일 writer로 유지하고 독립 검토만 병렬화하라.
매일 또는 세션 종료 때 구현/검증/미확인/다음 작업을 짧게 checkpoint에 기록하라.

필수 E2E: Jira 코드 사용처 전체 탐색, SSD 계산식 원문·단위·테스트 드릴다운,
기존 자산 사용 계획과 실제 read/SDK 사례, update --all의 변경분 반영,
삭제/rename/force-push/권한 변경 처리, 동일 탐색의 후속 질문 연속성이다.

설계 변경은 구체적인 실패 근거가 있을 때만 ADR로 기록한다.
새 dependency를 추가하기 전에 기존 선택으로 해결할 수 있는지 확인하라.
성능은 warm/cold와 retrieval/answer generation을 분리해 측정한다.
Hit@5와 Recall@k를 혼동하지 말고, 전사 전체 의미상 완전성을 약속하지 마라.
Accepted는 실제 환경의 Gate 증거가 있을 때만 사용하라.
```

## 3. 재개 지시

```text
최신 checkpoint, 마지막 통합 검사, acceptance matrix의 미완료 항목을 먼저 읽어라.
지난 세션에서 완료·검증한 작업은 보존한다. 지금 작업 중인 Task와 관련 source 계약만 복원한다.
현재 snapshot/model/schema가 checkpoint와 다르면 변경 영향만 확인한다.
실패 원인이 환경인지 코드인지 구분하고 같은 무효 명령을 반복하지 않는다.
다음 독립적인 최소 수직 기능을 완성하고 결과를 확인하라.
```

## 4. 이곳에서 제공한 코드와 현장 구현의 경계

reference core는 RRF, 파생 무효화, all-of 접근 판정, coverage, update 분류 같은 범용 로직을 실제 테스트할 수 있게 제공한다. Git reader는 **합성 로컬 Git**에서 pinned source 원칙을 검증한다. 인증·network·native parser·모델 loader는 mock 성공으로 포장하지 않는다. 실제 host adapter와 model의 correctness/performance는 T00/T10에서 확인한다.
