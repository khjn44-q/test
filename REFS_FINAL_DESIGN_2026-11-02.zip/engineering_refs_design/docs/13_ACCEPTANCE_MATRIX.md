# 13. 요구사항 추적 및 완료 기준

현재 제품 전체 상태는 **Designed**다. 범용 참조 모듈 검사는 [검증 보고서](../verification/REPORT.md)에 별도 기록한다. 아래 matrix의 PASS는 현장 구현 후 실제 증거가 있어야 채울 수 있다.

| ID | 요구사항 | 구현 우선순위/작업 | 최소 합격 증거 |
|---|---|---|---|
| R01 | Git을 코드 정본으로 사용 | P0 T01 | dirty working tree와 다른 고정 커밋 값을 반환 |
| R02 | 사용자 checkout 무변경 | P0 T01 | 작업 전후 Git status 동일 |
| R03 | 서버 없이 로컬 실행 | P0 T00 | 웹 listen 없이 CLI/stdio smoke |
| R04 | Windows 네이티브 지원 | P0 T00 | 회사 표준 PC의 설치·search·update 로그 |
| R05 | 프로젝트 요약 사전 생성/임베딩 | P0 T03 | 실제 model fingerprint와 vector coverage |
| R06 | 작은 내부 함수 직접 발견 | P0 T03 | summary에 없는 정답 source 검색 성공 |
| R07 | 한국어 질문·영문 코드 연결 | P0 T03/T10 | holdout Hit/Recall 보고 |
| R08 | exact identifier 보존 | P0 T03 | 동일 이름 decoy와 정확 symbol 시험 |
| R09 | 임베딩/LLM 과잉 비용 억제 | P0 T03/T05 | unchanged reembed 0, extraction 범위 기록 |
| R10 | 근거에 commit/blob/range 포함 | P0 T02 | 모든 fixture EvidenceRef 검증 |
| R11 | generated snippet와 원문 좌표 구분 | P0 T02 | source mapping 검증 |
| R12 | source unavailable/revoked 명시 | P0 T01/T10 | 잘못된 최신 source 대체 0 |
| R13 | 수동 특정 repo 갱신 | P0 T05 | target 외 source 재처리 없음 |
| R14 | 수동 전체 갱신은 변경분만 | P0 T05 | checked/changed/reused count 일치 |
| R15 | rebuild와 update 구분 | P0 T05 | model change reembed, no-op update reuse |
| R16 | 삭제/rename/새 파일 파생 무효화 | P0 T05 | claims/recipes/parent cards 변경 결과 |
| R17 | force push/shallow/ref 변경 처리 | P0 T05 | manifest fallback 및 실패 구분 |
| R18 | 원자 게시/실패 복구/동시 writer | P0 T05 | kill/disk-full/lock regression |
| R19 | model/extractor/schema version 분리 | P0 T02/T05 | incompatible embedding space 혼합 거부 |
| R20 | 빠름/정확/깊이 수준 | P1 T03/T04/T07 | preset별 수행 단계 trace |
| R21 | 전체 탐색 breadth 독립 | P1 T06 | all+deep 조합과 전체 결과 보존 |
| R22 | 전체 목록의 pagination/coverage | P1 T06 | 상한 초과 fixture에서도 정답 소실 0 |
| R23 | docs-only/dependency-only 오판 방지 | P1 T06 | Jira fixture class 판정 |
| R24 | 정의·참조·호출·테스트 drilldown | P1 T04 | relation resolution/evidence 검사 |
| R25 | 대화 후속 문맥 유지 | P1 T09 | ordinal→asset ID 안정성, pinned snapshot |
| R26 | 기술 지식·예외·전제 추출 | P1 T04/T07 | scope/unknown/contradiction 사례 |
| R27 | 실제 수식과 이론식 구분 | P1 T07 | 코드식 재구성·단위·분기 원문 근거 |
| R28 | 테스트 존재와 실행 성공 구분 | P1 T07/T08 | receipt 없으면 execution_verified 금지 |
| R29 | API/SDK/코드 재사용 | P1 T08 | 실제 단일 operation 또는 package 이용 E2E |
| R30 | recipe readiness와 관련성 분리 | P1 T08 | outdated version/권한 부족 반례 |
| R31 | 검색이 임의 실행을 유발하지 않음 | P0/P1 T01/T08 | hook/URL/shell 악성 입력 regression |
| R32 | Skill 자연어 활용 | P1 T09 | 실제 하네스 baseline/with-skill 시나리오 |
| R33 | 자동 탐색 중복·재진입 억제 | P1 T09 | 동일 목표·revive·empty event 시험 |
| R34 | 사용자 의도에 맞는 심층 수행 | P1 T09 | explicit all/deep 요청을 FAST에서 중단하지 않음 |
| R35 | 모델 반출 정책·비밀 미노출 | P0 T00/T10 | 허용 network/log/payload 검사 |
| R36 | 파생 지식 ACL all-of | P0 T02/T10 | A-only에서 A+B derived 불가 |
| R37 | fallback/실패/미발견 구분 | P0 T03/T10 | model outage/auth fail/no-match 상태 |
| R38 | 속도와 정확도 실측 | P1 T10 | 규정 corpus/장비/cold-warm/percentile |
| R39 | 팀 설치형 배포·제거 | P2 T11 | 두 PC smoke, source 보존 |
| R40 | shared index 배포 조건 | P2 T11 | group/expiry/signature manifest 검사 |
| R41 | 중앙 사용자별 권한 | P3 T12 | 실제 principal isolation/RLS/ACL revoke |
| R42 | 중앙/로컬 근거 version 정합 | P3 T12 | mismatch 동작과 fallback |
| R43 | 백업/rollback·인간 보정 보존 | P0/P2 T05/T11 | 새 인덱스 실패·운영 기록 복구 |
| R44 | UI는 후순위·코어와 분리 | P4 T13 | headless 전체 acceptance |

## Release 판정

G10 개인형은 R01~R38과 R43의 개인형 범위를 통과해야 한다. R39~R40은 팀 패키지 release에 추가한다. R41~R42는 중앙형 release의 필수이며 로컬 성공으로 대신할 수 없다. R44는 UI 착수 시 확인한다. 보안 critical 실패, 원문 위조, stale를 최신으로 오표시, ‘전체’에서 잘린 결과를 완료 처리하는 문제는 release blocker다.

성능 목표 미달만 있을 때는 현장 장비 profile을 명확히 제한해 conditional pilot을 허용할 수 있지만 목표 달성으로 표시하지 않는다. 채택 여부는 사용자 실제 사용 사례로 확인한다.
