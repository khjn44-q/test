# 10. 배포·기업 확장·운영 인수인계

## 1. 배포는 서버 운영과 동일하지 않다

| 형식 | 운영 서버 | 데이터 위치 | 권장 시점 |
|---|---|---|---|
| 개인 로컬 | 없음 | 자신의 Git cache·카탈로그·인덱스 | 첫 검증/개인 사용 |
| 팀 설치 패키지 | 없음 | 사용자별 독립 데이터 | 여러 개발자에게 도구를 배포할 때 |
| 승인 snapshot 배포 | 다운로드 저장소만 있을 수 있음 | 동일 권한 그룹별 snapshot + 사용자 cache | 반복 인덱싱 비용이 크고 접근 집합이 안정적일 때 |
| 중앙 검색 서비스 | 필요 | 사내 서버 인덱스, 사용자별 접근 통제 | 여러 권한 집합·대규모/동시 갱신이 필요할 때 |
| 중앙 발견 + 로컬 분석 | 중앙 검색만 필요 | 중앙 카드/검색, 로컬 exact code/실행 | 중앙 자원 절약과 로컬 실행을 함께 원할 때 |

최초 추천은 **로컬 패키지를 팀에 배포하는 방식**이다. 배포할 수 있어야 한다는 이유만으로 전사 중앙 서버부터 구축하지 않는다.

## 2. 로컬/팀 설치 패키지

배포 artifact는 조직 scope의 npm tarball 또는 승인된 zip/install package다. Node 런타임을 조직 표준으로 제공하거나 별도 설치 번들로 제공할 수 있다. native DLL/grammar/모델은 플랫폼별 승인 빌드·hash를 묶고 스크립트에서 인터넷 latest를 가져오지 않는다. Windows x64가 첫 호환성 Gate, Linux는 사내 host/CI용이다. WSL2·Docker는 선택 사항이다.

설정은 사용자별 `config`, cache/index, audit/receipt, logs 경로를 분리한다. Git credential은 OS/Git helper가 관리한다. 패키지에 회사 토큰·실제 host·개인 index를 포함하지 않는다. Skill과 OMP extension은 옵션으로 설치하고 기존 설정을 backup한 뒤 필요한 항목만 병합한다. 전역 설정 파일을 통째로 덮어쓰지 않는다.

설치 smoke는 doctor→합성 작은 repo 인덱싱→한글 질문→원문→update→삭제 반영→uninstall로 끝난다. 런타임 모델 download 없이 작동하는지 검사한다. 제거 시 프로그램·모델 cache·개인 index·작업 영수증 중 무엇을 지울지 구분하고, 사용자의 원본 Git과 작업 폴더는 지우지 않는다.

## 3. 버전·업데이트·롤백

app version, schema version, index generation, embedding space, extractor version, host adapter version을 별도로 둔다. binary 업데이트가 자동으로 파괴적 DB migration이나 전량 re-embed를 유발하지 않게 한다. migration plan과 추가 disk estimate를 보여 주고 실행한다. rollback binary가 새 schema를 읽을 수 없는 경우 이전 binary+이전 generation을 짝으로 되돌린다.

배포 manifest에는 target OS/arch, dependencies, license/NOTICE, digest, optional SBOM, migration compatibility, network destinations를 포함한다. `release-lock.example.json`은 현장에서 실제 검증한 정확한 버전으로 채운다. 이 패키지에는 외부 의존성이 설치·검증됐다는 가짜 lockfile을 넣지 않는다.

## 4. 중앙 서비스 기준안

사내 기존 Sourcegraph가 충분하면 그 검색·정밀 navigation·MCP를 provider로 재사용하고, REFS는 기술 지식/recipe/provenance orchestration만 보완한다. 새로 중앙 서비스를 운영해야 하면 하나의 application/API + worker 프로세스 + PostgreSQL/pgvector + artifact storage로 시작한다. 초기부터 Kubernetes·Kafka·Redis·graph DB를 모두 요구하지 않는다. code exact search 규모가 요구하면 Zoekt를 독립 provider로 추가한다. [S05](14_SOURCE_ATLAS.md#s05) · [S18](14_SOURCE_ATLAS.md#s18)

중앙 앱의 identity는 사내 SSO/OIDC와 연결하고 Git principal mapping을 명시한다. remote MCP는 승인된 HTTP transport와 인증을 사용한다. 소스 수집 credential과 사용자의 자산 실행 credential을 분리한다. 수집 worker가 서비스 계정으로 읽은 자료는 index ACL과 provenance를 갖는다. 정책 동기화 지연은 명시 SLA로 관리하며 즉시 일치한다고 가정하지 않는다. [S19](14_SOURCE_ATLAS.md#s19) · [S28](14_SOURCE_ATLAS.md#s28) · [S29](14_SOURCE_ATLAS.md#s29)

## 5. 혼합형의 일관성

중앙 결과에는 repo/commit/blob/evidence digest와 query manifest를 포함한다. 로컬이 해당 commit을 읽을 권한과 객체를 갖는지 확인한다. 로컬 HEAD가 달라도 중앙 근거를 같은 commit으로 resolve하며, 불가하면 최신으로 몰래 대체하지 않는다. 로컬에서 새로 분석한 코드를 중앙에 올릴 때는 기존 source 접근·반출 조건을 다시 적용한다. 중앙 카드와 로컬 코드가 다른 버전이면 사용 계획은 재검증한다.

## 6. 운영 절차

| 상황 | 처리 |
|---|---|
| Git 인증 만료 | 갱신/원문 read를 AUTH_REQUIRED로 구분, 권한 정책 범위의 기존 cache만 사용 |
| 모델 binary 미반입 | lexical-only 동작, semantic 기능이 미작동임을 표시 |
| parser 실패 | 해당 파일 text fallback, semantic edge를 추정으로 표시 |
| 업데이트 중단/디스크 부족 | active generation 유지, staging 정리/재개, 필요한 공간 보고 |
| repo 삭제/권한 회수 | deny 우선, 해당 파생 결과 차단, 회사 정책에 따른 정리 |
| 잘못된 AI 지식 신고 | 해당 claim quarantine/override, 근거는 보존, 다른 자산 자동 삭제 금지 |
| 중앙 장애 | 로컬 index가 승인된 offline 정책을 충족할 때만 이용, 오래된 지식으로 실행 강행 금지 |
| 인덱스 손상 | last READY 복구 또는 원본으로 파생 인덱스 재생성, 인간 보정/receipts는 backup 복원 |

## 7. 규모 확대를 결정하는 신호

저장소 수 하나로 전환하지 않는다. source bytes/chunks, 변경량, warm p95, cold start, 전수 스캔 시간, DB shadow copy I/O, 최대 memory, 동시 사용자와 권한 집합을 측정한다. 다음 중 실제 병목이 발생할 때 해당 계층만 바꾼다: raw exact scan이 탐색 예산을 초과하면 Zoekt, dense scan 규모·동시성이 문제면 중앙 pgvector/전용 provider, 권한/배포 복제 비용이 문제면 중앙 검색. 세 전환을 한꺼번에 진행하지 않는다.
