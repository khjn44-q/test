# 02. 데이터 모델·식별자·권위

기계 검증 계약은 `../contracts/`에 둔다. 이 문서는 필드의 의미와 변경 규칙을 정의한다. 예시 ID는 모두 합성 데이터이며 실제 사내 저장소를 뜻하지 않는다.

## 1. 원본과 파생 데이터

| 데이터 | 권위 | 보존 원칙 |
|---|---|---|
| 코드·Git 문서 | Git commit/blob | 원문을 바꾸지 않는다. |
| 공식 정책·지원 문서 | 승인된 문서 source/version | Git 코드 관찰과 별도 근거다. |
| 생성 summary·embedding·관계 추정 | 재생성 가능한 파생물 | 원문과 extractor/model version에 연결한다. |
| 인간 보정·공식 확인 | 기록한 주체·시점·대상 범위 | 자동 재생성이 덮어쓰지 않는다. |
| 실행 영수증 | 실제 execution bridge의 receipt | 대상 버전·입력 범위·환경·결과를 남긴다. |
| 세션·작업 진행 | 이 제품의 운영 데이터 | 보존/삭제 정책을 따른다. |

따라서 ‘DB 전부 지워도 Git으로 완전 복구’는 성립하지 않는다. 파생 인덱스와 인간/운영 원본을 분리해 백업한다.

## 2. 네 층과 세부 종류

L0 프로젝트/패키지 카드, L1 기능·API·사용법, L2 기술 주장·수식·알고리즘, L3 원문·심볼·테스트·예제다. 이들은 다른 제품이 아니라 `asset.kind`가 다른 레코드다. 식별 관계는 `contains`, `implements`, `declares`, `references`, `calls`, `depends_on`, `tested_by`, `example_of`, `derived_from`, `contradicts`, `supersedes`, `validated_by`로 시작한다.

`calls`는 반드시 resolver 수준을 갖는다: `lexical_candidate`, `syntax_observed`, `type_resolved`, `runtime_observed`. 이름 문자열이 같은 것은 해석된 호출 관계가 아니다. `tested_by` 역시 가까운 파일명만으로 확정하지 않는다.

## 3. 식별자 세 가지를 분리한다

**Asset ID**는 사람이 이어서 보는 기능의 논리 ID다. **Version ID**는 특정 스냅샷의 의미 표현이다. **Evidence ID**는 특정 원문 범위다. 같은 함수가 이동하면 Asset ID를 이어 줄 수 있지만 자동 rename 추정이 애매하면 새 ID와 `possible_successor` 후보 관계를 만들고 확정하지 않는다.

SourceRef 필수값:

- `host_id`, `repo_id`, `object_format` (`sha1` 또는 `sha256`).
- `commit_oid`, `blob_oid`, `path`, `content_sha256`.
- `byte_start` 포함, `byte_end` 미포함. 표시용 `line_start/line_end`는 1-based inclusive.
- `symbol_key`와 `symbol_resolution` 선택값.
- `encoding`, `line_ending`, `extractor_fingerprint`.

Git의 객체 ID와 순수 파일 bytes의 SHA-256은 다르다. 문자열 길이를 40자로 고정하지 않는다. 줄 번호는 원문 커밋의 표시 좌표이며 그 자체가 영구 ID가 아니다. CRLF 변환·Unicode·multibyte 문자 때문에 byte offset과 column offset을 혼동하지 않는다. 기본 reader는 UTF-8/UTF-8 BOM을 다루고 다른 encoding은 명시적 decoder 설정 없이는 `unsupported_encoding`으로 남긴다. Git path는 임의 bytes를 허용하므로 UTF-8로 표현 불가한 경로는 bytes/base64를 내부 보존하고 일반 인터페이스에서 누락 사유를 표시한다.

## 4. 주요 엔티티

| 엔티티 | 필수 내용 |
|---|---|
| Repository | 안정 host/repo ID, canonical URL, 허용 ref, archive 상태, 정책 참조 |
| Snapshot | repo/ref/commit, fetched_at, content tree, 권한 확인 상태 |
| SourceUnit | blob, 경로, 범위, 종류, symbol, parent unit |
| AssetVersion | logical asset, snapshot, kind, title, description, evidence, extracted_at |
| Claim | 주장, 적용 범위, 조건, 예외, 근거 유형, 반대 근거, 해석 여부 |
| Evidence | 원문 범위, 인용 부분, 원문 확인 상태 |
| Relation | 양쪽 버전 ID, 관계 종류, resolver, evidence IDs |
| Recipe | 진입점, input/output 계약, 버전 조건, 효과, credential 참조, 확인 기록 |
| Generation | catalog version, search index path, source manifest, model fingerprints, state |
| Coverage | intended/eligible/indexed/scanned 범위, 단계별 실패와 제외 이유 |
| Session | goal, query plan, pinned manifest, 결과 집합, 선택 자산, 미해결 질문 |
| Override | 작성자, 대상 ID, 근거, 변경 이유, 유효범위 |
| ExecutionReceipt | tool/operation, parameter digest, code/service version, environment, time, outcome |

본문을 중복 저장하는 이유가 명확해야 한다. Git 객체 캐시는 재현을 위한 bytes, QMD 문서는 검색용 표현, catalog는 관계/근거/업무 상태다. 동일한 전체 코드의 또 다른 FTS 엔진은 초기 기본 구성에 추가하지 않는다.

## 5. 권한 상속

파생 레코드의 `required_scopes`는 사용된 원본들의 제약을 모두 만족해야 하는 **all-of** 집합이다. 서로 독립적인 공개 근거만으로도 동일한 주장을 만들 수 있다면 접근 범위가 다른 별도 표현을 생성한다. 멀티소스 문장을 한 source에만 연결해 다른 source의 내용을 흘리지 않는다. source ID는 비밀이 아니지만 접근은 매번 확인한다.

검색 관련성, freshness, 근거 수준, reuse 상태, 실행 성공 여부를 한 점수나 배지로 합치지 않는다. 필요한 경우 각각의 차원을 표시한다.

## 6. 모델 fingerprint와 캐시

Embedding cache key는 `security_domain + model_artifact_digest + dimension + tokenizer/prompt/normalization + payload_hash`다. 요약 cache는 실제로 읽은 evidence set, extraction instruction, model config를 포함한다. 시간·현재 커밋 같은 비의미 메타데이터를 embedding 본문에 넣지 않아 같은 코드의 무의미한 재임베딩을 막는다.

그러나 blob만 같다고 해석을 무조건 재사용하지 않는다. import target·config·의존성 lock·정책·사용법이 달라지면 해석과 재사용 가능성은 무효화한다. 벡터 bytes 재사용과 의미 검증 재사용은 별개의 결정이다.

## 7. 계약 버전

외부 응답은 `schema_version: "1.0"`, `request_id`, `manifest_id`, `freshness`, `coverage`, `warnings`를 갖는다. additive optional 필드는 minor, 의미 변경·필수 필드 변경은 major다. 미지원 major는 조용히 추정하지 않고 `UNSUPPORTED_SCHEMA`를 반환한다. 생성된 문서 줄 번호를 Git 코드 줄 번호로 전환하는 mapping은 필수다. QMD docid나 snippet은 제품의 Evidence ID를 대체하지 않는다. [S02](14_SOURCE_ATLAS.md#s02) · [S04](14_SOURCE_ATLAS.md#s04)
