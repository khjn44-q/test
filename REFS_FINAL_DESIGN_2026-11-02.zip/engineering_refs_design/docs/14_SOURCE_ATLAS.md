# 14. Source Atlas · 공개 근거와 검증 한계



조회 기준일: **2026-11-02**. 이 목록은 공식 문서와 공개 구현 소스의 확인 기록이다. 웹 도구가 반환한 페이지는 캐시될 수 있고 main은 이동한다. 모든 항목을 같은 날의 실제 최신 release로 보장하지 않는다. 기업 설치에 사용할 정확한 버전·commit·artifact digest는 G0에서 고정한다.



`source_read`는 실제 소스 본문을 읽었다는 뜻이며 실행·성능·사내 호환성을 증명하지 않는다. 사내 소스·정책·계정은 제공되지 않았고 이 작업에서 열람하지 않았다. 외부 라이브러리/모델을 설치해 비교하는 benchmark도 수행하지 않았다.



기존 대화의 Space 문서는 대화에 포함된 전체 내용과 후속 요구를 사용했다. Space URL을 새로 읽었다고 주장하지 않는다. 별도 연구 내용을 중복 수집하기보다 버전·API·보안 경계의 결정에 영향을 주는 공개 근거를 확인했다.



<a id="s01"></a>

## S01 — QMD README

원문: [QMD README](https://github.com/tobi/qmd/blob/main/README.md)

확인 수준: `official_document_read`

설계 반영: 로컬 하이브리드 검색·SDK·모델 설정·플랫폼 주의사항. 제품 성능 검증은 아님.

남은 검증: 실제 승인 버전·설치 환경·자료 규모에서 동작과 라이선스 의무를 확인한다.



<a id="s02"></a>

## S02 — QMD public SDK source

원문: [QMD public SDK source](https://raw.githubusercontent.com/tobi/qmd/main/src/index.ts)

확인 수준: `source_read`

설계 반영: createStore, searchLex, searchVector, search, update, embed, close. 열람한 SearchOptions에 임의 ACL 조건이 보장되지 않음.

남은 검증: 실제 승인 버전·설치 환경·자료 규모에서 동작과 라이선스 의무를 확인한다.



<a id="s03"></a>

## S03 — QMD inference implementation

원문: [QMD inference implementation](https://raw.githubusercontent.com/tobi/qmd/main/src/llm.ts)

확인 수준: `source_read`

설계 반영: Qwen embedding 질의/문서 포맷, GGUF 모델, stdout 분리, 재정렬 구현. 환경 실행 미검증.

남은 검증: 실제 승인 버전·설치 환경·자료 규모에서 동작과 라이선스 의무를 확인한다.



<a id="s04"></a>

## S04 — QMD MCP implementation

원문: [QMD MCP implementation](https://github.com/tobi/qmd/blob/main/src/mcp/server.ts)

확인 수준: `source_read`

설계 반영: 도구 인터페이스 참고. 제품 provenance/권한/업데이트 계약을 대신하지 않음.

남은 검증: 실제 승인 버전·설치 환경·자료 규모에서 동작과 라이선스 의무를 확인한다.



<a id="s05"></a>

## S05 — Zoekt maintained repository README

원문: [Zoekt maintained repository README](https://github.com/sourcegraph/zoekt/blob/main/README.md)

확인 수준: `official_document_read`

설계 반영: 코드 trigram·부분문자열·정규식 검색과 CLI/서비스 배포. 새 중앙 도입의 운영비 별도.

남은 검증: 실제 승인 버전·설치 환경·자료 규모에서 동작과 라이선스 의무를 확인한다.



<a id="s06"></a>

## S06 — Zoekt design

원문: [Zoekt design](https://github.com/sourcegraph/zoekt/blob/main/doc/design.md)

확인 수준: `official_document_read`

설계 반영: trigram indexing, 다중 저장소/브랜치 설계. 문서의 성능 목표를 본 제품 실측으로 쓰지 않음.

남은 검증: 실제 승인 버전·설치 환경·자료 규모에서 동작과 라이선스 의무를 확인한다.



<a id="s07"></a>

## S07 — ripgrep README

원문: [ripgrep README](https://github.com/BurntSushi/ripgrep)

확인 수준: `official_document_read`

설계 반영: 정규식 파일 탐색, 기본 ignore 동작. 명시적인 tracked-file 범위와 별도 결합 필요.

남은 검증: 실제 승인 버전·설치 환경·자료 규모에서 동작과 라이선스 의무를 확인한다.



<a id="s08"></a>

## S08 — SQLite FTS5

원문: [SQLite FTS5](https://sqlite.org/fts5.html)

확인 수준: `official_document_read`

설계 반영: BM25, unicode61, trigram. 한국어 형태소 분석기로 일반화하지 않음.

남은 검증: 실제 승인 버전·설치 환경·자료 규모에서 동작과 라이선스 의무를 확인한다.



<a id="s09"></a>

## S09 — sqlite-vec README

원문: [sqlite-vec README](https://github.com/asg017/sqlite-vec/blob/main/README.md)

확인 수준: `official_document_read`

설계 반영: 임베디드 벡터 확장, 여러 플랫폼, pre-v1 breaking-change 경고.

남은 검증: 실제 승인 버전·설치 환경·자료 규모에서 동작과 라이선스 의무를 확인한다.



<a id="s10"></a>

## S10 — LanceDB hybrid search

원문: [LanceDB hybrid search](https://docs.lancedb.com/search/hybrid-search)

확인 수준: `official_document_read`

설계 반영: 로컬 저장과 vector/FTS hybrid, TypeScript API. 기업 인증은 별도 책임.

남은 검증: 실제 승인 버전·설치 환경·자료 규모에서 동작과 라이선스 의무를 확인한다.



<a id="s11"></a>

## S11 — pgvector

원문: [pgvector](https://github.com/pgvector/pgvector)

확인 수준: `official_document_read`

설계 반영: 정확/근사 검색, HNSW 필터 후 후보 부족과 iterative scans; tenant 분할 필요 검토.

남은 검증: 실제 승인 버전·설치 환경·자료 규모에서 동작과 라이선스 의무를 확인한다.



<a id="s12"></a>

## S12 — Tree-sitter introduction

원문: [Tree-sitter introduction](https://tree-sitter.github.io/tree-sitter/)

확인 수준: `official_document_read`

설계 반영: 증분 구문 트리. 타입 해석·완전 호출 그래프를 제공한다고 간주하지 않음.

남은 검증: 실제 승인 버전·설치 환경·자료 규모에서 동작과 라이선스 의무를 확인한다.



<a id="s13"></a>

## S13 — SCIP protocol

원문: [SCIP protocol](https://github.com/scip-code/scip)

확인 수준: `official_document_read`

설계 반영: 정의/참조/구현 탐색 프로토콜. 이전 sourcegraph/scip 주소가 리다이렉트됨.

남은 검증: 실제 승인 버전·설치 환경·자료 규모에서 동작과 라이선스 의무를 확인한다.



<a id="s14"></a>

## S14 — LSP specification 3.17

원문: [LSP specification 3.17](https://microsoft.github.io/language-server-protocol/specifications/lsp/3.17/specification/)

확인 수준: `official_document_read`

설계 반영: 언어 서버 기반 navigation 계약. 특정 서버의 지원/실행환경은 검증 필요.

남은 검증: 실제 승인 버전·설치 환경·자료 규모에서 동작과 라이선스 의무를 확인한다.



<a id="s15"></a>

## S15 — GitLab exact code search

원문: [GitLab exact code search](https://docs.gitlab.com/user/search/exact_code_search/)

확인 수준: `official_document_read`

설계 반영: 플랜/인덱스/기능 조건 존재. 실제 사내 설치에서 능력 감지 필요.

남은 검증: 실제 승인 버전·설치 환경·자료 규모에서 동작과 라이선스 의무를 확인한다.



<a id="s16"></a>

## S16 — GitLab search API

원문: [GitLab search API](https://docs.gitlab.com/api/search/)

확인 수준: `official_document_read`

설계 반영: 검색 scope/ref와 결과 근거. 전체 완전성 및 모든 브랜치 지원을 가정하지 않음.

남은 검증: 실제 승인 버전·설치 환경·자료 규모에서 동작과 라이선스 의무를 확인한다.



<a id="s17"></a>

## S17 — GitLab MCP tools

원문: [GitLab MCP tools](https://docs.gitlab.com/user/model_context_protocol/mcp_server_tools/)

확인 수준: `official_document_read`

설계 반영: 버전 조회·GitLab 작업 도구. 현재 조회 페이지 Beta 표기; 이전 대화의 GA 단정은 채택하지 않음.

남은 검증: 실제 승인 버전·설치 환경·자료 규모에서 동작과 라이선스 의무를 확인한다.



<a id="s18"></a>

## S18 — Sourcegraph MCP

원문: [Sourcegraph MCP](https://sourcegraph.com/docs/api/mcp)

확인 수준: `official_document_read`

설계 반영: Enterprise 검색/탐색 연결 및 인증/도구 접근 관리. 기존 도입 시 재사용 후보.

남은 검증: 실제 승인 버전·설치 환경·자료 규모에서 동작과 라이선스 의무를 확인한다.



<a id="s19"></a>

## S19 — Sourcegraph permission syncing

원문: [Sourcegraph permission syncing](https://sourcegraph.com/docs/admin/permissions/syncing)

확인 수준: `official_document_read`

설계 반영: 권한 polling·on-demand 동기화; 원본 권한과 즉시 동일함을 보장하지 않음.

남은 검증: 실제 승인 버전·설치 환경·자료 규모에서 동작과 라이선스 의무를 확인한다.



<a id="s20"></a>

## S20 — Sourcegraph structural search

원문: [Sourcegraph structural search](https://sourcegraph.com/docs/code-search/types/structural)

확인 수준: `official_document_read`

설계 반영: 공식 문서상 기본 비활성·활발히 개발되지 않음. 신규 핵심 의존으로 선정하지 않음.

남은 검증: 실제 승인 버전·설치 환경·자료 규모에서 동작과 라이선스 의무를 확인한다.



<a id="s21"></a>

## S21 — Qwen3-Embedding-0.6B official model card

원문: [Qwen3-Embedding-0.6B official model card](https://huggingface.co/Qwen/Qwen3-Embedding-0.6B)

확인 수준: `official_model_card_read`

설계 반영: 0.6B, 100+ languages, 최대 1024차원, Apache-2.0 표기. 내부 정확도 미측정.

남은 검증: 실제 승인 버전·설치 환경·자료 규모에서 동작과 라이선스 의무를 확인한다.



<a id="s22"></a>

## S22 — Qwen3-Reranker-0.6B official model card

원문: [Qwen3-Reranker-0.6B official model card](https://huggingface.co/Qwen/Qwen3-Reranker-0.6B)

확인 수준: `official_model_card_read`

설계 반영: 작은 reranker 후보, 모델별 입력 포맷/score 재현 검증 필요.

남은 검증: 실제 승인 버전·설치 환경·자료 규모에서 동작과 라이선스 의무를 확인한다.



<a id="s23"></a>

## S23 — BGE-M3 official model card

원문: [BGE-M3 official model card](https://huggingface.co/BAAI/bge-m3)

확인 수준: `official_model_card_read`

설계 반영: 다국어, 1024차원, 8192 길이, dense/sparse/multi-vector; MIT 표기.

남은 검증: 실제 승인 버전·설치 환경·자료 규모에서 동작과 라이선스 의무를 확인한다.



<a id="s24"></a>

## S24 — EmbeddingGemma official model card

원문: [EmbeddingGemma official model card](https://huggingface.co/google/embeddinggemma-300m)

확인 수준: `official_model_card_read`

설계 반영: 300M, 100+ 언어, 코드/기술 문서 포함, 768차원 및 축소. Gemma terms; 영어 전용 단정은 잘못.

남은 검증: 실제 승인 버전·설치 환경·자료 규모에서 동작과 라이선스 의무를 확인한다.



<a id="s25"></a>

## S25 — OMP extensions

원문: [OMP extensions](https://github.com/can1357/oh-my-pi/blob/main/docs/extensions.md)

확인 수준: `official_document_read`

설계 반영: before_agent_start/context/tool hooks; prompt와 revive 등 재진입 조건을 구별해야 함.

남은 검증: 실제 승인 버전·설치 환경·자료 규모에서 동작과 라이선스 의무를 확인한다.



<a id="s26"></a>

## S26 — Agent Skills specification

원문: [Agent Skills specification](https://agentskills.io/specification)

확인 수준: `official_document_read`

설계 반영: SKILL.md 메타데이터/본문 구조. 스킬만으로 자동 실행 또는 권한 강제 보장 안 됨.

남은 검증: 실제 승인 버전·설치 환경·자료 규모에서 동작과 라이선스 의무를 확인한다.



<a id="s27"></a>

## S27 — MCP TypeScript SDK

원문: [MCP TypeScript SDK](https://github.com/modelcontextprotocol/typescript-sdk)

확인 수준: `official_document_read`

설계 반영: 조회 자료는 v2 안정 계열과 v1 분리 안내. 실제 승인 client와 호환 release 고정 필요.

남은 검증: 실제 승인 버전·설치 환경·자료 규모에서 동작과 라이선스 의무를 확인한다.



<a id="s28"></a>

## S28 — MCP transport overview 2026-07-28

원문: [MCP transport overview 2026-07-28](https://modelcontextprotocol.io/specification/2026-07-28/basic/transports)

확인 수준: `official_document_read`

설계 반영: stdio와 Streamable HTTP 경로. 버전별 세부 protocol 계약은 해당 SDK로 처리.

남은 검증: 실제 승인 버전·설치 환경·자료 규모에서 동작과 라이선스 의무를 확인한다.



<a id="s29"></a>

## S29 — MCP security best practices

원문: [MCP security best practices](https://modelcontextprotocol.io/docs/2026-07-28/tutorials/security/security_best_practices)

확인 수준: `official_document_read`

설계 반영: token passthrough, confused deputy, SSRF, state handles, local MCP 보안 경계.

남은 검증: 실제 승인 버전·설치 환경·자료 규모에서 동작과 라이선스 의무를 확인한다.



<a id="s30"></a>

## S30 — Git diff documentation

원문: [Git diff documentation](https://git-scm.com/docs/git-diff)

확인 수준: `official_document_read`

설계 반영: 커밋 간 비교, rename 탐지, NUL-delimited 경로 처리 설계에 사용.

남은 검증: 실제 승인 버전·설치 환경·자료 규모에서 동작과 라이선스 의무를 확인한다.



<a id="s31"></a>

## S31 — Git cat-file documentation

원문: [Git cat-file documentation](https://git-scm.com/docs/git-cat-file)

확인 수준: `official_document_read`

설계 반영: 원본 객체 읽기와 batch 읽기. checkout 정규화와 원본 bytes 구분.

남은 검증: 실제 승인 버전·설치 환경·자료 규모에서 동작과 라이선스 의무를 확인한다.



<a id="s32"></a>

## S32 — SQLite Online Backup API

원문: [SQLite Online Backup API](https://www.sqlite.org/backup.html)

확인 수준: `official_document_read`

설계 반영: 활성 DB의 일관된 사본. WAL 파일 단순 복사 대신 지원 backup 사용.

남은 검증: 실제 승인 버전·설치 환경·자료 규모에서 동작과 라이선스 의무를 확인한다.



<a id="s33"></a>

## S33 — PostgreSQL row security

원문: [PostgreSQL row security](https://www.postgresql.org/docs/current/ddl-rowsecurity.html)

확인 수준: `official_document_read`

설계 반영: RLS default-deny와 owner 예외. service role/owner 분리 및 실제 정책 검증 필요.

남은 검증: 실제 승인 버전·설치 환경·자료 규모에서 동작과 라이선스 의무를 확인한다.



<a id="s34"></a>

## S34 — Jira Cloud issue search

원문: [Jira Cloud issue search](https://developer.atlassian.com/cloud/jira/platform/rest/v3/api-group-issue-search/)

확인 수준: `official_document_read`

설계 반영: Cloud search API 표면. 사내 Data Center 버전과 혼용하지 않음.

남은 검증: 실제 승인 버전·설치 환경·자료 규모에서 동작과 라이선스 의무를 확인한다.



<a id="s35"></a>

## S35 — Jira Data Center REST API

원문: [Jira Data Center REST API](https://developer.atlassian.com/server/jira/platform/rest-apis/)

확인 수준: `official_document_read`

설계 반영: Data Center 별도 REST와 버전별 문서. 실제 배포 버전을 기반으로 사용법 검증.

남은 검증: 실제 승인 버전·설치 환경·자료 규모에서 동작과 라이선스 의무를 확인한다.



<a id="s36"></a>

## S36 — QMD package manifest

원문: [QMD package manifest](https://github.com/tobi/qmd/blob/main/package.json)

확인 수준: `official_manifest_read`

설계 반영: Node/native dependencies/optional platform packages와 MIT 표기. 공개 main을 승인 lockfile로 간주하지 않음.

남은 검증: 실제 승인 버전·설치 환경·자료 규모에서 동작과 라이선스 의무를 확인한다.



## 출처를 설계에 사용하는 규칙



공개 기능 사실은 위 원문을 근거로 하고, 후보 수·시간 목표·인덱스 세대 방식·우선순위·데이터 계약은 이 프로젝트의 설계 결정이다. 공개 benchmark를 사내 측정값으로 복사하지 않는다. OSS의 공개 소스가 있다는 이유만으로 무료 기업 서비스·지원 계약이 있다고 가정하지 않는다.
