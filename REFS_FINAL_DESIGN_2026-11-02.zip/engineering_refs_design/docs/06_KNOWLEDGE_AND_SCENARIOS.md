# 06. 전문 지식·수식·Jira/SSD 시나리오

## 1. 지식은 근거를 가진 주장 단위다

기능 소개와 지식 주장을 분리한다. 지식 레코드는 `statement`, `scope`, `preconditions`, `exceptions`, `evidence_types`, `source_refs`, `contradictions`, `inference_note`, `validity`를 갖는다. 증거 유형은 `docs_declared`, `code_observed`, `test_specified`, `execution_verified`, `policy_normative`, `owner_asserted`, `model_inferred`다. 여러 유형이 동시에 존재할 수 있다. 일렬의 점수로 합치지 않는다.

생성 모델은 먼저 정확한 source ID/range를 선택하고 그 범위에서만 주장 후보를 작성한다. 프로그램은 ID 존재·commit·범위·본문 hash·인용 부분을 검증한다. 의미적 entailment는 별도 문제이므로 문자열 참조 검증 통과를 내용 검증 완료로 부르지 않는다. 고위험·다중 파일·상충 주장만 제한적 추가 확인하고 모든 문장에 모델 3개를 호출하지 않는다.

예외와 negative fact를 보존한다. ‘지원한다’만 저장하면 ‘특정 firmware에서는 비활성’ 같은 중요한 조건을 잃는다. 코드에 재시도 3회가 있다고 회사 정책이 3회라고 일반화하지 않는다. 이미 있는 공식 문서가 현재 유효하다면 규정의 권위는 문서에 두고 코드와의 차이를 별도로 표시한다.

## 2. 수식 카드 계약

수식 카드에는 원문 표현, 코드에서 재구성한 이산식, 일반 이론식과의 연결, 변수·단위, 상태 변수, 초기/경계 조건, timestep/solver, parameter source, 보정 데이터, clamp/분기, 적용 범위, 검증 상태를 둔다. 각 필드에 `known/unknown/inferred`와 근거를 부여한다.

단위가 변수 이름으로 추정된 경우 확정하지 않는다. `temp`를 자동으로 K나 °C로 단정하지 않고 입력 변환·출력 문서·테스트를 찾는다. 온도 차이에는 둘의 수치가 같아도 절대온도 비선형 항에는 같지 않을 수 있으므로 맥락을 확인한다. floating-point·fixed-point·scaling·saturation을 ‘예쁜 수식’으로 정리하면서 삭제하지 않는다.

## 3. 시나리오 A: Jira 전체 탐색

사용자: ‘사내에서 Jira API 쓰는 프로젝트 전부 찾아줘. 이슈 조건별 대시보드를 만들고 싶어.’

### 처리 흐름

- 현재 허용 inventory/ref snapshot과 마지막 update 시각을 고정한다. 최신 Git 변경 확인을 요청한 경우 먼저 update하고, 단순 조회에서는 인덱스 시점을 숨기지 않는다.
- `breadth=all`, `depth=verified`, intent는 `find_references + reuse_design`로 설정한다.
- detector pack이 Jira 단어, REST route, JQL, SDK 의존성, host aliases, wrapper reference, issue field 소비 코드를 검사한다. 미확정 host는 보조 신호다.
- 결과를 `confirmed_direct`, `confirmed_wrapper`, `dependency_only`, `docs_only`, `test_only`, `unresolved`로 분류한다.
- 실제 호출의 operation, authentication adapter, JQL construction, pagination, requested fields, retry/rate-limit 처리, tenant/project scope를 source 단위로 확인한다.
- dashboard 프로젝트는 API client 자산과 UI/집계 자산을 구분한다. 한 repo가 여러 종류를 제공할 수 있다.
- 전체 목록을 제공한 뒤 현재 목적에 필요한 조합을 1~3개로 추천한다. 추천 정렬 때문에 전체 목록이 없어지지 않는다.

### 기대 출력 형태 — 실제 결과가 아닌 템플릿

| 항목 | 값 |
|---|---|
| 검색 범위 | 실제 manifest에 포함된 repo/ref/commit 요약 |
| Jira 사용 확정 | 직접 호출과 wrapper별 repo 수·전체 목록 |
| 미확정 | dependencies/docs-only, 해석 못한 runtime 경로 |
| 조회 기능 | 검색/JQL/issue detail/fields/pagination의 evidence |
| 대시보드 활용 | 집계 data contract, 필터·refresh·캐시 참조 |
| 바로 사용 | 현재 identity/environment의 검증 상태가 있는 recipe |
| 드릴다운 | 각 호출의 source/definition/references/tests/usage |

Cloud와 Data Center API·인증·페이지네이션을 혼용하지 않는다. 공개 문서가 서로 다른 API 표면을 제공하므로 실제 사내 설치 종류·버전에 맞는 계약을 읽는다. 과거 REST 경로나 샘플 JQL을 곧바로 현재 호출에 쓰지 않는다. [S34](14_SOURCE_ATLAS.md#s34) · [S35](14_SOURCE_ATLAS.md#s35)

사용자: ‘이걸로 내 조건의 이슈를 조회해줘.’ → `prepare_use`가 기존 tool ID, 환경, 현재 credential binding, 구체 입력·예상 영향과 확인 방법을 만들고 하네스가 실행한다. 조회 결과에 접근 가능한 프로젝트/이슈만 반환되었는지 확인한다. 성공은 해당 조회 operation의 영수증이지 전체 API의 보안 인증이 아니다.

## 4. 시나리오 B: SSD 열 모델과 수식

사용자: ‘사내 SSD 열역학 시뮬레이션 코드 있어? 어떤 수식이야?’

프로젝트 이름에 SSD가 없더라도 power/temperature/thermal node/conductance/capacitance/heat flux·device parameter·시간 적분 함수를 함께 탐색한다. 이름만 비슷한 모니터링 대시보드, throttle threshold 코드, 실제 열 시뮬레이터를 구분한다. 후보의 계산 entrypoint에서 parameter loading·단위 변환·step loop·solver·validation을 연결한다.

### 합성 fixture로 설명하는 드릴다운

패키지의 `examples/fixtures/thermal_model.py`는 제품 설계 검사를 위해 새로 만든 **한 노드 교육용 코드**다. 실제 SSD 모델이나 사내 발견물로 해석하면 안 된다. 다음 계산을 구현한다.

`T_next = T + dt / C * (P - (T - T_ambient) / R)`

이 코드로부터 재구성한 식은

\[
T_{n+1}=T_n+\frac{\Delta t}{C}\left[P_n-\frac{T_n-T_a}{R}\right].
\]

코드에서 관찰되는 것은 이산 업데이트다. 상수 R,C와 lumped single node 가정 아래 연결할 수 있는 연속식은

\[
C\frac{dT}{dt}=P(t)-\frac{T-T_a}{R}.
\]

일반 모델 지식을 그대로 사내 코드의 식이라고 답하지 않는다. 다중 노드 코드라면 실제 상태 vector·conductance matrix·node coupling을 확인해야 한다. dt/R/C의 관계와 Euler 수치 안정성은 코드의 parameter 범위에서 별도로 검토한다. fixture의 안정성 조건 `0 < dt < 2RC`는 오차 증폭 인자 `1-dt/(RC)`의 절댓값이 1보다 작다는 대수적 결과다. 이는 실제 SSD 모델 검증이 아니다.

### 출력에 필요한 내용

실제 노드 수, 입력 power profile, R/C 단위와 값 출처, ambient boundary, integration scheme, clamp·nonlinear term, calibration data, 테스트 존재·실행 여부, 실측 오차가 확인됐는지 제시한다. 보정 데이터가 없으면 정확도를 숫자로 상상하지 않는다.

‘사용해 볼 수 있습니다’의 예는 실제 entrypoint와 input 계약을 읽은 뒤 생성한다. 지원하는 입력이 일정 전력뿐이면 임의 waveform 입력 기능이 있다고 하지 않는다. 사용자가 5W→10W 시뮬레이션을 요청하면 먼저 입력 지원·parameters·환경을 확인하고 승인된 실행 도구로 실제 결과를 만든다. 미실행 상태에서 가상의 그래프를 실제 시뮬레이션처럼 제시하지 않는다.

## 5. 설명은 단계적으로, 지식은 재사용 가능하게

첫 답변은 후보와 핵심 수식·제약만 제시한다. ‘NAND와 컨트롤러 온도를 따로 계산해?’라는 후속 질문은 같은 snapshot의 state vector와 coupling code로 내려간다. 분석에서 새로 알게 된 사실은 source set과 함께 후보로 저장한다. 모델이 만든 답변을 다시 근거로 삼아 인덱스를 자기 강화하지 않는다.
