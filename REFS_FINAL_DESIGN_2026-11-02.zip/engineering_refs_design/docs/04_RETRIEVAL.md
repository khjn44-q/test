# 04. 빠름·정확함·깊이·전체성을 함께 갖춘 검색

## 1. 두 축으로 모델링한다

`depth = fast | verified | deep`, `breadth = ranked | all`이다. 사용자 친화 별칭 FAST/PRECISE/DEEP/EXHAUSTIVE는 유지하지만 내부에서 네 종류의 검색 엔진을 만들지 않는다.

| 요청 | 깊이·범위 | 동작 |
|---|---|---|
| ‘관련 코드 있어?’ | fast + ranked | 인덱스 후보, 짧은 근거, 추가 탐색 가능 부분 |
| ‘실제로 어디서 호출해?’ | verified + ranked | 실제 source·symbol·호출부 확인 |
| ‘수식/구현 차이를 자세히’ | deep + ranked | 필요한 계산 경로와 전제·테스트·설정 분석 |
| ‘모든 Jira 사용 프로젝트’ | verified + all | 전체 manifest의 증거 검출과 판정, 전체 결과 페이지화 |
| ‘모든 구현의 수식 비교’ | deep + all | 전수 후보 수집 후 모든 판정 대상의 깊은 비교 |

사용자가 이미 깊은 조사나 전체 조사를 요청했으면 FAST만 주고 다시 허락을 묻지 않는다. 빠른 중간 결과를 제공하면서 요청된 수준까지 수행한다. 단순 질문에는 가능한 후속 행동을 한 문장으로 제시한다.

## 2. 후보 생성

프로젝트/기능/지식/원문의 네 경로를 같은 허용 scope에서 검색한다. 프로젝트 상위 결과를 다른 경로의 hard filter로 쓰지 않는다. exact identifier 경로는 별도로 둔다. 예산은 초기 설정이며 환경별 측정으로 조정한다.

- query embedding은 동일 텍스트에 한 번 계산하고 가능한 경로에서 재사용한다. provider가 재사용을 공개 지원하지 않으면 내부 접근으로 억지 구현하지 말고 호출 수를 기록한다.
- 한국어 원문을 유지하고 camelCase/snake_case 분해·등록 별칭·업무 약칭을 보조로 사용한다. 영어 번역을 유일한 검색문으로 사용하지 않는다.
- 기본은 LLM query expansion 없이 시작한다. 낮은 hit·낮은 근거·사용자 표현 불일치에서 최대 두 번의 추가 표현을 생성한다. 생성된 HyDE 텍스트는 검색 힌트이지 근거가 아니다.
- lane별 lexical 20, dense 20을 초기 후보량으로 삼고 전체 중복 제거 뒤 최대 80개를 비교한다. verified는 24개, deep는 필요 시 40개 이내의 rerank 후보로 시작한다.
- 특정 identifier가 정확히 일치한 결과는 별도 exact-hit bucket으로 보존한다. fuzzy similarity가 더 높다는 이유로 없애지 않는다.

QMD `search({queries, rerank:false})`, `searchLex`, `searchVector` 등 공개 제어점을 활용한다. 본 제품이 외부 RRF를 적용할 때 provider 내부에서 이미 fusion된 순위와 원래 lane 순위를 이중 합산하지 않는다. provider가 원시 lane을 주지 못하면 그 결과를 단일 lane으로 취급한다. [S02](14_SOURCE_ATLAS.md#s02)

## 3. 순위 결합과 다양성

기본 결합은 weighted RRF다.

`score(d) = Σ_l w_l / (60 + rank_l(d))`, rank는 1부터 시작한다.

초기 lane weight는 모두 1로 두고, 동일 문서가 같은 lane에서 중복 나오면 한 번만 계산한다. lexical score, cosine distance, reranker score를 단위 정규화 없이 숫자 덧셈하지 않는다. 보조 메타데이터는 deprecated/환경 불일치 설명이나 동점 정렬에 쓰고 진짜 관련 결과를 소거하는 강제 규칙으로 남용하지 않는다.

같은 복제 코드·fork 결과를 군집화해 상위 추천의 중복을 줄인다. **추천 화면**에서는 repo당 최대 2개를 기본으로 보여 주지만, 전체 조사에서는 모든 repo occurrence를 보존한다. dedup은 증거 소실이나 사용 프로젝트 수 축소를 뜻하지 않는다. 동일 함수라도 서로 다른 버전/사용 조건이면 분리한다.

LLM 재정렬 전에는 사용자와 모델 처리 정책으로 허용된 내용만 남긴다. 재정렬 실패/timeout은 원래 fusion 순위로 명시적 fallback하고 `rerank_applied:false`를 기록한다. 미지원 reranker artifact를 조용히 다른 모델로 대체하지 않는다.

## 4. 원문 검증

verified 모드는 각 주장의 핵심 SourceRef를 읽어 commit/blob/hash/range를 검증한다. 문서의 설명과 코드의 현재 구현을 구분한다. 테스트 파일 존재와 테스트 실행 성공은 다른 evidence다. source read가 실패한 후보는 `candidate_unverified`로 남기고 확정 구현처럼 표현하지 않는다.

모델에게 전체 저장소를 한 번에 보내지 않는다. 첫 context pack은 진입점/입출력/인증/주요 설정/대표 테스트이며, 추가 질문에 따라 호출·데이터 경로를 확장한다. 답변에는 확인한 경로, 사용 제약, 미해결 부분을 남긴다.

## 5. 전체 탐색은 top-k 검색이 아니다

`breadth=all`은 inventory snapshot에 있는 모든 허용 저장소의 manifest를 대상으로 한다. lexical 패턴·manifest dependency·심볼·import·설정값·wrapper 관계를 조합한 detector pack을 사용한다. dense 검색은 추가 후보를 보완하지만 전수성 판정의 분모가 아니다.

Jira detector 예: 제품명/host alias, REST 경로, SDK import, JQL 문자열 생성, 검색 함수 wrapper, 관련 설정의 실제 소비 코드. README에 단어만 있는 것, lockfile만 있는 것, 사용되지 않는 예제, mock-only 결과는 별도 class다. 프로젝트를 ‘실제 Jira 사용’으로 확정하려면 실제 호출 또는 해석된 wrapper 경로의 근거를 요구한다. runtime 문자열 조합/외부 gateway는 미해결 범위를 남긴다.

scanner는 결과 상한으로 중단하지 않는다. 사용자에게는 top summary와 전체 목록의 cursor를 주고 전체 occurrence는 artifact/JSON으로 보존한다. 중단 시 `PARTIAL`, 현재 checkpoint와 남은 repo를 반환한다. 실제 권한 밖 저장소의 이름/개수는 노출하지 않는다.

## 6. coverage는 다차원이다

`eligible_repositories`, `scanned_repositories`, `eligible_files`, `scanned_files`, `eligible_bytes`, `scanned_bytes`, `parser_supported_units`, `vectorized_units`, `judged_candidates`, `unresolved_candidates`를 따로 기록한다. 파일 수 100%가 의미상 모든 기능 발견 100%를 뜻하지 않는다.

결론 문구 예: ‘허용된 24개 저장소의 지정 ref에서 적격 텍스트 18,200개를 검사했습니다. 7개 repo에서 코드 근거를 확인했고 2개 wrapper 경로는 해석을 완료하지 못했습니다. 다른 브랜치·LFS 내용은 포함하지 않았습니다.’ 숫자는 실제 run에서만 채운다.

`scope_scan_complete`는 검사가 끝났다는 뜻이고 `semantic_completeness`는 원칙적으로 `not_proven`이다. 고정된 합성 평가 fixture에서만 알려진 정답 전부를 찾았다고 검증한다. 무제한 완전성을 약속하지 않는다.

## 7. 세션 연속성

session은 목적·제약, scope manifest, 발견한 asset/evidence, 검증된 관계, 읽은 source hash, 선택 후보, 미해결 질문, 사용 예산을 보존한다. ‘두 번째 프로젝트’는 결과 ordinal만이 아니라 해당 turn의 asset ID mapping으로 해석한다.

인덱스가 업데이트되어도 기존 session의 evidence를 몰래 최신 코드로 바꾸지 않는다. 최신 정보가 필요하면 old/new manifest delta를 보여 주고 바뀐 부분만 다시 읽는다. 전체 generation 번호가 바뀌었다고 관련 없는 작업까지 무조건 재검색하지 않는다. 관련 repo/module/schema/policy footprint가 바뀌었는지 확인한다.

## 8. 실패 상태

`NO_MATCH_IN_SCOPE`, `PARTIAL_COVERAGE`, `STALE_INDEX`, `SOURCE_UNAVAILABLE`, `AUTH_REQUIRED`, `ACCESS_DENIED`, `MODEL_UNAVAILABLE`, `BUDGET_EXHAUSTED`, `GENERATION_EXPIRED`를 구분한다. 접근할 수 없는 자산의 존재를 알려 주는 error detail은 반환하지 않는다. 모델 실행 불가 시 lexical-only 결과를 줄 수 있지만 semantic search를 수행했다고 표시하지 않는다.
