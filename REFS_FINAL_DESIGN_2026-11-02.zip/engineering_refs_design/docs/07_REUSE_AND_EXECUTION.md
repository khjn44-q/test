# 07. API 직접 사용·SDK·코드 재사용

## 1. 재사용의 의사결정

기존 서비스 호출, 공용 package 의존, wrapper/adapter, upstream 기여, 부분 코드 복사, fork, pattern reference, 신규 구현을 비교한다. ‘기존이 있으므로 무조건 사용’도 ‘조금 다르니 처음부터 새로’도 기본값이 아니다. 사용자 목적·runtime·결합도·업데이트 책임·실제 지원 상태를 비교한다.

사용자가 사내 오픈소스 재사용을 원한다고 명확히 말했다. 그러므로 합당한 내부 사용 조건에서 참고·수정·복사를 적극적으로 설계한다. 매번 추상적인 허가를 다시 묻지 않는다. 다만 API 인증, 대상 데이터, 운영 변경은 코드 열람과 구별된다. 실제 고지/조건이 있으면 source attribution에 보존하고 법적 판단을 AI가 만들어내지 않는다.

## 2. Recipe의 필수 필드

- `asset_version_id`, `recipe_id`, `recipe_revision`.
- `kind`: api/mcp/sdk/cli/source/template.
- `entrypoint`: 등록 tool binding 또는 package/export, 일반 임의 shell 문자열 아님.
- `input_schema`, `output_contract`, 최소 example 입력.
- `version_constraints`, `runtime_constraints`, `network_constraints`.
- `credential_ref`, `required_permissions`: 비밀 자체는 저장하지 않는다.
- `preconditions`, `side_effects`, `data_scope`.
- `setup_steps`, `verification_steps`, `rollback_or_cleanup` 필요한 경우.
- `evidence_ids`, `execution_receipts`, `known_limitations`.

CLI 실행은 문자열을 shell로 넘기기보다 허용 executable과 argv 배열로 구성한다. SDK 설치 과정의 lifecycle script도 실행이므로 정적 코드 열람과 다르게 처리한다. API 주소는 등록 binding에서 resolve하며 검색 문서의 URL을 무조건 호출하지 않는다.

## 3. 상태는 독립적으로 계산한다

기능 존재 `found`, 현재 적합성 `fit`, 준비 `ready/needs_setup/needs_verification/reference_only/unavailable`, 지원 상태 `active/deprecated/unknown`, 실제 실행 `not_run/passed/failed`를 분리한다. 오래됐지만 안정적인 공용 SDK를 단순 commit recency만으로 탈락시키지 않는다.

`ready`는 현재 principal·환경·operation·version·입력 유형의 전제 충족 상태다. ‘모든 입력에서 동작’, ‘모든 endpoint 안전’, ‘전사 승인’이라는 의미가 아니다. timeout이나 rate-limit 실패는 권한 실패와 구분한다. 성공 테스트가 만료되거나 서비스 schema가 바뀌면 해당 readiness만 무효화한다.

## 4. prepare → execute → receipt

`prepare_use`는 읽기·계획 작업이다. 실제 execution bridge가 동작하는 주체, target, input digest, effects, policy decision을 고정한 plan ID를 발급한다. 사용자 의도가 이미 이 operation을 포함하면 중복 승인을 요구하지 않는다. 새 운영 write나 범위 확대는 그 구체 효과에 대한 기존 하네스의 승인 경로를 따른다.

계획과 실행 사이에 version·identity·parameters·effects가 변하면 plan을 재검증한다. 반복 요청은 plan/operation별 idempotency 가능 여부에 따라 처리한다. read 요청에도 서버의 quota·개인정보 처리가 영향을 받으므로 예상 부하와 scope를 제한한다.

실행 결과 영수증에는 실제 tool ID/version, repo/package/service version, environment ID, parameter digest, 시작/종료 시각, exit/result status, 검증 결과를 기록한다. payload 전체를 기본 로그에 저장하지 않는다. 재시도 가능한 오류와 재시도 시 중복 부작용이 발생하는 오류를 구분한다.

## 5. 코드 재사용 인수인계

부분 코드를 가져오는 결과에는 원본 commit·path·symbol, 새 위치, 보존한 동작, 변경한 가정, 필요한 의존성, 가져온/추가할 테스트, 원본 업데이트 추적 책임을 포함한다. 이 정보를 `reuse-manifest.json`으로 남길 수 있다. 원본 함수가 호출하는 private helper·config·data schema를 빠뜨리지 않는다. 단순 복사량이나 적은 줄 수를 재사용 품질로 보지 않는다.

## 6. 범용 실행기를 만들지 않는 이유

REFS는 무엇을 쓰면 되는지와 그 근거를 제공하는 제품이다. 기존 하네스가 Git checkout·코드 편집·검사·API 호출을 할 수 있다면 이 능력을 복제하지 않는다. 검색 MCP에 임의 명령 실행, 자동 MCP 설치, 토큰 전달 프록시를 한꺼번에 추가하지 않는다. MCP 보안 지침은 토큰 passthrough·confused deputy·SSRF 같은 경계를 별도로 다룬다. [S29](14_SOURCE_ATLAS.md#s29)
