# 09. 사내 제약·권한·비밀·위협 모델

## 1. 위협 경계

소스 작성자, 저장소 README, 검색 결과, 모델 응답은 실행 정책의 권위가 아니다. 신뢰된 입력은 사용자 요청, 조직 정책 설정, 인증된 사용자 신원, 승인된 provider binding이다. Git 열람 권한·인덱싱/보관 허용·모델 처리 허용·자산 실행 권한을 구분한다.

| 위험 | 기본 통제 | 검증 |
|---|---|---|
| source에 숨은 prompt injection | 데이터로 제공, system 지침 승격 금지, 권한 판단은 코드 | 악성 README·주석 fixture |
| repo path/URL을 통한 임의 읽기 | 등록 repo/source ID만 resolve, path traversal·redirect 제한 | ../, symlink, host redirect 테스트 |
| credential 유출 | OS credential helper/secret reference, payload·로그 redaction | 토큰 모양 값이 로그/검색에 없는지 검사 |
| ACL 회수 후 캐시 노출 | 정책 epoch와 출력 직전 확인, deny 우선 | 모든 generation/cache/session 회수 테스트 |
| 모델로 사내 자료 반출 | embedding/rerank/LLM 각각 승인 경로, 자동 외부 fallback 금지 | 네트워크 차단 smoke |
| 무분별한 코드 실행 | static read 기본, 실행은 기존 하네스와 작업 권한 | package hook·MCP config 미실행 확인 |
| 악성 source parser | file size/time/memory 제한, 필요시 sandbox worker | 거대 파일·잘못된 AST 입력 |
| updater 동시성/전원 중단 | single writer, staging/READY/pointer, resume journal | kill/fault injection |
| 조합 지식의 권한 혼합 | source all-of ACL, 독립 표현 분리 | A-only 사용자에게 A+B 요약 미노출 |

## 2. 개인형의 실제 한계

개인 PC에는 본인이 읽을 수 있는 데이터가 캐시된다. 같은 OS 사용자에게 이미 전달된 파일의 암호학적 회수를 검색 프로그램이 보장할 수 없다. 따라서 ‘권한 철회 즉시 모든 개인 복제본을 완전히 삭제’ 같은 약속은 하지 않는다. 프로그램은 인지한 회수를 이후 결과에서 차단하고 승인된 보존 정책에 따라 cache를 정리한다.

offline 모드는 조직이 승인한 자료·기간에 한해서만 쓴다. 권한 cache TTL은 정책으로 정하고, 온라인 확인이 의무인데 실패하면 private 결과를 fail-closed 처리한다. 원격 권한을 확인할 수 없다는 이유로 이전 권한을 영구 사용하지 않는다. 동시에 개인형에 전사 SSO 제품 전체를 새로 만들지는 않는다.

## 3. 중앙형의 ACL

인증된 principal을 server가 확정하고 repo/source 필터를 생성한다. 사용자가 전달한 scope는 축소 조건일 뿐이다. 중앙 수집용 서비스 계정이 볼 수 있는 모든 자료를 사용자가 볼 수 있는 것으로 취급하지 않는다. repository 필터를 적용한 후보만 외부 reranker와 생성 모델로 보낸다. trusted retrieval 내부의 후보 계산과 사용자/모델에 노출되는 경계를 구분한다.

PostgreSQL RLS를 사용할 때 service role이 table owner/superuser/BYPASSRLS로 동작하지 않는지 검사한다. RLS를 켰다는 사실만으로 모든 조회가 안전해지는 것은 아니다. ANN 필터가 후보를 줄여 recall을 악화시키면 iterative search·보안 영역 분할·작은 scope exact search를 사용한다. 권한 검사 없이 overfetch한 결과를 모델이 거르게 하지 않는다. [S11](14_SOURCE_ATLAS.md#s11) · [S33](14_SOURCE_ATLAS.md#s33)

## 4. 인덱스 공유

팀 전체가 정확히 같은 자료 접근·보관 조건을 갖는다는 확인 없이 개인의 QMD/SQLite 파일을 공용 폴더에 배포하지 않는다. 공유 스냅샷은 recipient group, source snapshot, policy domain, model fingerprint, digest, signature, expiry를 포함한 manifest로 배포한다. snapshot은 수신된 순간의 허용 복제이므로 이후 회수가 중요한 자료는 중앙 조회형으로 남기는 편이 맞다.

공유 파일시스템의 같은 SQLite를 여러 PC가 writer로 열도록 하지 않는다. 앱 binary/skill 배포와 data/index 배포는 별개의 절차다.

## 5. 라이선스·공급망

OSS 코드와 모델 weights의 조건은 별도로 기록한다. model card의 license label은 시작 정보이지 회사 승인 자체가 아니다. 설치 시 승인한 release/commit/package digest/model digest/grammar version을 기록하고, runtime의 `npx latest`나 모델 자동 다운로드를 기본 금지한다. 연결 도구는 사내 CA/proxy를 정상 설정하고 TLS 검증을 끄는 방식으로 우회하지 않는다.

## 6. 로그와 측정

기본 이벤트: request/job ID, anonymized principal key, manifest ID, stage timing, counts, error category, cache hit. 코드·질의 원문·JQL·사용자 데이터·token은 기본 로그에 남기지 않는다. 디버그 모드는 기간·접근자를 제한하고 삭제 절차를 둔다. external telemetry는 off다. 검색 품질 feedback도 접근 제한이 있는 데이터로 취급한다.
