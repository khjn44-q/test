# 11. 성능·정확도·비용·평가 설계

## 1. 잘못된 지표를 쓰지 않는다

`Hit@5`는 질문의 알려진 정답 중 하나 이상이 상위 5개에 나타난 비율이다. `Recall@k`는 질문별 알려진 모든 정답 중 상위 k에 포함된 비율이다. 정답 20개인 질문에서 Recall@5의 최대치는 25%이므로 같은 90% 목표를 적용할 수 없다. navigation, implementation detail, broad discovery, formula understanding, reuse planning을 다른 task로 평가한다.

근거 링크가 열리는 비율과 그 원문이 주장을 실제로 뒷받침하는 비율도 구분한다. 수식/단위/분기 정확성, ‘전부’ 요청의 repo-level·callsite-level 누락, API recipe의 실제 실행 결과는 별도 지표다.

## 2. 목표 — 실측 결과가 아니다

| 계층 | 초기 acceptance 목표 | 조건 |
|---|---|---|
| FAST 검색 payload | warm p95 ≤ 2s | 고정 평가 corpus/장비, 모델 로딩 제외, 로딩 지표 별도 |
| verified 후보+제한 rerank | warm p95 ≤ 8s | 모델 답변 문장 생성·깊은 분석/원격 인증 대기는 별도 |
| 원문 read | local cache p95 ≤ 300ms | 실제 Git object/hash/range 검증 포함, 최초 원격 fetch 제외 |
| 탐색형 Hit@5 | ≥ 0.90 | 독립적인 탐색 질문, macro 평균과 개별 실패 목록 |
| 복수 정답 Recall@20 | ≥ 0.85 | 알려진 정답 수/판정 규칙을 공개한 평가셋 |
| claim 원문 연결 | 핵심 확인 주장 100% | inference는 표시, 없는 ID 생성 0 |
| evidence entailment | 검토한 핵심 주장 ≥ 0.95 | 평가자가 scope/조건/예외까지 판정 |
| 전체 검색 | synthetic known-gold 100%; 사내는 측정 recall+coverage | 의미상 전사 100% 보장 없음 |
| 업데이트 | unchanged source vector 재계산 0 | model/prompt fingerprint가 동일한 경우 |
| 안전 | 지정 regression 시나리오 유출·무단 실행 0 | 절대적 무결점 보장과 구분 |

성능·품질 미달 시 목표를 조용히 낮추지 않는다. 장비/데이터 범위와 원인을 기록하고 profile 변경 또는 명시적 예외 승인을 남긴다. 실제 측정이 없으므로 이 문서는 목표를 제시할 뿐 달성했다고 주장하지 않는다.

## 3. 두 단계 평가셋

초기 20~30개 질문으로 wiring/실패 유형을 찾고, release 전에 60~120개 이상 독립 질문으로 확인한다. 임의 개수 채우기가 아니라 실제 Jira/API·SSD/수식·작은 유틸리티·반례·없음·stale·권한·업데이트를 포함한다. tuning/holdout을 repo·질문 의도별로 나눠 거의 같은 질문의 표현만 바꿔 leakage를 만들지 않는다.

사내 실제 지식으로 gold를 만들 때 코드 위치/올바른 범위/허용 답변/오답 조건을 기록한다. 정답을 모르는 질문에서 top 결과가 그럴듯하다는 이유로 정확도 점수를 주지 않는다. `../examples/evaluation_cases.json`은 시작용 시나리오이며 실행된 실제 retrieval benchmark가 아니다.

## 4. 비교 실험

A lexical+identifier, B A+요약 dense, C B+원문 dense, D C+제한 rerank를 동일 corpus/질문/장비에서 비교한다. 각 단계의 증가 비용과 Hit/Recall/evidence precision 이득을 본다. 답변 생성 모델은 고정해 retrieval 개선을 분리한다.

Qwen3-0.6B, EmbeddingGemma-300M, BGE-M3는 같은 query/doc 규약을 억지로 공유하지 않고 각 모델의 공식 prompt/pooling/normalization을 사용한다. 출력 차원 축소·양자화·runtime을 바꾸면 별도 실험이다. 모델끼리 벡터 공간을 섞지 않는다. 대형/코드 특화 모델은 작은 모델의 명확한 실패를 개선할 때만 후속 후보로 둔다. [S21](14_SOURCE_ATLAS.md#s21) · [S22](14_SOURCE_ATLAS.md#s22) · [S23](14_SOURCE_ATLAS.md#s23) · [S24](14_SOURCE_ATLAS.md#s24)

## 5. instrumentation

각 요청에 `auth_ms`, `query_embed_ms`, `lexical_ms`, `dense_ms`, `fusion_ms`, `rerank_ms`, `source_read_ms`, `model_answer_ms`, `total_ms`, input/output tokens, candidate counts, cache hits를 기록한다. `total`에 포함한 범위를 명시하고 percentile 계산의 표본 수·cold/warm·concurrency를 함께 보고한다. 결과가 빨라 보이게 실패/timeout을 percentile에서 제거하지 않는다.

프로세스 CPU/RSS/peak memory, GPU resident memory, disk size, update copy bytes, source read bytes, vector count, reembedded/reused count, queue wait를 측정한다. 실무 PC에서는 사용자의 편집/빌드와 자원 경쟁도 보아야 한다.

## 6. 비용 모델

vector raw bytes = `N × dimensions × bytes_per_element`다. 100,000개 × 1024차원 × float32 4bytes = 409,600,000bytes, 약 390.6MiB다. 본문/FTS/metadata/cache/model/generation 사본이 추가되므로 전체 요구 RAM·disk로 오해하지 않는다.

초기 시간은 실제 embed throughput `r chunks/s`로 `N/r`를 계산하고, source fetch/parse/LLM extraction/DB I/O를 따로 더한다. 이 설계에서는 측정된 r이 없으므로 ‘몇 분이면 전사 인덱싱’ 같은 수치를 제시하지 않는다. 생성 모델 비용은 실제 읽은 tokens×단가이며 회사 모델/계약에 따라 달라진다.

개발 단계부터 모든 code unit에 LLM summary를 생성하면 비용이 커진다. 전체 code embedding과 selective semantic extraction을 분리하고, 실제 반복 질의에서 이득이 있는 자료만 별도 해설 카드로 승격한다.

## 7. 최적화와 중단 규칙

FAST는 LLM expansion/재정렬 없이 exact+hybrid first다. verified는 근거가 불명확한 상위 후보에 비용을 쓴다. deep는 미해결 질문별로 자료를 확장한다. 전체 탐색은 bounded pagination과 checkpoint를 쓰며 budget 초과 시 partial을 반환한다. ‘충분히 고민했다’가 아니라 필요한 근거/질문이 해결됐는지로 종료한다.

pilot에서 동일 실패가 반복되고 새 backend/graph/model이 그 실패를 개선할 근거가 있을 때만 확대한다. 개선폭·비용·회귀 위험을 ADR에 기록한다. 테스트 수, 코드량, 모델 호출량을 진척 지표로 사용하지 않는다.
