# 05. 원문 드릴다운과 근거 그래프

## 1. 제품 불변조건

**확인된 사실로 말하는 핵심 주장에는 하나 이상의 원문 Evidence ID가 있어야 한다.** 모델의 해석에는 `model_inferred` 표시와 그 해석에 사용한 원문을 붙인다. 원문은 해당 시점의 commit/blob를 가리킨다. 최신 브랜치 링크는 편의 이동일 뿐 이전 주장의 증거를 대신하지 않는다.

‘항상 드릴다운’은 각 사실의 근거 경로가 누락되지 않음을 의미한다. 삭제된 저장소, 권한 회수, 보존 기간 만료, 원격 객체 GC에서는 원문을 열 수 없을 수 있다. 이때 `revoked/missing/expired`를 반환하고 다른 코드를 대신 보여 주지 않는다.

## 2. 탐색 계약

`refs inspect <asset> --view summary|code|knowledge|usage|tests`

`refs evidence <evidence-id> --context-lines 12`

`refs trace <symbol-version-id> --relation references|calls|tested_by --direction in|out --depth 1`

`refs compare <asset-version-a> <asset-version-b>`

네 명령은 같은 기계 계약을 CLI와 MCP로 제공한다. 참조 목록에는 resolver와 coverage를 함께 반환한다. 최대 깊이/노드 수를 지정하고 cycle을 감지한다. 한 번에 모든 관계를 그래프 그림으로 늘어놓지 않는다.

## 3. 원문을 읽는 절차

1. Evidence ID를 서버 카탈로그에서 resolve한다. 호출자가 보낸 임의 파일 경로/URL을 곧바로 읽지 않는다.
2. 현재 read/AI-processing 정책을 확인한다.
3. session이 고정한 commit/blob를 가져온다. Git 객체 캐시를 우선하되 hash를 검증한다.
4. 범위를 적용하기 전에 원문 bytes/encoding/line map을 확인한다.
5. 요청한 범위와 제한된 주변 문맥을 반환한다. truncated 여부와 next range를 포함한다.
6. Git 호스트의 커밋 permalink, local logical source URI, source version을 제공한다. 경로를 URL encode한다.

정의/참조가 추정이면 ‘참조 후보’라고 표현한다. 이전 코드 범위가 달라졌을 때 원문 span 검증을 생략하지 않는다. `git cat-file`의 객체/batch read는 checkout보다 원문 bytes 보존에 적합한 기반이다. [S31](14_SOURCE_ATLAS.md#s31)

## 4. 수식과 코드의 연결

수식은 하나의 code range에 항상 들어 있지 않다. 초기조건 파일, 시간 간격 설정, 계산 함수, 단위 변환, saturation/clamp 코드, 학습 파라미터가 여러 곳에 흩어질 수 있다. `formula.realized_by[]`, `parameter.defined_by[]`, `assumption.supported_by[]`, `validation.receipts[]`를 별도 연결한다.

`equation_form`은 `verbatim_document`, `symbolic_reconstruction`, `descriptive_approximation`으로 구분한다. LaTeX가 잘 만들어졌다는 이유로 검증된 방정식이 되지 않는다. 재구성에는 입력변수/제어분기/단위 변환과 적용 범위를 함께 기재한다.

## 5. 지식 관계의 품질

관계가 있다는 주장도 근거가 필요하다. 단순한 파일명 유사도는 테스트 연결 후보다. SCIP에 정확한 reference occurrence가 있으면 `type_resolved`로 올릴 수 있지만 런타임에서 모든 분기가 실행됨을 뜻하지 않는다. SCIP는 정의·참조·구현 navigation을 위한 공개 프로토콜이며 특정 언어 인덱서의 완전성을 보장하는 형식은 아니다. [S13](14_SOURCE_ATLAS.md#s13)

관계 테이블에 traversal용 인덱스 `(from_id,type)`와 `(to_id,type)`를 둔다. 첫 버전은 SQL recursive traversal 또는 제한 BFS로 충분하다. 실제 다중-hop 질의가 병목으로 측정되기 전에는 graph DB를 도입하지 않는다.

## 6. 답변의 최소 구성

‘프로젝트 X에 열 계산 모델이 있습니다’에는 asset, source, commit을 붙인다. ‘NAND/컨트롤러를 분리합니다’에는 각 노드 상태와 결합 항을 계산하는 근거를 붙인다. 테스트가 있으면 테스트와 **실행 여부**를 함께 보여 준다. 사용 예제는 실제 entrypoint/argument 계약을 확인한 뒤 제시한다.

답변 끝의 후속 제안은 한 가지로 좁힌다. 예: ‘이 모델의 시간 간격·보정 파라미터까지 이어서 확인할까요?’ 사용자가 이미 이를 요청했다면 다시 물어보지 말고 수행한다.
