# 08. CLI·MCP·Skill·자동 탐색 계약

## 1. 인터페이스 원칙

검색·드릴다운·전체 탐색·사용 준비·갱신은 공통 application service를 호출한다. CLI와 MCP에 서로 다른 검색 로직을 복제하지 않는다. CLI stdout은 JSON 모드에서 한 개의 JSON 또는 명시적 JSONL event stream만 출력하고 로그는 stderr로 보낸다. 모델 native 로그가 stdout을 오염시키는지 설치 smoke test에 넣는다. [S03](14_SOURCE_ATLAS.md#s03)

## 2. CLI 명령

```text
refs doctor --json
refs inventory import <file> --json
refs update --all --json
refs update --repo <id> --json
refs update --all --plan --json
refs rebuild --all --json
refs status --all --json
refs search "질문" --depth fast|verified|deep --breadth ranked|all --json
refs search "후속 질문" --session <id> --json
refs inspect <asset-id> --view code|knowledge|usage|tests --json
refs evidence <evidence-id> --json
refs trace <symbol-version-id> --relation references --direction in --json
refs compare <version-a> <version-b> --json
refs prepare-use <asset-id> --environment <id> --json
refs job status|cancel|resume <job-id> --json
refs mcp --stdio
```

exit code는 0 성공/정상 no-match, 2 잘못된 입력, 3 인증·권한 문제, 4 partial/stale 요구 불충족, 5 내부/외부 의존 실패, 130 사용자 취소를 제안한다. 에이전트는 exit code만 보지 않고 response.status를 읽는다. human-readable 모드에서도 실제 미발견과 실패를 분리한다.

## 3. MCP 도구

| 도구 | Application service | 쓰기 여부 |
|---|---|---|
| `refs_search` | search(request) | 읽기 + session 상태 기록 |
| `refs_inspect` | inspect(asset, view, manifest) | 읽기 |
| `refs_read_evidence` | readEvidence(id, context, manifest) | 읽기 |
| `refs_trace` | trace(node, relation, direction, budget) | 읽기 |
| `refs_compare` | compare(versionA, versionB) | 읽기 |
| `refs_prepare_use` | prepareUse(asset, goal, environment) | 계획, 외부 실행 없음 |
| `refs_index_status` | getStatus(scope) | 읽기 |
| `refs_update` | update(request) | 로컬 파생 인덱스 변경, 명시 요청 필요 |
| `refs_job` | status/cancel/resume | 해당 작업 소유권 적용 |

초기 host에 도구 수 부담이 있으면 trace/compare를 `refs_inspect`의 mode로 묶을 수 있다. 계약 자체는 바꾸지 않는다. 업데이트는 검색 실패를 핑계로 자동 full rebuild하지 않는다.

긴 작업은 호스트가 보유한 job 관리에 연결한다. 로컬 CLI 실행 프로세스가 종료되면 작업도 종료/중단되며 checkpoint만 남는다. resume 명령으로 다시 실행한다. 호스트의 background task가 실제 존재할 때만 ‘진행 중’ 상태를 반환한다. tool response에 존재하지 않는 예약 실행을 약속하지 않는다.

## 4. 공통 응답

```json
{
  "schema_version": "1.0",
  "request_id": "req-example",
  "session_id": "session-example",
  "manifest_id": "manifest-example",
  "status": "partial",
  "depth": "verified",
  "breadth": "all",
  "freshness": {"checked_at": "2026-11-02T00:00:00Z", "remote_current": "unknown"},
  "results": [],
  "coverage": {"scope_scan_complete": false, "semantic_completeness": "not_proven"},
  "warnings": ["예시 값이며 실제 조사 결과가 아님"],
  "next_cursor": null
}
```

`pending_repo_ids`·coverage·오류 상세에는 현재 조회 권한이 유지되는 저장소만 포함한다. 권한이 없는 저장소의 이름·개수·존재를 이 필드로 노출하지 않는다.

cursor는 session/manifest/scope/principal에 묶고 임의 외부 ID로 query scope를 확장하지 못하게 한다. 중앙형에서는 서명하거나 서버 상태로 저장한 opaque token을 사용한다. denied 리소스 존재가 드러나는 검색 count나 similarity score를 반환하지 않는다.

## 5. Skill

`../skills/internal-reuse/SKILL.md`는 설치용 초안이다. 설명은 새 기능·사내 레퍼런스·API/SDK/수식 질문에서 쓰도록 하고 본문에 검색→증거→활용 절차를 둔다. Skill 파일에 전체 프로젝트 목록과 credentials를 넣지 않는다. 공식 Agent Skills 명세의 frontmatter·본문·참조 구조를 따른다. [S26](14_SOURCE_ATLAS.md#s26)

스킬은 실행 절차이지 자동 실행 보장이나 보안 통제가 아니다. OMP 확장은 새 개발 목표와 명시 검색을 감지해 bounded FAST를 시작하고, 깊은 분석 여부는 사용자가 요청한 목표와 evidence gap에 맞춰 결정한다. 기존 작업 규칙과 충돌하면 상위 정책을 유지한다.

## 6. OMP 확장 상세

`before_agent_start` 등 공개 hook은 설치 버전을 확인하여 사용한다. 공개 문서상 재진입 원인·revive 등의 조건이 있으므로 empty/synthetic/revive 이벤트를 새 사용자 요청으로 처리하지 않는다. [S25](14_SOURCE_ATLAS.md#s25)

확장의 입력은 goal fingerprint, explicit request flags, current task ID, changed requirement footprint다. 출력은 session ID와 짧은 후보 hint이며 긴 코드와 문서는 일반 tool result로 제공한다. 검색된 AGENTS.md, prompt, README를 system prompt로 승격하지 않는다.

초기 intent 규칙은 명시 ‘찾아/레퍼런스/기존/전부’와 새 작업 시작 signal로 구성한다. 중요한 구현 계획이 시작될 때 스킬이 missed trigger를 보완한다. 작은 문구 변경이나 이미 검토한 함수의 편집에는 재검색하지 않는다. uncertain intent에 별도 LLM을 매 turn 호출하지 않는다.

부작용 없는 자동 FAST에도 wall-clock budget을 두고 timeout 결과를 전달한다. 인덱스 stale면 ‘최신’이라고 말하지 않는다. 사용자가 ‘최신 전체’라고 요청하면 update→all scan을 이어 수행하며 새 확인 질문을 반복하지 않는다.

## 7. MCP 버전과 로컬 프로세스

stdio는 client가 child process를 시작하는 통신 방식이다. localhost 웹 포트를 운영할 필요가 없다. 원격 배포가 필요할 때만 Streamable HTTP와 인증을 추가한다. MCP 버전별 lifecycle/transport는 공식 SDK에 맡기고 직접 JSON-RPC 서버를 새로 만들지 않는다. 열람한 SDK 문서는 v2 안정 계열과 v1 분리를 안내하므로 실제 회사 client가 지원하는 버전과 정확한 package import를 lockfile로 고정한다. [S27](14_SOURCE_ATLAS.md#s27) · [S28](14_SOURCE_ATLAS.md#s28)
