# 03. Git 수집·수동 갱신·증분 무효화·복구

## 1. 명령의 정확한 의미

| CLI | OMP 별칭 예시 | 계약 |
|---|---|---|
| `refs inventory import repos.yaml` | `/refs 등록` | 목록·ref·권한 경계를 등록. 원본 저장소는 변경하지 않음. |
| `refs update --all` | `/refs 전체업데이트` | 등록된 모든 활성 저장소의 변경 여부 확인, 변경분만 처리. |
| `refs update --repo <id>` | `/refs 업데이트 <id>` | 지정 저장소 및 그 파생물만 갱신. |
| `refs update --all --plan` | `/refs 업데이트계획` | 읽기 원격 확인과 예상 처리량 반환. 파생 데이터 게시 안 함. |
| `refs rebuild --all` | `/refs 전체재생성` | 현재 선택 스냅샷에서 parse/extract/embed를 새로 생성. |
| `refs update --resume <job>` | `/refs 재개 <job>` | 살아 있는 작업은 상태 조회, 중단 작업은 checkpoint 기준 재개. |
| `refs cancel <job>` | `/refs 중단 <job>` | 안전 지점에서 취소, 게시된 세대는 유지. |
| `refs status --all` | `/refs 상태` | 시점·commit·coverage·실패·모델·캐시 크기. |
| `refs history <asset> --from <v> --to <v>` | `/refs 변경점 <asset>` | 원문 diff와 확인된 기능/사용법 차이 분리. |

명령 이름은 구현할 계약이다. 이 설계 패키지가 해당 CLI 전체를 설치한 것은 아니다. ‘전체업데이트’는 `rebuild`로 매핑하지 않는다. 기본은 수동이며 스케줄러는 사용자가 켰을 때만 동작한다.

## 2. 최초 수집

등록된 repo/ref만 resolve하고 commit을 고정한다. `Git ls-tree -r -z` 또는 API tree를 통해 파일 inventory를 만든다. Git 객체 bytes를 읽으므로 로컬 ignored/hidden 기본 설정 때문에 tracked 파일을 놓치지 않는다. 큰 파일·binary·vendor·generated·secret·submodule·LFS pointer는 사유별 처리 상태를 남긴다. README와 주석은 입력 데이터이며 지침이나 실행 권한이 아니다.

내용 hash 기반으로 같은 blob의 parse/chunk 결과를 재사용한다. parser 미지원 시 텍스트 단위로 검색 가능성을 유지한다. 함수/클래스·공개 API·문서 절을 기본 chunk로 사용하고 긴 단위는 parent ID를 보존하여 분할한다. 코드 signature/import/짧은 주변 주석은 문맥으로 붙이되 실제 원문 mapping을 남긴다.

프로젝트/패키지 summary는 manifest·exports·주요 모듈·문서를 함께 근거로 만든다. 모든 파일에 비용 높은 생성 모델을 적용하지 않는다. 첫 인덱스에는 근거가 확인된 자산과 `analysis_pending` 상태를 함께 게시할 수 있다. 미완료를 완료로 표시하지 않는다.

## 3. 임베딩 정책

기본 `standard` 정책은 생성 코드 등을 제외한 1st-party 텍스트 소스·문서·테스트의 적격 chunk와 L0–L2 카드를 임베딩한다. 모든 코드를 LLM으로 해설하지는 않는다. 프로토콜/manifest/lock의 반복 항목은 구조 필드로 추출하고 사용자가 찾을 의미가 없는 반복 bytes는 임베딩에서 제외한다.

초기 대규모 데이터가 자원 한도를 넘으면 `budgeted`를 **명시적으로** 켤 수 있다. 이 경우 모든 소스의 exact/lexical 경로를 유지하고, 카드→공개 인터페이스→업무 핵심→나머지 순서로 body embedding을 확장한다. 비임베딩 범위와 선택 규칙을 저장한다. 표준 profile을 구현하면서 budgeted 엔진까지 동시에 만들 필요는 없다. 이전 답변의 ‘모든 코드 임베딩’이라는 문구는 generated/vendor/비밀/바이너리를 포함한다는 뜻이 아니다.

## 4. 증분 알고리즘

```text
acquire writer lock(profile)
freeze intended repository set; resolve target commits once
for each accessible repository:
    if commit and relevant configuration fingerprints unchanged: mark unchanged
    else:
        get changed/deleted/renamed paths(old_commit, target_commit)
        read changed blobs at target_commit, never working-tree HEAD
        reuse identical byte-derived parse/vector cache where valid
        invalidate reverse dependency closure(source → claim/recipe/card)
        add directory membership invalidation for new/deleted files
        invalidate semantic dependents when exports/config/lock/policy changes
        stage source map + derived records + search updates
validate staged references and declared coverage
publish READY generation atomically
release lock
```

`diff old new --name-status -z -M` 형태의 NUL-delimited 결과를 처리한다. 경로의 공백·탭·개행을 split whitespace로 파싱하지 않는다. rename은 Git의 추정 결과이며 논리 자산 identity의 확정 증거와 구분한다. [S30](14_SOURCE_ATLAS.md#s30)

새 파일이 생겼을 때 과거 summary가 그 파일을 근거로 갖지 않았다는 이유로 summary 갱신을 생략하면 안 된다. package/directory membership digest를 summary dependency로 등록한다. dependency lock 변경은 package 호환성과 recipe를 재검토하지만 모든 unchanged blob을 다시 임베딩하지 않는다.

## 5. force push·태그·브랜치 변경

branch head의 fast-forward 여부와 무관하게 선택한 두 tree를 비교한다. base commit이 없어졌거나 shallow 경계 밖이면 필요한 객체를 조회하고, 불가하면 해당 저장소의 전체 manifest 차이를 계산한다. Git hosting ref는 이동할 수 있으므로 tag도 실제 commit에 resolve한다. snapshot을 보관해야 하는 기간에는 private cache ref 또는 고정 blob cache로 객체를 pin한다. 단순 웹 permalink만 저장하면 원격 GC 후 열리지 않을 수 있다.

기본 브랜치가 바뀌면 기존 ref를 조용히 새로운 ref로 덮지 않는다. `track_default_branch` 정책과 변경 기록에 따라 새 snapshot을 선택한다. submodule은 상위 커밋의 gitlink와 실제 하위 snapshot을 따로 기록한다.

## 6. 원자적 게시와 운영 비용

첫 로컬 버전은 하나의 profile 단위로 catalog·QMD DB와 manifest를 새 generation 디렉터리에 준비한다. 기존 QMD DB는 SQLite의 지원 백업 방식으로 일관된 사본을 만들고 변경만 반영할 수 있다. DB bytes 사본 비용과 semantic re-embedding 비용은 다르다. 지원되는 copy-on-write snapshot이 없으면 DB 전체 I/O가 발생할 수 있음을 성능 보고에 포함한다. 활성 WAL DB 파일만 일반 복사하지 않는다. [S32](14_SOURCE_ATLAS.md#s32)

1. `PREPARING` 디렉터리와 update journal 생성.
2. source snapshot, catalog rows, search index를 같은 manifest 기준으로 stage.
3. source/evidence 참조·schema·embedding fingerprint와 필수 coverage 확인.
4. directory를 `READY`로 만들고 fsync 가능한 파일/메타데이터를 flush.
5. 작은 control DB의 active generation pointer를 트랜잭션으로 교체.
6. 진행 중인 요청은 lease한 세대를 끝까지 읽고, 다음 요청만 새 세대 사용.

Windows에서 사용 중인 DB 파일 rename을 강제하지 않는다. 새 경로+pointer 교체 후 reader lease가 끝나면 이전 파일을 정리한다. 디스크 부족·process kill·QMD 실패 시 pointer를 바꾸지 않는다. resume 시 staging 상태와 source fingerprint가 같은지 검증한다. 같은 수동 명령이 두 번 들어오면 동일 job fingerprint로 합치거나 `WRITER_BUSY`를 반환한다.

전체 갱신 중 일부 repo 접근이 실패하면 성공한 repo의 새 snapshot과 실패한 repo의 마지막 정상 snapshot을 포함한 **명시적 mixed-freshness manifest**를 게시할 수 있다. 실패 repo는 stale이며 회수된 권한은 즉시 차단한다. ‘전체 최신화 성공’으로 표시하지 않는다. 전체 검색의 fresh 요구를 충족하지 못하면 결과 상태는 partial이다.

## 7. 롤백·보존·변경 리포트

롤백은 이전 READY pointer를 선택하되 현재 권한 deny 상태를 되돌리지 않는다. 최신 generation 2개와 진행 작업의 pinned evidence를 기본 보존하고 회사 정책으로 조정한다. 오래된 generation 만료 시 기존 session은 `GENERATION_EXPIRED`와 재탐색 경로를 받는다. 수동 보정과 실행 영수증은 별도 백업한다.

갱신 리포트에는 `checked / changed / unchanged / failed / revoked`, 읽은 bytes, 신규/재사용 vector 수, 무효화 claim 수, 삭제 자산, parse fallback, 게시 세대를 기록한다. ‘바뀐 수식/호출/사용법’은 원문 diff로 확인한 것과 AI의 의미 해석을 구분해 표시한다.
