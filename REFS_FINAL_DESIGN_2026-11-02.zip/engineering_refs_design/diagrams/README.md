# 설계도 원본



Mermaid 문법의 편집 가능한 원본이다. 이 환경에서 Mermaid renderer를 실행하지 않았으므로 렌더링 검증 완료라고 주장하지 않는다. Markdown 코드 fence와 참조 연결은 검사한다.



## 01_local_architecture

[원본 파일](01_local_architecture.mmd)

```mermaid

flowchart LR
  U[개발 요청] --> H[OMP 또는 기존 하네스]
  H --> S[internal-reuse Skill]
  H --> X[자동 탐색 어댑터]
  S --> C[REFS 공통 코어]
  X --> C
  CLI[refs CLI] --> C
  MCP[선택적 stdio MCP] --> C
  C --> CAT[SQLite 카탈로그]
  C --> Q[QMD 검색 어댑터]
  Q --> IDX[로컬 검색 인덱스]
  C --> G[Git 원문 어댑터]
  G --> REM[기존 사내 Git]
  G --> CACHE[읽기용 객체 캐시]
  W[수동 update 작업] --> CAT
  W --> IDX
  W --> G
  H --> USE[기존 승인 API SDK CLI 실행]

```



## 02_query_sequence

[원본 파일](02_query_sequence.mmd)

```mermaid

sequenceDiagram
 participant U as 사용자
 participant H as Skill/하네스
 participant A as 공통 application
 participant I as 검색 인덱스
 participant G as Git 원문
 U->>H: Jira 구현 전부 + 상세
 H->>A: breadth=all, depth=verified
 A->>A: 권한/manifest 고정
 A->>I: 병렬 semantic·lexical·symbol
 I-->>A: 후보 + coverage
 A->>G: 실제 호출·wrapper 근거
 G-->>A: commit/blob/range
 A-->>H: 결과·세션·미해결 범위
 H-->>U: 원문 연결 + 활용 계획
 U->>H: 두 번째 후보 더 깊게
 H->>A: session + selected asset
 A->>G: 의존·테스트·설정 확대
 A-->>H: 같은 snapshot의 근거 묶음

```



## 03_update_state

[원본 파일](03_update_state.mmd)

```mermaid

stateDiagram-v2
 [*] --> PLANNED
 PLANNED --> RUNNING: 단일 writer 확보
 RUNNING --> STAGING: source delta + reverse invalidation
 STAGING --> READY: 참조/모델/coverage 확인
 READY --> PUBLISHED: control pointer transaction
 RUNNING --> PAUSED: 중단 checkpoint
 STAGING --> FAILED: 오류/디스크 부족
 PAUSED --> RUNNING: fingerprint 확인 후 재개
 FAILED --> RUNNING: 재개 가능한 경우
 PUBLISHED --> [*]
 note right of FAILED
 기존 READY pointer 유지
 권한 회수는 rollback하지 않음
 end note

```



## 04_provenance

[원본 파일](04_provenance.mmd)

```mermaid

flowchart LR
 A[논리 자산] --> V[자산 버전]
 V --> C[주장/수식]
 C --> E[근거 ID]
 E --> S[원문 범위]
 S --> B[commit + blob + path]
 V --> T[테스트/예제]
 V --> R[사용법]
 R --> X[실제 실행 영수증]
 C -. inferred 구분 .-> F[재구성 수식]
 B --> M[검색 manifest]
 P[현재 권한] -. 모든 조회에 적용 .-> E

```



## 05_distribution

[원본 파일](05_distribution.mmd)

```mermaid

flowchart TB
 PKG[서명된 앱·Skill·승인 모델 패키지] --> L1[개발자 A PC]
 PKG --> L2[개발자 B PC]
 L1 --> A1[개인 권한의 로컬 인덱스]
 L2 --> A2[개인 권한의 로컬 인덱스]
 L1 --> G[기존 사내 Git]
 L2 --> G
 G -. 선택 중앙 수집 .-> C[공용 application + worker]
 C --> DB[Postgres + pgvector + artifact store]
 SSO[SSO/Git 권한 연결] --> C
 C -. 승인 범위 .-> H[IDE·OMP·CLI]

```



## 06_reuse_boundary

[원본 파일](06_reuse_boundary.mmd)

```mermaid

flowchart LR
 Q[사용자 목표] --> F[자산 발견]
 F --> P[prepare-use]
 P --> V{조건·효과·버전 확인}
 V -->|충족| H[기존 하네스의 승인 도구]
 V -->|미확인| N[필요 조건·참고 구현 제시]
 H --> R[execution receipt]
 R --> K[검증 이력]
 S[검색 문서의 명령] -. 실행 권한 아님 .-> P

```



## 07_implementation_dag

[원본 파일](07_implementation_dag.mmd)

```mermaid

flowchart TD
 T00[호환성 좁은 검증] --> T01[Git 불변 reader]
 T01 --> T02[카탈로그 원문 계약]
 T02 --> T03[lexical dense 검색]
 T02 --> T05[증분 갱신]
 T03 --> T04[주장 드릴다운]
 T03 --> T06[전체 스캔]
 T04 --> T06
 T04 --> T07[수식 깊은 분석]
 T04 --> T08[재사용 계획]
 T05 --> T09[세션 자동 연결]
 T06 --> T09
 T07 --> T09
 T08 --> T09
 T09 --> T10[개인 release 검증]
 T10 --> T11[팀 배포]
 T11 --> T12[선택 중앙 서비스]
 T10 --> T13[마지막 UI]
 T12 -. 중앙 UI가 필요할 때만 .-> T13

```


