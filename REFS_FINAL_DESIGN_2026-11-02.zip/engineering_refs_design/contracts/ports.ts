/** Provider-neutral design contracts; declarations, not a running product. */
export type Depth = 'fast' | 'verified' | 'deep';
export type Breadth = 'ranked' | 'all';
export type ManifestId = string;
export type EvidenceId = string;
export interface AccessContext {
  readonly principalId: string;
  readonly authzEpoch: number;
  readonly allowedScopes: readonly string[];
  readonly deniedScopes: readonly string[];
  readonly modelRouteId: string;
  readonly expiresAt: string;
}
export interface SourceRef {
  readonly hostId: string; readonly repoId: string;
  readonly objectFormat: 'sha1'|'sha256'; readonly commitOid: string;
  readonly path: string; readonly blobOid: string; readonly contentSha256: string;
  readonly byteStart: number; readonly byteEnd: number;
  readonly lineStart: number; readonly lineEnd: number;
  readonly encoding: string; readonly lineEnding: 'lf'|'crlf'|'mixed'|'none';
  readonly extractorFingerprint: string; readonly symbolKey?:string;
}
export interface VerifiedSource {
  readonly source: SourceRef; readonly text: string; readonly excerpt: string;
  readonly verification: 'bytes_verified';
}
export interface SearchRequest {
  readonly query: string; readonly depth: Depth; readonly breadth: Breadth;
  readonly requestedScope?: readonly string[]; readonly sessionId?: string;
  readonly freshness: 'indexed'|'require_current';
  readonly pageSize: number; readonly cursor?: string;
}
export interface SearchCandidate {
  readonly assetId: string; readonly versionId: string;
  readonly lane: 'repository'|'capability'|'knowledge'|'source';
  readonly evidenceIds: readonly EvidenceId[];
  readonly whyRelevant: string; readonly semanticVerified: boolean;
}
export interface Coverage {
  readonly scopeScanComplete: boolean; readonly judgmentComplete: boolean;
  readonly semanticCompleteness: 'not_proven';
  readonly eligibleFiles: number|null; readonly scannedFiles: number;
  readonly pendingRepoIds: readonly string[];
}
export interface SearchResponse {
  readonly schemaVersion: '1.0'; readonly requestId: string;
  readonly sessionId: string; readonly manifestId: ManifestId;
  readonly status: 'ok'|'no_match'|'partial'|'failed';
  readonly depth: Depth; readonly breadth: Breadth;
  readonly freshness: {readonly checkedAt:string|null; readonly remoteCurrent:'current_at_check'|'stale'|'unknown'};
  readonly results: readonly SearchCandidate[]; readonly coverage: Coverage;
  readonly warnings: readonly string[]; readonly nextCursor: string|null;
}
export interface SourceProvider {
  readSource(source: SourceRef, context: AccessContext): Promise<VerifiedSource>;
}
export interface RetrievalProvider {
  search(request: SearchRequest, context: AccessContext): Promise<SearchResponse>;
}
export interface EvidenceService {
  readEvidence(id: EvidenceId, manifest: ManifestId, context: AccessContext): Promise<VerifiedSource>;
}
export interface UpdateRequest {
  readonly scope: {readonly all:true} | {readonly repoIds:readonly string[]};
  readonly mode: 'incremental'|'rebuild'; readonly planOnly: boolean;
}
export interface UpdateReport {
  readonly jobId:string; readonly state:'planned'|'published'|'partial'|'failed';
  readonly manifestId:ManifestId|null; readonly checked:number; readonly changed:number;
  readonly reusedVectors:number; readonly newVectors:number; readonly warnings:readonly string[];
}
export interface IndexService {
  update(request:UpdateRequest,context:AccessContext):Promise<UpdateReport>;
}
export interface ReusePlan {
  readonly assetId:string; readonly recipeId:string;
  readonly readiness:'ready'|'needs_setup'|'needs_verification'|'reference_only'|'deprecated'|'unavailable';
  readonly missingConditions:readonly string[]; readonly effects:readonly string[];
  readonly toolRef:string|null; readonly evidenceIds:readonly EvidenceId[];
  readonly executionPerformed:false;
}
export interface ReuseService {
  prepareUse(assetId:string,goal:string,environmentId:string,context:AccessContext):Promise<ReusePlan>;
}

/** Implemented by an existing authorized harness, not by the search core. */
export interface AuthorizedExecutionPlan {
  readonly planId:string; readonly recipeId:string; readonly manifestId:ManifestId;
  readonly toolRef:string; readonly operation:string; readonly validatedInput:unknown;
  readonly parameterDigest:string; readonly environmentId:string;
  readonly authorizationRef:string;
}
export interface ExecutionReceipt {
  readonly receiptId:string; readonly recipeId:string; readonly toolOperationId:string;
  readonly parameterDigest:string; readonly targetVersion:string;
  readonly environmentId:string; readonly executedAt:string;
  readonly outcome:'succeeded'|'failed'|'cancelled'|'unknown';
  readonly outputReference:string|null;
}
export interface ExecutionBridge {
  execute(plan:AuthorizedExecutionPlan,context:AccessContext):Promise<ExecutionReceipt>;
}
