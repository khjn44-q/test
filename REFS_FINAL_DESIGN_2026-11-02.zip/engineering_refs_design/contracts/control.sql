-- Mutable operations database: kept outside replaceable generation directories.
PRAGMA foreign_keys = ON;
PRAGMA user_version = 1;
CREATE TABLE publication (
  profile_id TEXT PRIMARY KEY,
  active_manifest_id TEXT,
  active_directory TEXT,
  revision INTEGER NOT NULL DEFAULT 0 CHECK(revision>=0)
);
CREATE TABLE job (
  job_id TEXT PRIMARY KEY,
  profile_id TEXT NOT NULL REFERENCES publication(profile_id),
  principal_id TEXT NOT NULL,
  request_fingerprint TEXT NOT NULL,
  state TEXT NOT NULL CHECK(state IN ('PLANNED','RUNNING','PAUSED','CANCELLED','FAILED','PUBLISHED')),
  checkpoint_json TEXT NOT NULL CHECK(json_valid(checkpoint_json)),
  updated_at TEXT NOT NULL
);
CREATE UNIQUE INDEX one_running_writer ON job(profile_id) WHERE state='RUNNING';
CREATE TABLE session (
  session_id TEXT PRIMARY KEY,
  principal_id TEXT NOT NULL,
  manifest_id TEXT NOT NULL,
  goal_fingerprint TEXT NOT NULL,
  state_json TEXT NOT NULL CHECK(json_valid(state_json)),
  updated_at TEXT NOT NULL
);
CREATE TABLE reader_lease (
  lease_id TEXT PRIMARY KEY,
  manifest_id TEXT NOT NULL,
  owner_id TEXT NOT NULL,
  expires_at TEXT NOT NULL
);
CREATE TABLE access_state (
  principal_id TEXT NOT NULL,
  scope_id TEXT NOT NULL,
  decision TEXT NOT NULL CHECK(decision IN ('allow','deny','unknown')),
  checked_at TEXT NOT NULL,
  expires_at TEXT NOT NULL,
  authz_epoch INTEGER NOT NULL CHECK(authz_epoch>=0),
  PRIMARY KEY(principal_id,scope_id)
);
CREATE TABLE human_override (
  override_id TEXT PRIMARY KEY,
  target_id TEXT NOT NULL,
  actor_id TEXT NOT NULL,
  payload_json TEXT NOT NULL CHECK(json_valid(payload_json)),
  evidence_refs_json TEXT NOT NULL CHECK(json_valid(evidence_refs_json)),
  created_at TEXT NOT NULL
);
CREATE TABLE execution_receipt (
  receipt_id TEXT PRIMARY KEY,
  recipe_id TEXT NOT NULL,
  principal_id TEXT NOT NULL,
  tool_operation_id TEXT NOT NULL,
  parameter_digest TEXT NOT NULL,
  target_version TEXT NOT NULL,
  environment_id TEXT NOT NULL,
  outcome TEXT NOT NULL CHECK(outcome IN ('succeeded','failed','cancelled','unknown')),
  output_reference TEXT,
  executed_at TEXT NOT NULL
);
-- Cross-database IDs are checked by the publication/replay application contract.
-- Do not attach obsolete snapshots to undo current access denials.
