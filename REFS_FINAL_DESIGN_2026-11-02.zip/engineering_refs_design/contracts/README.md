# 기계 검증 가능한 계약

`refs.schema.json`은 CLI/MCP wire의 snake_case 계약이다. `ports.ts`는 application port의 camelCase TypeScript 선언이며 boundary adapter가 명시적으로 매핑한다. `SearchResponse` 포트에는 freshness/depth/breadth도 보존해야 한다. JSON Schema validator는 `/query` 길이, enum, 필수 필드 등을 확인하지만 권한·원문 hash·범위 교차 조건·주장 타당성을 보장하지 않는다.

`catalog.sql`은 generation별 파생 카탈로그의 초기 DDL이다. `control.sql`은 교체하지 않는 publication pointer, 작업, 세션, 권한 상태, 인간 보정과 실행 영수증이다. reference DDL을 현장 migration의 시작점으로 사용하되 실제 migration/backup/lock/concurrent crash 검증 후 운영한다. 두 DB 사이 FK는 SQLite가 자동 강제하지 않으므로 게시·읽기 서비스가 manifest/source 관계를 검사한다.

## 필수 application invariants

1. Git object_format에 맞는 commit/blob 길이와 실제 객체 유형을 확인한다.
2. byte_start/end가 원문 bytes 범위 안에 있고 line_start/end와 같은 원문을 가리켜야 한다.
3. grounded 사실·관계는 실제 supporting evidence를 갖는다. inferred는 그 상태를 유지한다.
4. 파생 레코드는 모든 원본의 required scopes를 만족해야 하며 read 전 현재 deny를 적용한다.
5. evidence를 읽는 manifest가 session의 pinned manifest와 다르면 명시적으로 전환해야 한다.
6. execution_verified는 모델 문자열이 아닌 control DB의 실제 execution receipt로 뒷받침한다.
7. generation READY 전에 source mapping·index model fingerprint·coverage를 검사한다.
8. no_match는 검색이 끝난 범위에만 해당한다. partial/unknown을 숨기지 않는다.
9. no-op update는 embedding/semantic analysis 작업을 생성하지 않는다.
10. recipes는 비밀값이나 arbitrary shell을 저장하지 않는다. tool_ref는 승인 registry의 ID다.

예시의 `a...` 커밋과 `b...` blob은 합성 sentinel이다. 실제 Git에서 존재하거나 검증됐다는 뜻이 아니다. `examples/evidence.json`은 형식 예시(`located`)이며 실제 reader 시험은 임시 Git을 만들어 생성된 실제 commit/blob으로 실행한다.
