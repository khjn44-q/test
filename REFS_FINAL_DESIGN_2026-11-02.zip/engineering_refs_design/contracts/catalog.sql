-- REFS reference catalog v1. One catalog snapshot per immutable generation.
-- Application services enforce authorization, byte/line concordance, evidence entailment,
-- all-of provenance, and publication. SQL constraints alone do NOT establish those facts.
PRAGMA foreign_keys = ON;
PRAGMA user_version = 1;

CREATE TABLE repository (
  repo_id TEXT PRIMARY KEY,
  host_id TEXT NOT NULL,
  canonical_url TEXT NOT NULL,
  object_format TEXT NOT NULL CHECK(object_format IN ('sha1','sha256')),
  allowed_refs_json TEXT NOT NULL CHECK(json_valid(allowed_refs_json)),
  policy_ref TEXT NOT NULL,
  archived INTEGER NOT NULL DEFAULT 0 CHECK(archived IN (0,1))
);
CREATE TABLE snapshot (
  snapshot_id TEXT PRIMARY KEY,
  repo_id TEXT NOT NULL REFERENCES repository(repo_id),
  ref_name TEXT NOT NULL,
  commit_oid TEXT NOT NULL CHECK(length(commit_oid) IN (40,64) AND commit_oid NOT GLOB '*[^0-9a-f]*'),
  fetched_at TEXT NOT NULL,
  inventory_digest TEXT NOT NULL,
  UNIQUE(snapshot_id,repo_id)
);
CREATE TABLE source_unit (
  source_id TEXT PRIMARY KEY,
  snapshot_id TEXT NOT NULL,
  repo_id TEXT NOT NULL,
  path TEXT NOT NULL,
  blob_oid TEXT NOT NULL CHECK(length(blob_oid) IN (40,64) AND blob_oid NOT GLOB '*[^0-9a-f]*'),
  content_sha256 TEXT NOT NULL CHECK(length(content_sha256)=64 AND content_sha256 NOT GLOB '*[^0-9a-f]*'),
  byte_start INTEGER NOT NULL CHECK(byte_start>=0),
  byte_end INTEGER NOT NULL CHECK(byte_end>=byte_start),
  line_start INTEGER NOT NULL CHECK(line_start>=1),
  line_end INTEGER NOT NULL CHECK(line_end>=line_start),
  kind TEXT NOT NULL CHECK(kind IN ('code','document','test','example','config','manifest')),
  symbol_key TEXT,
  symbol_resolution TEXT CHECK(symbol_resolution IN ('lexical_candidate','syntax_observed','type_resolved','runtime_observed')),
  parent_source_id TEXT REFERENCES source_unit(source_id),
  encoding TEXT NOT NULL DEFAULT 'utf-8',
  line_ending TEXT NOT NULL CHECK(line_ending IN ('lf','crlf','mixed','none')),
  extractor_fingerprint TEXT NOT NULL,
  required_scopes_json TEXT NOT NULL CHECK(json_valid(required_scopes_json)),
  FOREIGN KEY(snapshot_id,repo_id) REFERENCES snapshot(snapshot_id,repo_id)
);
CREATE INDEX source_lookup ON source_unit(snapshot_id,path);
CREATE INDEX symbol_lookup ON source_unit(symbol_key);

CREATE TABLE document_source (
  document_source_id TEXT PRIMARY KEY,
  provider_id TEXT NOT NULL,
  immutable_revision TEXT NOT NULL,
  canonical_locator TEXT NOT NULL,
  content_sha256 TEXT NOT NULL CHECK(length(content_sha256)=64),
  required_scopes_json TEXT NOT NULL CHECK(json_valid(required_scopes_json))
);
CREATE TABLE evidence (
  evidence_id TEXT PRIMARY KEY,
  source_id TEXT REFERENCES source_unit(source_id),
  document_source_id TEXT REFERENCES document_source(document_source_id),
  locator_json TEXT NOT NULL CHECK(json_valid(locator_json)),
  excerpt_sha256 TEXT NOT NULL CHECK(length(excerpt_sha256)=64),
  verification TEXT NOT NULL CHECK(verification IN ('located','bytes_verified','unavailable','revoked')),
  CHECK((source_id IS NOT NULL) != (document_source_id IS NOT NULL))
);
CREATE TABLE asset (
  asset_id TEXT PRIMARY KEY,
  kind TEXT NOT NULL CHECK(kind IN ('repository','package','capability','api','algorithm','formula','knowledge','symbol','code','test','example'))
);
CREATE TABLE asset_version (
  version_id TEXT PRIMARY KEY,
  asset_id TEXT NOT NULL REFERENCES asset(asset_id),
  snapshot_id TEXT REFERENCES snapshot(snapshot_id),
  title TEXT NOT NULL,
  search_text TEXT NOT NULL,
  payload_json TEXT NOT NULL CHECK(json_valid(payload_json)),
  required_scopes_json TEXT NOT NULL CHECK(json_valid(required_scopes_json)),
  extractor_fingerprint TEXT NOT NULL,
  state TEXT NOT NULL CHECK(state IN ('draft','grounded','analysis_pending','stale','invalidated')),
  created_at TEXT NOT NULL
);
CREATE TABLE asset_evidence (
  version_id TEXT NOT NULL REFERENCES asset_version(version_id),
  evidence_id TEXT NOT NULL REFERENCES evidence(evidence_id),
  role TEXT NOT NULL CHECK(role IN ('supports','contradicts','context')),
  PRIMARY KEY(version_id,evidence_id,role)
);
CREATE TABLE claim (
  claim_id TEXT PRIMARY KEY,
  version_id TEXT NOT NULL REFERENCES asset_version(version_id),
  statement TEXT NOT NULL,
  scope_json TEXT NOT NULL CHECK(json_valid(scope_json)),
  conditions_json TEXT NOT NULL CHECK(json_valid(conditions_json)),
  exceptions_json TEXT NOT NULL CHECK(json_valid(exceptions_json)),
  model_inferred INTEGER NOT NULL CHECK(model_inferred IN (0,1)),
  status TEXT NOT NULL CHECK(status IN ('candidate','supported','conflicted','stale','invalidated'))
);
CREATE TABLE claim_evidence (
  claim_id TEXT NOT NULL REFERENCES claim(claim_id),
  evidence_id TEXT NOT NULL REFERENCES evidence(evidence_id),
  kind TEXT NOT NULL CHECK(kind IN ('docs_declared','code_observed','test_specified','execution_verified','policy_normative','owner_asserted','model_inferred')),
  role TEXT NOT NULL CHECK(role IN ('supports','contradicts','context')),
  PRIMARY KEY(claim_id,evidence_id,kind,role)
);
CREATE TABLE relation (
  relation_id TEXT PRIMARY KEY,
  from_version_id TEXT NOT NULL REFERENCES asset_version(version_id),
  to_version_id TEXT NOT NULL REFERENCES asset_version(version_id),
  kind TEXT NOT NULL CHECK(kind IN ('contains','implements','declares','references','calls','depends_on','tested_by','example_of','derived_from','contradicts','supersedes','validated_by','possible_successor')),
  resolution TEXT NOT NULL CHECK(resolution IN ('lexical_candidate','syntax_observed','type_resolved','runtime_observed','document_declared','model_inferred'))
);
CREATE TABLE relation_evidence (
  relation_id TEXT NOT NULL REFERENCES relation(relation_id),
  evidence_id TEXT NOT NULL REFERENCES evidence(evidence_id),
  PRIMARY KEY(relation_id,evidence_id)
);
-- Include source, membership, config, lock, policy, model and extractor dependencies.
-- dependency_key is a typed canonical ID validated by the application, not free text.
CREATE TABLE derivation_dependency (
  dependent_version_id TEXT NOT NULL REFERENCES asset_version(version_id),
  dependency_key TEXT NOT NULL,
  dependency_digest TEXT NOT NULL,
  PRIMARY KEY(dependent_version_id,dependency_key)
);
CREATE INDEX reverse_dependency ON derivation_dependency(dependency_key);
CREATE TABLE recipe (
  recipe_id TEXT PRIMARY KEY,
  version_id TEXT NOT NULL REFERENCES asset_version(version_id),
  mode TEXT NOT NULL CHECK(mode IN ('api','mcp','sdk','cli','code','template')),
  tool_ref TEXT,
  input_schema_json TEXT NOT NULL CHECK(json_valid(input_schema_json)),
  output_schema_json TEXT NOT NULL CHECK(json_valid(output_schema_json)),
  preconditions_json TEXT NOT NULL CHECK(json_valid(preconditions_json)),
  effects_json TEXT NOT NULL CHECK(json_valid(effects_json)),
  credential_refs_json TEXT NOT NULL CHECK(json_valid(credential_refs_json)),
  payload_digest TEXT NOT NULL,
  state TEXT NOT NULL CHECK(state IN ('draft','reviewed','deprecated'))
  -- Readiness is computed per principal/environment/version, not a permanent ready flag.
);
CREATE TABLE generation (
  manifest_id TEXT PRIMARY KEY,
  created_at TEXT NOT NULL,
  model_fingerprint TEXT NOT NULL,
  parser_fingerprint TEXT NOT NULL,
  policy_fingerprint TEXT NOT NULL,
  state TEXT NOT NULL CHECK(state IN ('PREPARING','READY','FAILED')),
  index_path TEXT NOT NULL
);
CREATE TABLE generation_snapshot (
  manifest_id TEXT NOT NULL REFERENCES generation(manifest_id),
  repo_id TEXT NOT NULL REFERENCES repository(repo_id),
  snapshot_id TEXT NOT NULL,
  freshness TEXT NOT NULL CHECK(freshness IN ('current_at_check','stale','unknown')),
  PRIMARY KEY(manifest_id,repo_id),
  FOREIGN KEY(snapshot_id,repo_id) REFERENCES snapshot(snapshot_id,repo_id)
);
CREATE TABLE generation_asset (
  manifest_id TEXT NOT NULL REFERENCES generation(manifest_id),
  version_id TEXT NOT NULL REFERENCES asset_version(version_id),
  PRIMARY KEY(manifest_id,version_id)
);
CREATE TABLE coverage (
  manifest_id TEXT NOT NULL REFERENCES generation(manifest_id),
  repo_id TEXT NOT NULL REFERENCES repository(repo_id),
  stage TEXT NOT NULL CHECK(stage IN ('inventory','lexical','vector','symbols','semantic','scope_scan','judgment')),
  eligible_count INTEGER CHECK(eligible_count>=0),
  completed_count INTEGER NOT NULL CHECK(completed_count>=0),
  state TEXT NOT NULL CHECK(state IN ('complete','partial','failed','excluded','unknown')),
  reasons_json TEXT NOT NULL CHECK(json_valid(reasons_json)),
  PRIMARY KEY(manifest_id,repo_id,stage),
  CHECK(eligible_count IS NULL OR completed_count<=eligible_count)
);
CREATE TABLE search_mapping (
  manifest_id TEXT NOT NULL REFERENCES generation(manifest_id),
  provider_doc_id TEXT NOT NULL,
  version_id TEXT REFERENCES asset_version(version_id),
  source_id TEXT REFERENCES source_unit(source_id),
  mapping_json TEXT NOT NULL CHECK(json_valid(mapping_json)),
  PRIMARY KEY(manifest_id,provider_doc_id),
  CHECK(version_id IS NOT NULL OR source_id IS NOT NULL)
);
