/**
 * Bounded reference reader for an already registered, trusted local Git directory.
 * This is NOT a credential broker, repository registration service or authorization layer.
 * Reads committed objects without checkout, textconv, filters, shell or network.
 */
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { TextDecoder } from 'node:util';

export function readGitSource(input) {
  const {repositoryPath, commitOid, path: sourcePath, expectedSha256,
    maxBytes=4*1024*1024, lineStart=1} = input ?? {};
  if (typeof repositoryPath !== 'string' || !repositoryPath || repositoryPath.includes('\0')) throw new Error('INVALID_REPOSITORY_PATH');
  if (typeof commitOid !== 'string' || !/^(?:[0-9a-f]{40}|[0-9a-f]{64})$/.test(commitOid)) throw new Error('INVALID_COMMIT_OID');
  if (typeof sourcePath !== 'string' || !sourcePath || sourcePath.includes('\0') || sourcePath.includes('\\') ||
      sourcePath.startsWith('/') || /^[A-Za-z]:/.test(sourcePath) || sourcePath.split('/').some(x=>x===''||x==='.'||x==='..')) {
    throw new Error('INVALID_SOURCE_PATH');
  }
  if (!Number.isSafeInteger(maxBytes) || maxBytes<=0 || maxBytes>64*1024*1024) throw new Error('INVALID_SIZE_LIMIT');
  if (expectedSha256 !== undefined && !/^[0-9a-f]{64}$/.test(expectedSha256)) throw new Error('INVALID_CONTENT_HASH');
  // Identity/access must have been verified by the caller. Suppress ambient replacement
  // objects and network prompts; child processes are bounded and not shell-expanded.
  const env={...process.env, GIT_TERMINAL_PROMPT:'0', GIT_OPTIONAL_LOCKS:'0', GIT_NO_REPLACE_OBJECTS:'1', GIT_NO_LAZY_FETCH:'1'};
  for (const key of ['GIT_DIR','GIT_WORK_TREE','GIT_INDEX_FILE','GIT_OBJECT_DIRECTORY','GIT_ALTERNATE_OBJECT_DIRECTORIES']) delete env[key];
  const run=(args,limit=1024*1024)=>{
    try { return execFileSync('git',['--no-replace-objects','--literal-pathspecs','-c','protocol.allow=never','-C',repositoryPath,...args],
      {env,encoding:null,timeout:10000,maxBuffer:limit,stdio:['ignore','pipe','pipe']}); }
    catch (error) { const wrapped=new Error('GIT_READ_FAILED'); wrapped.cause=error; throw wrapped; }
  };
  if (run(['cat-file','-t',commitOid]).toString('ascii').trim()!=='commit') throw new Error('NOT_A_COMMIT');
  const listing=run(['ls-tree','-z',commitOid,'--',sourcePath]);
  const entries=[]; let at=0;
  for (let i=0;i<listing.length;i++) if(listing[i]===0){entries.push(listing.subarray(at,i));at=i+1;}
  const target=Buffer.from(sourcePath,'utf8');
  let selected;
  for(const entry of entries){const tab=entry.indexOf(9);if(tab>0&&entry.subarray(tab+1).equals(target)){selected=entry.subarray(0,tab).toString('ascii');break;}}
  if(!selected) throw new Error('SOURCE_NOT_FOUND');
  const match=/^(\d{6}) (\w+) ([0-9a-f]{40}|[0-9a-f]{64})$/.exec(selected);
  if(!match||!['100644','100755'].includes(match[1])||match[2]!=='blob') throw new Error('UNSUPPORTED_SOURCE_MODE');
  const blobOid=match[3];
  const size=Number(run(['cat-file','-s',blobOid]).toString('ascii').trim());
  if(!Number.isSafeInteger(size)||size<0||size>maxBytes) throw new Error('SOURCE_TOO_LARGE');
  const bytes=run(['cat-file','blob',blobOid],maxBytes+1024);
  if(bytes.length!==size) throw new Error('SOURCE_SIZE_MISMATCH');
  const contentSha256=createHash('sha256').update(bytes).digest('hex');
  if(expectedSha256!==undefined&&contentSha256!==expectedSha256) throw new Error('SOURCE_HASH_MISMATCH');
  let text;
  try { if(bytes.includes(0)) throw new Error('binary'); text=new TextDecoder('utf-8',{fatal:true,ignoreBOM:true}).decode(bytes); }
  catch { throw new Error('UNSUPPORTED_ENCODING'); }
  const starts=[0];
  for(let i=0;i<bytes.length;i++) if(bytes[i]===10&&i+1<bytes.length) starts.push(i+1);
  const lineCount=starts.length; // An empty blob is represented as one empty display line.
  const lineEnd=input.lineEnd??lineCount;
  if(!Number.isInteger(lineStart)||!Number.isInteger(lineEnd)||lineStart<1||lineEnd<lineStart||lineEnd>lineCount) throw new Error('INVALID_LINE_RANGE');
  const byteStart=starts[lineStart-1],byteEnd=lineEnd<lineCount?starts[lineEnd]:bytes.length;
  return {commitOid,blobOid,path:sourcePath,contentSha256,text,
    excerpt:new TextDecoder('utf-8',{fatal:true,ignoreBOM:true}).decode(bytes.subarray(byteStart,byteEnd)),
    byteStart,byteEnd,lineStart,lineEnd,lineCount,sizeBytes:bytes.length};
}
