/** Pure reference invariants. No network, model runtime, database, or authorization authority. */
export interface RankedLane { readonly name: string; readonly weight: number; readonly ids: readonly string[]; }
export interface FusedHit { id: string; score: number; ranks: Record<string, number>; }
const order = (a: string, b: string): number => a < b ? -1 : a > b ? 1 : 0;
const sorted = (xs: Iterable<string>): string[] => [...xs].sort(order);
function requireId(id: string): void {
  if (typeof id !== 'string' || id.length === 0) throw new TypeError('ID_MUST_BE_NONEMPTY');
}

/** Weighted reciprocal-rank fusion; duplicate IDs in one lane cannot inflate a score. */
export function weightedRrf(lanes: readonly RankedLane[], k = 60): FusedHit[] {
  if (!Number.isFinite(k) || k < 0) throw new RangeError('INVALID_RRF_K');
  const names = new Set<string>();
  const rows = new Map<string, FusedHit>();
  // Sorting avoids order-dependent floating point accumulation and output object order.
  for (const lane of [...lanes].sort((a, b) => order(a.name, b.name))) {
    requireId(lane.name);
    if (names.has(lane.name)) throw new TypeError('DUPLICATE_LANE');
    names.add(lane.name);
    if (!Number.isFinite(lane.weight) || lane.weight < 0) throw new RangeError('INVALID_LANE_WEIGHT');
    if (lane.weight === 0) continue;
    const seen = new Set<string>();
    let rank = 0;
    for (const id of lane.ids) {
      requireId(id);
      if (seen.has(id)) continue;
      seen.add(id); rank++;
      const row = rows.get(id) ?? { id, score: 0, ranks: Object.create(null) as Record<string, number> };
      row.score += lane.weight / (k + rank);
      row.ranks[lane.name] = rank;
      rows.set(id, row);
    }
  }
  return [...rows.values()].sort((a, b) => b.score - a.score || order(a.id, b.id));
}

export interface DerivationEdge { readonly dependency: string; readonly dependent: string; }
/** Seeds can be source IDs, policy IDs or directory-membership digests. Includes seeds. */
export function invalidateDependents(seeds: readonly string[], edges: readonly DerivationEdge[]): string[] {
  const adjacency = new Map<string, Set<string>>();
  for (const {dependency, dependent} of edges) {
    requireId(dependency); requireId(dependent);
    const children = adjacency.get(dependency) ?? new Set<string>();
    children.add(dependent); adjacency.set(dependency, children);
  }
  const visited = new Set<string>();
  const queue = [...seeds];
  for (let cursor = 0; cursor < queue.length; cursor++) {
    const node = queue[cursor]!; requireId(node);
    if (visited.has(node)) continue;
    visited.add(node);
    for (const child of adjacency.get(node) ?? []) if (!visited.has(child)) queue.push(child);
  }
  return sorted(visited);
}

export interface UnitDigest {
  readonly id: string;
  readonly contentHash: string;
  readonly embeddingTextHash: string;
  readonly semanticContextHash: string;
  readonly locatorHash: string;
}
export interface PipelineFingerprint { readonly embedding: string; readonly extraction: string; }
export interface UnitChangePlan {
  added: string[]; removed: string[]; reparse: string[]; reembed: string[];
  reanalyze: string[]; remap: string[]; unchanged: string[];
}
function unitMap(units: readonly UnitDigest[]): Map<string, UnitDigest> {
  const result = new Map<string, UnitDigest>();
  for (const unit of units) {
    for (const value of Object.values(unit)) requireId(value);
    if (result.has(unit.id)) throw new TypeError('DUPLICATE_UNIT');
    result.set(unit.id, unit);
  }
  return result;
}
/** Compare already-described units. The caller still owns Git diff, chunking and publication. */
export function planUnitChanges(previous: readonly UnitDigest[], current: readonly UnitDigest[],
  oldFp: PipelineFingerprint, newFp: PipelineFingerprint): UnitChangePlan {
  for (const value of [...Object.values(oldFp), ...Object.values(newFp)]) requireId(value);
  const old = unitMap(previous), next = unitMap(current);
  const plan: UnitChangePlan = { added: [], removed: [], reparse: [], reembed: [], reanalyze: [], remap: [], unchanged: [] };
  for (const id of sorted(old.keys())) if (!next.has(id)) plan.removed.push(id);
  for (const id of sorted(next.keys())) {
    const now = next.get(id)!, before = old.get(id);
    const added = before === undefined;
    const bodyChanged = added || before.contentHash !== now.contentHash;
    const extractionChanged = oldFp.extraction !== newFp.extraction;
    const reparse = bodyChanged || extractionChanged;
    const reembed = added || before.embeddingTextHash !== now.embeddingTextHash || oldFp.embedding !== newFp.embedding;
    const reanalyze = bodyChanged || extractionChanged || before.semanticContextHash !== now.semanticContextHash;
    const remap = bodyChanged || before.locatorHash !== now.locatorHash;
    if (added) plan.added.push(id);
    if (reparse) plan.reparse.push(id);
    if (reembed) plan.reembed.push(id);
    if (reanalyze) plan.reanalyze.push(id);
    if (remap) plan.remap.push(id);
    if (!reparse && !reembed && !reanalyze && !remap) plan.unchanged.push(id);
  }
  return plan;
}

/** A helper only: the caller must obtain grants/denies from a trusted policy authority. */
export function allowAllOf(required: readonly string[], grants: readonly string[], denies: readonly string[] = []): boolean {
  if (required.length === 0) return false;
  const allowed = new Set(grants), denied = new Set(denies);
  return required.every(scope => typeof scope === 'string' && scope.length > 0 && allowed.has(scope) && !denied.has(scope));
}

export interface RepositoryScan {
  readonly repoId: string;
  readonly eligibleFiles: number | null; // null means inventory not established, not zero files
  readonly scannedFiles: number;
  readonly status: 'scanned' | 'pending' | 'failed' | 'excluded';
  readonly unresolvedCandidates: number;
}
export interface ScanCoverage {
  intendedRepositories: number; scannedRepositories: number; unknownInventories: number;
  knownEligibleFiles: number; scannedFiles: number; fileCoverage: number | null;
  scopeScanComplete: boolean; judgmentComplete: boolean;
  unresolvedCandidates: number; semanticCompleteness: 'not_proven';
}
function nonNegativeInteger(x: number): boolean { return Number.isInteger(x) && x >= 0; }
export function summarizeCoverage(scans: readonly RepositoryScan[]): ScanCoverage {
  const seen = new Set<string>();
  const result: ScanCoverage = { intendedRepositories: 0, scannedRepositories: 0, unknownInventories: 0,
    knownEligibleFiles: 0, scannedFiles: 0, fileCoverage: null, scopeScanComplete: false,
    judgmentComplete: false, unresolvedCandidates: 0, semanticCompleteness: 'not_proven' };
  for (const row of scans) {
    requireId(row.repoId);
    if (seen.has(row.repoId)) throw new TypeError('DUPLICATE_REPOSITORY');
    seen.add(row.repoId);
    if (!['scanned','pending','failed','excluded'].includes(row.status)) throw new TypeError('INVALID_SCAN_STATUS');
    if (!nonNegativeInteger(row.scannedFiles) || !nonNegativeInteger(row.unresolvedCandidates) ||
        (row.eligibleFiles !== null && (!nonNegativeInteger(row.eligibleFiles) || row.scannedFiles > row.eligibleFiles))) {
      throw new RangeError('INVALID_COVERAGE_COUNTS');
    }
    if (row.status === 'excluded') {
      if (row.eligibleFiles !== 0 || row.scannedFiles !== 0 || row.unresolvedCandidates !== 0) throw new RangeError('INVALID_EXCLUDED_COUNTS');
      continue;
    }
    result.intendedRepositories++;
    if (row.eligibleFiles === null) result.unknownInventories++;
    else result.knownEligibleFiles += row.eligibleFiles;
    result.scannedFiles += row.scannedFiles;
    result.unresolvedCandidates += row.unresolvedCandidates;
    if (row.status === 'scanned') {
      if (row.eligibleFiles === null || row.scannedFiles !== row.eligibleFiles) throw new RangeError('FALSE_SCAN_COMPLETION');
      result.scannedRepositories++;
    }
  }
  if (result.unknownInventories === 0 && result.knownEligibleFiles > 0) result.fileCoverage = result.scannedFiles / result.knownEligibleFiles;
  result.scopeScanComplete = result.intendedRepositories > 0 && result.scannedRepositories === result.intendedRepositories;
  result.judgmentComplete = result.scopeScanComplete && result.unresolvedCandidates === 0;
  return result;
}

export function assertManifest(sessionManifest: string, evidenceManifest: string): void {
  requireId(sessionManifest); requireId(evidenceManifest);
  if (sessionManifest !== evidenceManifest) throw new Error('MANIFEST_MISMATCH');
}
