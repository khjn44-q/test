# REFS 검증된 참조 코어

이 폴더는 제품 전체가 아니다. 외부 서비스 없이 시험할 수 있는 다음 작은 계약을 실제 코드로 구현했다.

| 함수 | 책임 | 포함하지 않는 것 |
|---|---|---|
| `weightedRrf` | rank fusion, lane 중복 제거, 결정론적 동률 | 임베딩·QMD 실행·retrieval quality |
| `invalidateDependents` | source/config/membership의 역방향 무효화 | 실제 DB write·Git delta 수집 |
| `planUnitChanges` | 내용/문맥/모델/위치 변경별 처리 계획 | 파일 파싱·LLM 분석·generation 게시 |
| `allowAllOf` | provenance scope 집합의 all-of+deny 계산 | 로그인·권한 수집·기업 인증 |
| `summarizeCoverage` | unknown 분모·실패·pending을 보존 | 의미적 완전성 증명 |
| `assertManifest` | snapshot 혼합 차단 | 세션 DB 구현 |
| `readGitSource` | 등록된 로컬 Git의 커밋 원문 읽기 | remote credential·clone·repo 등록·source 권한 |

`src/core.ts`는 TypeScript strict로 빌드한다. `src/git-reader.mjs`는 Node 표준 모듈을 사용하는 실행 가능한 ESM이다. 제품 TypeScript adapter로 옮길 때 같은 contract tests를 유지한다. stdout protocol/worker scheduling 등은 아직 구현하지 않았다.

## 실행

승인된 Node와 Git, TypeScript 5.8.3이 준비된 환경에서:

```sh
npm test
```

이 작업 환경에서는 전역 TypeScript를 사용했다. `npm install` 또는 외부 dependency·model 다운로드는 하지 않았다. 회사에서는 승인 registry/오프라인 패키지로 의존성을 설치하고 실제 lockfile을 생성한다. 이 폴더의 package.json은 개발용이며 배포 승인 lockfile이 아니다.

## 확인한 범위

35개 Node tests: 순수 계약 24개, 실제 임시 Git source reader 11개. Git fixture는 테스트마다 OS 임시 디렉터리에 생성하고 제거한다. 사용자 Git은 건드리지 않는다. 모델 검색 품질·Windows native 호환·기업 보안은 이 테스트로 검증되지 않는다.

`git-reader`는 한 파일 4MiB 기본/64MiB 최대, Git child 10초 제한의 참조 구현이다. 프로덕션에서는 async batch cat-file, cancellation, 현재 접근 검사, binary/non-UTF8 fallback, submodule/LFS 처리와 structured error mapping을 application 경계에 추가한다. timeout을 성능 SLA로 해석하지 않는다.

## Red → Green 기록

`../verification/core-red.log`는 최초 24개 중 20개 실패(4개 validation-error tests는 stub에서도 통과)를 기록한다. `git-reader-red.log`는 11개 미구현 실패다. 최종 전체 green은 `reference-suite.log`에 있다. 초기 실패 로그를 최신 실패로 혼동하지 않는다.
