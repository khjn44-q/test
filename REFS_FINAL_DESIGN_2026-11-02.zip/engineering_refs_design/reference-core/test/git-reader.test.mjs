import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, writeFileSync, mkdirSync, rmSync, readFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { execFileSync } from 'node:child_process';
import { createHash } from 'node:crypto';
import { readGitSource } from '../src/git-reader.mjs';

function fixture() {
  const repo = mkdtempSync(path.join(tmpdir(), 'refs-fixture-'));
  const git = (...args) => execFileSync('git', ['-C', repo, ...args], {encoding:'utf8'}).trim();
  git('init', '-q'); git('config','user.name','Fixture'); git('config','user.email','fixture@example.invalid');
  git('config','core.autocrlf','false');
  mkdirSync(path.join(repo,'src'));
  const original = '온도 = 25\r\npower = 5\r\nreturn 온도\r\n';
  writeFileSync(path.join(repo,'src','열 모델.py'),original,'utf8');
  writeFileSync(path.join(repo,'-odd.txt'),'safe\n');
  writeFileSync(path.join(repo,'binary.dat'),Buffer.from([0, 255, 65]));
  git('add','--','src/열 모델.py','-odd.txt','binary.dat'); git('commit','-qm','fixture');
  return {repo, git, original, commit:git('rev-parse','HEAD')};
}
function withRepo(fn) { const f=fixture(); try { return fn(f); } finally { rmSync(f.repo,{recursive:true,force:true}); } }

test('reader returns committed bytes, never dirty working tree', () => withRepo(f => {
  writeFileSync(path.join(f.repo,'src','열 모델.py'),'dirty\n');
  const result=readGitSource({repositoryPath:f.repo,commitOid:f.commit,path:'src/열 모델.py'});
  assert.equal(result.text,f.original);
  assert.equal(readFileSync(path.join(f.repo,'src','열 모델.py'),'utf8'),'dirty\n');
  assert.equal(result.contentSha256,createHash('sha256').update(f.original).digest('hex'));
  assert.match(result.blobOid,/^[a-f0-9]{40}$/);
}));
test('UTF-8 byte ranges preserve CRLF and correct inclusive line coordinates', () => withRepo(f => {
  const result=readGitSource({repositoryPath:f.repo,commitOid:f.commit,path:'src/열 모델.py',lineStart:2,lineEnd:2});
  assert.equal(result.excerpt,'power = 5\r\n');
  assert.equal(result.byteStart,Buffer.byteLength('온도 = 25\r\n'));
  assert.equal(result.byteEnd,result.byteStart+Buffer.byteLength('power = 5\r\n'));
  assert.equal(result.lineCount,3);
}));
test('leading dash file is a literal path and is not an option', () => withRepo(f => {
  assert.equal(readGitSource({repositoryPath:f.repo,commitOid:f.commit,path:'-odd.txt'}).text,'safe\n');
}));
test('non-commit revision strings are rejected before invoking git', () => withRepo(f => {
  assert.throws(()=>readGitSource({repositoryPath:f.repo,commitOid:'HEAD',path:'-odd.txt'}),/INVALID_COMMIT_OID/);
  assert.throws(()=>readGitSource({repositoryPath:f.repo,commitOid:'--help',path:'-odd.txt'}),/INVALID_COMMIT_OID/);
}));
test('traversal and absolute paths are rejected', () => withRepo(f => {
  for (const p of ['../secret','/etc/passwd','a/../b','C:\\secret','a\\b','a//b','a\0b']) {
    assert.throws(()=>readGitSource({repositoryPath:f.repo,commitOid:f.commit,path:p}),/INVALID_SOURCE_PATH/);
  }
}));
test('missing source is explicit, not substituted with another path', () => withRepo(f => {
  assert.throws(()=>readGitSource({repositoryPath:f.repo,commitOid:f.commit,path:'missing.py'}),/SOURCE_NOT_FOUND/);
}));
test('expected content hash mismatch is rejected', () => withRepo(f => {
  assert.throws(()=>readGitSource({repositoryPath:f.repo,commitOid:f.commit,path:'-odd.txt',expectedSha256:'0'.repeat(64)}),/SOURCE_HASH_MISMATCH/);
}));
test('line ranges outside source or inverted ranges are rejected', () => withRepo(f => {
  for (const [lineStart,lineEnd] of [[0,1],[3,2],[1,4],[1.5,2]]) {
    assert.throws(()=>readGitSource({repositoryPath:f.repo,commitOid:f.commit,path:'src/열 모델.py',lineStart,lineEnd}),/INVALID_LINE_RANGE/);
  }
}));
test('git symlink is not dereferenced', () => withRepo(f => {
  const blob=execFileSync('git',['-C',f.repo,'hash-object','-w','--stdin'],{input:'../outside',encoding:'utf8'}).trim();
  f.git('update-index','--add','--cacheinfo',`120000,${blob},link`); f.git('commit','-qm','add link');
  assert.throws(()=>readGitSource({repositoryPath:f.repo,commitOid:f.git('rev-parse','HEAD'),path:'link'}),/UNSUPPORTED_SOURCE_MODE/);
}));
test('binary source does not silently decode as replacement text', () => withRepo(f => {
  assert.throws(()=>readGitSource({repositoryPath:f.repo,commitOid:f.commit,path:'binary.dat'}),/UNSUPPORTED_ENCODING/);
}));
test('read bound rejects large blob before returning it', () => withRepo(f => {
  assert.throws(()=>readGitSource({repositoryPath:f.repo,commitOid:f.commit,path:'src/열 모델.py',maxBytes:5}),/SOURCE_TOO_LARGE/);
}));
