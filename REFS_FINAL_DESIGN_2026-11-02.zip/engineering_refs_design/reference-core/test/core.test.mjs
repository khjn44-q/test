import test from 'node:test';
import assert from 'node:assert/strict';
import { weightedRrf, invalidateDependents, planUnitChanges, allowAllOf,
         summarizeCoverage, assertManifest } from '../dist/core.js';

const fingerprints = { embedding: 'embed-v1', extraction: 'extract-v1' };
const unit = (id, changes = {}) => ({ id, contentHash: 'body1', embeddingTextHash: 'text1',
  semanticContextHash: 'context1', locatorHash: 'loc1', ...changes });

test('RRF accumulates independent lanes', () => {
  const hits = weightedRrf([{name:'lex',weight:1,ids:['a','b']},{name:'dense',weight:1,ids:['b','c']}]);
  assert.equal(hits[0].id, 'b');
  assert.ok(Math.abs(hits[0].score - (1/62 + 1/61)) < 1e-12);
});
test('RRF counts duplicate IDs only once in a lane', () => {
  const a = weightedRrf([{name:'lex',weight:1,ids:['a','a','b']}]);
  assert.equal(a.length, 2); assert.equal(a[0].score, 1/61); assert.equal(a[1].score, 1/62);
});
test('RRF is deterministic for ties independent of lane order', () => {
  const a = {name:'x',weight:1,ids:['z']}, b = {name:'y',weight:1,ids:['a']};
  assert.deepEqual(weightedRrf([a,b]), weightedRrf([b,a]));
  assert.equal(weightedRrf([a,b])[0].id,'a');
});
test('RRF rejects duplicate lane names', () => {
  assert.throws(()=>weightedRrf([{name:'x',weight:1,ids:['a']},{name:'x',weight:1,ids:['b']}]));
});
test('RRF rejects invalid numeric settings', () => {
  for (const weight of [-1, NaN, Infinity]) assert.throws(()=>weightedRrf([{name:'x',weight,ids:['a']}]));
  assert.throws(()=>weightedRrf([], -1));
});
test('RRF handles empty input and zero weight', () => {
  assert.deepEqual(weightedRrf([]),[]);
  assert.deepEqual(weightedRrf([{name:'x',weight:0,ids:['a']}]),[]);
});
test('invalidation reaches transitive summaries', () => {
  assert.deepEqual(invalidateDependents(['source'],[
    {dependency:'source',dependent:'claim'}, {dependency:'claim',dependent:'card'}]), ['card','claim','source']);
});
test('invalidation terminates on a cycle and preserves unrelated nodes', () => {
  assert.deepEqual(invalidateDependents(['a'],[
    {dependency:'a',dependent:'b'},{dependency:'b',dependent:'a'},
    {dependency:'x',dependent:'y'}]), ['a','b']);
});
test('membership changes invalidate summaries even for previously unseen files', () => {
  assert.deepEqual(invalidateDependents(['directory-membership'],[
    {dependency:'directory-membership',dependent:'package-card'}]),['directory-membership','package-card']);
});
test('no-op update schedules no re-embedding', () => {
  const p = planUnitChanges([unit('a')],[unit('a')],fingerprints,fingerprints);
  assert.deepEqual(p.unchanged,['a']); assert.deepEqual(p.reembed,[]); assert.deepEqual(p.reanalyze,[]);
});
test('location-only update remaps without re-embedding', () => {
  const p = planUnitChanges([unit('a')],[unit('a',{locatorHash:'loc2'})],fingerprints,fingerprints);
  assert.deepEqual(p.remap,['a']); assert.deepEqual(p.reembed,[]); assert.deepEqual(p.reanalyze,[]);
});
test('semantic dependency changes reanalyze without new vector when text is unchanged', () => {
  const p = planUnitChanges([unit('a')],[unit('a',{semanticContextHash:'context2'})],fingerprints,fingerprints);
  assert.deepEqual(p.reanalyze,['a']); assert.deepEqual(p.reembed,[]);
});
test('model change re-embeds without reparsing identical source', () => {
  const p = planUnitChanges([unit('a')],[unit('a')],fingerprints,{...fingerprints,embedding:'embed-v2'});
  assert.deepEqual(p.reembed,['a']); assert.deepEqual(p.reparse,[]); assert.deepEqual(p.reanalyze,[]);
});
test('source and embedding payload changes schedule necessary work', () => {
  const p = planUnitChanges([unit('a')],[unit('a',{contentHash:'body2',embeddingTextHash:'text2'})],fingerprints,fingerprints);
  assert.deepEqual(p.reparse,['a']); assert.deepEqual(p.reembed,['a']); assert.deepEqual(p.reanalyze,['a']);
});
test('add and delete are explicit and deleted units are not embedded', () => {
  const p = planUnitChanges([unit('a')],[unit('b')],fingerprints,fingerprints);
  assert.deepEqual(p.added,['b']); assert.deepEqual(p.removed,['a']); assert.deepEqual(p.reembed,['b']);
});
test('extraction change revalidates meaning without gratuitous vector recomputation', () => {
  const p = planUnitChanges([unit('a')],[unit('a')],fingerprints,{...fingerprints,extraction:'extract-v2'});
  assert.deepEqual(p.reparse,['a']); assert.deepEqual(p.reanalyze,['a']); assert.deepEqual(p.reembed,[]);
});
test('duplicate IDs in a snapshot are rejected', () => {
  assert.throws(()=>planUnitChanges([unit('a'),unit('a')],[],fingerprints,fingerprints));
});
test('derived claim requires all source scopes', () => {
  assert.equal(allowAllOf(['A','B'],['A']),false);
  assert.equal(allowAllOf(['A','B'],['A','B']),true);
});
test('deny overrides grants and empty provenance is not public', () => {
  assert.equal(allowAllOf(['A'],['A'],['A']),false);
  assert.equal(allowAllOf([],['A']),false);
});
test('coverage separates scan completion from unresolved judgments', () => {
  const c = summarizeCoverage([{repoId:'a',eligibleFiles:10,scannedFiles:10,status:'scanned',unresolvedCandidates:2}]);
  assert.equal(c.scopeScanComplete,true); assert.equal(c.judgmentComplete,false);
  assert.equal(c.semanticCompleteness,'not_proven'); assert.equal(c.fileCoverage,1);
});
test('failed unknown inventory does not fabricate 100 percent coverage', () => {
  const c = summarizeCoverage([
    {repoId:'a',eligibleFiles:10,scannedFiles:10,status:'scanned',unresolvedCandidates:0},
    {repoId:'b',eligibleFiles:null,scannedFiles:0,status:'failed',unresolvedCandidates:0}]);
  assert.equal(c.scopeScanComplete,false); assert.equal(c.fileCoverage,null);
});
test('empty scope has no ratio and is not claimed to be searched', () => {
  const c = summarizeCoverage([]); assert.equal(c.scopeScanComplete,false); assert.equal(c.fileCoverage,null);
});
test('coverage rejects inconsistent counts and duplicate repository entries', () => {
  assert.throws(()=>summarizeCoverage([{repoId:'a',eligibleFiles:1,scannedFiles:2,status:'scanned',unresolvedCandidates:0}]));
  const r={repoId:'a',eligibleFiles:1,scannedFiles:1,status:'scanned',unresolvedCandidates:0};
  assert.throws(()=>summarizeCoverage([r,r]));
});
test('manifest mismatch is never silently reinterpreted', () => {
  assert.equal(assertManifest('m1','m1'),undefined);
  assert.throws(()=>assertManifest('m1','m2'),/MANIFEST_MISMATCH/);
});
