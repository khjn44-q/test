"""Synthetic mathematical fixture tests; NOT evidence for any actual SSD."""
import math
import sys
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'fixtures'))
from thermal_model import step_temperature

class ThermalTests(unittest.TestCase):
    def test_one_euler_step(self):
        # 25 + 0.5/10 * (4 - (25-20)/5) = 25.15
        self.assertAlmostEqual(step_temperature(25,4,20,5,10,0.5),25.15)
    def test_equilibrium_is_preserved(self):
        self.assertEqual(step_temperature(40,4,20,5,10,0.5),40)
    def test_no_power_at_ambient_is_stationary(self):
        self.assertEqual(step_temperature(20,0,20,5,10,0.5),20)
    def test_small_step_moves_toward_equilibrium(self):
        t=20
        for _ in range(100):
            next_t=step_temperature(t,4,20,5,10,0.5)
            self.assertGreater(next_t,t)
            self.assertLess(next_t,40)
            t=next_t
    def test_invalid_physical_parameters(self):
        for r,c,dt in [(0,10,1),(5,-1,1),(5,10,0)]:
            with self.assertRaisesRegex(ValueError,'positive'):
                step_temperature(25,4,20,r,c,dt)
    def test_nonfinite_inputs(self):
        for x in (math.nan,math.inf,-math.inf):
            with self.assertRaisesRegex(ValueError,'finite'):
                step_temperature(x,4,20,5,10,0.5)
    def test_unstable_explicit_step_is_rejected(self):
        with self.assertRaisesRegex(ValueError,'stability'):
            step_temperature(25,4,20,5,10,100)
    def test_temperature_units_are_differences_not_absolute_kelvin_conversion(self):
        a=step_temperature(25,4,20,5,10,0.5)
        b=step_temperature(298.15,4,293.15,5,10,0.5)
        self.assertAlmostEqual(b-a,273.15)

if __name__=='__main__': unittest.main()
