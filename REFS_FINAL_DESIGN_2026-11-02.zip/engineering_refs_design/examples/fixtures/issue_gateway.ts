/** Synthetic static-discovery fixture. NOT a real company API client.
 * No network is called here; an injected transport would perform the request.
 * Jira deployment/version/pagination must be resolved against the real instance.
 */
export interface Transport {
  post(path: string, body: unknown): Promise<unknown>;
}
export async function searchIssuePage(transport: Transport, jql: string, cursor?: string) {
  if (!jql.trim()) throw new Error('JQL_REQUIRED');
  return transport.post('/rest/api/3/search/jql', {
    jql, fields: ['key', 'status', 'assignee'], maxResults: 50,
    ...(cursor ? {nextPageToken: cursor} : {}),
  });
}
