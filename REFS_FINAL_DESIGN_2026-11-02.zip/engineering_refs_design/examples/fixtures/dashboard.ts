/** Synthetic wrapper caller. The file deliberately does not contain "Jira". */
import { searchIssuePage, type Transport } from './issue_gateway';
export async function loadAssignedIssues(t: Transport, projectKey: string) {
  if (!/^[A-Z][A-Z0-9_]*$/.test(projectKey)) throw new Error('INVALID_PROJECT_KEY');
  return searchIssuePage(t, `project = ${projectKey} AND assignee = currentUser()`);
}
