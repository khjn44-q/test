"""Synthetic, educational one-node explicit-Euler thermal fixture.

Not a measured SSD model. No hardware calibration, geometry or vendor data.
R_th: K/W; C_th: J/K; power: W; dt: s. Temperatures use one consistent scale.
"""
from math import isfinite


def step_temperature(
    temperature: float,
    power: float,
    ambient: float,
    resistance: float,
    capacitance: float,
    dt: float,
) -> float:
    """One Euler step; rejects the scalar model's unstable/neutral time steps."""
    values = (temperature, power, ambient, resistance, capacitance, dt)
    if not all(isfinite(v) for v in values):
        raise ValueError('all inputs must be finite')
    if resistance <= 0 or capacitance <= 0 or dt <= 0:
        raise ValueError('resistance, capacitance and dt must be positive')
    if dt >= 2.0 * resistance * capacitance:
        raise ValueError('explicit Euler stability requires dt < 2 R C')
    heat_loss = (temperature - ambient) / resistance
    return temperature + (dt / capacitance) * (power - heat_loss)
