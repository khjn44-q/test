# 배포 아카이브 검증

## 후보 아카이브 실제 검사

`candidate-package.json`: 163개 파일의 크기/SHA-256 manifest, ZIP CRC, 경로 안전성과 누락·추가 파일 대조를 통과했다. 이 수는 중간 후보의 수이며 최종 ZIP에는 이 검증 기록과 본 문서가 추가된다.

후보 ZIP을 `/mnt/data/refs_v3_candidate_extract`의 새 폴더에 풀고 **압축에서 꺼낸 wheel**로 새 venv를 만들었다. `candidate-extracted-install.json`의 실제21개 명령이 exit0으로 끝났고, source-tree import 없이 검색·원문·갱신·옛 근거 보존을 확인했다. candidate SHA는 candidate-package.json에 있고 최종 ZIP SHA와 다르다.

## 최종 게시

최종 ZIP은 동일 build_bundle.py로 다시 생성한다. 전체 파일 SHA-256은 ZIP 안 MANIFEST.json, ZIP 자체 CRC/파일 목록/해시는 생성 직후 verify_bundle.py로 다시 확인한다. ZIP은 출하될 때까지 현재 컨테이너에서 실제 존재/크기/read가 확인된 경로만 링크한다. 이전 답변의 존재하지 않는 링크를 재사용하지 않는다.

검증 명령:

```text
python scripts/verify_bundle.py <받은 ZIP>
```

소스/문서/테스트/실험 스크립트·결과/설치 wheel이 포함된다. `.git`, 실제 source corpus·database, 토큰, venv, pycache, 다른 ZIP, 선택 외부 모델·SDK/NumPy binary는 포함하지 않는다. 공개 Git 코드나 사내 source도 번들에 포함하지 않는다.

파일 무결성은 원본 bytes가 전달됐다는 확인이지 보안 인증/사용 승인/최종 기능 acceptance가 아니다.
