# REFS Runtime 0.3 최종 검증 보고서

**새 재구현. 과거 잃어버린 구현을 복구한 파일이 아니다.** 이 보고서는 현재 소스와 실제 실행 receipt에 근거한다. 이전 TypeScript 패키지의59개 테스트를 합산하지 않았다.

## 최종 로컬 결과

| 항목 | 결과 | 실제 증거 |
|---|---|---|
| 전체 회귀 | **142 passed, 1 skipped, failures/errors 0** | [release-suite.json](release-suite.json), [로그](release-suite.log), [JUnit](release-tests.xml) |
| 자체 코드 부모 process line coverage | 85.87% | [coverage.json](coverage.json); subprocess CLI 미계측, 제품 완성률 아님 |
| wheel 빌드 | exit0 | [wheel-build.log](wheel-build.log) |
| 깨끗한 venv offline wheel 설치·CLI E2E | passed | [wheel-smoke.json](wheel-smoke.json), [receipt](wheel-smoke-run.json) |
| 120개 독립 synthetic Git 규모 시험 | passed, exit0 | [scale120-final.json](scale120-final.json), [receipt](scale120-final-run.json) |
| 공개 Git100 | **blocked, attempted0, indexed0** | [public100.json](public100.json), DNS 실패 |
| 공식 MCP SDK protocol | **SKIPPED** | 환경에 mcp SDK 없음. registry binding unit test와 구분 |

Runtime source digest: `a20585051cc9e7c372067d08795a0aa299ae2a84b9109a909a1325135bf389d6`. 포함 wheel SHA-256: `f6c39049e2b3697337b2dd80dac32d056434958f53839d0ed99244ee7954eddf`. wheel 내부 Python 모듈이 현재 src bytes와 일치함을 배포 계약 테스트에서 확인했다.

## 실제 설치 시험의 범위

외부 pip 다운로드 없이 새 venv에 wheel을 설치하고, 프로그램 소스 폴더와 다른 cwd/PYTHONPATH 없는 환경에서 import 위치를 확인했다. 합성 local Git을 등록해 index/search/evidence, dirty tree에서 과거 원문 보존, no-op zero read, 새 commit 갱신, 과거 evidence 유지, whole-file scan, 실행 없는 reuse plan과 source Git status 무변경을 확인했다. [상세 설치 결과](wheel-smoke.json).

## 규모 결과의 의미

120repo, 5,400tracked files, 약7.5MB 원문, 최초77,440source units를 다뤘다. 모의1024차원 벡터로 처리·저장 경로를 검증했다. [실측 표](../docs/PERFORMANCE.md). 공개/사내 실자료의 semantic 품질은 측정하지 않았다. no-op rawread0/newvectors0, rename newvectors0, 4repo 수정·삭제·추가·이동 이후 과거 evidence 보존을 확인했다.

## 주요 추가 회귀

다중 scope SQL planner 회귀, stale note의 LIMIT 이전 필터, chunk 경계 whole-file 매칭, unindexed scope partial, source-less model claim 거부, false execution authority 거부, 긴 model input 분할, summary embedding 실패 재시도, model fingerprint구분, explicit probe/summary 실패 partial, MCP wrapper closure 인자 유출을 검사했다.

## 실행하지 못한 영역

- 실제 사내 Git 인증·CA·프록시와 100+ 실자료 품질.
- 실제 사내 embedding/LLM의 한국어·기술 수식 정확도와 network latency.
- 공식 MCP SDK와 실제 stdio host 통합, OMP/Chat 등의 Skill 자동 활성화.
- Windows native 설치·프로세스·NTFS 정책.
- 실제 JiraAPI/SDK 실행, 실제 SSD실측/calibration.
- C/C++/Java/TS의 완전한 타입·호출 관계, 중앙SSO/ACL, cacheGC·retention.
- 독립 서브에이전트 리뷰. 이번 검토는 자체 코드 대조와 실행 시험이다.

따라서 상태는 **지원된 로컬 코어 Implemented + locally tested, 사내 Accepted 아님**이다. 미지원 영역을 모두 ‘미세 설정만 남음’이라고 표현하지 않는다.

## 검증 재실행

```text
python -m pytest -q
python scripts/smoke_install.py --wheel dist/engineering_refs-0.3.0-py3-none-any.whl --output wheel-smoke-new.json
python bench/scale.py --repositories 120 --files 40 --functions 8 --dimensions 1024 --queries 16 --output scale-new.json
python scripts/verify_bundle.py <최종 ZIP>
```

기본 코어는 dependency0이며 테스트에는 pytest, 가속에는 NumPy, MCP에는 공식SDKv2가 별도 필요하다. package는 이를 runtime에서 자동 다운로드하지 않는다.

## 패키징 계약

`build_bundle.py`는 필수 파일 존재, 허용 경로, file size/SHA-256 manifest를 생성하고 ZIP CRC 및 전체 파일 목록을 검증한 후에만 최종 경로로 게시한다. `MANIFEST.json`은 ZIP 안 모든 나머지 파일을 열거한다. 자체 ZIP의 해시를 ZIP 안에 넣는 순환 요구는 두지 않는다. 최종 ZIP 자체 해시는 사용자에게 전달하기 직전 별도 검증 결과로 확인한다. 중간 후보 ZIP에서 fresh extraction/install을 실제 수행했고 [패키징 기록](PACKAGING.md) 및 [추출 후 설치 결과](candidate-extracted-install.json)에 포함했다. 마지막 게시에서도 전체 manifest와 CRC를 다시 확인한다.

실패했던 red 로그·중단된 초기 scale 기록은 재현 이력이며 현재 성공 증거가 아니다. 최종 판정은 이 문서가 연결한 최신receipt만 사용한다.
