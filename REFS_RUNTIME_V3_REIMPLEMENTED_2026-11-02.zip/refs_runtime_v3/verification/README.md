# 검증 파일 읽기

최종 기준: FINAL_REPORT.md → release-summary.json → release-suite.json/log/XML → scale120-final.json/run.json → wheel-smoke.json. S*-red는 의도적으로 구현 전 실패를 재현한 기록이고 green은 해당 단계 회귀다. `final-suite`는 중간134-pass 기록, `release-suite`가 현재 전체 검증이다.

`public100.json`의 blocked는 숨길 수 없는 실험 제약이다. wrapper exit4는 이 차단 상태를 기록하며 core 회귀 suite 실패와 다르다. `scale120-before.log`, embedding-resume/hybrid-probe와 old scale120.json은 병목 조사·중간 실행 기록이다. 최종source digest와 일치하는 scale120-final만 최종 성능 표에 사용한다.

MCP registry-only unit test는 SDK decorator 인자 mapping만 검증한다. 실제 MCP protocol test의 skip을 대체하지 않는다. coverage는 부모 pytest process line 측정이며 subprocess CLI와 wheel smoke를 포괄하지 않는다. 높은 line coverage는 성능/보안/의미 정확도를 증명하지 않는다.
