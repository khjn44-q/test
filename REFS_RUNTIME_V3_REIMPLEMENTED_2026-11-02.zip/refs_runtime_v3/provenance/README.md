# 이전 자료의 역할

INPUT_DESIGN.md / INPUT_PLAN.md / INPUT_VERIFICATION.md는 제공된 이전 설계 ZIP에서 읽은 자료를 보존한 것이다. 새 Python 구현의 설치 지시나 현재 실행 성과가 아니다. TypeScript/QMD 구성이나 이전 59개 테스트를 이번 결과로 혼합하지 않는다.

현재 정본은 ../src/, ../docs/, ../HANDOFF_KO.md, ../verification/FINAL_REPORT.md다. 새 변경점은 WORKLOG와 actual tests에서 확인한다. 기존 분실 구현물을 회수했다고 주장하지 않는다.
