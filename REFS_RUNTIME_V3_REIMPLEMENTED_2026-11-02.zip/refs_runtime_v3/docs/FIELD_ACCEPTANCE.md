# 사내 현장 Acceptance

구현/합성 verified와 실제 사내 Accepted는 다르다. 이 표를 통과하기 전 전사 배포 완료라고 보고하지 않는다.

## F0 설치·계약

- [ ] 회사 표준 Windows/Python/Git에서 포함 wheel offline 설치, `doctor`, 실제 local repo index/read 성공.
- [ ] 회사 CA/proxy/helper로 read-only remote fetch 성공. source status/hash가 전후 동일.
- [ ] embedding endpoint의 model/revision/dim/query-doc format/token limit 확인. 실제 vector 반환과 fingerprint 분리.
- [ ] LLM JSON/citation output 확인. 잘못된 ID/quote/권위 출력이 거부됨.
- [ ] token이 CLI/log/config/index document에 들어가지 않음. 회사 반출·cache 규정 확인.
- [ ] real SDK v2와 실제 선택 하네스의 stdio 도구 호출 검증. SDK가 없으면 CLI 경로만 accepted 표시.

## F1 100+ inventory와 변경

- [ ] 실제 보유 전체 Git 목록을 등록. 실패/제외/미지원 repo와 ref를 집계하고 접근 불가 정보를 별도 노출하지 않음.
- [ ] 첫 update 후 100+ repo의 commit/coverage/재사용 vector 수 확인.
- [ ] 두 번째 무변경 update의 files_read=0/vectors_created=0 확인(모델/profile 변경 없음 조건).
- [ ] 실제 변경이 있는 repo에서 추가/수정/rename/delete 반영. 구 source evidence가 기존 byte를 유지.
- [ ] 모델 장애로 갱신이 실패해도 last-good snapshot 유지. 재개 시 성공 repo를 재작업하지 않음.
- [ ] 여유 공간·index/바이너리 cache 증가량·backup restore 확인. 대규모 운영에 필요한 GC/retention은 별도 구현.

## F2 실제 검색 품질

시작 gold는 30개 이상, release 전 다양성을 확보한 별도 holdout으로 확장한다. 숫자를 채우기보다 실제 질문을 포함한다.

| 그룹 | 예 | 필요한 gold |
|---|---|---|
| exact | 함수/클래스명 | repo,commit,path,symbol |
| 기능 탐색 | 사내 token 갱신 | 관련 구현과 decoy |
| 전체 탐색 | Jira API 모든 사용 프로젝트 | 직접/wrapper/docs-only/dependency-only 분류 |
| 기술 지식 | SSD 열 모델의 이산식 | 계산/parameter/unit/조건/test source |
| 재사용 | SDK를 대시보드에 연결 | 환경·인증·입출력·실행 결과 |
| 실패/없음 | 실제 없는 기능 | 검색 범위와 올바른 no_match/partial |

Hit@5와 Recall@k를 구분하고 한국어 alias 효과와 실제 embedding 효과도 분리한다. ‘전체’는 검사 coverage와 판정된 사용처 gold recall을 따로 보고한다. synthetic 120 repo의 40/40 literal 검출을 사내 의미 recall100%로 바꾸지 않는다.

## F3 원문·수식·활용

- [ ] 핵심 사실에 exact evidence ID/commit/path/범위가 있음.
- [ ] unit이 이름에서 추정됐으면 unknown/inferred. 예쁜 일반 수식을 사내 구현식이라고 단정하지 않음.
- [ ] code_expression source 일치, symbolic reconstruction의 가정·분기·clamp·scaling 보존.
- [ ] test 존재와 실행 성공 구분. 실제 실행을 원하면 기존 하네스에서 승인된 환경으로 실행하고 별도 receipt.
- [ ] prepare-use의 reference_only를 자동 ready로 변경하지 않음. API operation/credential/버전 확인이 선행됨.

## F4 성능

동일 corpus/snapshot/model/장비에서 최초 fetch·parse·embedding·LLM summary·no-op·small mutation·warm/cold search·evidence read·all scan을 각각 기록한다. 목표(실측 보장 아님): warm search payload p95≤2s, 제한 verified retrieval p95≤8s. 모델 답변 생성·원격 fetch·cold TLS/model 대기는 따로 포함/제외를 명시한다.

NumPy, SQLite version, vector dim, CPU/RAM, concurrent tasks, query sample 수를 기록한다. 실제 제약에서 목표 미달이면 profile/ANN을 검토하고 예외를 명시하지 수치를 낮춰 성공이라고 하지 않는다.

## G0~G3 현장 판정

G0=설치·두 모델 계약·read-only source, G1=100+index+incremental, G2=실제 Jira/SSD 원문과 gold 품질, G3=하네스와 실제 사용자 재사용. 회사에 필수인 미구현 parser/ACL/실행 연결이 있으면 해당 Gate는 blocked/partial이다. 단순 test 개수로 Accepted를 선언하지 않는다.
