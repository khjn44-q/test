# 목적 중심 미세 튜닝 가이드

## 1. 조정 순서

성능 숫자를 먼저 낮추기보다 원문 정합성→누락/오탐→응답시간→최초 비용 순서로 판단한다. source 권한·hash·commit 검증을 제거해서 빨라지게 하지 않는다. 같은 corpus·질문·모델 revision을 고정하고 한 번에 한 축만 바꾼다.

사내 LLM에게 요청할 기본 지시:

> 현재 코드와 실제 설정을 읽고, 이 문서의 최소 변경 경계를 지켜라. 변경 전후 같은 질문·동일 snapshot을 비교하라. 호출 수·latency·coverage·정답 source를 기록하라. synthetic fixture의 hit를 사내 의미 검색 품질로 바꾸지 마라. 원문·증분·권한 계약을 유지하고 변경한 fingerprint를 기록하라.

## 2. 설정으로 바꿀 수 있는 값

| 값/기본 | 언제 조정하는가 | 비용·무효화 | 확인 |
|---|---|---|---|
| index.chunk_chars=3000 | 긴 함수가 input 한도를 초과하거나 문맥이 짧음 | parser fingerprint 변화→새 parse/snapshot. vector는 동일 payload면 재사용 | source bytes 재조립, 단위/조건 누락 |
| index.max_file_bytes=2097152 | 유용한 파일이 too_large로 제외됨 | 허용 범위 변화, RAM 증가 | status 제외 사유·parser 메모리 |
| index.max_files=200000 | monorepo 파일 수 초과 | repo 한도; 조용히 일부만 처리하지 않음 | 예상 source bytes와 운영 예산 |
| index.fetch_depth=1 | 과거 이력 필요/호스트 shallow 미지원 | cache 네트워크·디스크. content parsing fingerprint는 유지 | 회사 Git 호환, 오래된 evidence 보존 |
| index.git_timeout=60 | 원격 Git 응답이 느림 | 기다림 증가. 최대600초 | source 오류와 인증 오류 분리 |
| index.embedding_batch_items=32 | 모델 호출당 overhead가 큼 | vector space 변화 없음 | 요청 quota, provider batch_items와 조합 |
| index.embedding_scope=all_text | 원문 dense 비용이 지나침 | summaries_only는 raw vectors 조회/생성 생략, raw lexical·scan 유지 | hidden utility/문서 없는 기능 Recall 하락 여부 |
| exclude_globs/dirs | vendor/generated/비밀/쓸모없는 대용량 | parser scope fingerprint 변화 | 중요한 내부 모듈을 실수로 제외하지 않았는가 |
| include_globs=[] | 제한된 경로만 처리하도록 명시 | 기본은 전체 적격 tracked text | 전체 조사 coverage_basis 확인 |
| provider batch_items=32 | HTTP batch 상한 조절 | vector 공간 무변경 | 응답 index alignment, 429 |
| provider max_input_chars | 모델 context/tokenizer 계약 맞춤 | 자동 truncation 없음 | prefix+symbol+source 포함 길이 |
| provider timeout/retries | 실제 서비스 지연 | 호출 중복/대기 비용 | 4xx 무한retry 금지 |
| LLM max_output_tokens | JSON이 잘리거나 과잉 생성 | LLM cache fingerprint 변화 | parse failure·불필요한 claims |

`max_chars`는 token/byte가 아니다. 한국어·코드·기술 기호의 tokenization을 회사 모델로 표본 확인한다. 서버가 토큰 한도를 알려주면 tokenizer 기반 adapter를 좁게 추가한다.

## 3. 코드의 좁은 튜닝 지점

| 파일 | 허용되는 좁은 변경 | 피할 것 |
|---|---|---|
| retrieval.py:ALIASES/terms | 실제 실패한 한국어·사내 약어 보조 | 일반 기술을 같은 개념으로 과도하게 합치기 |
| retrieval.py:rrf/search | cap, lane weight, per-repo 추천량 | 벡터/FTS 점수 직접 더하기, all scan에 top-k 적용 |
| retrieval.py:_dense | 승인 벡터 backend로 교체하는 경계 | provenance나 source ID를 backend docid로 교체 |
| chunks.py:chunk_file | 주 언어 parser와 의미 경계 개선 | generated text의 좌표를 Git 원문 좌표로 표시 |
| analysis.py:SYSTEM_PROMPT/PROMPT_VERSION | 팀 용어·공식 source-first 출력 강화 | evidence 없는 execution/policy 권위 부여 |
| analysis.py:summarize | 경로/공개 API 우선순위, max_sources 예산 | sample summary를 전체 repo 이해로 표시 |
| providers.py 또는 전용 adapter | endpoint/body/headers/stream 변환 | 임의 외부 fallback, token 로그, TLS off |
| mcp_server.py | 승인 SDK API 차이 | 검색 알고리즘을 MCP에 다시 구현 |

강한 식별자(`refresh_access_token`, `Client.search`)가 실제 심볼에 정확히 일치하면 dense/모델 호출을 건너뛴다. 짧은 일반 단어 `Jira`는 이 경로로 단정하지 않는다. 결과 mode와 warning에서 확인한다.

## 4. A/B 평가표

A: raw lexical/exact만. B: A+LLM summary embeddings(summaries_only). C: B+raw embeddings(all_text). 동일 embedding revision을 쓰고 raw·summary embedding 비용을 분리한다. 실제 정답이 있는 질문에서 다음을 기록한다.

- 탐색 Hit@5: 하나 이상 정답이 top5에 있는가.
- 다중 정답 Recall@20: 알려진 모든 source 중 얼마나 포함됐는가.
- 전체 조사 repo/callsite recall: gold 대상에서 측정. scope scan complete는 의미상 완전성 증명이 아니다.
- 원문 연결 정확도와 주장 의미 정확도를 분리.
- 최초 cold 응답, warm p50/p95, query embed, lexical/dense, answer generation을 분리.
- API/SDK를 실제 사용 가능하게 하는 데 걸린 시간과 추가 수정량.

평가 질문을 보고 튜닝한 뒤 같은 표현만 바꿔 holdout이라고 하지 않는다. 100개 저장소 수 자체보다 source bytes·chunk 수·vector 차원·변경량이 비용을 결정한다.

## 5. 100개 이상 운영에서 주의할 한계

현재 dense는 NumPy 가속 가능한 bounded exact scan이다. 최고 정확도 ANN 또는 대규모 전사 서비스로 포장하지 않는다. source units가 수백만 개이면 query latency가 선형 증가한다. 우선 named-identifier fast path, summaries_only A/B, 불필요한 생성/외부코드 제외를 적용한다. 그래도 raw dense recall이 중요하면 승인된 ANN backend를 해당 함수 경계에서 추가하고 snapshot/scope filtering 및 삭제 갱신을 검증한다.

NumPy가 없으면 stdlib dot-product fallback이 동작하지만 이번 120-repo dense 성능 수치는 NumPy가 있는 환경이다. 사내 PC에서도 동일한 수치를 보장하지 않는다. query HTTP latency와 SDK/CLI startup도 별도로 측정한다.

repo update는 직렬 publication이며 여러 repo의 네트워크/모델 요청을 한꺼번에 flood하지 않는다. WAN/모델 overhead가 실제 지배하면 source fetch에만 제한된 worker 수를 적용하거나 batch coordinator를 추가한다. SQLite connection을 여러 thread에 그냥 공유하지 않는다.

## 6. 중단 기준

새 그래프DB/포털/프레임워크 도입 전에 실패 query, 기존 방식의 부족, 기대 이득, 추가 운영비, rollback 방법을 한 페이지에 기록한다. 사내 model endpoint 연결 때문에 이미 검증한 Git/SQLite 코어 전체를 새로 작성하지 않는다. 개선이 holdout에 이득이 없으면 제거한다.
