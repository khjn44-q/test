# 사내 모델 연결 계약

## 1. 제공된 자원의 역할

LLM은 사람이 읽을 수 있는 프로젝트·기능·지식 설명을 생성한다. 임베딩 모델은 입력 text를 벡터로 변환해 관련 후보를 찾는다. 임베딩으로 축약문을 생성하는 구조가 아니다. 사내 모델을 이미 제공받는 조건이므로 local weights·GPU·별도 reranker 서비스는 강제하지 않는다.

코어는 `embed(texts, role)`와 `complete(messages)`만 요구한다. 어떤 하네스를 쓰는지는 이 계약과 무관하다. LLM 미설정 시 `analyze`가 source pack을 반환하므로 승인된 현재 하네스가 해석할 수도 있다.

## 2. JSON 설정

`examples/config.corporate.example.json`을 복사하고 **모든 예시 값**을 실제 계약으로 바꾼다. 파일에는 token 값이 아니라 환경변수 이름을 둔다.

| 설정 | 의미 | 주의 |
|---|---|---|
| endpoint 또는 endpoint_env | 정확한 API 전체 URL | 두 필드를 동시에 사용하지 않음. /v1 등의 suffix를 자동 덧붙이지 않음 |
| model | 서비스가 받는 모델 ID | deployment ID와 모델명이 다르면 회사 계약을 따른다 |
| revision | 승인된 불변 모델 revision | 같은 이름으로 backend가 바뀌면 revision을 바꾼다 |
| dimensions | 실제 embedding dimension | 반환 벡터 차원과 반드시 동일 |
| api_key_env | token을 읽을 환경변수 이름 | 비워 두면 auth header를 붙이지 않음 |
| auth_header/auth_prefix | 예: Authorization/Bearer | 사용자 token을 로그·fingerprint에 포함하지 않음 |
| ca_file | 회사 CA bundle 파일 | TLS 검증을 끄는 옵션은 제공하지 않음 |
| query_prefix/document_prefix | 모델별 instruction | query/document 규약이 다른 모델은 정확히 구분 |
| response_format | embedding `openai` 또는 `vectors` | 이 문자열은 wire 형식 이름이며 외부 OpenAI 호출을 뜻하지 않음 |
| max_input_chars | 단일 입력 character 한도 | token 한도가 아님. 모델 tokenizer/서비스 계약에 맞게 보수적으로 설정 |
| max_batch_chars/batch_items | 요청 합계·항목 한도 | prefix 포함. 서버의 request size·quota와 대조 |
| timeout/retries/retry_backoff | 제한된 장애 처리 | 429/일부5xx/연결 장애만 retry. 인증/4xx를 무작정 반복하지 않음 |
| max_response_bytes | 응답 크기 상한 | JSON 파싱 전 제한 |
| security_domain | cache 보안 경계 식별자 | 다른 데이터 허용 경계를 같은 이름으로 합치지 않음 |
| preprocessing_revision | 의미 입력 처리 버전 | prefix·정규화/토큰 처리 변경을 명확히 기록 |
| json_output | LLM JSON 응답 요청 옵션 | 서비스가 지원하지 않으면 false로 두고 prompt 계약 사용 |
| max_output_tokens | LLM 출력 한도 | 서버의 field 이름/범위를 확인 |

최소 환경변수 예시(실제 secret을 문서에 복사하지 않음):

```powershell
$env:REFS_EMBEDDING_URL = 'https://approved-model-host.example.invalid/embeddings'
$env:REFS_LLM_URL = 'https://approved-model-host.example.invalid/chat/completions'
$env:REFS_EMBEDDING_TOKEN = '<회사에서 발급한 비밀값>'
$env:REFS_LLM_TOKEN = '<회사에서 발급한 비밀값>'
python -m refs --config refs.company.json doctor --probe-models
```

`doctor`의 기본 실행은 외부 모델 호출을 하지 않는다. `--probe-models`는 실제 요청이므로 정책을 확인한 뒤 명시적으로 실행한다. 실패한 probe는 partial을 반환한다.

## 3. 기본 embedding wire 형식

요청:

```json
{"model":"internal-embed","input":["문서 A","문서 B"],"encoding_format":"float"}
```

기본 응답:

```json
{"data":[{"index":0,"embedding":[0.1,0.2,0.3]},{"index":1,"embedding":[0.3,0.2,0.1]}]}
```

또는 `response_format="vectors"`일 때:

```json
{"vectors":[[0.1,0.2,0.3],[0.3,0.2,0.1]]}
```

예시 차원3은 문서용이다. 실제 dimensions를3으로 임의 설정하지 않는다. data 순서가 바뀌어도 index로 복원한다. 중복/누락 index, count mismatch, bool/문자열/NaN/Inf/zero vector, 잘못된 차원은 거부한다. 반환 벡터는 L2 정규화 후 little-endian float32로 저장한다.

큰 입력은 임의 truncate하지 않고 `INPUT_TOO_LONG`으로 실패한다. chunk 크기를 줄이거나 승인 tokenizer로 분할하는 명시 변경을 해야 한다. symbol header와 prefix도 입력 길이에 포함된다.

## 4. 기본 LLM wire 형식

```json
{"model":"internal-chat","messages":[{"role":"system","content":"..."},{"role":"user","content":"..."}],"temperature":0,"max_tokens":2048}
```

응답의 `choices[0].message.content`는 JSON 문자열이어야 한다. tool calls, multipart content, streaming SSE, 자동 모델 fallback은 이 어댑터가 지원하지 않는다. 회사 gateway가 다른 계약이면 전용 adapter를 추가한다.

생성 내용 계약은 `analysis.py:SYSTEM_PROMPT`와 `_validate`가 정본이다.

```json
{"claims":[{"statement":"확인한 동작","kind":"knowledge","epistemic":"code_observed","citations":[{"evidence_id":"실제로 전달된 ID","quote":"원문에 정확히 있는 비어 있지 않은 문장"}]}],"unknowns":["현재 환경에서 실행하지 않음"]}
```

허용 kind: capability/knowledge/formula/usage. epistemic: code_observed/docs_declared/test_specified/model_inferred. 실행 성공·회사 정책·담당자 확인 권위는 모델이 부여할 수 없다. formula의 code_expression은 literal 근거를 요구하고 symbolic_reconstruction은 model_inferred여야 한다.

긴 source는 source evidence span을 쪼개며 잘린 범위가 생기면 coverage에 남긴다. max_model_calls를 넘으면 partial이다. citation check를 통과해도 의미적 entailment, 과학적 정확도, 올바른 단위·가정은 별도 평가 대상이다.

## 5. 캐시와 모델 교체

Embedding key = space fingerprint + role + payload hash. 이름/경로/commit만 변경되면 같은 payload vector를 재사용한다. query prefix와 document prefix는 분리한다.

새 revision/dimensions/prefix/domain이면 새로운 vector space를 생성한다. 기존 space와 섞지 않는다. 같은 source는 재파싱할 필요 없이 `update --all`로 새 space를 채울 수 있다. 이전 space 자동 삭제는 아직 없으므로 디스크 사용량을 확인한다.

LLM note cache는 모델 fingerprint(출력 설정 포함), prompt version, 질문, 실제 evidence IDs, model-call budget에 묶인다. source tree가 바뀌면 관련 note를 보수적으로 stale 처리한다. 새 prompt/추출 규칙으로 재분석하려면 PROMPT_VERSION을 올린다.

## 6. 커스텀 어댑터가 지켜야 하는 테스트

`tests/test_providers.py`의 실제 loopback HTTP fixture를 회사 wire format으로 바꿔 재실행한다. 테스트 서버의 고정 vector를 실제 의미 모델 성능으로 보고하지 않는다. 필수 반례: 응답 순서 변경, 길이/차원 불일치, NaN/0, 429 retry, 401 즉시 실패, timeout, 비정상 JSON, redirect, 과대 응답, 토큰 미설정, query/document instruction.

TLS/CA·proxy는 회사 네트워크에서 별도 smoke한다. urllib의 표준 proxy 환경변수를 사용하며 TLS 검증 off로 우회하지 않는다. 코드에 임의 header/body mapping eval 기능을 넣지 않는다.
