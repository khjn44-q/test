# REFS Runtime v3 — 실행 설계

상태: 새 재구현의 설계 기준선. 과거 분실 구현을 복구한 것이 아니다.
정본: 이 문서와 실제 src/ 코드. provenance/INPUT_DESIGN.md는 이전 TypeScript/QMD 설계로, 요구사항 근거만 보존한다.

## 목적과 현실적 제약
100개 이상의 읽기 전용 사내 Git에서 코드·수식·전문지식을 발견하고, 불변 원문으로 드릴다운하며, 기존 하네스가 재사용하도록 근거 묶음을 제공한다. 사내 LLM은 요약·해석, 임베딩 모델은 검색용 벡터 생성 역할이다. 임베딩 모델 자체가 읽을 수 있는 프로젝트 요약을 작성하는 것은 아니다.

서버, QMD, 별도 reranker, graph DB, 로컬 모델 weights는 필수가 아니다. Python 3.11+와 Git, SQLite FTS5를 기본으로 한다. NumPy는 dense scan 가속에 선택적으로 사용한다. MCP는 공식 Python SDK 선택 의존성이고 CLI와 같은 코어를 호출한다. Git 쓰기/push·수집 소스 실행·임의 셸 실행은 제공하지 않는다.

## 선택 비교
1. 기존 QMD/TypeScript 유지: 로컬 모델 실행·네이티브 의존과 사내 endpoint 어댑터의 중복이 생긴다. 이번 자원 제약에는 기본 선택하지 않는다.
2. Python/SQLite + 사내 HTTP provider: 설치·운영 최소, Git/원문/검색 계약을 직접 통제. 선택한다. 작은 검증된 모듈만 작성한다.
3. 중앙 서비스/ANN/SCIP 전면 도입: 현장 규모·언어·권한 요구가 확인되기 전에는 과도하다. 확장 경계를 문서화하되 현재 구현하지 않는다.

## 핵심 구조
```mermaid
flowchart LR
 G[Read-only Git] --> I[Git objects / chunking]
 I --> B[Content-addressed local blob cache]
 I --> D[SQLite immutable snapshots + FTS5]
 I --> E[Approved embedding HTTP provider]
 E --> V[Fingerprint-separated vector cache]
 Q[CLI / optional MCP / harness] --> C[Common core]
 C --> D
 C --> V
 C --> B
 C --> L[Optional approved LLM]
 L --> N[Citation-checked analysis notes]
 N --> D
```

## 효율 관련 주요 변경
- 전체 DB 사본을 매 update마다 만들지 않는다. immutable snapshot/파일 mapping과 공유 chunk/vector를 사용하고, repo active pointer는 짧은 SQLite transaction으로 교체한다.
- 100개 중 한 repo만 바뀌면 그 repo만 처리한다. 해당 repo에서 같은 blob은 재파싱하지 않고 같은 embedding payload는 재전송하지 않는다.
- 경로·commit ID를 embedding payload에 넣지 않는다. 단순 rename과 commit 변경은 벡터를 재사용한다.
- 파일 단위 Git cat-file 프로세스를 반복하지 않고 batch로 읽는다. 한 배치의 총 bytes와 timeout을 제한한다.
- lexical / exact / dense 결과를 RRF로 결합한다. 프로젝트 요약을 원문 검색의 필수 선행 필터로 쓰지 않는다.
- vector는 float32로 저장하고 bounded batch exact cosine scan을 기본으로 한다. 수백만 chunk ANN 성능을 보장하지 않는다. 실제 크기·p95로 backend 교체를 결정한다.
- LLM 요약은 명시적인 summarize/analyze 단계이며 raw source 인덱싱을 막지 않는다. summary coverage와 처리 실패를 표시한다.

## 데이터와 일관성
Repository / Snapshot / SnapshotFile / Blob / Chunk / Embedding / Evidence / Note / Session.
Snapshot에는 repo, commit, parser/config fingerprint, coverage가 있다. Source evidence는 snapshot, path, Git blob OID, SHA256, byte/line span에 연결한다. Git objects와 raw file hash는 서로 다르다. UTF-8/CRLF를 보존하고 symlink/submodule/LFS/binary/비밀 경로는 분리 표시한다.

갱신은 repo 단위로 원자적이다. update --all은 전체 Git의 공통 시점 transaction이 아니며 실패한 repo는 이전 snapshot과 stale 상태를 유지한다. query session은 조회 시 선택한 snapshot map을 고정한다. 권한(등록 repo enable/disable)은 현재 상태를 항상 적용한다. 중앙 사용자별 ACL은 이 로컬 제품의 지원 범위가 아니다.

## 검색·드릴다운
- ranked: exact identifier + FTS5 + 선택 dense, top results와 evidence.
- all/scan: 선택된 모든 적격 원문 파일에서 literal 또는 내장 detector 조건을 검사. chunk 경계와 top-k에 의한 누락 방지. cursor는 scope와 snapshot에 묶인다.
- inspect/evidence/trace/compare: 불변 원문, 전체 파일 페이지화, syntax/lexical 참조 후보, 버전 diff.
- deep: 질문에 필요한 evidence pack을 기존 하네스 또는 사내 LLM에 제공. arbitrary code execution 없음.
- prepare-use: 진입점/의존·테스트·예제 근거와 미확인 조건을 반환. 검색 성공을 API 사용 권한·실행 성공으로 해석하지 않는다.

## 모델 경계
HTTPS 기본, loopback HTTP는 테스트 시에만 명시 허용. 인증은 환경변수 참조. TLS 검증 off 없음. redirect 거부, 제한된 timeout/retry/backoff, batch bytes/items 제한, 응답 크기 제한. 모델 fingerprint에는 endpoint origin, model/revision/dimension/query/document prefix/normalization/domain이 포함된다. 토큰은 fingerprint·로그에 포함하지 않는다.

LLM이 반환하는 근거 ID와 quote는 실제 input 원문과 대조한다. 통과는 reference validation이며 entailment/수식 의미 검증이 아니다. execution_verified/policy_normative를 모델 출력으로 허용하지 않는다. 원문은 지시가 아닌 데이터다.

## 배포·실험
로컬 설치형이 기본. 공식 MCP SDK를 설치할 수 없으면 CLI는 동작하고 MCP는 명확한 missing dependency 오류를 준다. cloud chat이 로컬 PC에 접근할 수 있다고 가정하지 않는다.

공개 Git 100개 테스트는 네트워크 획득 성공 여부부터 기록한다. 실패 시 합성 Git 100개 규모 시험과 공개 코드 일부 시험을 구분하고 공개 100개 성공이라고 표시하지 않는다. 실제 사내 모델이 없으면 fake provider로 wiring만 검증하고 의미 검색 품질은 미검증이다.

## 완료 수준
새 소스·테스트·실행 로그·HANDOFF·ZIP CRC/sha 검증이 필수. 구현량으로 99%/100%를 주장하지 않는다. 지원 범위는 최종 acceptance matrix에 기록한다.

## 최종 구현 세부와 비용 경계

SQLite 한 DB의 주요 객체는 repositories/snapshots/snapshot_files/units/vectors/notes/evidence/sessions/jobs다. [실제 DDL](../contracts/CATALOG.sql)을 참고한다. `snapshot_files.parse_key`로 같은 blob의 chunk 집합을 공유하며, 캐시 키는 raw content와 parser 설정에 연결된다. mapping에는 path·Git blob·commit을 보존해 같은 내용의 복사도 발생 위치별로 돌려준다.

`all_text`는 원문 chunk와 생성 요약을 벡터화한다. `summaries_only`는 원문 dense 경로를 끄고 생성된 요약만 벡터화한다. 두 모드 모두 모든 적격 원문 FTS/전체 scan/원문 조회를 보존한다. 요약 표본에서 빠진 작은 함수의 자연어 발견 가능성은 감소할 수 있으므로 품질 A/B로 선택한다. 이전 raw vector를 자동 삭제하지 않으며 이를 사용하지 않을 뿐이다.

FTS 후보에서 scope를 후보마다 120회 반복 탐색하는 SQLite query plan이 규모 시험에서 발견되었다. `+f.snapshot_id` 조건으로 해당 복합 인덱스 선택을 제외하고 parse_key lookup을 사용하도록 조정했다. scope 검사 자체와 LIMIT 전 필터는 유지했다. 이 선택을 보편적인 SQL 최적화법으로 확대하지 않고 `test_scale_regression.py`에 특정 회귀를 고정했다.

Dense는 NumPy가 있으면 512행 block float32 dot product, 없으면 stdlib bounded scan을 수행한다. 텍스트 본문은 top 후보 선택 이후에만 읽는다. 최고 메모리는 source corpus·SQLite·Python chunking·vector block의 합이며 100개 repo라는 숫자만으로 결정되지 않는다. 7.5MB 합성 코드의 결과를 수백GB corpus에 외삽하지 않는다.

## 갱신 상태와 일관성

```mermaid
stateDiagram-v2
    [*] --> planned
    planned --> running: OS writer lock
    running --> repo_staging: resolve commit and compare files
    repo_staging --> repo_published: short atomic transaction
    repo_staging --> repo_failed: source or model error
    repo_failed --> running: next repository, old active retained
    repo_published --> running: next repository
    running --> completed: all succeeded
    running --> partial: failures or explicit cancellation
    completed --> [*]
    partial --> [*]
```

Snapshot ID는 commit과 parser/filter 설정을 함께 반영한다. model-space는 별도 fingerprint다. 임베딩을 나중에 연결해도 raw source를 Git에서 다시 읽을 필요가 없다. `rebuild`는 재분할·mapping 재작성이고 동일 vector payload는 여전히 재사용된다. 모델 재생성이 필요하면 revision/preprocessing fingerprint를 변경해야 한다. 이 차이는 API/튜닝 문서에 고정한다.

전체 update의 repo별 성공 시각은 다를 수 있다. 세션은 그 시점의 snapshot map을 고정해 mixed-freshness를 명시한다. 이 버전의 enable/disable은 로컬 사용자가 명시한 정책이며 Git 원격 ACL 철회 감지 서비스는 아니다. 권한이 사라진 원본의 로컬 복제까지 자동 회수한다고 약속하지 않는다.

## 지식 생성과 드릴다운

```mermaid
flowchart LR
    Q[사용자 질문] --> K[원문 검색]
    K --> E[불변 evidence ID]
    E --> A[bounded context pack]
    A --> L[승인 LLM]
    L --> V[ID quote 권위 검증]
    V --> N[claim note plus source refs]
    N --> E
    E --> C[commit blob byte line]
    C --> T[관련 호출 테스트 후보]
```

원문 ID·quote 검증은 entailment를 증명하지 않는다. 내부 모델이 quote와 무관한 주장을 만들 수도 있다. 결과에 `model_inferred`/unknown을 남기고 사용자가 source를 확인할 수 있게 한다. 분석 LLM 응답에서는 큰 원문을 다시 중복 반환하지 않고 source refs를 제공한다. LLM 미설정 모드에서는 하네스가 분석할 실제 context를 반환한다.

## 배포 형태

```mermaid
flowchart TB
    Z[동일 설치 ZIP / wheel] --> A[사용자 A 로컬 CLI MCP]
    Z --> B[사용자 B 로컬 CLI MCP]
    A --> DA[A 권한의 전용 index]
    B --> DB[B 권한의 전용 index]
    DA --> G[기존 Git]
    DB --> G
    A --> M[승인 모델 endpoint]
    B --> M
    C[향후 중앙 검색·SSO] -. 별도 미구현 .-> G
```

여러 사용자가 같은 SQLite를 공유하는 서버형 배포는 지원하지 않는다. 앱 배포와 private 데이터 배포를 구분하며 중앙 ACL·retention·remote MCP·SSO는 후속 작업이다.
