# 성능 실험 — 실제 측정과 적용 한계

## 고정한 조건

최종 소스 SHA-256: `a20585051cc9e7c372067d08795a0aa299ae2a84b9109a909a1325135bf389d6`. `scale120-final.json`에 같은 digest가 기록되어 있다. 독립된 **120개 합성 local Git 저장소**, tracked 파일 5,400개, 원문 7,511,782bytes, 최초 code/source units 77,440개. 생성한 함수·fixture를 실행하지 않고 검색·인덱싱만 수행했다.

1,024차원 SHAKE 기반 **모의 벡터**이며 언어·코드 의미 모델이 아니다. NumPy가 있는 Linux에서 측정했다. 첫 실행은 cold OS cache를 강제로 비운 시험이 아니므로 ‘완전 cold’라고 하지 않는다. p95 표본은 16개로 작고 이 표본에서는 거의 최대값이다.

| 측정 | 실제 결과 | 포함 범위 |
|---|---:|---|
| 최초 raw index | 18.727s | 이미 만들어진 local Git 읽기·parse·FTS·metadata |
| 모의 벡터 backfill | 19.707s | fixture 벡터 생성·SQL·캐시. 실제 model/network latency 제외 |
| 문자열/식별자 warm p50 / p95 | 8.26 / 49.62ms | 혼합 lexical query 집합 |
| hybrid warm p50 / p95 | 1760.78 / 2384.33ms | natural-string queries, NumPy exact dense+FTS+fixture query vector |
| whole-file literal scan | 504.23ms | 적격 전체 파일, 기대 Jira route 40개 repo |
| 전체 무변경 update | 946.31ms | 120개 확인; raw read 0, new vectors 0 |
| 4개 repo 변경 update | 1000.45ms | add/delete/rename/edit, raw read 3, new vectors 2 |
| rename 재임베딩 | 0개 | body payload 동일 |
| DB / 압축 source cache | 278.35 / 1.34MiB | raw vectors와 metadata 포함 |
| Python process peak RSS | 117.00MiB | Linux ru_maxrss, child process 전체 포함 값 아님 |

Known-gold: exact identity 질문4개 Hit@5=1, literal API route 기대40repo/발견40repo. 일반 자연어 정확도·전사 API 사용 여부 recall을 뜻하지 않는다. 전체 원문 7.5MB는 실제 대형 repo100개의 대표 분포가 아니다. 디스크·vector수·file size·언어 분포·변경량을 현장에서 다시 측정해야 한다.

## 해결한 병목

초기 FTS SQL이 candidate마다 snapshot scope를 반복 probe했다. VM instruction-budget 회귀로 원인을 고정하고 SQL planner 조건을 좁게 변경했다. dense도 큰 text를 스캔하면서 로드하지 않고 identity/vector만 읽은 다음 top source를 가져오게 바꿨다. 이전 중단/부분 profile 로그는 역사 자료이며 최종 시간과 혼합하지 않는다.

## 재실행

```text
python bench/scale.py --repositories 120 --files 40 --functions 8 --dimensions 1024 --queries 16 --output scale120.json
```

새 scratch 폴더를 생성하며 원본 사용자의 Git을 변경하지 않는다. 이 시험은 모의 model wiring/처리 성능만 검증한다. 공개 실자료 시험은 `bench/public.py --execute`로 명시 수행한다. 현재 환경의 공개100은 DNS 차단으로 attempted/indexed=0이다.

## 아직 최적이라고 주장할 수 없는 것

실제 embedding endpoint 왕복시간, tokenizer입력 한도, 서버 batching정책, 한국어 의미품질, multiuserconcurrency, Windows file/process overhead는 미측정이다. 2초 search목표를 실제 모델까지 충족했다고 표시하지 않는다. 본 run의 hybrid p95도 2초보다 크다. summary-first 비용/Recall A/B와 ANN 확장은 현장 지표가 필요할 때 진행한다.
