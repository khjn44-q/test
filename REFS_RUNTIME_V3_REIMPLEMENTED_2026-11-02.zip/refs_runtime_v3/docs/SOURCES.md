# 근거·연구 기록과 새 설계 판단의 구분

## 입력 자료

사용자가 제공한 기존 REFS 설계/계획/검증 보고서와 이 대화의 후속 요구를 사용했다. `provenance/`는 그 출처 기록이다. 이전 검증의 59개 통과를 이번 Python 제품 시험 수에 합산하지 않는다. 잃어버린 Python 구현을 읽거나 복원했다고 주장하지 않는다.

유지한 요구: read-only Git, 100+ repo, 요약·임베딩, 원문 drilldown, 기술 지식, 수동 증분 갱신, 하네스 독립, ZIP 하나. 변경한 결정: Python/SQLite 단일 로컬 코어, 사내 endpoint, separate reranker/QMD 불필요, repo별 짧은 transaction, raw/summary vector profile, 선택 official MCP adapter.

## 공개 1차 근거

확인 수준은 **공식 문서 읽기**다. 실제 배포 라이브러리 실행 여부와 혼동하지 않는다. 기준 작업일 2026-11-02, 웹 페이지는 캐시될 수 있으며 사내 exact release는 현장 lock으로 고정한다.

| 원문 | 반영 | 실제 실행 검증 |
|---|---|---|
| [Git cat-file](https://git-scm.com/docs/git-cat-file) | 불변 object와 batch bytes | 설치된 Git의 로컬 fixture에서 검증 |
| [Git fetch](https://git-scm.com/docs/git-fetch) | 지정 ref·shallow 읽기 cache | local file remote fixture; 외부 DNS 차단 |
| [SQLite FTS5](https://www.sqlite.org/fts5.html) | external content FTS, BM25 | 실제 SQLite 3.46.1에서 검증 |
| [SQLite optimizer §8.1](https://www.sqlite.org/optoverview.html) | 특정 query plan의 unary `+`로 인덱스 조건 제외 | 실제 120 scope regression 및 VM budget 검증; 다른 버전 재측정 |
| [Python sqlite3](https://docs.python.org/3/library/sqlite3.html) | transaction/Backup API | 실제 DB backup→reopen 검증 |
| [MCP Python SDK v2 실행](https://py.sdk.modelcontextprotocol.io/run/) | `MCPServer`, decorator, stdio | **SDK 미설치, protocol 미검증** |
| [MCP Python SDK 시작](https://py.sdk.modelcontextprotocol.io/get-started/) | optional client/server test 방법 | fixture registry는 SDK 대체 검증이 아님 |
| [Agent Skills 형식](https://agentskills.io/specification) | 작은 SKILL.md와 reference guide | 하네스 activation 미검증 |

## 자체 설계·실험

RRF 가중치·후보 상한·batch 크기·timeout·chunk_chars·100+ 목록 처리 전략은 본 프로젝트의 설계 선택이다. 공식 제품의 성능 보장값이 아니다. source-span/권위검사/fingerprint/scoped candidate·benchmark 테스트가 실제 선택의 검증 근거다.

`bench/public_repositories.json`의 100 URL은 시험 입력 후보이며 유지보수·license·download 성공을 확인한 목록이 아니다. 실제 공공 Git 100개 성능 수치는 없다. `scale120-final.json`은 생성한 120개 Git, SHAKE 기반 모의 1024차원 벡터, 작은 텍스트 파일 분포의 처리 성능이다. 의미 검색 평가나 실제 사내 모델 처리율로 해석하지 않는다.
