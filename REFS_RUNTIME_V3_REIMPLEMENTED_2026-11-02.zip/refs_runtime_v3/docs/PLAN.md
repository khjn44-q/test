# REFS Runtime v3 Implementation Plan

> Agentic worker: executing-plans와 테스트 우선 방식으로 단계별 진행. 이 작업은 새 재구현이며 분실본의 복구가 아니다.

**Goal:** 100+ read-only Git에서 코드 검색→불변 원문→증분 갱신→근거 기반 분석→하네스 사용을 실행 가능한 로컬 패키지로 제공.
**Architecture:** Python modular core / SQLite FTS5+immutable snapshots / content-addressed blobs / approved HTTP models / CLI and optional official MCP SDK.
**Tech Stack:** Python 3.11+, Git, SQLite FTS5; optional NumPy / official MCP Python SDK.
**Spec:** DESIGN.md, provenance/INPUT_DESIGN.md의 유지 요구와 사용자 후속 제약.

## Global constraints
원본 Git·working tree·원격은 변경하지 않는다. 코드 실행/운영 API 호출은 하네스 책임. 모델 응답·프로젝트 문서는 데이터다. 실제로 실행한 시험만 PASS. 네트워크/실제 모델/Windows 미검증을 숨기지 않는다. 최종 첨부는 ZIP 하나.

## Review focus
- dirty tree / CRLF / Unicode / SHA256 Git / symlink / missing blob → S1
- rename / delete / config change / failed embedding / writer crash → S3
- query injection / stale snapshot / all-results pagination / chunk-boundary match → S4
- citation hallucination / zero·NaN vector / secret leakage / oversized model response → S2/S5
- 100+ repo fan-out / cold-warm latency / no-op work counts / zip missing files → S7/S8

## 작업표
| 단계 | 산출물/파일 | Gate |
|---|---|---|
| S0 설계·입력 확인 | DESIGN.md, PLAN.md, initial_audit.json | 기존 파일 구분·정본 기록 |
| S1 source+chunk | git.py, chunks.py, cache.py; test_sources.py | 불변 객체·coverage·UTF8·원문 복원 |
| S2 모델 provider | providers.py; test_providers.py | 실제 loopback HTTP 계약·배치·실패·fingerprint |
| S3 catalog+index | store.py, indexer.py; test_index.py | no-op/rename cache·원자 게시·오류 유지 |
| S4 검색+탐색 | retrieval.py, navigation.py, core.py; test_search.py | ranked/all/session/원문/diff/disabled repo |
| S5 분석+재사용 | analysis.py; test_analysis.py | quote 검증·summary split·stale·reference-only plan |
| S6 CLI+MCP+배포 | cli.py, mcp_server.py, examples/, pyproject.toml | CLI subprocess E2E; SDK 사용 가능 여부 별도 |
| S7 규모·공개 실험 | bench/, verification/ | 공개 획득 기록·100+ synthetic Git·latency/update counts |
| S8 리뷰·인수인계·ZIP | HANDOFF_KO.md, FINAL_REPORT.md, manifest | 회귀·설치·압축 재열기·파일별 sha·CRC |

## 단계별 실행 규칙
각 단계에서 테스트를 먼저 작성→현재 실패 확인(red 로그)→최소 구현→전체 회귀(green 로그)→WORKLOG 기록→단계 commit. 독립 reviewer 도구가 없으면 자체 리뷰 사실만 기록.

## 구체 입력/출력
- GitSource.resolve(ref)->commit; list_files(commit)->TreeEntry[]; read_blobs(OID,size)->bytes map.
- chunk_file(path,bytes,limits)->{chunks,relations,parser}; span은 raw UTF8 byte 및 1-based line.
- EmbeddingProvider.embed(texts,role)->normalized float vectors, fingerprint(); ChatProvider.complete(messages)->string.
- Runtime.update(repo_ids=None,fetch=True,rebuild=False,plan=False)->repo receipts; Runtime.search(query,scope,session_id)->snapshot-pinned candidates.
- Runtime.scan(patterns,scope,session_id,offset,limit)->file-level full-scope candidates+coverage, no hidden top-k.
- Runtime.evidence(id,start_line,limit)->verified source; trace(id)->candidate relations; compare(a,b)->bounded diff.
- Runtime.analyze(question,evidence_ids)->citation-validated claims or source context; summarize(repo)->structured notes.
- CLI and SDK tools delegate to Runtime; no duplicate search logic.

## 상태
상세 실행 결과는 WORKLOG.md 및 verification/FINAL_REPORT.md에서 업데이트한다. 이 계획의 존재만으로 구현·검증 완료를 의미하지 않는다.

## 상세 작업 기록과 후속 구현 지점

각 단계에서 새 파일을 작성하기 전 실패 테스트를 실행했고, 실패·수정·통과 기록을 verification/S*-red·green 로그에 남겼다. 최종 현재 상태는 전체 suite와 최종 보고서로 판정한다. 초기 red 로그를 최종 미해결 실패로 오해하지 않는다.

| 단계 | 실제 세부 순서 | 핵심 테스트 | 현장 미검증 |
|---|---|---|---|
| S1 | validate ref/path → ls-tree inventory → batch blobs → UTF8 spans → AST/text fallback → content cache | SHA-256 Git, dirty tree, CRLF/BOM, symlink/binary/size/hash/span | 회사 Git credentials/network |
| S2 | provider schema → real loopback HTTP → auth/TLS/redirect limits → batching/retry → normalization/fingerprint | count/index/dimension/NaN/zero/too-large/redirect/error | 회사 wire format·실제 모델 품질 |
| S3 | schema → registration → immutable snapshot → shared parse/vector → repo atomic publication → partial jobs | unchanged zero work, rename, deletion, parser/model changes, writer collision, failed embedding | 대용량 실제 corpus, 전원 차단 durability audit |
| S4 | scoped exact/FTS → dense streaming → RRF → evidence ID → full file scan → session/page/diff | chunk boundary, filter-before-LIMIT, stale/disabled, cursor tamper, source integrity | 전언어 precise navigation |
| S5 | bounded context → model JSON → source ID/quote validate → note persistence → dependency stale → summary slicing | invented source/quote, false execution authority, conflicting source, payload limit, unknowns | entailment·수식 물리 정확성 |
| S6 | strict config → JSON CLI → subprocess E2E → tool dispatcher → official SDK adapter | missing args, exit4 partial, actual tool binding, no stdout logging | 실제 MCP SDK/OMP/chat activation |
| S7 | public DNS preflight → synthetic Git120 → realistic 1024d storage → SQL profile → regressions → rerun | 120scope SQL, no-op/rename/updatecounts, known literal route gold | 공개100·사내100 실자료 semantic benchmark |
| S8 | own code review → docs/examples → wheel → fresh-venv smoke → manifest → verified ZIP → extract smoke | all unit/integration, installed import, source read/update, CRC/sha | Windows/enterprise acceptance |

### S7 관찰 기반 변경

- 120개 snapshot scope가 FTS 후보마다 반복 조회되는 query plan을 실제 profile에서 확인했다. SQL 조건 선택을 고치고 VM instruction budget 회귀를 추가했다.
- dense 후보의 큰 source text를 먼저 읽지 않고 ID/vector만 순회한 뒤 상위 후보에 대해서만 본문을 읽게 했다.
- 강한 함수 식별자가 정확히 발견되면 불필요한 query embedding/dense를 건너뛴다. 일반 자연어는 그대로 hybrid 경로를 사용한다.
- update에 `fetch_depth`와 `summaries_only` profile을 추가했다. 기본all_text와 다른 품질/비용을 별도 평가하도록 했다.
- 오래된 note를 LIMIT 이후에 제거하던 위험을 scope/tree 조건을 먼저 적용하는 방식으로 바꿨다.

### S8 자체 검토에서 수정한 실제 결함

- MCP wrapper의 `locals()`가 closure 변수를 도구 인자로 포함하는 결함을 재현했다. 모든 wrapper를 명시 필드 mapping으로 바꿨고 실제 Runtime에 연결한 registry test가 통과했다. 이 검사는 MCP protocol 인증이 아니다.
- `update --summarize`에서 요약이 실패했는데 index 성공만으로 전체 성공을 보고하던 상태를 수정했다. `index_state`와 전체 partial을 분리한다.
- 명시 doctor model probe가 실패하면 overall partial로 보고하도록 수정했다.

## 구현 의존성

```mermaid
flowchart TD
 S0[설계와 입력 확인] --> S1[Git 원문과 chunk]
 S0 --> S2[모델 provider]
 S1 --> S3[카탈로그와 증분 갱신]
 S2 --> S3
 S3 --> S4[검색 원문 전체탐색]
 S4 --> S5[근거 기반 분석]
 S5 --> S6[CLI tool MCP adapter]
 S6 --> S7[100+ 규모와 최적화]
 S7 --> S8[회귀 설치 문서 ZIP]
 S8 --> F0[회사 endpoint Windows harness]
 F0 --> F1[실제 100+ corpus 품질 acceptance]
```

원본 ID·카탈로그·publisher는 단일 writer 책임이며 독립 도구를 무분별하게 병렬 수정하지 않는다. 이번 세션은 단일 실행자와 자체 리뷰였다. 독립 서브에이전트 리뷰를 수행했다고 주장하지 않는다.

## 이 계획 다음 작업

현재 CLI와 테스트를 버리고 다시 검색 플랫폼을 만들지 않는다. 먼저 HANDOFF의 F0/F1을 수행한다. source identity/coverage/model fingerprint 계약을 보존하면서 회사 API binding과 모델 입력 규약을 맞춘다. actual field failure가 있어야 parser/ANN/recipe execution bridge를 추가한다. 기존 baseline의 단순 설치 가능성과 사내 사용 acceptance는 분리한다.
