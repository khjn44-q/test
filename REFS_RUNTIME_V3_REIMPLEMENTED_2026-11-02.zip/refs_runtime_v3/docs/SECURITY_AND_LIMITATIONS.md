# 보안 경계와 제한

## 제공하는 통제

- 원본 Git/checkout은 읽기 전용. managed bare cache의 fetch와 local derived DB 쓰기는 허용된 내부 작업이다.
- Git argv 배열, option/ref 검증, hooks/fsmonitor/recurse submodule 비활성, token-bearing stderr 비노출.
- symlink/gitlink/LFS pointer/binary/미지원 encoding/크기 초과 파일을 excluded로 기록.
- `.env` 경로와 private-key header를 기본 제외. **완전한 secret scanner/DLP가 아니다.** 코드에 하드코딩한 token·개인정보가 자동 탐지된다고 가정하지 않는다.
- 원문 압축 cache는 크기/sha 검증, evidence는 Git blob OID와 SHA256/span 확인.
- model URL HTTPS, 인증 env ref, TLS 검증, redirect 거부, bounded response/retry/input.
- 생성 source text는 prompt 지시가 아닌 데이터. 임의 shell/package/API 실행 기능 없음.
- 현재 repo enabled 상태를 query/evidence/scan page에서 검사. notes의 모든 source dependency scope가 충족되어야 검색 결과로 보임.

## 로컬 단일 사용자 경계

이 프로그램은 전사 ACL 서버가 아니다. 같은 OS 사용자에게 전달된 SQLite/blob을 다시 완전히 회수할 수 없다. Git 권한 변경을 실시간 sync하지 않으며 repo disable은 로컬 운영자 범위 제한이다. 따라서 원본 읽기·cache 보관·사내 모델 전송이 회사 정책상 허용되는지 먼저 확인한다.

DB·source cache·note·session 질문·scan literal·backup은 private 자료다. 세션 query가 DB에 저장되므로 민감한 Jira/JQL 질문도 보존 정책 대상이다. 로그에 token은 넣지 않지만 기본 CLI status에는 사용자가 등록한 repo ID 등이 나온다. 이를 공개 배포/외부 모니터링으로 전송하지 않는다.

파일 권한은 Unix에서 개인용으로 설정하지만 Windows NTFS ACL과 disk encryption은 현장 정책에 맡긴다. 암호화·SSO·MFA를 구현했다고 표시하지 않는다.

## 해석·재사용의 한계

인용문이 실제 source에 있다는 사실은 주장이 논리적으로 맞다는 것을 증명하지 않는다. 수식·단위·가정·API 동작을 실제 코드 및 테스트로 추가 확인한다. code_observed/test_specified와 execution_verified는 다르다. tests는 source 인덱싱 중 실행하지 않는다.

Jira detector의 source_candidate는 문서 단어보다 강한 근거라는 뜻도 자동 보장하지 않는다. path 분류와 literal match를 보여주는 candidate다. wrapper/동적 URL/서비스 gateway는 추가 조사 대상이다. 모든 언어의 정확한 호출그래프는 제공하지 않는다.

## 모델·network 범위

두 모델은 등록된 서비스로만 호출한다. 서버가 token instructions를 무시하거나 gateway에 다른 hidden behavior가 있으면 adapter만으로 막을 수 없다. TLS CA·proxy·endpoint routing은 사내 네트워크에서 실제 확인한다. DNS rebinding/SSRF를 막는 enterprise egress proxy를 새로 제공하지 않는다. endpoint 설정은 신뢰된 사용자/운영자가 소유하며 source 문서가 바꿀 수 없다.

외부 telemetry/자동 model download는 없다. Git과 model endpoint 접속은 해당 명령을 실행할 때 발생한다. 라이브러리 설치는 승인 package 경로로 수행한다. public benchmark는 공개 repo 읽기만 하고 source install/build/test를 실행하지 않는다.

## 큰 파일·규모

기본 적격 파일 한도2MiB, repo 파일수 한도200000. UTF8 기반. bytes inventory는 먼저 읽으므로 매우 큰 Git tree 자체의 peak memory도 고려한다. shallow fetch도 최신 tree의 큰 binary 다운로드를 OS 수준으로 차단하는 hard quota는 아니다.

dense exact scan은 bounded memory지만 N×dimension 비용이다. NumPy 없는 stdlib fallback의 대규모 latency는 별도 측정한다. private source 전체가 항상 모델에 전송되는 것은 아니지만 `all_text` profile 최초 embedding에서는 모든 적격 text chunk가 승인 embedding endpoint에 전달된다. 전송 허용 scope를 잘못 설정하지 않는다.

## 상태가 명확해야 하는 항목

실제 사내 model quality / Windows 네이티브 / real SDK stdio / 하네스 자동 activation / 사내 API 실행 / public100 network experiment / 중앙 multiuser 보안은 이번 합성·loopback 시험으로 완료 처리할 수 없다. FINAL_REPORT와 FIELD_ACCEPTANCE를 함께 읽는다.
