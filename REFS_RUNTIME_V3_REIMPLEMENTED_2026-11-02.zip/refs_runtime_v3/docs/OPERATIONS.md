# 운영·갱신·백업

## 명령 의미

| 작업 | 명령 | 의미 |
|---|---|---|
| 전체 변경 확인 | update --all --plan | read-only ref 확인과 변경 예상. 원문 index publish/model 호출 없음. remote cache fetch는 발생 가능 |
| 전체 갱신 | update --all | 모든 enabled repo 확인 후 변경분만 처리 |
| 개별 갱신 | update --repo ID | 지정 repo만 확인 |
| 오프라인 remote cache | update --all --no-fetch | 이미 보유한 managed ref 사용. 원격 최신 확인 아님 |
| 전체 재처리 | rebuild --all | 현재 ref 기준 재확인·vector 재생성. semantic parser 변경은 PARSER_VERSION 필수 |
| 요약 동반 | update --all --summarize | raw index 결과와 summary 결과를 분리. 요약 실패는 overall partial |
| 상태 | status / job list / job status ID | 실제 checked commit·error·job 기록 |
| 안전 취소 | job cancel ID | 다음 repository 경계에서 관찰. 곧바로 HTTP/Git process를 강제 종료하는 명령 아님 |
| 재개 | update --resume ID | 성공 repo 제외, 실패·남은 repo의 현재 ref를 다시 확인 |
| 범위 제외 | repo disable ID | 이후 search/evidence/scan page에서 차단. disk상의 복사본을 암호학적으로 회수하지 않음 |

명령의 global `--config` 또는 `--home`은 하위 명령 앞에 놓는다. 예: `refs --config refs.company.json update --all`.

## 저장과 일관성

하나의 updater만 OS writer lock을 보유한다. stale lock 파일을 삭제할 필요가 없다. OS가 process exit에서 lock을 해제한다. 살아 있는 다른 updater가 있으면 WRITER_BUSY다.

source/parse/vector 작업은 publication transaction 밖에서 수행하고 cache를 재사용한다. source tree·file mappings·active snapshot pointer는 repo별 짧은 SQLite transaction에서 반영한다. partial update에서는 일부 repo는 새 commit, 일부는 last good이다. 전사 최신화 완료라고 표시하지 않는다.

검색 session과 scan run은 당시 snapshot map을 고정한다. 과거 evidence를 최신 코드로 바꾸지 않는다. `latest_indexed`는 원격 최신과 다르며 remote_current는 unknown으로 반환된다. 최신 원격 확인이 필요하면 먼저 update를 명시 실행한다.

## 실패별 행동

| 상태 | 행동 |
|---|---|
| GIT_COMMAND_FAILED/GIT_TIMEOUT | 기존 Git helper·SSH·CA·ref 접근을 확인. source URL token을 로그에 복사하지 않음 |
| missing local repo | --path가 실제 회사 경로인지 확인. 자동 다른 repo를 대신 등록하지 않음 |
| INPUT_TOO_LONG/LLM_INPUT_TOO_LONG | tokenizer와 prefix 포함 한도를 확인. chunk/payload 명시 분할, 조용한 truncation 금지 |
| MODEL_HTTP_401/403 | 인증·정책 확인, 반복 retry 금지 |
| MODEL_HTTP_429 | batch·quota·동시 작업 조절. bounded retry가 끝나면 partial을 보존 |
| model outage | raw 기존 snapshot은 유지. semantic search fallback 여부 표시 |
| QUOTE_NOT_SUPPORTED/CITATION_NOT_IN_CONTEXT | 모델 출력 계약 오류. 근거 없는 claim을 저장하지 말고 해당 입력/모델을 현장 안전 로그로 검사 |
| SOURCE_UNAVAILABLE/hash mismatch | cache 손상 가능. 숨기지 말고 backup/재인덱싱. 다른 commit으로 대체 금지 |
| SQLite disk full/SQL failure | last published snapshot 보존. 공간 확보 후 failed job resume |
| kill -9/process 종료 | DB running 기록이 실제 작업 생존을 뜻하지 않음. OS 확인 후 resume. source별 vector cache 재사용 |
| 부족한 검색 결과 | scope·excluded·parser·embedding profile·modelspace부터 확인, 전사에 없다고 단정하지 않음 |

## 백업

업데이트를 중단한 뒤 새 빈 destination에 실행한다.

```text
python scripts/backup_state.py --home F:/REFS_DATA --destination F:/REFS_BACKUP/2026-11-02
```

SQLite backup API로 일관된 catalog를 만들고 참조 raw blobs를 hash 검증하여 복사한다. `BACKUP_MANIFEST.json`이 verified여야 한다. 실패하면 INCOMPLETE_BACKUP marker가 남으며 정상복구점으로 취급하지 않는다. source Git·모델 인증·config를 임의 export하지 않는다. backup에는 private code/embedding/query/note가 있으므로 접근 통제를 적용한다.

복원은 모든 REFS process를 종료하고 빈 data directory에 backup의 catalog/blobs를 배치한다. config/env·원격 Git cache는 별도 연결한다. 기존 local repo location은 DB에 기록되므로 다른 PC에서 경로가 바뀌면 새 index나 검토된 registry migration이 필요하다. sqlite WAL 파일 하나만 수동 복사하는 방식은 피한다.

## 아직 제공하지 않는 운영 기능

자동 cache/과거 snapshot/오래된 modelspace GC, 중앙 사용자별 ACL lease, 전사 audit aggregation, 암호화 key관리, 패키지 자동update, true in-file scan-resume, 전사 source-index rollback UI는 없다. 필요한 것부터 별도 task로 구현한다. 이 버전은 사용자별 독립 data directory의 로컬 코어다.
