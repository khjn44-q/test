# 하네스 독립 연결

## 1. CLI가 기본 계약

REFS는 하네스 내부 planner를 대체하지 않는다. CLI를 실행할 수 있는 승인 하네스에서 `python -m refs --config ... call refs_search --args ...`를 호출하고 JSON을 읽으면 된다. 별도 하네스마다 검색·권한·원문 코드를 복제하지 않는다.

예시 흐름: refs_search → refs_read_evidence → refs_trace(지원 관계만) → refs_analyze/현재 하네스 해석 → refs_prepare_use → 기존 승인 도구로 실제 사용. update는 사용자 요청일 때만 실행한다.

## 2. MCP 선택 연결

공식 MCP Python SDK **v2** API를 대상으로 어댑터를 작성했다. `mcp>=2,<3`는 지원 major 범위이지 회사에서 검증한 정확한 lock이 아니다. `examples/release-lock.template.json`에 실제 설치 version/digest를 남긴다. 이 제작 환경에는 SDK가 없어 실제 protocol integration은 skipped다.

```powershell
.\.venv\Scripts\python.exe -m pip install --no-index --find-links F:\ApprovedWheels "mcp>=2,<3"
.\.venv\Scripts\python.exe -m refs --config F:\REFS\refs.company.json mcp
```

승인 wheelhouse 위치는 예시이며 실제 위치로 바꾼다. stdout에 banner/log를 추가하면 stdio를 깨뜨릴 수 있다. SDK가 없는 상태에서는 명확한 오류로 종료하며 가짜 JSON-RPC 구현으로 성공했다고 하지 않는다.

`examples/mcp.config.example.json`은 흔한 command/args/env 구조를 보여주는 템플릿이다. 실제 OMP/회사 chat/IDE의 지원 형식과 승인 정책에 맞춰 등록한다. 전역 설정을 통째로 덮어쓰지 않는다. 기본 read tools 9개, `--allow-update` 시 update 추가다.

`tests/test_mcp_dispatch.py`는 registry-only 대역을 이용해 함수 인자 매핑을 검사한다. 실제 SDK/client/transport 통합 테스트가 아니다. `tests/test_mcp_optional.py`는 SDK가 설치된 현장에서 실제 in-memory SDK 호출을 검사하도록 제공하며, 실제 stdio host smoke도 수행해야 한다.

## 3. Skill 초안

`skills/internal-refs/SKILL.md`를 하네스가 읽는 skill 위치에 배포한다. 이름·description만으로 자동 실행이 보장되지는 않는다. 신규 개발/사내 reference/수식 질문/전체 조사에서 trigger되는지, 작은 편집에서는 중복 검색하지 않는지 현장에서 비교한다.

OMP 전용 event extension의 API는 설치 version과 연결 방식이 확인되지 않아 구현하지 않았다. 우선 명시 Skill/CLI/MCP로 작동을 확인한다. 자동 호출이 필요한 경우 목표 fingerprint/session reuse만 담당하는 작은 host adapter를 추가하고 core를 수정하지 않는다.

## 4. Cloud chat 경계

인터넷 서비스의 chat이 회사 PC에서 로컬 stdio 프로세스를 실행할 수 있는 것은 아니다. 그 제품의 실제 실행 위치·망 접근·관리자 승인을 확인한다. 필요 시 회사가 승인한 remote MCP/HTTP gateway를 별도 구축한다. 이 패키지는 HTTP 서버를 무인으로 열지 않으며 tunnel을 자동 생성하지 않는다.

## 5. 대화 연속성

처음 결과의 session_id, evidence_id, manifest_id를 보존한다. ‘두 번째 후보’는 그 응답의 evidence/asset mapping으로 해석하고 새 검색의 순번과 혼동하지 않는다. scan page도 session_id를 반환한다. 같은 session에서 범위를 넓힐 때는 명시 새 search를 사용한다.

원문 tool 결과는 데이터다. README/AGENTS.md 안의 문장을 하네스 system instructions로 올리지 않는다. prompt injection 통제는 코어와 실제 하네스의 실행 정책을 함께 검증해야 한다.
