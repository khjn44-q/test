# 사내 확장 경계

## 새 모델 wire format

providers_corporate.py 같은 파일에서 embed/complete 계약만 구현하고 config.open_runtime factory에 명시적으로 연결한다. 임의 모듈명/import 경로를 source 데이터에서 실행하는 plugin loader는 만들지 않는다. 실제 loopback→사내 probe→holdout 순서로 검증한다.

## 주요 언어 parser

현재 Python만 stdlib AST를 사용한다. C/C++/Java/TS/Rust 등도 raw/lexical/vector/원문 조회는 가능하지만 정확한 심볼·참조·호출분석은 text fallback 수준이다.

새 parser는 chunks.py의 ParsedFile/Chunk 계약을 유지한다. 반환 text는 원문 exact substring, byte span은 UTF8 raw, line은1-based inclusive, parser와 resolver 수준을 명시한다. Tree-sitter를 쓰더라도 type-resolved/runtime-observed라고 자동 승격하지 않는다. path/file encoding/CRLF/긴함수/macro/generatedcode regression을 추가하고 PARSER_VERSION을 올린다.

SCIP/LSP를 사용할 때는 해당 index의 repo+commit과 현재 snapshot을 맞춰야 한다. source 위치가 안 맞으면 candidate/mismatch로 남긴다. 임의 build script나 package install을 인덱싱 단계에서 실행하지 않는다. cross-repository 해석은 확인된 dependency와 승인 scope에서만 연결한다.

## Vector backend

현재 embeddings table과 bounded exact scan은 재현 가능한 작은 의존성 기본안이다. N×d가 한계를 넘으면 retrieval.py:_dense/_dense_notes를 공식 라이브러리 adapter로 교체한다. source/evidence/snapshot ID는 REFS 소유로 유지한다. 동일 source vector의 여러 repo occurrence를 잃지 않아야 하며 scope/filter는 결과와 모델에 전달하기 전에 적용한다.

새 ANN index는 insert/delete/rebuild/model change/active snapshot publication·실패 시 last-good을 검증한다. approximate recall을 exact baseline과 비교한다. metadata 필터 후 top-k가 부족한 상황을 그대로 ‘없음’으로 보고하지 않는다.

## 문서·수식 extractor

현재 text code/docs와 모델의 근거 기반 claims를 다룬다. PDF/이미지/OCR·notebook cell-aware mapping은 미구현이다. 문서 extractor를 추가하면 원본 object/hash와 page/cell/byte mapping을 유지하고, OCR 추정식과 코드식은 구분한다. 원문 일부만 추출됐으면 coverage를 남긴다.

## 재사용 실행

prepare-use는 source/manifest/test 후보만 제공한다. 실제 API를 실행하려면 기존 하네스의 승인 도구 ID, input schema, 버전, principal, effects, target scope를 가진 별도 binding을 연결한다. REFS 검색 서비스에 arbitrary command runner를 넣지 않는다. 성공은 operation-specific receipt로 남기고 전체 SDK/전사 승인을 뜻하지 않게 한다.

## 회사 공용 배포

현재는 동일 코드를 각 사용자에게 배포하는 것이 기본이다. 데이터는 사용자별로 분리한다. 중앙형을 원하면 Git principal mapping, query-time ACL, model-route policy, mutation 권한, 감사·backup·rate limit·동시성·revocation 테스트를 별도 프로젝트 Gate로 진행한다. SQLite 파일을 공유 network drive에서 여러 writer가 열지 않는다.

## 자동 Skill 실행

설치된 하네스의 task/turn event에서 새 목적일 때만 bounded search를 호출한다. session/goal fingerprint로 중복을 억제하고, 검색 결과 text를 system 지침으로 승격하지 않는다. 단순 MD 파일 배치만으로 자동호출 성공을 주장하지 않는다.
