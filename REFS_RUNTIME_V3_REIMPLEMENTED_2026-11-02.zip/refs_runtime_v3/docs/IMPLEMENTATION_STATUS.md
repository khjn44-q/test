# 구현 상태·요구사항 추적

이 표는 실제 소스·테스트 경로를 연결한다. **Implemented/locally verified와 사내 Accepted는 다르다.** 최신 실행 개수·환경은 [최종 보고서](../verification/FINAL_REPORT.md)에 있다. 아래 테스트 파일 존재만으로 PASS로 판정하지 않는다.

| 요구사항 | 실제 구현 | 검증 파일/실험 | 상태와 한계 |
|---|---|---|---|
| 원본 Git 읽기 전용 | `git.py`, `indexer.py` | `test_sources.py`, `test_index.py`, scale120 | 로컬 fixture 검증. managed cache만 fetch; 원격 회사 인증 미검증 |
| 커밋·blob·hash·span | `git.py`, `navigation.py` | source/search/hardening | bytes 확인, dirty tree/CRLF/Unicode/범위·내용 불일치 검사 |
| 100개 이상 목록 | `cli.import_inventory`, `indexer` | public runner/scale120 | 120개의 독립 synthetic Git. 공개100은 DNS 차단 |
| 사전 프로젝트 요약 | `analysis.summarize` | `test_analysis.py` | 대표 source sampling, 부분 coverage. 전체 저장소 의미 분석 완료가 아님 |
| 한국어→영문 코드 | alias + embedding adapter | provider/search tests | 연결·fallback 시험. 실제 사내 semantic quality 미검증 |
| 정확 식별자/문자열/dense 결합 | `retrieval.py` | search/profile/scale regression | 실제 FTS와 RRF. exact dense scan, 별도 ANN 없음 |
| 작은 함수 직접 발견 | Python AST/source units | sources/search/scale120 | parent summary에 종속되지 않음 |
| 수동 특정/전체 update | `indexer.py`, `cli.py` | index/hardening/scale120 | 변경분 처리, `rebuild` 구분, repo별 원자 게시 |
| no-op·rename embedding 재사용 | content payload+fingerprint | index/profile/scale120 | source read·embedding 호출 수 계측 |
| 삭제·새 파일·설정 변화 | snapshot mapping + tree-bound notes | index/analysis/hardening | summary는 repo tree 단위 보수적 무효화. 함수 수준 의미 dependency graph 없음 |
| 실패 복구·동시 writer | SQLite transaction+OS lock | index/hardening | 이전 active 보존, repo 단위 resume. arbitrary in-file checkpoint 없음 |
| 전체 탐색 | `scanning.py` whole-file literal/detector | search/scale120 | paging·budget·excluded coverage. 실제 API 호출 여부는 추가 분석 필요 |
| 원문·비교·관계 | `navigation.py` | search/sources | Python syntax/lexical 후보, 완전 call graph 아님 |
| 수식·기술 지식 | `analysis.py` | analysis tests | 인용문/ID·권위 거부. 실제 물리/의미 entailment 판정 별도 |
| 후속 대화 | immutable sessions/scan session | search/hardening | snapshot pinning. 실제 하네스 대화 자동 연결은 현장 검증 |
| read-only 재사용 계획 | `prepare_use` | analysis/CLI | 항상 reference_only. 실제 API 실행·SDK 설치·receipt 저장 구현 없음 |
| 모델 분리 | `providers.py` | 19개 초기 provider 시험 및 추가 회귀 | loopback HTTP 실통신, 기업 endpoint 미연결 |
| CLI | `cli.py` | subprocess CLI, wheel smoke | JSON 응답·partial exit·resume·probe |
| MCP | `mcp_server.py`, official SDK v2 adapter | registry binding + optional protocol test | 인자 바인딩 검증. 실제 SDK 미설치로 protocol test skipped |
| Skill | `skills/internal-refs/` | activation cases 문서 | **설치 초안**, baseline/with-skill 현장 시험 미수행 |
| Windows | portable Python/Git/OS lock 분기 | 현장 smoke 필요 | 이번 실행은 Linux. Windows 지원 검증 완료 아님 |
| 백업 | `scripts/backup_state.py` | `test_packaging_tools.py` | DB Backup API + referenced blobs, reopen/evidence 확인 |
| 배포 | wheel + ZIP+manifest | bundle tests/fresh install | 기본 코어 offline install; optional packages 별도 승인 |
| 중앙/팀 공유 ACL | 없음 | 없음 | 사용자별 로컬 설치만. 공용 데이터 배포는 추가 보안 작업 |
| cache GC·retention | 없음 | 없음 | 자동 삭제 위험을 피함. 별도 후속 구현 필요 |
| UI | 없음 | 없음 | 요구대로 후순위 |

## 단계 판정

S0~S7의 지원 범위 구현과 로컬 시험은 실행 로그에 남겼다. S8은 문서·배포·최종 회귀와 압축 검증이다. 이 파일을 먼저 썼다는 이유로 최종 ZIP 검증이 완료되었다고 간주하지 않는다. 실제 ZIP 출하 증거는 `verification/FINAL_REPORT.md`와 ZIP 내부 `MANIFEST.json` 및 별도 검증 명령 결과다.

## 현장에 남은 우선 작업

F0: 회사 모델/네트워크/Windows/하네스 계약 확인. F1: 실제 100+ Git에서 자연어·수식·전체 조사 품질 측정. F2: 실제 실패를 근거로 주요 언어 parser·정밀 참조·API operation binding 추가. F3: 규모가 exact vector scan/보존용량을 넘으면 ANN·GC 추가. 중앙 service/SSO/UI는 별도 프로젝트 단계다.

프로그램 완성도를 임의로 90/99/100%로 매기지 않는다. 특히 사용자가 C++ 열 모델의 완전한 호출 관계와 API 즉시 실행을 필수로 본다면, 해당 기능은 현재 패키지에 모두 구현된 것이 아니다.
