# 산출물 범위와 외부 자료

이 패키지는 사용자 요청에 따라 새로 작성한 REFS Runtime 코드·문서·테스트다. 분실된 이전 구현을 복구한 것이 아니다. 별도 오픈소스 배포 라이선스 선택은 소유 조직의 정책에 따라 결정한다. 이 문서는 회사 법무 승인이나 제3자 권리 보증을 뜻하지 않는다.

`provenance/`는 사용자에게 이전에 제공된 설계/참조 기록이다. `bench/public_repositories.json`은 공개 주소 문자열만 포함하며 그 저장소의 코드를 번들에 재배포하지 않는다. 합성 benchmark는 `bench/scale.py`가 생성한 데이터다. 공개 100개 저장소 다운로드는 이 환경에서 실패했다.

선택적 NumPy와 공식 MCP SDK는 이 ZIP에 포함되지 않는다. 사내 승인 wheelhouse에서 별도 설치하고 각 LICENSE/NOTICE/버전·의존성을 확인한다. 기본 자체 wheel은 외부 runtime dependency가 없다. Python/Git/SQLite는 환경 전제이며 그 배포 라이선스는 각 공급자에 따른다.
