"""Whole-source literal investigation, separately from top-k retrieval."""
from __future__ import annotations
from array import array
import base64
import bisect
import hashlib
import hmac
import json
import re
import secrets
import time
import uuid
from .errors import RefsError
from .navigation import select_scope,check_scope,evidence_record,put_evidence,save_session
from .store import digest,dumps,now

DETECTORS={
 'jira':['jira','jql','search_issues','/rest/api/2/','/rest/api/3/','/rest/agile/'],
 'thermal':['thermal','heat_transfer','temperature','conductivity','resistance','capacitance','heat flux']}


def _secret(runtime):
    runtime.store.conn.execute('INSERT OR IGNORE INTO meta VALUES(?,?)',('cursor_secret',secrets.token_hex(32)))
    return runtime.store.one('SELECT value FROM meta WHERE key=?',('cursor_secret',))['value'].encode()


def cursor_encode(runtime,run_id,offset):
    body=base64.urlsafe_b64encode(dumps({'run':run_id,'offset':offset}).encode()).decode().rstrip('=')
    return body+'.'+hmac.new(_secret(runtime),body.encode(),hashlib.sha256).hexdigest()


def cursor_decode(runtime,value):
    try:
        if len(value)>2048:raise ValueError()
        body,sig=value.split('.')
        if not hmac.compare_digest(sig,hmac.new(_secret(runtime),body.encode(),hashlib.sha256).hexdigest()):raise ValueError()
        payload=json.loads(base64.urlsafe_b64decode(body+'='*(-len(body)%4)))
        if not isinstance(payload['run'],str) or type(payload['offset'])!=int or payload['offset']<0:raise ValueError()
        return payload['run'],payload['offset']
    except (ValueError,KeyError,TypeError):raise RefsError('INVALID_CURSOR') from None


def _page(runtime,run_id,offset,limit):
    row=runtime.store.one('SELECT * FROM scan_runs WHERE scan_id=?',(run_id,))
    if not row:raise RefsError('SCAN_UNAVAILABLE')
    scope=json.loads(row['scope_json']);check_scope(runtime,scope)
    total=runtime.store.conn.execute('SELECT count(*) FROM scan_matches WHERE scan_id=?',(run_id,)).fetchone()[0]
    if offset>total:raise RefsError('CURSOR_OUT_OF_RANGE')
    matches=runtime.store.rows('SELECT payload_json FROM scan_matches WHERE scan_id=? AND position>=? ORDER BY position LIMIT ?',(run_id,offset,limit))
    results=[json.loads(r['payload_json']) for r in matches]
    coverage=json.loads(row['coverage_json'])
    session_id=save_session(runtime,'scan:'+row['patterns_json'],scope,[r['evidence_id'] for r in results])
    return {'schema_version':'3.0','status':'ok' if row['state']=='complete' else 'partial','breadth':'all',
            'scan_id':run_id,'session_id':session_id,'manifest_id':digest(scope),'patterns':json.loads(row['patterns_json']),
            'total_matches':total,'results':results,'coverage':coverage,
            'next_cursor':cursor_encode(runtime,run_id,offset+len(results)) if offset+len(results)<total else None,
            'freshness':{'mode':'pinned_indexed_sources','remote_current':'unknown'},
            'notice':'Literal/detector coverage is not proof of semantic completeness or actual API execution.'}


def scan(runtime,patterns=None,*,detector=None,repo_ids=None,session_id=None,cursor=None,limit=50,
         max_matches=100000,max_seconds=120,max_bytes=1024*1024*1024):
    if type(limit)!=int or not 1<=limit<=500:raise RefsError('INVALID_PAGE_SIZE')
    if cursor:
        if patterns or detector or repo_ids or session_id:raise RefsError('CURSOR_REQUEST_CANNOT_CHANGE_SCOPE')
        run,offset=cursor_decode(runtime,cursor);return _page(runtime,run,offset,limit)
    if detector:
        if detector not in DETECTORS:raise RefsError('UNKNOWN_DETECTOR')
        patterns=DETECTORS[detector]
    patterns=list(dict.fromkeys(patterns or []))
    if not 1<=len(patterns)<=64 or any(not isinstance(p,str) or not p or len(p)>512 for p in patterns):raise RefsError('INVALID_PATTERNS')
    if not 1<=max_matches<=1000000 or not 0<max_seconds<=3600 or max_bytes<=0:raise RefsError('INVALID_SCAN_BUDGET')
    scope=select_scope(runtime,repo_ids,session_id);run='scan-'+uuid.uuid4().hex
    files=runtime.store.rows('''SELECT f.*,s.repo_id FROM snapshot_files f JOIN snapshots s ON s.snapshot_id=f.snapshot_id
        WHERE f.snapshot_id IN (SELECT value FROM json_each(?)) AND f.status='indexed' ORDER BY s.repo_id,f.path''',
        (dumps([s for s in scope.values() if s]),))
    all_files=runtime.store.rows('SELECT f.status,f.reason,count(*) AS n FROM snapshot_files f WHERE f.snapshot_id IN (SELECT value FROM json_each(?)) GROUP BY f.status,f.reason',
        (dumps([s for s in scope.values() if s]),))
    exclusions={r['reason']:r['n'] for r in all_files if r['status']!='indexed'}
    coverage={'tracked_files':sum(r['n'] for r in all_files),'excluded_files':sum(exclusions.values()),
              'excluded_reasons':exclusions,'coverage_basis':'indexed_eligible_text_only','registered_in_scope':len(scope),'indexed_repositories':sum(v is not None for v in scope.values()),
              'eligible_files':len(files),'scanned_files':0,'eligible_bytes':sum(f['size'] for f in files),
              'scanned_bytes':0,'read_bytes':0,'failed_files':0,'scope_scan_complete':False,
              'semantic_completeness':'not_proven','stopped_reason':None}
    runtime.store.conn.execute('INSERT INTO scan_runs VALUES(?,?,?,?,?,?)',(run,dumps(scope),dumps(patterns),'running',dumps(coverage),now()))
    compiled=[(p,re.compile(re.escape(p),re.IGNORECASE)) for p in patterns]
    start=time.perf_counter();position=0;pending=[];stopped=False
    def flush():
        if not pending:return
        with runtime.store.transaction():
            for rec,item,pos in pending:
                put_evidence(runtime,rec)
                runtime.store.conn.execute('INSERT INTO scan_matches VALUES(?,?,?,?,?)',(run,pos,rec['repo_id'],rec['evidence_id'],dumps(item)))
        pending.clear()
    try:
        for f in files:
            if time.perf_counter()-start>max_seconds or coverage['read_bytes']+f['size']>max_bytes:
                coverage['stopped_reason']='time_or_byte_budget';stopped=True;break
            runtime._repo(f['repo_id'])
            try:body=runtime.cache.get(f['content_hash']);text=body.decode('utf-8')
            except Exception:coverage['failed_files']+=1;continue
            coverage['read_bytes']+=len(body)
            spans={}
            # Escaped literals avoid untrusted regex backtracking programs.
            for p,regex in compiled:
                for m in regex.finditer(text):
                    spans.setdefault((m.start(),m.end()),[]).append(p)
                    if len(spans)>max_matches-position:break
                if len(spans)>max_matches-position:break
            byte_offsets=None
            if spans and not text.isascii():
                byte_offsets=array('I',[0])
                for char in text:byte_offsets.append(byte_offsets[-1]+len(char.encode()))
            line_starts=[0]
            for m in re.finditer('\n',text):line_starts.append(m.end())
            for (a,b),matched in sorted(spans.items()):
                if position>=max_matches:stopped=True;coverage['stopped_reason']='match_budget';break
                ba=byte_offsets[a] if byte_offsets is not None else a;bb=byte_offsets[b] if byte_offsets is not None else b
                la=bisect.bisect_right(line_starts,a);lb=bisect.bisect_right(line_starts,max(a,b-1))
                rec=evidence_record({**f,'byte_start':ba,'byte_end':bb,'line_start':la,'line_end':lb,'unit_id':None})
                low=f['path'].lower();parts=low.split('/')
                cls='test_only' if 'tests' in parts or parts[-1].startswith('test_') else ('docs_only' if low.endswith(('.md','.rst','.txt','.adoc')) else ('dependency_only' if low.endswith(('.toml','.lock','package.json')) else 'source_candidate'))
                item={'repo_id':f['repo_id'],'snapshot_id':f['snapshot_id'],'path':f['path'],'evidence_id':rec['evidence_id'],
                      'line_start':la,'line_end':lb,'matched_text':text[a:b],'matched_patterns':matched,
                      'classification':cls,'execution_verified':False,'verification':'literal_match_in_verified_bytes'}
                pending.append((rec,item,position));position+=1
                if len(pending)>=256:flush()
            if stopped:break
            coverage['scanned_files']+=1;coverage['scanned_bytes']+=len(body)
        flush()
        coverage['scope_scan_complete']=not stopped and coverage['failed_files']==0 and all(scope.values())
        coverage['elapsed_ms']=round((time.perf_counter()-start)*1000,3)
        state='complete' if coverage['scope_scan_complete'] else 'partial'
        runtime.store.conn.execute('UPDATE scan_runs SET state=?,coverage_json=? WHERE scan_id=?',(state,dumps(coverage),run))
    except BaseException:
        flush();coverage['stopped_reason']='interrupted_or_error'
        runtime.store.conn.execute("UPDATE scan_runs SET state='interrupted',coverage_json=? WHERE scan_id=?",(dumps(coverage),run))
        raise
    return _page(runtime,run,0,limit)
