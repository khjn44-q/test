"""Strict JSON configuration. Credentials are environment-variable references, never stored values."""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import json
import os
from .errors import RefsError
from .indexer import IndexSettings
from .providers import ProviderConfig,EmbeddingProvider,ChatProvider

@dataclass(frozen=True)
class AppConfig:
    home: Path
    index: IndexSettings
    embedding: ProviderConfig|None=None
    llm: ProviderConfig|None=None


def load_config(path: str|Path|None=None,home: str|Path|None=None) -> AppConfig:
    requested_home=Path(home).expanduser().resolve() if home else None
    if path is None:
        base=requested_home or Path(os.environ.get('REFS_HOME',Path.home()/'.refs-runtime')).expanduser().resolve()
        candidate=base/'config.json'
        path=candidate if candidate.exists() else None
    value={};root=Path.cwd()
    if path is not None:
        p=Path(path).expanduser().resolve();root=p.parent
        if p.stat().st_size>1024*1024:raise RefsError('CONFIG_TOO_LARGE')
        try:value=json.loads(p.read_text(encoding='utf-8-sig'))
        except (ValueError,UnicodeError) as e:raise RefsError('INVALID_CONFIG_JSON') from e
    if not isinstance(value,dict) or set(value)-{'schema_version','home','index','embedding','llm'}:
        raise RefsError('UNKNOWN_CONFIG_FIELD')
    if value.get('schema_version',3)!=3:raise RefsError('UNSUPPORTED_CONFIG_VERSION')
    directory=requested_home or Path(value.get('home',os.environ.get('REFS_HOME',str(Path.home()/'.refs-runtime')))).expanduser()
    if not directory.is_absolute():directory=root/directory
    try:
        settings=IndexSettings(**value.get('index',{}));settings.validate()
        def provider(name):
            raw=value.get(name)
            if raw is None:return None
            if not isinstance(raw,dict):raise RefsError('INVALID_MODEL_CONFIG')
            raw=dict(raw)
            if 'endpoint_env' in raw:
                if 'endpoint' in raw:raise RefsError('DUPLICATE_ENDPOINT_CONFIG')
                raw['endpoint']=os.environ.get(raw.pop('endpoint_env'),'')
            c=ProviderConfig(**raw);c.validate()
            if name=='embedding' and not 1<=c.dimensions<=32768:raise RefsError('EMBEDDING_DIMENSIONS_REQUIRED')
            return c
        emb=provider('embedding');llm=provider('llm')
    except TypeError as e:raise RefsError('UNKNOWN_CONFIG_FIELD') from e
    return AppConfig(directory.resolve(),settings,emb,llm)


def open_runtime(config: AppConfig):
    from .core import Runtime
    return Runtime(config.home,settings=config.index,
                   embedding=EmbeddingProvider(config.embedding) if config.embedding else None,
                   llm=ChatProvider(config.llm) if config.llm else None)


def example_config():
    return {'schema_version':3,'home':'./refs-data','index':{'chunk_chars':3000,'max_file_bytes':2097152,'embedding_batch_items':32},
            'embedding':None,'llm':None}
