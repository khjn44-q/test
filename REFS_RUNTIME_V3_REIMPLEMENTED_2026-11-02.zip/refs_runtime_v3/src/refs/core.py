"""Harness-independent application API. CLI/MCP delegate here without duplicating logic."""
from .indexer import Index
from . import retrieval,navigation,scanning

class Runtime(Index):
    def search(self,query,**kwargs):return retrieval.search(self,query,**kwargs)
    def scan(self,patterns=None,**kwargs):return scanning.scan(self,patterns,**kwargs)
    def evidence(self,evidence_id,**kwargs):return navigation.read_evidence(self,evidence_id,**kwargs)
    def trace(self,evidence_id,**kwargs):return navigation.trace(self,evidence_id,**kwargs)
    def compare(self,a,b,**kwargs):return navigation.compare(self,a,b,**kwargs)
    def analyze(self,*args,**kwargs):
        from .analysis import analyze
        return analyze(self,*args,**kwargs)
    def summarize(self,*args,**kwargs):
        from .analysis import summarize
        return summarize(self,*args,**kwargs)
    def prepare_use(self,*args,**kwargs):
        from .analysis import prepare_use
        return prepare_use(self,*args,**kwargs)
    def find(self,query,*,breadth='ranked',depth='fast',repo_ids=None,session_id=None,limit=10):
        from .errors import RefsError
        if breadth not in {'ranked','all'} or depth not in {'fast','verified','deep'}:raise RefsError('INVALID_SEARCH_OPTIONS')
        if breadth=='ranked':result=self.search(query,repo_ids=repo_ids,session_id=session_id,limit=limit,depth=depth)
        else:
            query_terms=retrieval.terms(query)
            detector='jira' if 'jira' in query.lower() else None
            result=self.scan(None if detector else query_terms,detector=detector,repo_ids=repo_ids,session_id=session_id,limit=limit)
            result['depth']=depth
            result['query_plan']={'kind':'deterministic_detector' if detector else 'literal_terms','semantic_completeness':'not_proven'}
        if depth=='deep' and result['results']:
            ids=list(dict.fromkeys(eid for h in result['results'] for eid in h.get('evidence_ids',[h['evidence_id']])))
            selected=ids[:8]
            result['deep_context']=self.analyze(query,selected,max_sources=8,max_model_calls=4)
            result['deep_analysis_performed']=result['deep_context']['mode']=='llm_grounded'
            result['deep_coverage']={'selected_evidence':len(selected),'result_evidence':len(ids),
                                     'total_scan_matches':result.get('total_matches'),
                                     'all_candidates_analyzed':False if breadth=='all' and result.get('total_matches',0)>len(selected) else len(selected)==len(ids)}
            if not result['deep_coverage']['all_candidates_analyzed']:
                result['status']='partial';result.setdefault('warnings',[]).append('DEEP_ANALYSIS_BUDGET_REMAINS')
        return result
