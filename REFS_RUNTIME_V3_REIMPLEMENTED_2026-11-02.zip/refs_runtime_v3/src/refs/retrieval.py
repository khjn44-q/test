"""Hybrid retrieval with explicit lexical fallback and bounded-memory exact dense scan."""
from __future__ import annotations
from collections import defaultdict
import heapq
import json
import math
import re
import struct
import time
from .chunks import code_tokens
from .errors import RefsError
from .providers import normalized_vector
from .store import digest,dumps
from .navigation import select_scope,save_session,check_scope,evidence_record,put_evidence,read_evidence,source_url

ALIASES={
 '열저항':['thermal','resistance'],'열전달':['heat','thermal','conduction'],'온도':['temperature','thermal'],
 '발열':['power','thermal'],'시뮬레이션':['simulation','model','solver'],'수식':['equation','formula'],
 '인증':['authentication','auth','token'],'권한':['authorization','permission'],'이슈':['issue','jql'],
 '조회':['search','query'],'페이지네이션':['pagination','page'],'대시보드':['dashboard'],
 '재시도':['retry'],'캐시':['cache'],'모델':['model'],'솔버':['solver'],'오류':['error','exception']}
STOP={'사내','코드','관련','찾아줘','찾아','있어','뭐야','어떤','사용하는','프로젝트','please','find','code'}

def terms(query):
    values=re.findall(r'[^\W_]+',code_tokens(query),flags=re.UNICODE)
    out=[]
    for value in values:
        if value.lower() not in STOP:out.append(value.lower())
        for key,extras in ALIASES.items():
            if key in value:out.extend(extras)
    return list(dict.fromkeys(out))[:40]


def rrf(lanes,weights=None,k=60):
    if k<0:raise ValueError('INVALID_RRF_K')
    weights=weights or {};scores={};ranks=defaultdict(dict)
    for name in sorted(lanes):
        seen=set();rank=0;weight=weights.get(name,1.0)
        if not isinstance(weight,(int,float)) or not math.isfinite(weight) or weight<0:raise ValueError('INVALID_WEIGHT')
        for item in lanes[name]:
            if item in seen:continue
            seen.add(item);rank+=1
            scores[item]=scores.get(item,0)+weight/(k+rank);ranks[item][name]=rank
    return [{'id':id,'score':score,'ranks':ranks[id]} for id,score in sorted(scores.items(),key=lambda p:(-p[1],p[0]))]


BASE=''' FROM units u JOIN snapshot_files f ON f.parse_key=u.parse_key
JOIN snapshots s ON s.snapshot_id=f.snapshot_id JOIN repositories r ON r.repo_id=s.repo_id AND r.enabled=1 '''
FIELDS='u.*,f.path,f.git_oid,f.content_hash,s.repo_id,s.snapshot_id,s.commit_oid'
# Keep the composite parse_key/snapshot index from expanding each candidate into N scope probes.
# snapshot_id is a TEXT digest; unary + preserves its value while making membership a filter.
# The filter still executes BEFORE ORDER BY/LIMIT, including pinned historical scopes.
SCOPE=" +f.snapshot_id IN (SELECT value FROM json_each(?)) AND f.status='indexed' "

def key(row):return digest(['note',row['note_id']]) if row.get('note_id') else digest([row['snapshot_id'],row['path'],row['unit_id']])


def _dense(runtime,scope,q,cap):
    model=runtime.embedding
    sql='SELECT u.unit_id,f.path,s.snapshot_id,e.vector,e.dimensions'+BASE+''' JOIN embeddings e ON e.input_hash=u.input_hash
AND e.space=? AND e.role='document' WHERE '''+SCOPE
    cursor=runtime.store.conn.execute(sql,(model.fingerprint,dumps(list(scope.values()))))
    heap=[];scanned=0
    try:
        import numpy as np
    except ImportError:np=None
    while True:
        raw=cursor.fetchmany(512)
        if not raw:break
        rows=[dict(x) for x in raw]
        for row in rows:
            if row['dimensions']!=model.dimensions or len(row['vector'])!=model.dimensions*4:
                raise RefsError('CORRUPT_VECTOR_SPACE')
        if np is not None:
            matrix=np.stack([np.frombuffer(r['vector'],dtype='<f4') for r in rows])
            if not np.isfinite(matrix).all():raise RefsError('CORRUPT_VECTOR_SPACE')
            scores=matrix @ np.asarray(q,dtype=np.float32)
        else:
            scores=[sum(a*b for a,b in zip(struct.unpack('<'+'f'*model.dimensions,r['vector']),q)) for r in rows]
        for row,score in zip(rows,scores):
            score=float(score)
            if not math.isfinite(score):raise RefsError('CORRUPT_VECTOR_SPACE')
            row.pop('vector');row.pop('dimensions');kid=key(row);scanned+=1
            item=(score,kid,row)
            if len(heap)<cap:heapq.heappush(heap,item)
            elif item[:2]>heap[0][:2]:heapq.heapreplace(heap,item)
    # Read full source text only for the retained candidates, not for every vector.
    out=[]
    for _,_,candidate in sorted(heap,key=lambda p:(-p[0],p[1])):
        row=runtime.store.one('SELECT '+FIELDS+BASE+' WHERE u.unit_id=? AND f.snapshot_id=? AND f.path=?',
             (candidate['unit_id'],candidate['snapshot_id'],candidate['path']))
        if row:out.append(row)
    return out,scanned


def _trees(runtime,scope):
    return {rid:runtime.store.one('SELECT tree_digest FROM snapshots WHERE snapshot_id=?',(sid,))['tree_digest'] for rid,sid in scope.items() if sid}

NOTE_SCOPE=''' NOT EXISTS (SELECT 1 FROM json_each(n.dependencies_json) dependency
    LEFT JOIN json_each(?) allowed ON allowed.key=dependency.key
    WHERE allowed.key IS NULL OR allowed.value<>dependency.value) '''

def _note_rows(runtime,scope,raw,trees=None):
    trees=_trees(runtime,scope) if trees is None else trees
    out=[]
    for n in raw:
        deps=json.loads(n['dependencies_json'])
        if any(trees.get(rid)!=tree for rid,tree in deps.items()):continue
        ids=json.loads(n['evidence_json'])
        if not ids:continue
        e=runtime.store.one('SELECT * FROM evidence WHERE evidence_id=?',(ids[0],))
        if not e:continue
        snap=runtime.store.one('SELECT commit_oid FROM snapshots WHERE snapshot_id=?',(e['snapshot_id'],))
        row={**e,'note_id':n['note_id'],'evidence_ids':ids,'note_kind':n['kind'],
             'symbol':'','kind':'knowledge','resolution':'model_inferred','text':n['body'],'commit_oid':snap['commit_oid']}
        if 'vector' in n:row.update(vector=n['vector'],dimensions=n['dimensions'])
        out.append(row)
    return out


def _notes(runtime,scope,ts,cap):
    if not ts:return []
    match=' OR '.join('"'+t.replace('"','""')+'"' for t in ts)
    trees=_trees(runtime,scope)
    raw=runtime.store.rows("SELECT n.*,bm25(notes_fts) AS rank FROM notes_fts JOIN notes n ON n.rowid=notes_fts.rowid WHERE notes_fts MATCH ? AND "+NOTE_SCOPE+" ORDER BY rank LIMIT ?",(match,dumps(trees),cap))
    return _note_rows(runtime,scope,raw,trees)


def _dense_notes(runtime,scope,q,cap):
    trees=_trees(runtime,scope)
    sql="SELECT n.*,e.vector,e.dimensions FROM notes n JOIN note_embeddings ne ON ne.note_id=n.note_id JOIN embeddings e ON e.space=ne.space AND e.input_hash=ne.input_hash AND e.role='document' WHERE ne.space=? AND "+NOTE_SCOPE
    cursor=runtime.store.conn.execute(sql,(runtime.embedding.fingerprint,dumps(trees)))
    heap=[];count=0;ordinal=0
    # At most 512 rows plus bounded top candidates: no whole-corpus vector materialization.
    while True:
        raw=cursor.fetchmany(512)
        if not raw:break
        for row in _note_rows(runtime,scope,[dict(r) for r in raw],trees):
            if row['dimensions']!=len(q) or len(row['vector'])!=4*len(q):raise RefsError('CORRUPT_NOTE_VECTOR')
            vals=struct.unpack('<'+'f'*len(q),row.pop('vector'));row.pop('dimensions')
            score=sum(a*b for a,b in zip(vals,q));count+=1
            if not math.isfinite(score):raise RefsError('CORRUPT_NOTE_VECTOR')
            item=(score,key(row),ordinal,row);ordinal+=1
            if len(heap)<cap:heapq.heappush(heap,item)
            elif item[:3]>heap[0][:3]:heapq.heapreplace(heap,item)
    unique={}
    for item in sorted(heap,key=lambda x:(-x[0],x[1],x[2])):
        unique.setdefault(item[1],item[3])
    return list(unique.values()),count


def search(runtime,query,*,repo_ids=None,session_id=None,limit=10,depth='fast'):
    if not isinstance(query,str) or not query.strip() or len(query)>8000:raise RefsError('INVALID_QUERY')
    if type(limit)!=int or not 1<=limit<=200 or depth not in {'fast','verified','deep'}:raise RefsError('INVALID_SEARCH_OPTIONS')
    start=time.perf_counter();timing={};warnings=[];scope=select_scope(runtime,repo_ids,session_id)
    selected=[s for s in scope.values() if s];scope_json=dumps(selected);ts=terms(query)
    rows={};lanes={};cap=min(1000,max(80,limit*12))
    t=time.perf_counter()
    exact=[]
    if re.fullmatch(r'[\w.]+',query.strip(),flags=re.UNICODE):
        value=query.strip()
        # Literal equality and qualified-name suffix; SQL wildcard characters are escaped.
        escaped=value.replace('\\','\\\\').replace('%','\\%').replace('_','\\_')
        exact=runtime.store.rows('SELECT '+FIELDS+BASE+' WHERE '+SCOPE+" AND (u.symbol=? OR u.symbol LIKE ? ESCAPE '\\') ORDER BY s.repo_id,f.path,u.ordinal LIMIT ?",
                                 (scope_json,value,'%.'+escaped,cap))
    lanes['exact']=[key(r) for r in exact];rows.update((key(r),r) for r in exact)
    strong_identifier=bool(exact) and bool(re.search(r'[_\.]|[a-z][A-Z]',query.strip()))
    lexical=[]
    if ts and selected:
        match=(' AND ' if strong_identifier else ' OR ').join('"'+term.replace('"','""')+'"' for term in ts)
        sql='SELECT '+FIELDS+',bm25(units_fts,8.0,1.0) AS lexical_score FROM units_fts JOIN units u ON u.rowid=units_fts.rowid JOIN snapshot_files f ON f.parse_key=u.parse_key JOIN snapshots s ON s.snapshot_id=f.snapshot_id JOIN repositories r ON r.repo_id=s.repo_id AND r.enabled=1 WHERE units_fts MATCH ? AND '+SCOPE+' ORDER BY lexical_score,s.repo_id,f.path,u.ordinal LIMIT ?'
        lexical=runtime.store.rows(sql,(match,scope_json,cap))
    lanes['lexical']=[key(r) for r in lexical];rows.update((key(r),r) for r in lexical)
    notes=_notes(runtime,scope,ts,cap)
    lanes['knowledge']=[key(r) for r in notes];rows.update((key(r),r) for r in notes)
    timing['lexical_ms']=(time.perf_counter()-t)*1000
    mode='lexical_only';cache_hit=False;dense_count=0;dense_note_count=0
    if runtime.embedding is not None and selected and not strong_identifier:
        t=time.perf_counter()
        try:
            qhash=digest(query.encode());q=runtime.store.vector(runtime.embedding.fingerprint,'query',qhash)
            cache_hit=q is not None
            if q is None:
                batch=runtime.embedding.embed([query],role='query')
                if len(batch)!=1:raise RefsError('QUERY_VECTOR_COUNT')
                q=normalized_vector(batch[0],runtime.embedding.dimensions)
                runtime.store.put_vectors(runtime.embedding.fingerprint,'query',[(qhash,q)])
            q=normalized_vector(q,runtime.embedding.dimensions)
            timing['query_embedding_ms']=(time.perf_counter()-t)*1000;t=time.perf_counter()
            if runtime.settings.embedding_scope=='summaries_only':
                dense=[];dense_count=0;warnings.append('RAW_DENSE_DISABLED_BY_PROFILE')
            else:dense,dense_count=_dense(runtime,scope,q,cap)
            lanes['dense']=[key(r) for r in dense];rows.update((key(r),r) for r in dense)
            dense_notes,dense_note_count=_dense_notes(runtime,scope,q,cap)
            lanes['knowledge_dense']=[key(r) for r in dense_notes];rows.update((key(r),r) for r in dense_notes)
            mode='hybrid' if dense_count or dense_note_count else 'lexical_fallback'
            if not dense_count:warnings.append('NO_VECTORS_FOR_CURRENT_SPACE_IN_SCOPE')
            timing['dense_ms']=(time.perf_counter()-t)*1000
        except Exception as e:
            mode='lexical_fallback';warnings.append('SEMANTIC_SEARCH_UNAVAILABLE:'+type(e).__name__)
    if runtime.embedding is not None and strong_identifier:
        mode='exact_identifier';warnings.append('DENSE_SKIPPED_EXACT_IDENTIFIER')
    if runtime.embedding is None:warnings.append('EMBEDDING_NOT_CONFIGURED')
    if any(v is None for v in scope.values()):warnings.append('UNINDEXED_REPOSITORIES_IN_SCOPE')
    exact_set=set(lanes['exact'])
    fused=rrf(lanes,weights={'exact':2.0})
    fused.sort(key=lambda h:(0 if h['id'] in exact_set else 1,-h['score'],h['id']))
    chosen=[];counts=defaultdict(int);left=[]
    for h in fused:
        rid=rows[h['id']]['repo_id']
        if counts[rid]<2 or h['id'] in exact_set:
            chosen.append(h);counts[rid]+=1
        else:left.append(h)
    chosen=(chosen+left)[:limit]
    results=[]
    with runtime.store.transaction():
        for h in chosen:
            row=rows[h['id']];eid=row['evidence_ids'][0] if row.get('note_id') else put_evidence(runtime,evidence_record(row))
            item={'repo_id':row['repo_id'],'snapshot_id':row['snapshot_id'],'commit':row['commit_oid'],
                  'path':row['path'],'symbol':row['symbol'],'kind':row['kind'],'unit_id':row['unit_id'],
                  'evidence_id':eid,'score':h['score'],'ranks':h['ranks'],'snippet':row['text'][:360],
                  'verification':'reference_checked' if row.get('note_id') else 'indexed_source','resolution':row['resolution'],
                  'record_type':'knowledge' if row.get('note_id') else 'source','note_id':row.get('note_id'),
                  'evidence_ids':row.get('evidence_ids',[eid]),'semantic_entailment':'not_verified',
                  'exact_identifier':h['id'] in exact_set,'execution_verified':False,
                  'source_url':source_url(runtime,row['repo_id'],row['commit_oid'],row['path'])}
            results.append(item)
    if depth!='fast':
        t=time.perf_counter()
        for item in results:
            try:
                for cited_id in item['evidence_ids']:ev=read_evidence(runtime,cited_id,max_chars=2000)
                item['verification']='references_bytes_verified' if item['record_type']=='knowledge' else ev['verification']
            except Exception:
                item['verification']='unavailable';item['snippet']='';warnings.append('SOURCE_UNAVAILABLE')
        timing['evidence_ms']=(time.perf_counter()-t)*1000
    check_scope(runtime,scope)
    sid=save_session(runtime,query,scope,[r['evidence_id'] for r in results])
    timing['total_ms']=(time.perf_counter()-start)*1000
    scope_complete=all(scope.values()) and 'SOURCE_UNAVAILABLE' not in warnings
    return {'schema_version':'3.0','status':('ok' if results else 'no_match') if scope_complete else 'partial','session_id':sid,'parent_session_id':session_id,
            'manifest_id':digest(scope),'depth':depth,'breadth':'ranked','results':results,
            'query_terms':ts,'retrieval_mode':mode,'query_embedding_cache_hit':cache_hit,
            'coverage':{'registered_in_scope':len(scope),'indexed_repositories':len(selected),'scope_search_complete':scope_complete,
                        'dense_occurrences_scanned':dense_count,'dense_note_segments_scanned':dense_note_count,'semantic_completeness':'not_proven'},
            'freshness':{'mode':'pinned_session' if session_id else 'latest_indexed','remote_current':'unknown'},
            'warnings':list(dict.fromkeys(warnings)),'timings_ms':{k:round(v,3) for k,v in timing.items()},
            'deep_analysis_performed':False,'next_action':'analyze selected evidence' if depth=='deep' else 'read evidence'}
