"""Approved HTTP model adapters. No model downloads and no automatic external fallback."""
from __future__ import annotations
from dataclasses import dataclass, asdict
import hashlib
import ipaddress
import json
import math
import os
import ssl
import time
import urllib.error
import urllib.request
from urllib.parse import urlsplit
from typing import Protocol

class ProviderError(ValueError):
    pass

@dataclass(frozen=True)
class ProviderConfig:
    endpoint: str
    model: str
    revision: str
    dimensions: int = 0
    api_key_env: str = ''
    auth_header: str = 'Authorization'
    auth_prefix: str = 'Bearer '
    ca_file: str = ''
    allow_loopback_http: bool = False
    timeout: float = 20.0
    retries: int = 1
    retry_backoff: float = .5
    batch_items: int = 32
    max_batch_chars: int = 64000
    max_input_chars: int = 12000
    max_response_bytes: int = 8*1024*1024
    query_prefix: str = ''
    document_prefix: str = ''
    response_format: str = 'openai'
    security_domain: str = 'local-private'
    preprocessing_revision: str = 'utf8-normalize-l2-v1'
    json_output: bool = False
    max_output_tokens: int = 2048

    def validate(self) -> None:
        if not self.model or not self.revision: raise ProviderError('MODEL_REVISION_REQUIRED')
        u=urlsplit(self.endpoint)
        if not u.hostname or u.username or u.password or u.fragment or u.query:
            raise ProviderError('INVALID_ENDPOINT')
        loopback=False
        try: loopback=ipaddress.ip_address(u.hostname).is_loopback
        except ValueError: loopback=u.hostname=='localhost'
        if u.scheme!='https' and not (u.scheme=='http' and self.allow_loopback_http and loopback):
            raise ProviderError('HTTPS_REQUIRED')
        if not 0<self.timeout<=300 or not 0<=self.retries<=5 or not 0<=self.retry_backoff<=10:
            raise ProviderError('INVALID_RETRY_BUDGET')
        if not 1<=self.batch_items<=1024 or self.max_input_chars<32 or self.max_batch_chars<32:
            raise ProviderError('INVALID_INPUT_LIMIT')
        if self.max_response_bytes<256 or self.max_response_bytes>128*1024*1024:
            raise ProviderError('INVALID_RESPONSE_LIMIT')
        if any(c in self.auth_header+self.auth_prefix for c in '\r\n'):
            raise ProviderError('INVALID_AUTH_HEADER')

    @property
    def fingerprint(self) -> str:
        # Token/CA local path, timeout and batch tuning do not change the vector space.
        values={k:getattr(self,k) for k in ('endpoint','model','revision','dimensions','query_prefix',
                'document_prefix','response_format','security_domain','preprocessing_revision')}
        return hashlib.sha256(json.dumps(values,sort_keys=True,ensure_ascii=False).encode()).hexdigest()

class Embedder(Protocol):
    fingerprint: str
    dimensions: int
    def embed(self,texts: list[str],role: str='document') -> list[list[float]]: ...

class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,req,fp,code,msg,headers,newurl): return None

class JsonHTTP:
    def __init__(self, config: ProviderConfig):
        config.validate();self.config=config
        self.stats={'requests':0,'retries':0,'items':0}
        context=ssl.create_default_context(cafile=config.ca_file or None)
        self.opener=urllib.request.build_opener(_NoRedirect(),urllib.request.HTTPSHandler(context=context))

    def post(self,payload: dict) -> dict:
        c=self.config
        headers={'Content-Type':'application/json','Accept':'application/json','User-Agent':'refs-runtime/0.3'}
        if c.api_key_env:
            secret=os.environ.get(c.api_key_env)
            if not secret: raise ProviderError('MISSING_CREDENTIAL')
            if '\r' in secret or '\n' in secret: raise ProviderError('INVALID_CREDENTIAL')
            headers[c.auth_header]=c.auth_prefix+secret
        raw=json.dumps(payload,ensure_ascii=False,allow_nan=False,separators=(',',':')).encode()
        for attempt in range(c.retries+1):
            self.stats['requests']+=1
            retry_after=0.0
            try:
                req=urllib.request.Request(c.endpoint,data=raw,headers=headers,method='POST')
                with self.opener.open(req,timeout=c.timeout) as r:
                    if r.headers.get('Content-Length'):
                        try: size=int(r.headers['Content-Length'])
                        except ValueError: raise ProviderError('INVALID_CONTENT_LENGTH')
                        if size>c.max_response_bytes: raise ProviderError('RESPONSE_TOO_LARGE')
                    body=r.read(c.max_response_bytes+1)
                    if len(body)>c.max_response_bytes: raise ProviderError('RESPONSE_TOO_LARGE')
                try: value=json.loads(body)
                except (ValueError,UnicodeError) as e: raise ProviderError('INVALID_MODEL_JSON') from e
                if not isinstance(value,dict): raise ProviderError('MODEL_OBJECT_REQUIRED')
                return value
            except urllib.error.HTTPError as e:
                status=e.code
                if status in {429,500,502,503,504} and attempt<c.retries:
                    try: retry_after=min(float(e.headers.get('Retry-After','0')),5.0)
                    except (ValueError,TypeError): retry_after=0
                    e.close()
                else:
                    e.close();raise ProviderError(f'MODEL_HTTP_{status}') from None
            except (urllib.error.URLError,TimeoutError,OSError):
                if attempt>=c.retries: raise ProviderError('MODEL_CONNECTION_FAILED') from None
            self.stats['retries']+=1
            time.sleep(max(0,retry_after,min(c.retry_backoff*2**attempt,5.0)))
        raise ProviderError('MODEL_REQUEST_FAILED')


def normalized_vector(values,dimensions: int) -> list[float]:
    if not isinstance(values,list) or len(values)!=dimensions: raise ProviderError('VECTOR_DIMENSION_MISMATCH')
    if any(isinstance(v,bool) or not isinstance(v,(int,float)) or not math.isfinite(v) for v in values):
        raise ProviderError('NONFINITE_OR_NONNUMERIC_VECTOR')
    norm=math.hypot(*values)
    if not math.isfinite(norm) or norm<=1e-30: raise ProviderError('ZERO_OR_INVALID_VECTOR')
    return [float(v/norm) for v in values]

class EmbeddingProvider:
    def __init__(self,config: ProviderConfig):
        config.validate()
        if not 1<=config.dimensions<=32768: raise ProviderError('EMBEDDING_DIMENSIONS_REQUIRED')
        if config.response_format not in {'openai','vectors'}: raise ProviderError('UNKNOWN_RESPONSE_FORMAT')
        self.config=config;self.dimensions=config.dimensions;self.fingerprint=config.fingerprint
        self.http=JsonHTTP(config);self.stats=self.http.stats

    def embed(self,texts: list[str],role: str='document') -> list[list[float]]:
        if role not in {'query','document'}: raise ProviderError('INVALID_EMBEDDING_ROLE')
        prefix=self.config.query_prefix if role=='query' else self.config.document_prefix
        inputs=[]
        for text in texts:
            if not isinstance(text,str) or not text: raise ProviderError('EMPTY_EMBEDDING_INPUT')
            value=prefix+text
            if len(value)>self.config.max_input_chars or len(value)>self.config.max_batch_chars:
                raise ProviderError('INPUT_TOO_LONG')
            inputs.append(value)
        result=[];batch=[];chars=0
        for value in inputs:
            if batch and (len(batch)>=self.config.batch_items or chars+len(value)>self.config.max_batch_chars):
                result.extend(self._batch(batch));batch=[];chars=0
            batch.append(value);chars+=len(value)
        if batch: result.extend(self._batch(batch))
        return result

    def _batch(self,inputs: list[str]) -> list[list[float]]:
        response=self.http.post({'model':self.config.model,'input':inputs,'encoding_format':'float'})
        if self.config.response_format=='vectors':
            vectors=response.get('vectors')
        else:
            rows=response.get('data')
            if not isinstance(rows,list) or len(rows)!=len(inputs): raise ProviderError('VECTOR_COUNT_MISMATCH')
            indices=[r.get('index') for r in rows if isinstance(r,dict)]
            if len(indices)!=len(inputs) or any(type(i)!=int for i in indices) or set(indices)!=set(range(len(inputs))):
                raise ProviderError('VECTOR_INDEX_MISMATCH')
            vectors=[r.get('embedding') for r in sorted(rows,key=lambda x:x['index'])]
        if not isinstance(vectors,list) or len(vectors)!=len(inputs): raise ProviderError('VECTOR_COUNT_MISMATCH')
        result=[normalized_vector(v,self.dimensions) for v in vectors]
        self.stats['items']+=len(inputs)
        return result

class ChatProvider:
    def __init__(self,config: ProviderConfig):
        config.validate();self.config=config
        self.fingerprint=hashlib.sha256(json.dumps([config.fingerprint,config.json_output,config.max_output_tokens,'temperature=0'],sort_keys=True).encode()).hexdigest()
        self.http=JsonHTTP(config);self.stats=self.http.stats

    def complete(self,messages: list[dict[str,str]]) -> str:
        if not messages or any(m.get('role') not in {'system','user','assistant'} or not isinstance(m.get('content'),str) for m in messages):
            raise ProviderError('INVALID_MESSAGES')
        if sum(len(m['content']) for m in messages)>self.config.max_input_chars:
            raise ProviderError('LLM_INPUT_TOO_LONG')
        payload={'model':self.config.model,'messages':messages,'temperature':0,
                 'max_tokens':self.config.max_output_tokens}
        if self.config.json_output: payload['response_format']={'type':'json_object'}
        result=self.http.post(payload)
        try: content=result['choices'][0]['message']['content']
        except (KeyError,IndexError,TypeError): raise ProviderError('INVALID_CHAT_RESPONSE') from None
        if not isinstance(content,str): raise ProviderError('CHAT_TEXT_REQUIRED')
        self.stats['items']+=1
        return content
