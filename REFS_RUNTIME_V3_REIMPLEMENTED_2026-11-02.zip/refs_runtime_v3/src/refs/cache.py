"""Verified content-addressed raw-source cache; not a replacement source of truth."""
from __future__ import annotations
from pathlib import Path
import hashlib
import os
import re
import tempfile
import zlib

class CacheError(ValueError): pass

class BlobCache:
    def __init__(self, root: Path, max_bytes: int=16*1024*1024):
        self.root=Path(root);self.root.mkdir(parents=True,exist_ok=True,mode=0o700)
        self.max_bytes=max_bytes

    def path(self, digest: str) -> Path:
        if not re.fullmatch(r'[0-9a-f]{64}',digest): raise CacheError('INVALID_CONTENT_HASH')
        return self.root/digest[:2]/(digest[2:]+'.z')

    def put(self, body: bytes) -> str:
        if len(body)>self.max_bytes: raise CacheError('BLOB_TOO_LARGE')
        digest=hashlib.sha256(body).hexdigest();target=self.path(digest)
        target.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
        if target.is_symlink() or target.parent.is_symlink(): raise CacheError('CACHE_SYMLINK_REJECTED')
        if target.exists():
            self.get(digest)  # Never silently bless an already-corrupted cache entry.
            return digest
        fd,tmp=tempfile.mkstemp(prefix='.stage-',dir=target.parent)
        try:
            with os.fdopen(fd,'wb') as f:
                f.write(zlib.compress(body,level=3));f.flush();os.fsync(f.fileno())
            os.replace(tmp,target)
        finally:
            if os.path.exists(tmp): os.unlink(tmp)
        return digest

    def get(self, digest: str) -> bytes:
        p=self.path(digest)
        if p.is_symlink() or p.parent.is_symlink(): raise CacheError('CACHE_SYMLINK_REJECTED')
        try:
            with p.open('rb') as f: raw=f.read(self.max_bytes+65537)
            if len(raw)>self.max_bytes+65536: raise CacheError('CACHE_TOO_LARGE')
            d=zlib.decompressobj();body=d.decompress(raw,self.max_bytes+1)
            if len(body)>self.max_bytes or not d.eof or d.unused_data: raise CacheError('INVALID_CACHE_COMPRESSION')
        except (OSError,zlib.error) as e: raise CacheError('CACHE_UNAVAILABLE_OR_CORRUPT') from e
        if hashlib.sha256(body).hexdigest()!=digest: raise CacheError('CONTENT_HASH_MISMATCH')
        return body
