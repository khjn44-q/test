"""Evidence identity, source paging, snapshot sessions, and conservative navigation."""
from __future__ import annotations
import bisect
import difflib
import hashlib
import json
import time
import uuid
from urllib.parse import quote,urlsplit
from .errors import RefsError
from .store import digest,dumps,now


def select_scope(runtime,repo_ids=None,session_id=None):
    if session_id:
        s=runtime.store.one('SELECT * FROM sessions WHERE session_id=?',(session_id,))
        if not s or s['expires_at']<time.time():raise RefsError('SESSION_UNAVAILABLE_OR_EXPIRED')
        scope=json.loads(s['snapshots_json'])
        for rid in scope:runtime._repo(rid)
        if repo_ids is not None:
            if any(r not in scope for r in repo_ids):raise RefsError('SESSION_SCOPE_EXPANSION_REQUIRES_NEW_SEARCH')
            scope={r:scope[r] for r in repo_ids}
    else:
        rows=runtime.store.rows('SELECT repo_id,active_snapshot FROM repositories WHERE enabled=1 ORDER BY repo_id')
        if repo_ids is not None:
            for rid in repo_ids:runtime._repo(rid)
            rows=[r for r in rows if r['repo_id'] in repo_ids]
        scope={r['repo_id']:r['active_snapshot'] for r in rows}
    return scope


def check_scope(runtime,scope):
    for rid in scope: runtime._repo(rid)


def save_session(runtime,query,scope,result_ids):
    sid='session-'+uuid.uuid4().hex
    runtime.store.conn.execute('INSERT INTO sessions VALUES(?,?,?,?,?,?)',
                              (sid,query,dumps(scope),dumps(result_ids),now(),time.time()+30*86400))
    return sid


def evidence_record(row,*,byte_start=None,byte_end=None,line_start=None,line_end=None):
    r={'repo_id':row['repo_id'],'snapshot_id':row['snapshot_id'],'path':row['path'],
       'unit_id':row.get('unit_id'),'content_hash':row['content_hash'],'git_oid':row['git_oid'],
       'byte_start':row['byte_start'] if byte_start is None else byte_start,
       'byte_end':row['byte_end'] if byte_end is None else byte_end,
       'line_start':row['line_start'] if line_start is None else line_start,
       'line_end':row['line_end'] if line_end is None else line_end}
    r['evidence_id']='ev-'+digest(r)
    return r


def put_evidence(runtime,record):
    r=record
    runtime.store.conn.execute('INSERT OR IGNORE INTO evidence VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',
       (r['evidence_id'],r['repo_id'],r['snapshot_id'],r['path'],r.get('unit_id'),r['content_hash'],r['git_oid'],
        r['byte_start'],r['byte_end'],r['line_start'],r['line_end'],now()))
    return r['evidence_id']


def source_url(runtime,repo_id,commit,path):
    r=runtime._repo(repo_id);url=r['web_url']
    if not url:return None
    encoded=quote(path,safe='/')
    if '{commit}' in url or '{path}' in url:
        return url.replace('{commit}',commit).replace('{path}',encoded)
    host=urlsplit(url).hostname
    if host=='github.com':return url.rstrip('/')+'/blob/'+commit+'/'+encoded
    if host=='gitlab.com':return url.rstrip('/')+'/-/blob/'+commit+'/'+encoded
    return None  # No invented links for unknown self-hosted routing conventions.


def read_evidence(runtime,evidence_id,*,start_line=None,line_limit=120,start_byte=None,max_chars=16000):
    if not isinstance(evidence_id,str) or len(evidence_id)>80:raise RefsError('INVALID_EVIDENCE_ID')
    if type(line_limit)!=int or not 1<=line_limit<=1000 or not 32<=max_chars<=200000:raise RefsError('INVALID_READ_LIMIT')
    e=runtime.store.one('SELECT * FROM evidence WHERE evidence_id=?',(evidence_id,))
    if not e:raise RefsError('EVIDENCE_UNAVAILABLE')
    repo=runtime._repo(e['repo_id'])
    s=runtime.store.one('SELECT * FROM snapshots WHERE snapshot_id=? AND repo_id=?',(e['snapshot_id'],e['repo_id']))
    f=runtime.store.one('SELECT * FROM snapshot_files WHERE snapshot_id=? AND path=?',(e['snapshot_id'],e['path']))
    if not s or not f or f['content_hash']!=e['content_hash'] or f['git_oid']!=e['git_oid']:
        raise RefsError('EVIDENCE_SOURCE_MISMATCH')
    body=runtime.cache.get(e['content_hash'])
    h=hashlib.sha1() if len(e['git_oid'])==40 else hashlib.sha256()
    h.update(b'blob '+str(len(body)).encode()+b'\0'+body)
    if h.hexdigest()!=e['git_oid']:raise RefsError('GIT_OBJECT_HASH_MISMATCH')
    if not 0<=e['byte_start']<=e['byte_end']<=len(body):raise RefsError('EVIDENCE_RANGE_MISMATCH')
    text=body.decode('utf-8');lines=text.splitlines(keepends=True)
    offsets=[0]
    for line in lines: offsets.append(offsets[-1]+len(line.encode('utf-8')))
    total=len(lines)
    if start_byte is not None:
        if type(start_byte)!=int or not 0<=start_byte<=len(body):raise RefsError('INVALID_BYTE_OFFSET')
        try: body[:start_byte].decode('utf-8')
        except UnicodeError:raise RefsError('NOT_UTF8_BOUNDARY') from None
        begin=start_byte;end=len(body)
    elif start_line is not None:
        if type(start_line)!=int or not 1<=start_line<=max(1,total):raise RefsError('INVALID_LINE_OFFSET')
        begin=offsets[start_line-1];end=offsets[min(total,start_line-1+line_limit)]
    else:
        begin=e['byte_start'];end=e['byte_end']
    excerpt=body[begin:end].decode('utf-8')
    truncated=len(excerpt)>max_chars
    if truncated:
        excerpt=excerpt[:max_chars];end=begin+len(excerpt.encode())
    line_a=bisect.bisect_right(offsets,begin)
    line_b=bisect.bisect_right(offsets,max(begin,end-1))
    runtime._repo(e['repo_id'])  # Revocation after cache read must still fail closed at this boundary.
    return {'schema_version':'3.0','evidence_id':evidence_id,'repo_id':e['repo_id'],'snapshot_id':e['snapshot_id'],
            'commit':s['commit_oid'],'path':e['path'],'git_blob_oid':e['git_oid'],'content_sha256':e['content_hash'],
            'evidence_byte_start':e['byte_start'],'evidence_byte_end':e['byte_end'],
            'evidence_line_start':e['line_start'],'evidence_line_end':e['line_end'],
            'returned_byte_start':begin,'returned_byte_end':end,'returned_line_start':line_a,'returned_line_end':line_b,
            'total_lines':total,'text':excerpt,'verification':'bytes_verified','is_active_snapshot':repo['active_snapshot']==e['snapshot_id'],
            'truncated':truncated,'next_byte':end if end<len(body) else None,
            'next_start_line':line_b+1 if end<len(body) and end in offsets else None,
            'source_url':source_url(runtime,e['repo_id'],s['commit_oid'],e['path']),
            'source_instructions_trusted':False}


def compare(runtime,a,b,max_chars=32000):
    x=read_evidence(runtime,a,max_chars=200000);y=read_evidence(runtime,b,max_chars=200000)
    out=''.join(difflib.unified_diff(x['text'].splitlines(keepends=True),y['text'].splitlines(keepends=True),
         fromfile=x['commit']+'/'+x['path'],tofile=y['commit']+'/'+y['path']))
    return {'a':a,'b':b,'diff':out[:max_chars],'truncated':len(out)>max_chars or x['truncated'] or y['truncated'],
            'execution_performed':False,'scope':'selected evidence ranges, not automatically entire files'}


def trace(runtime,evidence_id,direction='out',limit=100):
    if direction not in {'in','out'} or not 1<=limit<=500:raise RefsError('INVALID_TRACE_REQUEST')
    ev=read_evidence(runtime,evidence_id,max_chars=32)
    e=runtime.store.one('SELECT * FROM evidence WHERE evidence_id=?',(evidence_id,))
    unit=runtime.store.one('SELECT * FROM units WHERE unit_id=?',(e['unit_id'],)) if e['unit_id'] else None
    symbol=unit['symbol'] if unit else ''
    scope={e['repo_id']:e['snapshot_id']};found=[];scanned=0;truncated=False
    for f in runtime.files(e['repo_id'],snapshot_id=e['snapshot_id']):
        if not f['parse_key']:continue
        p=runtime.store.one('SELECT relations_json,parser FROM parses WHERE parse_key=?',(f['parse_key'],));scanned+=1
        for edge in json.loads(p['relations_json']):
            match=(edge['source']==symbol and f['path']==e['path']) if direction=='out' else (edge['target'].split('.')[-1]==symbol.split('.')[-1] and bool(symbol))
            if not match:continue
            result={**edge,'path':f['path'],'repo_id':e['repo_id'],'snapshot_id':e['snapshot_id'],
                    'target_resolution':'lexical_candidate','execution_verified':False,'source_evidence_id':evidence_id}
            # Exact callsite is byte-grounded; the link to a similarly named target remains a candidate.
            body=runtime.cache.get(f['content_hash']);ls=body.splitlines(keepends=True);line=edge['line']
            bs=sum(len(x) for x in ls[:line-1]);be=bs+len(ls[line-1]) if 0<line<=len(ls) else bs
            rec=evidence_record({**f,'repo_id':e['repo_id'],'byte_start':bs,'byte_end':be,'line_start':line,'line_end':line,'unit_id':None})
            result['callsite_evidence_id']=put_evidence(runtime,rec)
            found.append(result)
            if len(found)>=limit:truncated=True;break
        if truncated:break
    return {'evidence_id':evidence_id,'symbol':symbol,'direction':direction,'relations':found,'truncated':truncated,
            'files_examined':scanned,'scope':'selected repository snapshot','coverage':'Python syntax only; no type-resolved or complete dynamic call graph'}
