"""Read immutable Git objects. Never checks out, edits, or pushes source repositories."""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import base64
import hashlib
import os
import re
import subprocess
from urllib.parse import urlsplit

class GitError(ValueError):
    def __init__(self, code: str, detail: str = ''):
        self.code = code
        super().__init__(code + (': ' + detail if detail else ''))

@dataclass(frozen=True)
class TreeEntry:
    path: str
    oid: str
    size: int
    mode: str
    object_type: str
    path_valid: bool = True
    path_bytes_b64: str = ''

    @property
    def is_regular(self) -> bool:
        return self.mode in {'100644', '100755'} and self.object_type == 'blob' and self.path_valid


def _env(allow_local: bool = False) -> dict[str, str]:
    env = dict(os.environ)
    for k in ('GIT_DIR','GIT_WORK_TREE','GIT_INDEX_FILE','GIT_OBJECT_DIRECTORY','GIT_ALTERNATE_OBJECT_DIRECTORIES'):
        env.pop(k, None)
    env.update(GIT_TERMINAL_PROMPT='0', GIT_OPTIONAL_LOCKS='0', GIT_NO_REPLACE_OBJECTS='1',
               GIT_ALLOW_PROTOCOL='https:ssh:file' if allow_local else 'https:ssh', GIT_PAGER='cat')
    return env


def run_git(path: Path, args: list[str], *, data: bytes | None = None,
            timeout: float = 30, allow_local: bool = False) -> bytes:
    command = ['git','-C',str(path),'-c','core.fsmonitor=false','-c','core.hooksPath='+os.devnull,
               '-c','gc.auto=0','-c','fetch.recurseSubmodules=false',*args]
    try:
        result = subprocess.run(command, input=data, capture_output=True, timeout=timeout,
                                env=_env(allow_local), check=False)
    except subprocess.TimeoutExpired as e:
        raise GitError('GIT_TIMEOUT') from e
    except OSError as e:
        raise GitError('GIT_UNAVAILABLE') from e
    if result.returncode:
        # Git stderr can contain credential-bearing URLs; deliberately do not return it.
        raise GitError('GIT_COMMAND_FAILED', f'{args[0]} exit={result.returncode}')
    return result.stdout


def _ref(ref: str) -> str:
    if not isinstance(ref,str) or not re.fullmatch(r'[A-Za-z0-9_./@{}~^+\-]+',ref) or ref.startswith('-') or len(ref)>300:
        raise GitError('INVALID_REF')
    return ref


class GitSource:
    def __init__(self, path: str | Path, *, max_file_bytes: int = 2*1024*1024, timeout: float = 30):
        self.path = Path(path).expanduser().resolve()
        if not self.path.is_dir(): raise GitError('REPOSITORY_NOT_FOUND')
        self.max_file_bytes = max_file_bytes
        self.timeout = timeout

    def resolve(self, ref: str = 'HEAD') -> str:
        oid = run_git(self.path,['rev-parse','--verify','--end-of-options',_ref(ref)+'^{commit}'],timeout=self.timeout).decode().strip()
        if not re.fullmatch(r'[0-9a-f]{40}|[0-9a-f]{64}',oid): raise GitError('INVALID_COMMIT')
        return oid

    def list_files(self, commit: str) -> list[TreeEntry]:
        if not re.fullmatch(r'[0-9a-f]{40}|[0-9a-f]{64}',commit): raise GitError('INVALID_COMMIT')
        raw = run_git(self.path,['ls-tree','-r','-l','-z','--full-tree',commit],timeout=self.timeout)
        entries=[]
        for item in raw.split(b'\0'):
            if not item: continue
            meta, path = item.split(b'\t',1)
            mode,typ,oid,size = meta.split()
            valid=True
            try: name=path.decode('utf-8')
            except UnicodeDecodeError:
                valid=False; name='[non-utf8:'+base64.b64encode(path).decode()+']'
            entries.append(TreeEntry(name,oid.decode(),int(size) if size != b'-' else 0,
                                     mode.decode(),typ.decode(),valid,base64.b64encode(path).decode() if not valid else ''))
        return entries

    def read_blobs(self, entries: list[TreeEntry], *, batch_bytes: int = 16*1024*1024) -> dict[str,bytes]:
        unique={e.oid:e for e in entries}
        for e in unique.values():
            if e.object_type != 'blob' or not re.fullmatch(r'[0-9a-f]{40}|[0-9a-f]{64}',e.oid):
                raise GitError('INVALID_BLOB')
            if e.size > self.max_file_bytes: raise GitError('FILE_TOO_LARGE')
        result={}; batch=[]; size=0
        for e in unique.values():
            if batch and (size+e.size>batch_bytes or len(batch)>=256):
                result.update(self._read_batch(batch));batch=[];size=0
            batch.append(e);size+=e.size
        if batch: result.update(self._read_batch(batch))
        return result

    def _read_batch(self, entries: list[TreeEntry]) -> dict[str,bytes]:
        raw=run_git(self.path,['cat-file','--batch'],data=('\n'.join(e.oid for e in entries)+'\n').encode(),timeout=self.timeout)
        result={}; pos=0
        for e in entries:
            end=raw.find(b'\n',pos)
            if end<0: raise GitError('INVALID_BATCH_RESPONSE')
            header=raw[pos:end].split();pos=end+1
            if len(header)!=3 or header[0].decode()!=e.oid or header[1]!=b'blob': raise GitError('INVALID_BATCH_RESPONSE')
            n=int(header[2])
            if n!=e.size or n>self.max_file_bytes: raise GitError('BLOB_SIZE_MISMATCH')
            body=raw[pos:pos+n];pos+=n
            if len(body)!=n or raw[pos:pos+1]!=b'\n': raise GitError('INVALID_BATCH_RESPONSE')
            pos+=1
            h=hashlib.sha1() if len(e.oid)==40 else hashlib.sha256()
            h.update(b'blob '+str(n).encode()+b'\0'+body)
            if h.hexdigest()!=e.oid: raise GitError('GIT_BLOB_HASH_MISMATCH')
            result[e.oid]=body
        if pos!=len(raw): raise GitError('TRAILING_BATCH_BYTES')
        return result


def validate_remote(remote: str, *, allow_local: bool=False) -> str:
    if not isinstance(remote,str) or not remote or any(c in remote for c in '\r\n\0') or remote.startswith('-'):
        raise GitError('INVALID_REMOTE')
    if allow_local and Path(remote).is_absolute() and Path(remote).is_dir(): return remote
    if re.fullmatch(r'[\w.-]+@[\w.-]+:[\w./~-]+',remote): return remote
    u=urlsplit(remote)
    if u.scheme not in {'https','ssh'} or not u.hostname or u.password or u.query or u.fragment:
        raise GitError('INVALID_REMOTE')
    if u.scheme=='https' and u.username: raise GitError('EMBEDDED_CREDENTIAL_REJECTED')
    return remote


def fetch_mirror(remote: str, cache_path: Path, ref: str='HEAD', *, allow_local: bool=False,
                 timeout: float=120, depth: int=1) -> tuple[GitSource,str]:
    validate_remote(remote,allow_local=allow_local);_ref(ref)
    if type(depth)!=int or not 0<=depth<=100000:raise GitError('INVALID_FETCH_DEPTH')
    cache_path=Path(cache_path).resolve();cache_path.mkdir(parents=True,exist_ok=True)
    if not (cache_path/'HEAD').exists(): run_git(cache_path,['init','--bare','--quiet'],allow_local=allow_local)
    # Writes only the managed cache, never the source repository or user's checkout.
    run_git(cache_path,['fetch','--no-tags','--no-recurse-submodules','--force',*(['--depth='+str(depth)] if depth else []),'--',remote,
                        f'{ref}:refs/refs-runtime/source'],timeout=timeout,allow_local=allow_local)
    source=GitSource(cache_path)
    return source,source.resolve('refs/refs-runtime/source')
