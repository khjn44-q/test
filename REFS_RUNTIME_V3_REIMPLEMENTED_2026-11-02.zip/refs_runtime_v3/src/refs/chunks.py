"""Lossless source partitioning; Python AST where available, labelled text fallback elsewhere."""
from __future__ import annotations
from dataclasses import dataclass,field
import ast
from array import array
import bisect
import hashlib
import re

PARSER_VERSION='refs-chunk-v3.1'

@dataclass(frozen=True)
class Chunk:
    text: str
    byte_start: int
    byte_end: int
    line_start: int
    line_end: int
    symbol: str
    kind: str
    resolution: str

@dataclass
class ParsedFile:
    chunks: list[Chunk]
    relations: list[dict]
    parser: str
    warnings: list[str]=field(default_factory=list)


def code_tokens(text: str) -> str:
    split=re.sub(r'([a-z0-9])([A-Z])',r'\1 \2',text)
    return re.sub(r'[_:/\\.\-]+',' ',split)


def _call_name(node: ast.AST) -> str:
    if isinstance(node,ast.Name): return node.id
    if isinstance(node,ast.Attribute):
        prefix=_call_name(node.value)
        return (prefix+'.' if prefix else '')+node.attr
    return ''


def chunk_file(path: str, data: bytes, max_chars: int=3000) -> ParsedFile:
    if max_chars<32: raise ValueError('CHUNK_LIMIT_TOO_SMALL')
    try: text=data.decode('utf-8')
    except UnicodeDecodeError as e: raise ValueError('UNSUPPORTED_UTF8') from e
    if '\x00' in text: raise ValueError('BINARY_SOURCE')
    if not text: return ParsedFile([],[],'text_fallback')
    lines=text.splitlines(keepends=True)
    line_offsets=[0]
    for line in lines: line_offsets.append(line_offsets[-1]+len(line))
    declarations=[];relations=[];parser='text_fallback';warnings=[]
    if path.lower().endswith('.py'):
        try:
            tree=ast.parse(text.lstrip('\ufeff'))
            parser='python_ast'
            def visit(node, prefix='', owner=''):
                newprefix=prefix;newowner=owner
                if isinstance(node,(ast.ClassDef,ast.FunctionDef,ast.AsyncFunctionDef)):
                    name=prefix+node.name
                    first=min([node.lineno]+[d.lineno for d in getattr(node,'decorator_list',[])])
                    declarations.append((line_offsets[first-1],line_offsets[min(node.end_lineno,len(lines))],name))
                    newprefix=name+'.';newowner=name
                if isinstance(node,ast.Call):
                    target=_call_name(node.func)
                    if target: relations.append({'source':owner,'target':target,'line':node.lineno,'kind':'calls','resolution':'syntax_observed'})
                if isinstance(node,(ast.Import,ast.ImportFrom)):
                    targets=[a.name for a in node.names] if isinstance(node,ast.Import) else [node.module or '']
                    for target in targets: relations.append({'source':owner,'target':target,'line':node.lineno,'kind':'imports','resolution':'syntax_observed'})
                for child in ast.iter_child_nodes(node): visit(child,newprefix,newowner)
            visit(tree)
        except (SyntaxError,ValueError,RecursionError): warnings.append('PYTHON_AST_FAILED_TEXT_FALLBACK')
    else:
        # Names are navigation hints, not a complete parser/call graph.
        pattern=re.compile(r'^\s*(?:export\s+)?(?:async\s+)?(?:function|class|def|fn)\s+([A-Za-z_$][\w$]*)')
        for n,line in enumerate(lines):
            m=pattern.match(line)
            if m: declarations.append((line_offsets[n],line_offsets[n+1],m.group(1)))
    cuts={0,len(text)}
    for start,end,_ in declarations: cuts.add(start);cuts.add(end)
    cuts=sorted(cuts);pieces=[]
    for start,end in zip(cuts,cuts[1:]):
        pos=start
        while pos<end:
            stop=min(end,pos+max_chars)
            if stop<end:
                newline=text.rfind('\n',pos,stop)
                if newline>=pos+max_chars//3: stop=newline+1
            candidates=[d for d in declarations if d[0]<=pos<d[1]]
            symbol=min(candidates,key=lambda d:d[1]-d[0])[2] if candidates else ''
            pieces.append((pos,stop,symbol));pos=stop
    # Character-to-byte map once, avoiding O(number_of_chunks * file_size) encoding.
    byte_offsets=array('I',[0])
    for char in text: byte_offsets.append(byte_offsets[-1]+len(char.encode('utf-8')))
    kind='document' if path.lower().endswith(('.md','.rst','.txt','.adoc')) else 'code'
    low=path.lower()
    if any(x in low.split('/') for x in ('test','tests','testing')) or low.split('/')[-1].startswith('test_'): kind='test'
    elif any(x in low.split('/') for x in ('example','examples')): kind='example'
    elif low.endswith(('.json','.toml','.yaml','.yml','.ini','.cfg','.lock')): kind='config'
    chunks=[]
    for start,end,symbol in pieces:
        chunks.append(Chunk(text[start:end],byte_offsets[start],byte_offsets[end],
                            bisect.bisect_right(line_offsets,start),bisect.bisect_right(line_offsets,max(start,end-1)),
                            symbol,kind,'syntax_observed' if parser=='python_ast' else 'lexical_candidate'))
    return ParsedFile(chunks,relations,parser,warnings)
