class RefsError(ValueError):
    def __init__(self, code: str, detail: str = ''):
        self.code=code
        super().__init__(code + (': '+detail if detail else ''))

class IndexError(RefsError):
    pass
