"""One tool dispatcher shared by CLI and the optional official MCP adapter."""
from .errors import RefsError

def invoke(runtime,name,arguments,*,allow_update=False):
    table={
        'refs_search':runtime.find,'refs_scan':runtime.scan,'refs_read_evidence':runtime.evidence,
        'refs_trace':runtime.trace,'refs_compare':runtime.compare,'refs_analyze':runtime.analyze,
        'refs_summarize':runtime.summarize,'refs_prepare_use':runtime.prepare_use,'refs_index_status':runtime.status,
    }
    if allow_update:table['refs_update']=runtime.update
    if name not in table:raise RefsError('UNKNOWN_TOOL')
    if not isinstance(arguments,dict):raise RefsError('OBJECT_ARGUMENTS_REQUIRED')
    try:return table[name](**arguments)
    except TypeError as e:raise RefsError('INVALID_TOOL_ARGUMENTS') from e
