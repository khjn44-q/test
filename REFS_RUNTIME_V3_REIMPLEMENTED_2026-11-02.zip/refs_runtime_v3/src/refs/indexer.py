"""Incremental ingestion. Network/model work is outside the publication transaction."""
from __future__ import annotations
from dataclasses import dataclass,asdict
from pathlib import Path,PurePosixPath
from collections import Counter
import fnmatch
import hashlib
import json
import re
import time
import uuid
from .errors import IndexError
from .cache import BlobCache
from .chunks import PARSER_VERSION,chunk_file
from .git import GitSource,fetch_mirror,validate_remote
from .providers import normalized_vector
from .store import Store,WriterLock,digest,dumps,now

@dataclass(frozen=True)
class IndexSettings:
    chunk_chars: int=3000
    max_file_bytes: int=2*1024*1024
    max_files: int=200000
    git_timeout: float=60
    fetch_depth: int=1
    embedding_batch_items: int=32
    embedding_scope: str='all_text'
    exclude_globs: tuple[str,...]=('.env','.env.*','**/.env','**/.env.*','*.min.js','*.map')
    exclude_dirs: tuple[str,...]=('.git','.venv','venv','node_modules','vendor','dist','build','__pycache__')
    include_globs: tuple[str,...]=()

    def validate(self):
        if self.embedding_scope not in {'all_text','summaries_only'}:raise IndexError('INVALID_EMBEDDING_SCOPE')
        if type(self.fetch_depth)!=int or not 0<=self.fetch_depth<=100000:raise IndexError('INVALID_FETCH_DEPTH')
        if not 64<=self.chunk_chars<=32000 or not 64<=self.max_file_bytes<=16*1024*1024:
            raise IndexError('INVALID_INDEX_LIMITS')
        if not 1<=self.max_files<=2000000 or not 1<=self.embedding_batch_items<=1024 or not 0<self.git_timeout<=600:
            raise IndexError('INVALID_INDEX_LIMITS')
    @property
    def fingerprint(self):
        value=asdict(self);value.pop('git_timeout');value.pop('embedding_batch_items');value.pop('fetch_depth');value.pop('embedding_scope')
        return digest([PARSER_VERSION,value,'secret-filter-v1'])


def _role(path):
    p=path.lower();parts=PurePosixPath(p).parts
    if 'tests' in parts or 'test' in parts or parts[-1].startswith('test_'):return 'test'
    if 'examples' in parts or 'example' in parts:return 'example'
    return PurePosixPath(p).suffix


def _safe_error(e):
    code=getattr(e,'code',None)
    if isinstance(code,str) and re.fullmatch('[A-Z0-9_]+',code): return code
    msg=str(e).split(':',1)[0]
    return msg if re.fullmatch('[A-Z0-9_]+',msg) else type(e).__name__

class Index:
    def __init__(self,home: str|Path,*,embedding=None,llm=None,settings: IndexSettings|None=None):
        self.home=Path(home).expanduser().resolve();self.home.mkdir(parents=True,exist_ok=True,mode=0o700)
        self.store=Store(self.home/'catalog.sqlite3');self.cache=BlobCache(self.home/'blobs')
        self.embedding=embedding;self.llm=llm;self.settings=settings or IndexSettings();self.settings.validate()
    def __enter__(self):return self
    def __exit__(self,*args):self.close()
    def close(self):self.store.close()

    def register(self,repo_id: str,*,path: str|None=None,url: str|None=None,ref: str='HEAD',web_url: str='',allow_local_remote: bool=False):
        if not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9_.-]{0,79}',repo_id):raise IndexError('INVALID_REPOSITORY_ID')
        if bool(path)==bool(url):raise IndexError('EXACTLY_ONE_SOURCE_REQUIRED')
        from .git import _ref
        _ref(ref)
        kind='local' if path else 'remote'
        location=str(Path(path).expanduser().resolve()) if path else validate_remote(url,allow_local=allow_local_remote)
        if web_url:validate_remote(web_url)
        prior=self.store.one('SELECT * FROM repositories WHERE repo_id=?',(repo_id,))
        if prior:
            if any(prior[k]!=v for k,v in [('location',location),('source_kind',kind),('ref',ref)]):
                raise IndexError('REPO_ID_ALREADY_BOUND')
            return {'repo_id':repo_id,'registered':False}
        with self.store.transaction() as c:
            c.execute('INSERT INTO repositories(repo_id,location,source_kind,ref,web_url,allow_local_remote) VALUES(?,?,?,?,?,?)',
                      (repo_id,location,kind,ref,web_url,int(allow_local_remote)))
        return {'repo_id':repo_id,'registered':True}

    def set_enabled(self,repo_id,enabled):
        if not self.store.one('SELECT repo_id FROM repositories WHERE repo_id=?',(repo_id,)):raise IndexError('REPOSITORY_NOT_FOUND')
        self.store.conn.execute('UPDATE repositories SET enabled=? WHERE repo_id=?',(int(bool(enabled)),repo_id))

    def _repo(self,repo_id):
        r=self.store.one('SELECT * FROM repositories WHERE repo_id=? AND enabled=1',(repo_id,))
        if not r:raise IndexError('REPOSITORY_UNAVAILABLE')
        return r

    def snapshot_map(self,repo_ids=None):
        rows=self.store.rows('SELECT repo_id,active_snapshot FROM repositories WHERE enabled=1 AND active_snapshot IS NOT NULL ORDER BY repo_id')
        if repo_ids is not None:
            for r in repo_ids:self._repo(r)
            rows=[r for r in rows if r['repo_id'] in repo_ids]
        return {r['repo_id']:r['active_snapshot'] for r in rows}

    def files(self,repo_id,snapshot_id=None):
        repo=self._repo(repo_id);sid=snapshot_id or repo['active_snapshot']
        if not sid:return []
        if not self.store.one('SELECT snapshot_id FROM snapshots WHERE snapshot_id=? AND repo_id=?',(sid,repo_id)):
            raise IndexError('SNAPSHOT_UNAVAILABLE')
        return self.store.rows('SELECT * FROM snapshot_files WHERE snapshot_id=? ORDER BY path',(sid,))

    def status(self):
        repos=self.store.rows('SELECT repo_id,enabled,active_snapshot AS snapshot_id,last_check,last_error FROM repositories ORDER BY repo_id')
        for r in repos:
            if r['snapshot_id']:
                s=self.store.one('SELECT commit_oid,coverage_json,created_at FROM snapshots WHERE snapshot_id=?',(r['snapshot_id'],))
                r.update(commit=s['commit_oid'],coverage=json.loads(s['coverage_json']),indexed_at=s['created_at'])
            else:r.update(commit=None,coverage=None,indexed_at=None)
        counts={table:self.store.conn.execute('SELECT count(*) FROM '+table).fetchone()[0] for table in ('units','snapshots','embeddings','notes')}
        return {'schema_version':'3.0','repositories':repos,**counts,
                'semantic_configured':self.embedding is not None,'embedding_scope':self.settings.embedding_scope,'embedding_fingerprint':getattr(self.embedding,'fingerprint',None),
                'llm_configured':self.llm is not None,'database_bytes':self.store.path.stat().st_size,
                'multiuser_authorization':False}

    def _source(self,repo,fetch):
        if repo['source_kind']=='local':
            source=GitSource(repo['location'],max_file_bytes=self.settings.max_file_bytes,timeout=self.settings.git_timeout)
            return source,source.resolve(repo['ref'])
        cache=self.home/'git'/ (repo['repo_id']+'.git')
        if fetch:
            source,commit=fetch_mirror(repo['location'],cache,repo['ref'],allow_local=bool(repo['allow_local_remote']),timeout=self.settings.git_timeout,depth=self.settings.fetch_depth)
            source.max_file_bytes=self.settings.max_file_bytes
            return source,commit
        source=GitSource(cache,max_file_bytes=self.settings.max_file_bytes,timeout=self.settings.git_timeout)
        return source,source.resolve('refs/refs-runtime/source')

    def _excluded(self,entry):
        if not entry.path_valid:return 'unsupported_path_encoding'
        if entry.mode=='120000':return 'symlink'
        if entry.mode=='160000':return 'submodule'
        if not entry.is_regular:return 'non_regular'
        if any(p in self.settings.exclude_dirs for p in PurePosixPath(entry.path).parts):return 'excluded_path'
        if any(fnmatch.fnmatchcase(entry.path,p) for p in self.settings.exclude_globs):return 'excluded_path'
        if self.settings.include_globs and not any(fnmatch.fnmatchcase(entry.path,p) for p in self.settings.include_globs):return 'outside_include_policy'
        if entry.size>self.settings.max_file_bytes:return 'too_large'
        return ''

    def _ensure_vectors(self,parse_keys,stats,rebuild=False):
        if self.embedding is None or self.settings.embedding_scope=='summaries_only':return
        model=self.embedding;seen=set();pending=[]
        def flush():
            if not pending:return
            vectors=model.embed([u['payload'] for u in pending],role='document')
            if len(vectors)!=len(pending):raise IndexError('VECTOR_COUNT_MISMATCH')
            checked=[normalized_vector(v,model.dimensions) for v in vectors]
            self.store.put_vectors(model.fingerprint,'document',[(u['input_hash'],v) for u,v in zip(pending,checked)])
            stats['vectors_created']+=len(pending);pending.clear()
        keys=sorted(set(k for k in parse_keys if k))
        for pos in range(0,len(keys),400):
            group=keys[pos:pos+400]
            rows=self.store.conn.execute('SELECT input_hash,payload FROM units WHERE parse_key IN ('+','.join('?'*len(group))+') ORDER BY rowid',group)
            for row in rows:
                u=dict(row)
                if u['input_hash'] in seen:continue
                seen.add(u['input_hash'])
                exists=self.store.one('SELECT dimensions FROM embeddings WHERE space=? AND role=? AND input_hash=?',
                                      (model.fingerprint,'document',u['input_hash']))
                if exists and not rebuild:
                    if exists['dimensions']!=model.dimensions:raise IndexError('VECTOR_SPACE_DIMENSION_CONFLICT')
                    stats['vectors_reused']+=1;continue
                pending.append(u)
                if len(pending)>=self.settings.embedding_batch_items:flush()
        flush()

    def _update_repo(self,repo,fetch,rebuild,plan):
        stats={k:0 for k in ('files_read','files_reused','units_created','vectors_created','vectors_reused','deleted_files','renamed_files')}
        source,commit= self._source(repo,fetch)
        old=self.store.one('SELECT * FROM snapshots WHERE snapshot_id=?',(repo['active_snapshot'],)) if repo['active_snapshot'] else None
        same=bool(old and old['commit_oid']==commit and old['pipeline_fp']==self.settings.fingerprint)
        if plan:return {'repo_id':repo['repo_id'],'status':'unchanged' if same and not rebuild else 'would_change','commit':commit,**stats}
        if same and not rebuild:
            files=self.files(repo['repo_id']);self._ensure_vectors([f['parse_key'] for f in files],stats)
            self.store.conn.execute('UPDATE repositories SET last_check=?,last_error=NULL WHERE repo_id=?',(now(),repo['repo_id']))
            return {'repo_id':repo['repo_id'],'status':'unchanged','commit':commit,'snapshot_id':old['snapshot_id'],**stats}
        entries=source.list_files(commit)
        if len(entries)>self.settings.max_files:raise IndexError('REPOSITORY_FILE_LIMIT_EXCEEDED')
        oldfiles={f['path']:f for f in self.files(repo['repo_id'])} if old else {}
        reuse_policy=bool(old and old['pipeline_fp']==self.settings.fingerprint)
        files=[];need=[];by_path={}
        for e in entries:
            base={'path':e.path,'git_oid':e.oid,'size':e.size,'mode':e.mode,'content_hash':None,'parse_key':None,'status':'excluded','reason':''}
            reason=self._excluded(e)
            prior=oldfiles.get(e.path)
            if reason:base['reason']=reason
            elif reuse_policy and not rebuild and prior and prior['git_oid']==e.oid:
                base.update({k:prior[k] for k in ('content_hash','parse_key','status','reason')});stats['files_reused']+=1
            else:need.append(e)
            files.append(base);by_path[e.path]=base
        # Bounded Git batches: read only changed/uncached locations, never a full checkout.
        for pos in range(0,len(need),128):
            batch=need[pos:pos+128];raws=source.read_blobs(batch)
            for e in batch:
                body=raws[e.oid];f=by_path[e.path];stats['files_read']+=1
                if b'\x00' in body:f['reason']='binary';continue
                if body.startswith(b'version https://git-lfs.github.com/spec/v1'):f['reason']='lfs_pointer';continue
                if re.search(rb'-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----',body):f['reason']='secret_material';continue
                try:body.decode('utf-8')
                except UnicodeError:f['reason']='unsupported_encoding';continue
                h=self.cache.put(body)
                parsekey=digest([h,PARSER_VERSION,_role(e.path),PurePosixPath(e.path).suffix,self.settings.chunk_chars])
                cached=self.store.one('SELECT parse_key FROM parses WHERE parse_key=?',(parsekey,))
                if not cached or rebuild:
                    parsed=chunk_file(e.path,body,max_chars=self.settings.chunk_chars)
                    stats['units_created']+=self.store.put_parse(parsekey,h,parsed)
                f.update(content_hash=h,parse_key=parsekey,status='indexed',reason='')
        newpaths={f['path'] for f in files};deleted=set(oldfiles)-newpaths
        added=[f for f in files if f['path'] not in oldfiles]
        old_by_oid={oldfiles[p]['git_oid'] for p in deleted}
        stats['renamed_files']=sum(f['git_oid'] in old_by_oid for f in added)
        stats['deleted_files']=len(deleted)
        self._ensure_vectors([f['parse_key'] for f in files],stats,rebuild=rebuild)
        parser_counts=Counter()
        for f in files:
            if f['parse_key']:
                parser_counts[self.store.one('SELECT parser FROM parses WHERE parse_key=?',(f['parse_key'],))['parser']]+=1
        coverage={'total_files':len(files),'indexed_files':sum(f['status']=='indexed' for f in files),
                  'excluded_files':sum(f['status']=='excluded' for f in files),
                  'excluded_reasons':dict(Counter(f['reason'] for f in files if f['reason'])),
                  'indexed_bytes':sum(f['size'] for f in files if f['status']=='indexed'),
                  'parser_counts':dict(parser_counts),'semantic_completeness':'not_proven',
                  'raw_scan_policy_complete':True,'vectors_requested':self.embedding is not None}
        readmes=[f for f in files if f['status']=='indexed' and PurePosixPath(f['path']).name.lower().startswith('readme')]
        sample=readmes[:2] or [f for f in files if f['status']=='indexed'][:2]
        card={'body':f"Repository {repo['repo_id']}\n"+'\n'.join(f['path']+'\n'+self.cache.get(f['content_hash']).decode('utf-8')[:1500] for f in sample),
              'paths':[f['path'] for f in sample]}
        td=digest([(e.path,e.oid,e.mode) for e in entries])
        sid=self.store.publish(repo['repo_id'],commit,self.settings.fingerprint,td,files,coverage,card)
        return {'repo_id':repo['repo_id'],'status':'changed','commit':commit,'snapshot_id':sid,**stats}

    def update(self,repo_ids=None,*,fetch=True,rebuild=False,plan=False):
        start=time.perf_counter();rows=self.store.rows('SELECT * FROM repositories WHERE enabled=1 ORDER BY repo_id')
        if repo_ids is not None:
            for rid in repo_ids:self._repo(rid)
            rows=[r for r in rows if r['repo_id'] in repo_ids]
        job='job-'+uuid.uuid4().hex
        results=[]
        with WriterLock(self.home/'writer.lock'):
            if not plan:self.store.conn.execute('INSERT INTO jobs VALUES(?,?,?,?,?,?,0)',(job,'running',now(),None,dumps([r['repo_id'] for r in rows]),'[]'))
            try:
                for r in rows:
                    if not plan and self.store.one('SELECT cancel_requested FROM jobs WHERE job_id=?',(job,))['cancel_requested']:
                        break
                    try: result=self._update_repo(r,fetch,rebuild,plan)
                    except Exception as e:
                        result={'repo_id':r['repo_id'],'status':'failed','error':_safe_error(e)}
                        if not plan:self.store.conn.execute('UPDATE repositories SET last_check=?,last_error=? WHERE repo_id=?',(now(),result['error'],r['repo_id']))
                    results.append(result)
                    if not plan:self.store.conn.execute('UPDATE jobs SET result_json=? WHERE job_id=?',(dumps(results),job))
            except BaseException:
                if not plan:self.store.conn.execute("UPDATE jobs SET state='interrupted',finished_at=?,result_json=? WHERE job_id=?",(now(),dumps(results),job))
                raise
            failed=sum(r['status']=='failed' for r in results)
            state='planned' if plan else ('cancelled' if len(results)<len(rows) else ('partial' if failed else 'completed'))
            if not plan:self.store.conn.execute('UPDATE jobs SET state=?,finished_at=? WHERE job_id=?',(state,now(),job))
        metrics={k:sum(r.get(k,0) for r in results) for k in ('files_read','files_reused','units_created','vectors_created','vectors_reused','deleted_files','renamed_files')}
        return {'schema_version':'3.0','job_id':None if plan else job,'state':state,'checked':len(results),
                'changed':sum(r['status']=='changed' for r in results),'unchanged':sum(r['status']=='unchanged' for r in results),
                'failed':failed,'pending':len(rows)-len(results),'results':results,**metrics,'elapsed_ms':round((time.perf_counter()-start)*1000,3)}
