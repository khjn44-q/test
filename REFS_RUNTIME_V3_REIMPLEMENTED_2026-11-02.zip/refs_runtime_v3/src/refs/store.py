"""Local single-user catalog. Immutable source versions; short atomic publication transactions."""
from __future__ import annotations
from contextlib import contextmanager
from pathlib import Path
import datetime
import hashlib
import json
import os
import sqlite3
import struct
from .errors import IndexError

SCHEMA_VERSION=1

def now() -> str:
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def dumps(value) -> str:
    return json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False)

def digest(value) -> str:
    return hashlib.sha256((value if isinstance(value,bytes) else dumps(value).encode())).hexdigest()

SCHEMA='''
CREATE TABLE meta(key TEXT PRIMARY KEY,value TEXT NOT NULL);
CREATE TABLE repositories(
 repo_id TEXT PRIMARY KEY,location TEXT NOT NULL,source_kind TEXT NOT NULL CHECK(source_kind IN ('local','remote')),
 ref TEXT NOT NULL,web_url TEXT NOT NULL DEFAULT '',allow_local_remote INTEGER NOT NULL DEFAULT 0,
 enabled INTEGER NOT NULL DEFAULT 1 CHECK(enabled IN (0,1)),active_snapshot TEXT,
 last_check TEXT,last_error TEXT);
CREATE TABLE snapshots(
 snapshot_id TEXT PRIMARY KEY,repo_id TEXT NOT NULL REFERENCES repositories(repo_id),
 commit_oid TEXT NOT NULL,pipeline_fp TEXT NOT NULL,tree_digest TEXT NOT NULL,
 created_at TEXT NOT NULL,coverage_json TEXT NOT NULL);
CREATE TABLE parses(parse_key TEXT PRIMARY KEY,content_hash TEXT NOT NULL,parser TEXT NOT NULL,
 relations_json TEXT NOT NULL,warnings_json TEXT NOT NULL);
CREATE TABLE units(
 rowid INTEGER PRIMARY KEY,unit_id TEXT NOT NULL UNIQUE,parse_key TEXT NOT NULL REFERENCES parses(parse_key),
 ordinal INTEGER NOT NULL,byte_start INTEGER NOT NULL,byte_end INTEGER NOT NULL,
 line_start INTEGER NOT NULL,line_end INTEGER NOT NULL,symbol TEXT NOT NULL,kind TEXT NOT NULL,
 resolution TEXT NOT NULL,text TEXT NOT NULL,search_text TEXT NOT NULL,payload TEXT NOT NULL,input_hash TEXT NOT NULL,
 CHECK(byte_start>=0 AND byte_end>=byte_start),CHECK(line_start>=1 AND line_end>=line_start),
 UNIQUE(parse_key,ordinal));
CREATE INDEX unit_parse ON units(parse_key);
CREATE INDEX unit_symbol ON units(symbol);
CREATE VIRTUAL TABLE units_fts USING fts5(symbol,search_text,content='units',content_rowid='rowid',tokenize='unicode61 remove_diacritics 2');
CREATE TRIGGER unit_ai AFTER INSERT ON units BEGIN INSERT INTO units_fts(rowid,symbol,search_text) VALUES(new.rowid,new.symbol,new.search_text); END;
CREATE TRIGGER unit_ad AFTER DELETE ON units BEGIN INSERT INTO units_fts(units_fts,rowid,symbol,search_text) VALUES('delete',old.rowid,old.symbol,old.search_text); END;
CREATE TABLE snapshot_files(
 snapshot_id TEXT NOT NULL REFERENCES snapshots(snapshot_id),path TEXT NOT NULL,
 git_oid TEXT NOT NULL,content_hash TEXT,parse_key TEXT REFERENCES parses(parse_key),
 size INTEGER NOT NULL,mode TEXT NOT NULL,status TEXT NOT NULL,reason TEXT NOT NULL,
 PRIMARY KEY(snapshot_id,path));
CREATE INDEX file_parse ON snapshot_files(parse_key,snapshot_id);
CREATE TABLE cards(rowid INTEGER PRIMARY KEY,snapshot_id TEXT NOT NULL UNIQUE REFERENCES snapshots(snapshot_id),
 repo_id TEXT NOT NULL,body TEXT NOT NULL,evidence_paths_json TEXT NOT NULL);
CREATE VIRTUAL TABLE cards_fts USING fts5(body,content='cards',content_rowid='rowid');
CREATE TRIGGER cards_ai AFTER INSERT ON cards BEGIN INSERT INTO cards_fts(rowid,body) VALUES(new.rowid,new.body); END;
CREATE TABLE embeddings(space TEXT NOT NULL,role TEXT NOT NULL,input_hash TEXT NOT NULL,
 dimensions INTEGER NOT NULL,vector BLOB NOT NULL,created_at TEXT NOT NULL,
 PRIMARY KEY(space,role,input_hash));
CREATE TABLE evidence(
 evidence_id TEXT PRIMARY KEY,repo_id TEXT NOT NULL REFERENCES repositories(repo_id),
 snapshot_id TEXT NOT NULL REFERENCES snapshots(snapshot_id),path TEXT NOT NULL,
 unit_id TEXT,content_hash TEXT NOT NULL,git_oid TEXT NOT NULL,
 byte_start INTEGER NOT NULL,byte_end INTEGER NOT NULL,line_start INTEGER NOT NULL,line_end INTEGER NOT NULL,
 created_at TEXT NOT NULL);
CREATE INDEX evidence_snapshot ON evidence(snapshot_id,path);
CREATE TABLE sessions(session_id TEXT PRIMARY KEY,query TEXT NOT NULL,snapshots_json TEXT NOT NULL,
 results_json TEXT NOT NULL,created_at TEXT NOT NULL,expires_at REAL NOT NULL);
CREATE TABLE notes(rowid INTEGER PRIMARY KEY,note_id TEXT NOT NULL UNIQUE,repo_id TEXT NOT NULL,
 snapshot_id TEXT NOT NULL,kind TEXT NOT NULL,question TEXT NOT NULL,body TEXT NOT NULL,
 payload_json TEXT NOT NULL,evidence_json TEXT NOT NULL,dependencies_json TEXT NOT NULL,
 model_fp TEXT NOT NULL,state TEXT NOT NULL CHECK(state IN ('active','stale')),
 input_hash TEXT NOT NULL,created_at TEXT NOT NULL);
CREATE VIRTUAL TABLE notes_fts USING fts5(body,content='notes',content_rowid='rowid');
CREATE TRIGGER notes_ai AFTER INSERT ON notes BEGIN INSERT INTO notes_fts(rowid,body) VALUES(new.rowid,new.body); END;
CREATE TABLE note_repositories(note_id TEXT NOT NULL,repo_id TEXT NOT NULL,PRIMARY KEY(note_id,repo_id));
CREATE INDEX notes_by_repo ON note_repositories(repo_id);
CREATE TABLE note_embeddings(note_id TEXT NOT NULL,space TEXT NOT NULL,input_hash TEXT NOT NULL,PRIMARY KEY(note_id,space,input_hash));
CREATE TABLE jobs(job_id TEXT PRIMARY KEY,state TEXT NOT NULL,started_at TEXT NOT NULL,finished_at TEXT,
 repos_json TEXT NOT NULL,result_json TEXT NOT NULL,cancel_requested INTEGER NOT NULL DEFAULT 0);
CREATE TABLE scan_runs(scan_id TEXT PRIMARY KEY,scope_json TEXT NOT NULL,patterns_json TEXT NOT NULL,
 state TEXT NOT NULL,coverage_json TEXT NOT NULL,created_at TEXT NOT NULL);
CREATE TABLE scan_matches(scan_id TEXT NOT NULL REFERENCES scan_runs(scan_id),position INTEGER NOT NULL,
 repo_id TEXT NOT NULL,evidence_id TEXT NOT NULL,payload_json TEXT NOT NULL,PRIMARY KEY(scan_id,position));
'''

class WriterLock:
    """OS lock is released on process exit; no stale-PID force-delete policy."""
    def __init__(self,path: Path): self.path=Path(path);self.handle=None
    def __enter__(self):
        self.path.parent.mkdir(parents=True,exist_ok=True)
        f=self.path.open('a+b');self.handle=f
        if f.tell()==0: f.write(b'0');f.flush()
        f.seek(0)
        try:
            if os.name=='nt':
                import msvcrt
                msvcrt.locking(f.fileno(),msvcrt.LK_NBLCK,1)
            else:
                import fcntl
                fcntl.flock(f.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
        except (OSError,BlockingIOError):
            f.close();self.handle=None;raise IndexError('WRITER_BUSY') from None
        return self
    def __exit__(self,*args):
        if self.handle:
            f=self.handle
            try:
                f.seek(0)
                if os.name=='nt':
                    import msvcrt
                    msvcrt.locking(f.fileno(),msvcrt.LK_UNLCK,1)
                else:
                    import fcntl
                    fcntl.flock(f.fileno(),fcntl.LOCK_UN)
            finally: f.close();self.handle=None

class Store:
    def __init__(self,path: Path):
        path=Path(path);path.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
        self.path=path
        self.conn=sqlite3.connect(path,timeout=10,isolation_level=None)
        self.conn.row_factory=sqlite3.Row
        self.conn.execute('PRAGMA foreign_keys=ON')
        self.conn.execute('PRAGMA busy_timeout=10000')
        self.conn.execute('PRAGMA journal_mode=WAL')
        self.conn.execute('PRAGMA synchronous=FULL')
        version=self.conn.execute('PRAGMA user_version').fetchone()[0]
        if version==0:
            try: self.conn.executescript('BEGIN IMMEDIATE;'+SCHEMA+f'PRAGMA user_version={SCHEMA_VERSION};COMMIT;')
            except Exception:
                if self.conn.in_transaction:self.conn.rollback()
                self.conn.close();raise
        elif version!=SCHEMA_VERSION:
            self.conn.close();raise IndexError('UNSUPPORTED_DATABASE_VERSION')
        if os.name!='nt': os.chmod(path,0o600)

    @contextmanager
    def transaction(self):
        self.conn.execute('BEGIN IMMEDIATE')
        try:
            yield self.conn
            self.conn.commit()
        except BaseException:
            self.conn.rollback();raise

    def rows(self,sql,args=()): return [dict(x) for x in self.conn.execute(sql,args)]
    def one(self,sql,args=()):
        row=self.conn.execute(sql,args).fetchone()
        return dict(row) if row else None
    def close(self): self.conn.close()

    def put_parse(self,parse_key,content_hash,parsed):
        existing=self.one('SELECT parse_key FROM parses WHERE parse_key=?',(parse_key,))
        if existing:return 0
        from .chunks import code_tokens
        with self.transaction() as c:
            c.execute('INSERT INTO parses VALUES(?,?,?,?,?)',
                      (parse_key,content_hash,parsed.parser,dumps(parsed.relations),dumps(parsed.warnings)))
            for i,u in enumerate(parsed.chunks):
                payload=(u.symbol+'\n' if u.symbol else '')+u.text
                c.execute('''INSERT INTO units(unit_id,parse_key,ordinal,byte_start,byte_end,line_start,line_end,
                          symbol,kind,resolution,text,search_text,payload,input_hash) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',
                          (digest([parse_key,i]),parse_key,i,u.byte_start,u.byte_end,u.line_start,u.line_end,
                           u.symbol,u.kind,u.resolution,u.text,code_tokens(u.text),payload,digest(payload.encode())))
        return len(parsed.chunks)

    def vector(self,space,role,input_hash):
        row=self.one('SELECT dimensions,vector FROM embeddings WHERE space=? AND role=? AND input_hash=?',(space,role,input_hash))
        if row is None:return None
        if len(row['vector'])!=row['dimensions']*4:raise IndexError('CORRUPT_VECTOR')
        return list(struct.unpack('<'+'f'*row['dimensions'],row['vector']))

    def put_vectors(self,space,role,items):
        with self.transaction() as c:
            for input_hash,vector in items:
                c.execute('INSERT OR REPLACE INTO embeddings VALUES(?,?,?,?,?,?)',
                          (space,role,input_hash,len(vector),struct.pack('<'+'f'*len(vector),*vector),now()))

    def publish(self,repo_id,commit,pipeline_fp,tree_digest,files,coverage,card):
        sid=digest([repo_id,commit,pipeline_fp])
        with self.transaction() as c:
            enabled=c.execute('SELECT enabled FROM repositories WHERE repo_id=?',(repo_id,)).fetchone()
            if not enabled or not enabled[0]: raise IndexError('REPOSITORY_DISABLED')
            c.execute('INSERT OR IGNORE INTO snapshots VALUES(?,?,?,?,?,?,?)',
                      (sid,repo_id,commit,pipeline_fp,tree_digest,now(),dumps(coverage)))
            for f in files:
                c.execute('INSERT OR IGNORE INTO snapshot_files VALUES(?,?,?,?,?,?,?,?,?)',
                          (sid,f['path'],f['git_oid'],f.get('content_hash'),f.get('parse_key'),f['size'],f['mode'],f['status'],f['reason']))
            c.execute('INSERT OR IGNORE INTO cards(snapshot_id,repo_id,body,evidence_paths_json) VALUES(?,?,?,?)',
                      (sid,repo_id,card['body'],dumps(card['paths'])))
            # Generated notes conservatively depend on all source-repository trees.
            # This preserves correctness when an uncited helper/config file changes.
            for n in c.execute("SELECT n.note_id,n.dependencies_json FROM notes n JOIN note_repositories nr ON nr.note_id=n.note_id WHERE nr.repo_id=? AND n.state='active'",(repo_id,)).fetchall():
                deps=json.loads(n['dependencies_json'])
                if deps.get(repo_id)!=tree_digest:
                    c.execute("UPDATE notes SET state='stale' WHERE note_id=?",(n['note_id'],))
            c.execute('UPDATE repositories SET active_snapshot=?,last_check=?,last_error=NULL WHERE repo_id=?',(sid,now(),repo_id))
        return sid
