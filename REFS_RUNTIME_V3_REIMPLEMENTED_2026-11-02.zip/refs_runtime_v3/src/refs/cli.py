"""Machine-readable CLI. JSON on stdout, diagnostics/help on their explicit paths."""
from __future__ import annotations
import argparse
from dataclasses import asdict
import importlib.util
import json
import os
from pathlib import Path
import platform
import sqlite3
import subprocess
import sys
from .config import load_config,open_runtime,example_config
from .errors import RefsError
from .store import digest,dumps
from .tools import invoke

class Parser(argparse.ArgumentParser):
    def error(self,message):raise RefsError('INVALID_ARGUMENT',message)


def parser():
    p=Parser(prog='refs',description='Read-only Git engineering reference engine. JSON output; no source execution.')
    p.add_argument('--home');p.add_argument('--config')
    sub=p.add_subparsers(dest='command',required=True)
    init=sub.add_parser('init-config');init.add_argument('--output',required=True)
    doctor=sub.add_parser('doctor');doctor.add_argument('--probe-models',action='store_true')
    repo=sub.add_parser('repo');rs=repo.add_subparsers(dest='repo_command',required=True)
    add=rs.add_parser('add');add.add_argument('repo_id');src=add.add_mutually_exclusive_group(required=True)
    src.add_argument('--path');src.add_argument('--url');add.add_argument('--ref',default='HEAD');add.add_argument('--web-url',default='')
    add.add_argument('--allow-local-remote',action='store_true')
    imp=rs.add_parser('import');imp.add_argument('file')
    rs.add_parser('list')
    for action in ('enable','disable'):
        x=rs.add_parser(action);x.add_argument('repo_id')
    for name in ('update','rebuild'):
        x=sub.add_parser(name);g=x.add_mutually_exclusive_group();g.add_argument('--all',action='store_true');g.add_argument('--repo',action='append')
        x.add_argument('--no-fetch',action='store_true');x.add_argument('--plan',action='store_true')
        x.add_argument('--summarize',action='store_true');x.add_argument('--summary-sources',type=int,default=24)
        x.add_argument('--resume')
    sub.add_parser('status')
    search=sub.add_parser('search');search.add_argument('query');search.add_argument('--repo',action='append');search.add_argument('--session')
    search.add_argument('--limit',type=int,default=10);search.add_argument('--depth',choices=['fast','verified','deep'],default='fast')
    search.add_argument('--breadth',choices=['ranked','all'],default='ranked')
    scan=sub.add_parser('scan');scan.add_argument('--pattern',action='append');scan.add_argument('--detector');scan.add_argument('--repo',action='append')
    scan.add_argument('--session');scan.add_argument('--cursor');scan.add_argument('--limit',type=int,default=50)
    scan.add_argument('--max-matches',type=int,default=100000);scan.add_argument('--max-seconds',type=float,default=120)
    ev=sub.add_parser('evidence');ev.add_argument('evidence_id');ev.add_argument('--start-line',type=int);ev.add_argument('--line-limit',type=int,default=120)
    ev.add_argument('--start-byte',type=int);ev.add_argument('--max-chars',type=int,default=16000)
    tr=sub.add_parser('trace');tr.add_argument('evidence_id');tr.add_argument('--direction',choices=['in','out'],default='out');tr.add_argument('--limit',type=int,default=100)
    co=sub.add_parser('compare');co.add_argument('a');co.add_argument('b')
    an=sub.add_parser('analyze');an.add_argument('question');an.add_argument('--evidence',action='append',required=True)
    an.add_argument('--max-sources',type=int,default=32);an.add_argument('--max-model-calls',type=int,default=8)
    su=sub.add_parser('summarize');su.add_argument('--repo',required=True);su.add_argument('--max-sources',type=int,default=24);su.add_argument('--max-model-calls',type=int,default=8)
    re=sub.add_parser('prepare-use');re.add_argument('evidence_id');re.add_argument('--goal',default='reuse this source')
    call=sub.add_parser('call');call.add_argument('tool');call.add_argument('--args',default='{}')
    job=sub.add_parser('job');job.add_argument('action',choices=['list','status','cancel']);job.add_argument('job_id',nargs='?')
    mcp=sub.add_parser('mcp');mcp.add_argument('--allow-update',action='store_true')
    return p


def doctor(runtime,config,probe=False):
    caps={'fts5':True,'numpy':importlib.util.find_spec('numpy') is not None,'mcp_sdk':importlib.util.find_spec('mcp') is not None,
          'embedding_configured':config.embedding is not None,'llm_configured':config.llm is not None}
    try:git=subprocess.check_output(['git','--version'],text=True,timeout=10).strip()
    except (OSError,subprocess.SubprocessError):git=None
    out={'schema_version':'3.0','python':platform.python_version(),'platform':platform.system(),
         'sqlite':sqlite3.sqlite_version,'git':git,'capabilities':caps,'network_probed':probe,
         'embedding_fingerprint':getattr(runtime.embedding,'fingerprint',None),'multiuser_mode':False}
    if probe:
        probes={}
        if runtime.embedding:
            try:v=runtime.embedding.embed(['REFS connectivity probe'],role='query');probes['embedding']={'ok':True,'dimensions':len(v[0])}
            except Exception as e:probes['embedding']={'ok':False,'error':type(e).__name__}
        if runtime.llm:
            try:runtime.llm.complete([{'role':'user','content':'Return JSON: {"claims":[],"unknowns":[]}'}]);probes['llm']={'ok':True}
            except Exception as e:probes['llm']={'ok':False,'error':type(e).__name__}
        out['model_probes']=probes
        if any(not x['ok'] for x in probes.values()):out['status']='partial'
    return out


def import_inventory(runtime,path):
    p=Path(path)
    if p.stat().st_size>5*1024*1024:raise RefsError('INVENTORY_TOO_LARGE')
    text=p.read_text(encoding='utf-8-sig')
    if text.lstrip().startswith(('[','{')):
        value=json.loads(text);records=value.get('repositories',[]) if isinstance(value,dict) else value
    else:
        from urllib.parse import urlsplit
        import re
        records=[]
        for line in text.splitlines():
            value=line.strip()
            if not value or value.startswith('#'):continue
            stem=value.rstrip('/').rsplit('/',1)[-1].removesuffix('.git')
            rid=(re.sub(r'[^A-Za-z0-9_.-]','-',stem).strip('.-') or 'repo')[:50]+'-'+digest(value.encode())[:10]
            records.append({'repo_id':rid,'path':value} if Path(value).is_dir() else {'repo_id':rid,'url':value})
    if not isinstance(records,list) or len(records)>10000:raise RefsError('INVALID_INVENTORY')
    registered=0;existing=0;errors=[]
    for i,record in enumerate(records):
        try:
            if not isinstance(record,dict):raise RefsError('INVALID_RECORD')
            allowed={'repo_id','path','url','ref','web_url','allow_local_remote'}
            if set(record)-allowed:raise RefsError('UNKNOWN_INVENTORY_FIELD')
            out=runtime.register(**record)
            registered+=int(out['registered']);existing+=int(not out['registered'])
        except Exception as e:errors.append({'row':i+1,'error':getattr(e,'code',type(e).__name__)})
    return {'state':'partial' if errors else 'completed','registered':registered,'existing':existing,'failed':len(errors),'errors':errors}


def dispatch(runtime,cfg,a):
    c=a.command
    if c=='doctor':return doctor(runtime,cfg,a.probe_models)
    if c=='status':return runtime.status()
    if c=='repo':
        if a.repo_command=='add':return runtime.register(a.repo_id,path=a.path,url=a.url,ref=a.ref,web_url=a.web_url,allow_local_remote=a.allow_local_remote)
        if a.repo_command=='import':return import_inventory(runtime,a.file)
        if a.repo_command=='list':return runtime.status()
        runtime.set_enabled(a.repo_id,a.repo_command=='enable');return {'repo_id':a.repo_id,'enabled':a.repo_command=='enable'}
    if c in {'update','rebuild'}:
        ids=a.repo
        if a.resume:
            job=runtime.store.one('SELECT * FROM jobs WHERE job_id=?',(a.resume,))
            if not job:raise RefsError('JOB_NOT_FOUND')
            done={r['repo_id'] for r in json.loads(job['result_json']) if r['status'] in {'changed','unchanged'}}
            ids=[rid for rid in json.loads(job['repos_json']) if rid not in done]
        out=runtime.update(ids,fetch=not a.no_fetch,rebuild=c=='rebuild',plan=a.plan)
        if a.resume:out.update(resumed_from=a.resume,resume_policy='re-resolve current refs; caches are reused, not an exact old-head replay')
        if a.summarize and not a.plan:
            summaries=[]
            for r in out['results']:
                if r['status']=='failed':continue
                if runtime.llm is None:summaries.append({'repo_id':r['repo_id'],'status':'LLM_NOT_CONFIGURED'});continue
                try:
                    x=runtime.summarize(r['repo_id'],max_sources=a.summary_sources)
                    summaries.append({'repo_id':r['repo_id'],'status':x['status'],'note_id':x['note_id'],'cache_hit':x['cache_hit'],'coverage':x['coverage']})
                except Exception as e:summaries.append({'repo_id':r['repo_id'],'status':'failed','error':getattr(e,'code',type(e).__name__)})
            out['summaries']=summaries
            out['index_state']=out['state']
            if any(x['status']!='ok' for x in summaries):out['state']='partial'
        return out
    if c=='search':return runtime.find(a.query,repo_ids=a.repo,session_id=a.session,limit=a.limit,depth=a.depth,breadth=a.breadth)
    if c=='scan':return runtime.scan(a.pattern,detector=a.detector,repo_ids=a.repo,session_id=a.session,cursor=a.cursor,limit=a.limit,max_matches=a.max_matches,max_seconds=a.max_seconds)
    if c=='evidence':return runtime.evidence(a.evidence_id,start_line=a.start_line,line_limit=a.line_limit,start_byte=a.start_byte,max_chars=a.max_chars)
    if c=='trace':return runtime.trace(a.evidence_id,direction=a.direction,limit=a.limit)
    if c=='compare':return runtime.compare(a.a,a.b)
    if c=='analyze':return runtime.analyze(a.question,a.evidence,max_sources=a.max_sources,max_model_calls=a.max_model_calls)
    if c=='summarize':return runtime.summarize(a.repo,max_sources=a.max_sources,max_model_calls=a.max_model_calls)
    if c=='prepare-use':return runtime.prepare_use(a.evidence_id,goal=a.goal)
    if c=='call':return invoke(runtime,a.tool,json.loads(a.args),allow_update=True)
    if c=='job':
        if a.action=='list':return {'jobs':runtime.store.rows('SELECT job_id,state,started_at,finished_at FROM jobs ORDER BY started_at DESC LIMIT 100')}
        job=runtime.store.one('SELECT * FROM jobs WHERE job_id=?',(a.job_id,))
        if not job:raise RefsError('JOB_NOT_FOUND')
        if a.action=='cancel':
            runtime.store.conn.execute('UPDATE jobs SET cancel_requested=1 WHERE job_id=?',(a.job_id,))
            return {'job_id':a.job_id,'cancel_requested':True,'observed_state':job['state'],'note':'Observed at a safe repository boundary; no background runner is started.'}
        return {**job,'repos_json':json.loads(job['repos_json']),'result_json':json.loads(job['result_json'])}
    raise RefsError('UNKNOWN_COMMAND')


def main(argv=None):
    try:
        a=parser().parse_args(argv)
        if a.command=='init-config':
            p=Path(a.output)
            with p.open('x',encoding='utf-8') as f:json.dump(example_config(),f,ensure_ascii=False,indent=2)
            print(dumps({'created':str(p.resolve()),'models_enabled':False}));return 0
        cfg=load_config(a.config,a.home)
        if a.command=='mcp':
            from .mcp_server import create_server
            create_server(cfg,allow_update=a.allow_update).run(transport='stdio');return 0
        with open_runtime(cfg) as runtime:out=dispatch(runtime,cfg,a)
        print(dumps(out))
        return 4 if out.get('state') in {'partial','cancelled'} or out.get('status')=='partial' else 0
    except FileExistsError:
        print(dumps({'status':'error','error':{'code':'CONFIG_EXISTS'}}));return 2
    except KeyboardInterrupt:
        print(dumps({'status':'error','error':{'code':'INTERRUPTED'}}));return 130
    except Exception as e:
        code=getattr(e,'code',None)
        if code is None:
            msg=str(e).split(':',1)[0]
            code=msg if msg and msg.replace('_','').isalnum() and msg.upper()==msg else type(e).__name__
        print(dumps({'status':'error','error':{'code':code},'hint':'Review HANDOFF_KO.md and the relevant configuration; no secret-bearing exception body is printed.'}))
        return 2 if isinstance(e,(ValueError,TypeError)) else 5
