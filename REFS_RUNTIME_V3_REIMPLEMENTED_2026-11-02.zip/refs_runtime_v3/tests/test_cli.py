import json
import os
import subprocess
import sys
from pathlib import Path
import importlib.util
import pytest
from conftest import make_repo,commit
from refs.config import load_config
from refs.errors import RefsError

ROOT=Path(__file__).resolve().parents[1]

def cli(home,*args):
    env=dict(os.environ,PYTHONPATH=str(ROOT/'src'))
    p=subprocess.run([sys.executable,'-m','refs','--home',str(home),*map(str,args)],capture_output=True,text=True,env=env,timeout=30)
    try: body=json.loads(p.stdout)
    except Exception:raise AssertionError(f'Not clean JSON: {p.stdout!r} / {p.stderr!r}')
    return p,body


def test_cli_e2e_update_search_read_change(tmp_path,repo):
    home=tmp_path/'home'
    assert cli(home,'repo','add','demo','--path',repo)[0].returncode==0
    p,out=cli(home,'update','--all');assert p.returncode==0 and out['changed']==1
    p,result=cli(home,'search','search_issues');assert p.returncode==0 and result['results']
    eid=result['results'][0]['evidence_id']
    p,source=cli(home,'evidence',eid);assert p.returncode==0 and 'def search_issues' in source['text']
    commit(repo,{'new.py':'def new_operation():\n    return 1\n'})
    assert cli(home,'update','--all')[1]['changed']==1
    assert 'def search_issues' in cli(home,'evidence',eid)[1]['text']


def test_cli_import_100_repo_inventory_without_mutating_git(tmp_path):
    records=[{'repo_id':f'r{i:03}','path':str(tmp_path/f'repo{i}'),'ref':'HEAD'} for i in range(110)]
    inventory=tmp_path/'repos.json';inventory.write_text(json.dumps({'repositories':records}))
    p,out=cli(tmp_path/'state','repo','import',inventory)
    assert p.returncode==0 and out['registered']==110
    assert len(cli(tmp_path/'state','status')[1]['repositories'])==110


def test_doctor_is_offline_and_json(tmp_path):
    p,out=cli(tmp_path/'state','doctor')
    assert p.returncode==0 and out['capabilities']['fts5']
    assert out['network_probed'] is False


def test_cli_unknown_evidence_structured_error(tmp_path):
    p,out=cli(tmp_path/'state','evidence','made-up')
    assert p.returncode!=0 and out['status']=='error'
    assert 'Traceback' not in p.stderr


def test_config_unknown_field_rejected(tmp_path):
    f=tmp_path/'config.json';f.write_text('{"surprise":true}')
    with pytest.raises(RefsError,match='UNKNOWN_CONFIG'):load_config(f)


def test_config_endpoint_and_home_resolution(tmp_path):
    f=tmp_path/'config.json';f.write_text(json.dumps({'home':'data',
      'embedding':{'endpoint':'https://embedding.example.invalid/v1/embeddings','model':'corp','revision':'r7','dimensions':32}}))
    cfg=load_config(f)
    assert cfg.home==tmp_path/'data'
    assert cfg.embedding.dimensions==32


def test_config_missing_env_not_leaked(tmp_path,monkeypatch):
    monkeypatch.setenv('VERY_SECRET','do-not-print-this')
    f=tmp_path/'config.json';f.write_text(json.dumps({'embedding':{'endpoint':'https://embedding.example.invalid/v1/embeddings','model':'corp','revision':'r7','dimensions':32,'api_key_env':'VERY_SECRET'}}))
    p,out=cli(tmp_path/'state','--config',f,'doctor')
    assert p.returncode==0 and 'do-not-print-this' not in p.stdout+p.stderr


def test_call_tool_uses_same_contract(tmp_path,repo):
    home=tmp_path/'home';cli(home,'repo','add','demo','--path',repo);cli(home,'update','--all')
    p,out=cli(home,'call','refs_search','--args',json.dumps({'query':'search_issues'}))
    assert p.returncode==0 and out['results']
    p,out=cli(home,'call','not_a_tool','--args','{}')
    assert p.returncode!=0 and out['error']['code']=='UNKNOWN_TOOL'


def test_search_all_cli_and_pagination(tmp_path):
    p=make_repo(tmp_path/'repo',{f'f{i}.py':f'jira_{i}=1\n' for i in range(25)})
    h=tmp_path/'state';cli(h,'repo','add','demo','--path',p);cli(h,'update','--all')
    process,out=cli(h,'search','jira','--breadth','all','--limit','5')
    assert process.returncode==0 and out['total_matches']==25 and out['next_cursor']


def test_optional_mcp_missing_dependency_is_explicit(tmp_path):
    if importlib.util.find_spec('mcp') is not None:pytest.skip('SDK is installed; integration test handles this case')
    p,out=cli(tmp_path/'state','mcp')
    assert p.returncode!=0 and out['error']['code']=='MCP_SDK_NOT_INSTALLED'


def test_init_config_does_not_overwrite(tmp_path):
    out=tmp_path/'settings.json'
    assert cli(tmp_path/'state','init-config','--output',out)[0].returncode==0
    p,body=cli(tmp_path/'state','init-config','--output',out)
    assert p.returncode!=0 and body['error']['code']=='CONFIG_EXISTS'


def test_deep_context_is_honest_without_llm(tmp_path,repo):
    home=tmp_path/'state';cli(home,'repo','add','demo','--path',repo);cli(home,'update','--all')
    p,out=cli(home,'search','search_issues','--depth','deep')
    assert p.returncode==0
    assert out['deep_context']['mode']=='context_only'
    assert out['deep_analysis_performed'] is False


def test_requested_summary_missing_llm_is_partial_not_overall_success(tmp_path):
    import subprocess,sys,json,os
    from conftest import make_repo
    p=make_repo(tmp_path/'repo',{'a.py':'def a():\n    return 1\n'})
    from refs.core import Runtime
    with Runtime(tmp_path/'state') as r:r.register('r',path=str(p))
    env=dict(os.environ,PYTHONPATH=str(__import__('pathlib').Path(__file__).resolve().parents[1]/'src'))
    proc=subprocess.run([sys.executable,'-m','refs','--home',str(tmp_path/'state'),'update','--all','--summarize'],
                        capture_output=True,text=True,env=env)
    out=json.loads(proc.stdout)
    assert proc.returncode==4 and out['state']=='partial'
    assert out['index_state']=='completed' and out['summaries'][0]['status']=='LLM_NOT_CONFIGURED'


def test_explicit_failed_doctor_probe_reports_partial():
    from types import SimpleNamespace
    from refs.cli import doctor
    class OfflineModel:
        fingerprint='test-only'
        def embed(self,*args,**kwargs):raise RuntimeError('synthetic outage')
    runtime=SimpleNamespace(embedding=OfflineModel(),llm=None)
    cfg=SimpleNamespace(embedding=True,llm=None)
    result=doctor(runtime,cfg,probe=True)
    assert result['status']=='partial'
    assert result['model_probes']['embedding']['ok'] is False
