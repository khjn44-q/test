import hashlib
import os
import pytest
from pathlib import Path
from conftest import git, commit, make_repo
from refs.git import GitSource, GitError, validate_remote, fetch_mirror
from refs.chunks import chunk_file
from refs.cache import BlobCache, CacheError


def test_pinned_commit_not_dirty_tree(repo):
    source=GitSource(repo); oid=source.resolve('HEAD')
    files=source.list_files(oid); entry=next(x for x in files if x.path=='src/client.py')
    (repo/'src/client.py').write_text('DIRTY\n')
    blobs=source.read_blobs([entry])
    assert b'search_issues' in blobs[entry.oid]
    assert b'DIRTY' not in blobs[entry.oid]
    assert git(repo,'status','--porcelain') == 'M src/client.py'


def test_unicode_space_crlf(repo):
    source=GitSource(repo); entry=next(x for x in source.list_files(source.resolve('HEAD')) if '온도' in x.path)
    body=source.read_blobs([entry])[entry.oid]
    assert b'\r\n' in body
    parts=chunk_file(entry.path,body,max_chars=64)
    assert b''.join(body[c.byte_start:c.byte_end] for c in parts.chunks)==body
    assert ''.join(c.text for c in parts.chunks)==body.decode()


def test_source_read_does_not_modify_git_status(repo):
    before=git(repo,'status','--porcelain')
    s=GitSource(repo); s.read_blobs(s.list_files(s.resolve('HEAD')))
    assert git(repo,'status','--porcelain')==before


def test_symlink_identified_not_followed(repo,tmp_path):
    if os.name=='nt': pytest.skip('symlink privileges vary on Windows')
    outside=tmp_path/'outside.txt';outside.write_text('do not read me')
    (repo/'link').symlink_to(outside)
    commit(repo)
    e=next(x for x in GitSource(repo).list_files(GitSource(repo).resolve('HEAD')) if x.path=='link')
    assert e.mode=='120000'
    assert e.is_regular is False


def test_sha256_git(tmp_path):
    p=make_repo(tmp_path/'sha256',{'x.py':'x = 3\n'},sha256=True)
    s=GitSource(p); ref=s.resolve('HEAD'); assert len(ref)==64
    e=s.list_files(ref)[0];assert len(e.oid)==64
    assert s.read_blobs([e])[e.oid]==b'x = 3\n'


@pytest.mark.parametrize('ref',['--help','','HEAD\nHEAD',';echo bad'])
def test_ref_rejected(repo,ref):
    with pytest.raises(GitError): GitSource(repo).resolve(ref)


def test_blob_size_limit(repo):
    s=GitSource(repo,max_file_bytes=4)
    with pytest.raises(GitError): s.read_blobs(s.list_files(s.resolve('HEAD')))


def test_missing_commit(repo):
    with pytest.raises(GitError): GitSource(repo).resolve('0'*40)


@pytest.mark.parametrize('remote',['ext::echo hacked','https://user:pass@example.com/repo','http://example.com/repo','https://example.com/repo?token=x'])
def test_unsafe_remote_rejected(remote):
    with pytest.raises(GitError): validate_remote(remote)


def test_remote_https_and_ssh():
    assert validate_remote('https://github.com/pallets/click.git')
    assert validate_remote('git@git.example:team/a.git')


def test_managed_fetch_local_fixture(repo,tmp_path):
    mirror=tmp_path/'cache.git'
    s,oid=fetch_mirror(str(repo),mirror,'refs/heads/main',allow_local=True)
    assert oid==git(repo,'rev-parse','HEAD')
    assert s.list_files(oid)
    commit(repo,{'new.py':'new = True\n'})
    _,oid2=fetch_mirror(str(repo),mirror,'refs/heads/main',allow_local=True)
    assert oid2!=oid
    assert git(repo,'status','--porcelain')==''


def test_python_symbols_and_calls():
    body=b'import math\n\nclass Model:\n    def step(self, x):\n        return math.exp(x)\n\ndef run(x):\n    return Model().step(x)\n'
    parsed=chunk_file('model.py',body,max_chars=80)
    assert parsed.parser=='python_ast'
    assert any(c.symbol=='Model.step' for c in parsed.chunks)
    assert any(r['target']=='math.exp' for r in parsed.relations)
    assert b''.join(body[c.byte_start:c.byte_end] for c in parsed.chunks)==body


def test_text_fallback_keeps_full_source():
    body=('// thermal resistance\nconst temp = power * resistance;\n'*40).encode()
    parsed=chunk_file('model.ts',body,max_chars=120)
    assert parsed.parser=='text_fallback'
    assert ''.join(c.text for c in parsed.chunks)==body.decode()
    assert all(len(c.text)<=120 for c in parsed.chunks)


def test_long_multibyte_line_no_loss():
    body=('온도測定'*200+'\r\n').encode()
    p=chunk_file('notes.md',body,max_chars=64)
    assert b''.join(body[c.byte_start:c.byte_end] for c in p.chunks)==body
    assert all(len(c.text)<=64 for c in p.chunks)
    assert all(c.line_start>=1 and c.line_end>=c.line_start for c in p.chunks)


def test_invalid_python_falls_back():
    p=chunk_file('bad.py',b'def broken(\n')
    assert p.parser=='text_fallback'
    assert p.warnings


def test_invalid_encoding_is_explicit():
    with pytest.raises(ValueError,match='UTF8'): chunk_file('bad.py',b'\xff\xfe\x00')


def test_cache_hash_and_atomic_read(tmp_path):
    cache=BlobCache(tmp_path/'blobs')
    body='고정 원문\r\n'.encode(); h=cache.put(body)
    assert h==hashlib.sha256(body).hexdigest()
    assert cache.get(h)==body
    assert cache.put(body)==h
    cache.path(h).write_bytes(b'broken')
    with pytest.raises(CacheError): cache.get(h)


def test_cache_path_traversal_rejected(tmp_path):
    cache=BlobCache(tmp_path/'blobs')
    with pytest.raises(CacheError): cache.get('../../bad')


def test_chunk_evidence_spans_exact():
    body=b'# preface\n\ndef alpha():\n    return 1\n\ndef beta():\n    return alpha()\n'
    p=chunk_file('m.py',body,max_chars=256)
    for c in p.chunks:
        assert c.text.encode()==body[c.byte_start:c.byte_end]
    assert {c.symbol for c in p.chunks}>={'alpha','beta'}


def test_managed_fetch_default_does_not_download_full_history(tmp_path):
    from conftest import make_repo,commit,git
    from refs.git import fetch_mirror
    origin=make_repo(tmp_path/'origin',{'file.py':'x=1\n'})
    commit(origin,{'file.py':'x=2\n'})
    commit(origin,{'file.py':'x=3\n'})
    source,oid=fetch_mirror(str(origin),tmp_path/'managed',allow_local=True)
    assert git(source.path,'rev-list','--count',oid)=='1'
    assert git(origin,'rev-list','--count','HEAD')=='3'
    assert git(origin,'status','--porcelain')==''
