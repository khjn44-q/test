from pathlib import Path
import importlib.util,subprocess,sys,json
from refs.core import Runtime
from conftest import make_repo

ROOT=Path(__file__).resolve().parents[1]

def test_consistent_backup_reopens_and_reads_original_evidence(tmp_path):
    script=ROOT/'scripts'/'backup_state.py'
    assert script.is_file(),'backup tool not implemented'
    p=make_repo(tmp_path/'repo',{'a.py':'def archived_source():\n    return 42\n'})
    with Runtime(tmp_path/'state') as r:
        r.register('r',path=str(p));r.update()
        eid=r.search('archived_source')['results'][0]['evidence_id']
    out=subprocess.run([sys.executable,str(script),'--home',str(tmp_path/'state'),'--destination',str(tmp_path/'backup')],capture_output=True,text=True)
    assert out.returncode==0,out.stdout+out.stderr
    report=json.loads(out.stdout);assert report['status']=='verified' and report['copied_blobs']==1
    with Runtime(tmp_path/'backup') as copy:
        assert 'return 42' in copy.evidence(eid)['text']
    again=subprocess.run([sys.executable,str(script),'--home',str(tmp_path/'state'),'--destination',str(tmp_path/'backup')],capture_output=True,text=True)
    assert again.returncode!=0
