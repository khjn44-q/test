from pathlib import Path
import os
import subprocess
import pytest

def git(path, *args):
    env = dict(os.environ, GIT_CONFIG_NOSYSTEM='1', GIT_CONFIG_GLOBAL=os.devnull)
    p = subprocess.run(['git', '-C', str(path), *args], capture_output=True, env=env, check=True)
    return p.stdout.decode('utf-8').strip()

def commit(path, files=None, message='fixture'):
    for name, value in (files or {}).items():
        target = Path(path) / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(value.encode() if isinstance(value,str) else value)
    git(path, 'add', '-A')
    git(path, '-c', 'user.name=Fixture', '-c', 'user.email=fixture@example.invalid',
        '-c', 'core.hooksPath=/dev/null', 'commit', '-q', '-m', message)
    return git(path, 'rev-parse', 'HEAD')

def make_repo(path, files=None, sha256=False):
    path = Path(path); path.mkdir(parents=True, exist_ok=True)
    args=['init','-q','-b','main']
    if sha256: args.append('--object-format=sha256')
    git(path,*args)
    commit(path,files or {'README.md':'fixture\n'})
    return path

@pytest.fixture
def repo(tmp_path):
    return make_repo(tmp_path/'repo', {
        'README.md':'Jira references\n',
        'src/client.py':'import requests\n\ndef search_issues(jql):\n    return requests.get("/rest/api/2/search", params={"jql": jql})\n',
        'src/온도 계산.py':'def step(T, P, dt, C, R, Ta):\r\n    return T + dt/C * (P - (T-Ta)/R)\r\n',
    })
