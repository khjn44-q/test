"""Release documentation and configuration consistency, not application semantic quality."""
from pathlib import Path
import json,re,sqlite3,zipfile
from refs.config import load_config
from refs.store import SCHEMA

ROOT=Path(__file__).resolve().parents[1]

def test_example_configs_use_actual_loader_without_network():
    for name in ('config.example.json','config.corporate.example.json','config.summary-first.example.json'):
        cfg=load_config(ROOT/'examples'/name)
        assert cfg.index.embedding_scope in {'all_text','summaries_only'}
        if cfg.embedding:assert cfg.embedding.dimensions==1024 and cfg.embedding.api_key_env
        if cfg.llm:assert cfg.llm.api_key_env
    assert load_config(ROOT/'examples'/'config.summary-first.example.json').index.embedding_scope=='summaries_only'

def test_exported_sql_matches_runtime_and_executes():
    text=(ROOT/'contracts'/'CATALOG.sql').read_text()
    assert text.split('\n',1)[1].strip()==SCHEMA.strip()
    conn=sqlite3.connect(':memory:');conn.executescript(text)
    assert conn.execute("select name from sqlite_master where name='repositories'").fetchone()
    conn.close()

def test_current_markdown_file_links_are_resolvable():
    files=[ROOT/'README.md',ROOT/'HANDOFF_KO.md']
    files+=list((ROOT/'docs').glob('*.md'))+list((ROOT/'contracts').glob('*.md'))+list((ROOT/'skills').rglob('*.md'))
    missing=[]
    for p in files:
        text=re.sub(r'```[\s\S]*?```','',p.read_text())
        for link in re.findall(r'\[[^\]]+\]\(([^)]+)\)',text):
            if link.startswith(('https://','http://','#','mailto:')):continue
            target=link.split('#',1)[0]
            if target and not (p.parent/target).exists():missing.append((str(p.relative_to(ROOT)),target))
    assert not missing,missing

def test_bundled_wheel_python_modules_match_current_source():
    wheel=ROOT/'dist'/'engineering_refs-0.3.0-py3-none-any.whl'
    assert wheel.is_file()
    with zipfile.ZipFile(wheel) as z:
        for path in (ROOT/'src'/'refs').glob('*.py'):
            assert z.read('refs/'+path.name)==path.read_bytes(),path.name
