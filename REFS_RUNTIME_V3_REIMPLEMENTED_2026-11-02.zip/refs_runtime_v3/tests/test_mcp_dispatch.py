"""Unit-test adapter argument binding; this fake registry does NOT test MCP protocol compatibility."""
import sys,types
from refs.config import AppConfig
from refs.indexer import IndexSettings
from refs.core import Runtime
from refs.mcp_server import create_server
from conftest import make_repo


def test_mcp_adapter_does_not_pass_closure_variables_as_tool_arguments(tmp_path,monkeypatch):
    class RegistryOnly:
        def __init__(self,*args,**kwargs):self.tools={}
        def tool(self):
            def register(func):self.tools[func.__name__]=func;return func
            return register
    package=types.ModuleType('mcp');server=types.ModuleType('mcp.server');server.MCPServer=RegistryOnly
    monkeypatch.setitem(sys.modules,'mcp',package);monkeypatch.setitem(sys.modules,'mcp.server',server)
    repo=make_repo(tmp_path/'repo',{'a.py':'def unique_method():\n    return 123\n'})
    cfg=AppConfig(tmp_path/'state',IndexSettings())
    with Runtime(cfg.home) as r:r.register('r',path=str(repo));r.update()
    adapter=create_server(cfg,allow_update=True)
    hit=adapter.tools['refs_search']('unique_method')['results'][0]
    evidence=adapter.tools['refs_read_evidence'](hit['evidence_id'])
    assert '123' in evidence['text']
    assert adapter.tools['refs_prepare_use'](hit['evidence_id'])['execution_performed'] is False
    assert adapter.tools['refs_scan'](patterns=['123'])['total_matches']==1
    assert adapter.tools['refs_trace'](hit['evidence_id'])['symbol']=='unique_method'
    assert adapter.tools['refs_compare'](hit['evidence_id'],hit['evidence_id'])['diff']==''
    assert adapter.tools['refs_analyze']('explain',[hit['evidence_id']])['mode']=='context_only'
    assert adapter.tools['refs_summarize']('r')['scope']=='repository_summary'
    assert adapter.tools['refs_update'](fetch=False)['unchanged']==1
    assert adapter.tools['refs_index_status']()['repositories']
