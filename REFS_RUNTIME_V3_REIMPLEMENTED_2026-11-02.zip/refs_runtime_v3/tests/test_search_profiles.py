from refs.core import Runtime
from refs.indexer import IndexSettings
from helpers import CountingEmbedder
from conftest import make_repo


def test_strong_exact_identifier_avoids_model_network_roundtrip(tmp_path):
    p=make_repo(tmp_path/'repo',{'a.py':'def refresh_access_token():\n    return 1\n'})
    model=CountingEmbedder()
    with Runtime(tmp_path/'state',embedding=model) as r:
        r.register('r',path=str(p));r.update();before=model.items
        out=r.search('refresh_access_token',depth='verified')
        assert model.items==before
        assert out['retrieval_mode']=='exact_identifier'
        assert out['results'][0]['verification']=='bytes_verified'


def test_summaries_only_embedding_preserves_all_raw_lexical_sources(tmp_path):
    p=make_repo(tmp_path/'repo',{'a.py':'def rare_function():\n    return "thermal resistance"\n'})
    model=CountingEmbedder()
    with Runtime(tmp_path/'state',embedding=model,settings=IndexSettings(embedding_scope='summaries_only')) as r:
        r.register('r',path=str(p));out=r.update()
        assert out['units_created']>0 and out['vectors_created']==0 and model.items==0
        found=r.search('thermal resistance')
        assert found['results'] and found['coverage']['dense_occurrences_scanned']==0
        assert 'RAW_DENSE_DISABLED_BY_PROFILE' in found['warnings']


def test_switching_embedding_scope_does_not_reparse_source(tmp_path):
    p=make_repo(tmp_path/'repo',{'a.py':'def a():\n    return "thermal model"\n'})
    model=CountingEmbedder()
    with Runtime(tmp_path/'state',embedding=model) as r:
        r.register('r',path=str(p));r.update();snap=r.snapshot_map()
        r.settings=IndexSettings(embedding_scope='summaries_only')
        out=r.update()
        assert out['files_read']==0 and r.snapshot_map()==snap
        assert r.search('thermal model')['coverage']['dense_occurrences_scanned']==0
