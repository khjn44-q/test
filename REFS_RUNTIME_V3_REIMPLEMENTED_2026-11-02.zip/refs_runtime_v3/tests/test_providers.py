import contextlib
import json
import os
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import pytest
from refs.providers import EmbeddingProvider, ChatProvider, ProviderConfig, ProviderError, JsonHTTP

@contextlib.contextmanager
def server(callback):
    seen=[]
    class Handler(BaseHTTPRequestHandler):
        def log_message(self,*args): pass
        def do_POST(self):
            body=json.loads(self.rfile.read(int(self.headers['Content-Length'])))
            seen.append({'body':body,'headers':dict(self.headers)})
            status,result,headers=callback(body,len(seen))
            raw=result if isinstance(result,bytes) else json.dumps(result).encode()
            self.send_response(status)
            for k,v in headers.items(): self.send_header(k,v)
            self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw)
    s=ThreadingHTTPServer(('127.0.0.1',0),Handler)
    t=threading.Thread(target=s.serve_forever,daemon=True);t.start()
    try: yield f'http://127.0.0.1:{s.server_port}/v1',seen
    finally: s.shutdown();s.server_close();t.join()

def cfg(url,**kwargs):
    return ProviderConfig(endpoint=url+'/embeddings',model='internal-test',revision='fixture-r1',
                          dimensions=3,allow_loopback_http=True,retry_backoff=0,**kwargs)


def test_embedding_http_batches_reorders_normalizes(monkeypatch):
    monkeypatch.setenv('REFS_TEST_KEY','private-value')
    def response(b,n):
        return 200,{'data':[{'index':i,'embedding':[3.,4.,0.]} for i in reversed(range(len(b['input'])))]},{}
    with server(response) as (url,seen):
        p=EmbeddingProvider(cfg(url,batch_items=2,api_key_env='REFS_TEST_KEY'))
        vectors=p.embed(['a','b','c'],role='document')
        assert len(seen)==2 and len(vectors)==3
        assert vectors[0]==pytest.approx([.6,.8,0])
        assert seen[0]['headers']['Authorization']=='Bearer private-value'
        assert p.stats['items']==3
        assert 'private-value' not in p.fingerprint


def test_role_prefix_and_no_silent_truncation():
    with server(lambda b,n:(200,{'data':[{'index':0,'embedding':[1,0,0]}]},{})) as (url,seen):
        p=EmbeddingProvider(cfg(url,query_prefix='query: ',document_prefix='doc: ',max_input_chars=64))
        p.embed(['abc'],role='query')
        assert seen[0]['body']['input']==['query: abc']
        with pytest.raises(ProviderError,match='INPUT_TOO_LONG'): p.embed(['a'*65],role='document')
        assert len(seen)==1


def test_fingerprint_revision_dimensions_prefix():
    a=EmbeddingProvider(cfg('http://127.0.0.1:3'))
    b=EmbeddingProvider(ProviderConfig(endpoint='http://127.0.0.1:3/embeddings',model='internal-test',revision='r2',dimensions=3,allow_loopback_http=True))
    c=EmbeddingProvider(cfg('http://127.0.0.1:3',query_prefix='other'))
    assert len({a.fingerprint,b.fingerprint,c.fingerprint})==3


@pytest.mark.parametrize('vector',[[1,2], [0,0,0], [float('nan'),0,1], [float('inf'),0,1], [True,0,1], ['1',0,1]])
def test_invalid_vectors_rejected(vector):
    with server(lambda b,n:(200,{'data':[{'index':0,'embedding':vector}]},{})) as (url,_):
        with pytest.raises(ProviderError): EmbeddingProvider(cfg(url)).embed(['x'])


def test_duplicate_response_indices():
    with server(lambda b,n:(200,{'data':[{'index':0,'embedding':[1,0,0]},{'index':0,'embedding':[1,0,0]}]},{})) as (url,_):
        with pytest.raises(ProviderError): EmbeddingProvider(cfg(url)).embed(['x','y'])


def test_retry_only_transient():
    with server(lambda b,n:(429,{'error':'secret server diagnostic'},{'Retry-After':'0'}) if n==1 else (200,{'data':[{'index':0,'embedding':[1,0,0]}]},{})) as (url,seen):
        p=EmbeddingProvider(cfg(url,retries=1));p.embed(['x'])
        assert len(seen)==2 and p.stats['retries']==1
    with server(lambda b,n:(400,{'error':'SECRET'},{})) as (url,seen):
        with pytest.raises(ProviderError) as e: EmbeddingProvider(cfg(url,retries=3)).embed(['x'])
        assert len(seen)==1 and 'SECRET' not in str(e.value)


def test_redirect_rejected():
    with server(lambda b,n:(307,b'',{'Location':'https://example.invalid/leak'})) as (url,seen):
        with pytest.raises(ProviderError,match='307'): EmbeddingProvider(cfg(url)).embed(['source'])
        assert len(seen)==1


def test_missing_key_fails_before_request(monkeypatch):
    monkeypatch.delenv('REFS_NEVER_SET',raising=False)
    with server(lambda b,n:(200,{},{})) as (url,seen):
        with pytest.raises(ProviderError,match='MISSING_CREDENTIAL'): EmbeddingProvider(cfg(url,api_key_env='REFS_NEVER_SET')).embed(['x'])
        assert not seen


def test_response_size_guard():
    with server(lambda b,n:(200,b'x'*2048,{})) as (url,_):
        with pytest.raises(ProviderError,match='RESPONSE_TOO_LARGE'): EmbeddingProvider(cfg(url,max_response_bytes=1024)).embed(['x'])


@pytest.mark.parametrize('endpoint',['http://example.com/api','https://u:p@example.com/api','https://example.com/api#bad'])
def test_endpoint_policy(endpoint):
    with pytest.raises(ProviderError): EmbeddingProvider(ProviderConfig(endpoint=endpoint,model='x',revision='r1',dimensions=3))


def test_chat_http_contract():
    with server(lambda b,n:(200,{'choices':[{'message':{'content':'{"claims":[]}'}}]},{})) as (url,seen):
        c=ChatProvider(ProviderConfig(endpoint=url+'/chat/completions',model='chat',revision='r1',allow_loopback_http=True))
        assert c.complete([{'role':'user','content':'question'}])=='{"claims":[]}'
        assert seen[0]['body']['model']=='chat'
        assert seen[0]['body']['temperature']==0


def test_vectors_response_shape():
    with server(lambda b,n:(200,{'vectors':[[1,0,0]]},{})) as (url,_):
        p=EmbeddingProvider(cfg(url,response_format='vectors'))
        assert p.embed(['x'])==[[1.,0.,0.]]
