import importlib.util
from pathlib import Path
import zipfile
import pytest

ROOT=Path(__file__).resolve().parents[1]

def load_builder():
    path=ROOT/'scripts'/'build_bundle.py'
    assert path.exists(), 'build_bundle.py is not implemented'
    spec=importlib.util.spec_from_file_location('refs_bundle_builder',path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module

def specimen(root):
    for name in ('README.md','HANDOFF_KO.md','pyproject.toml','docs/DESIGN.md','docs/PLAN.md','verification/FINAL_REPORT.md','src/refs/__init__.py','dist/engineering_refs-0.3.0-py3-none-any.whl'):
        p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text('fixture')
    for name in ('.git/config','examples/.env','src/refs/__pycache__/a.pyc','src/engineering_refs.egg-info/PKG-INFO','private.sqlite3'):
        p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text('do not ship')

def test_release_builder_verifies_and_excludes_private_and_generated_files(tmp_path):
    builder=load_builder();root=tmp_path/'project';specimen(root)
    out=tmp_path/'package.zip';report=builder.build_bundle(root,out)
    assert report['status']=='verified'
    with zipfile.ZipFile(out) as z:
        names=z.namelist()
        assert 'refs_runtime_v3/HANDOFF_KO.md' in names
        assert not any('.git/' in p or '__pycache__' in p or '.egg-info' in p or p.endswith('.env') or p.endswith('.sqlite3') for p in names)

def test_release_builder_refuses_incomplete_release(tmp_path):
    builder=load_builder();root=tmp_path/'project';root.mkdir()
    with pytest.raises(ValueError,match='MISSING_REQUIRED'):
        builder.build_bundle(root,tmp_path/'bad.zip')
    assert not (tmp_path/'bad.zip').exists()

def test_fresh_install_smoke_script_is_present():
    assert (ROOT/'scripts'/'smoke_install.py').is_file(), 'isolated wheel smoke runner missing'
