from pathlib import Path
import importlib.util,json,hashlib,zipfile
import pytest

ROOT=Path(__file__).resolve().parents[1]

def load_verifier():
    p=ROOT/'scripts'/'verify_bundle.py'
    assert p.is_file(),'bundle verifier not implemented'
    spec=importlib.util.spec_from_file_location('refs_verify',p);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module

def test_zip_verifier_checks_contents_and_tampering(tmp_path):
    verify=load_verifier().verify_zip
    content=b'hello';record={'path':'README.md','bytes':len(content),'sha256':hashlib.sha256(content).hexdigest()}
    manifest=json.dumps({'schema_version':1,'files':[record]}).encode()
    good=tmp_path/'good.zip'
    with zipfile.ZipFile(good,'w') as z:
        z.writestr('refs/README.md',content);z.writestr('refs/MANIFEST.json',manifest)
    assert verify(good)['files_verified']==1
    bad=tmp_path/'bad.zip'
    with zipfile.ZipFile(bad,'w') as z:
        z.writestr('refs/README.md',b'bad');z.writestr('refs/MANIFEST.json',manifest)
    with pytest.raises(ValueError):verify(bad)

def test_zip_verifier_rejects_unsafe_or_extra_paths(tmp_path):
    verify=load_verifier().verify_zip
    for name in ('refs/../escape.txt','refs/unlisted.txt'):
        path=tmp_path/'bad.zip'
        with zipfile.ZipFile(path,'w') as z:
            z.writestr('refs/MANIFEST.json',json.dumps({'schema_version':1,'files':[]}));z.writestr(name,b'x')
        with pytest.raises(ValueError):verify(path)
