import json
import os
import sqlite3
import pytest
from conftest import git, commit, make_repo
from helpers import CountingEmbedder
from refs.indexer import Index, IndexSettings, IndexError as RefsIndexError
from refs.store import Store, WriterLock


def setup_index(tmp_path,repo,embedding=None,**kwargs):
    idx=Index(tmp_path/'state',embedding=embedding,**kwargs)
    idx.register('example',path=str(repo),ref='HEAD')
    return idx


def test_initial_index_and_coverage(tmp_path,repo):
    with setup_index(tmp_path,repo) as idx:
        out=idx.update();assert out['changed']==1 and out['failed']==0
        status=idx.status();assert status['repositories'][0]['snapshot_id']
        assert status['repositories'][0]['coverage']['indexed_files']==3
        assert status['units']>0


def test_noop_no_reparse_or_embedding(tmp_path,repo):
    model=CountingEmbedder()
    with setup_index(tmp_path,repo,model) as idx:
        a=idx.update();n=model.items;s=idx.status()['repositories'][0]['snapshot_id']
        b=idx.update()
        assert b['unchanged']==1 and b['changed']==0
        assert b['files_read']==0 and b['units_created']==0 and b['vectors_created']==0
        assert model.items==n and idx.status()['repositories'][0]['snapshot_id']==s


def test_rename_reuses_source_vectors(tmp_path,repo):
    model=CountingEmbedder()
    with setup_index(tmp_path,repo,model) as idx:
        idx.update();n=model.items
        (repo/'src/client.py').rename(repo/'src/renamed.py');commit(repo)
        out=idx.update()
        assert out['changed']==1 and out['renamed_files']==1
        assert out['vectors_created']==0 and model.items==n
        paths=[x['path'] for x in idx.files('example')]
        assert 'src/renamed.py' in paths and 'src/client.py' not in paths


def test_delete_and_new_file(tmp_path,repo):
    with setup_index(tmp_path,repo,CountingEmbedder()) as idx:
        idx.update();old=idx.snapshot_map()
        (repo/'src/client.py').unlink();commit(repo,{'new.py':'def unique_new():\n    return 42\n'})
        out=idx.update();assert out['deleted_files']==1
        assert idx.snapshot_map()!=old
        assert all(f['path']!='src/client.py' for f in idx.files('example'))
        assert any(f['path']=='new.py' for f in idx.files('example'))


def test_model_failure_keeps_previous_snapshot(tmp_path,repo):
    model=CountingEmbedder()
    with setup_index(tmp_path,repo,model) as idx:
        idx.update();old=idx.snapshot_map();model.fail=True
        commit(repo,{'added.py':'def fresh_call():\n    return 12345\n'})
        out=idx.update()
        assert out['failed']==1 and idx.snapshot_map()==old
        assert idx.status()['repositories'][0]['last_error']
        model.fail=False
        assert idx.update()['changed']==1


def test_sql_failure_rolls_back_snapshot_publication(tmp_path,repo):
    with setup_index(tmp_path,repo) as idx:
        idx.update();old=idx.snapshot_map()
        idx.store.conn.execute("CREATE TRIGGER reject_publish BEFORE UPDATE OF active_snapshot ON repositories BEGIN SELECT RAISE(ABORT, 'injected failure'); END")
        commit(repo,{'new.py':'x=123\n'})
        out=idx.update();assert out['failed']==1 and idx.snapshot_map()==old
        idx.store.conn.execute('DROP TRIGGER reject_publish')
        assert idx.update()['changed']==1


def test_model_space_change_does_not_reparse(tmp_path,repo):
    first=CountingEmbedder('space-A')
    with setup_index(tmp_path,repo,first) as idx:
        idx.update();snap=idx.snapshot_map()
        second=CountingEmbedder('space-B');idx.embedding=second
        out=idx.update()
        assert second.items>0 and out['files_read']==0
        assert idx.snapshot_map()==snap
        assert idx.store.conn.execute('select count(distinct space) from embeddings').fetchone()[0]==2


def test_plan_does_not_publish(tmp_path,repo):
    with setup_index(tmp_path,repo,CountingEmbedder()) as idx:
        out=idx.update(plan=True)
        assert out['state']=='planned' and not idx.snapshot_map()
        assert idx.embedding.items==0


def test_disabled_repository_excluded(tmp_path,repo):
    with setup_index(tmp_path,repo) as idx:
        idx.update();idx.set_enabled('example',False)
        assert idx.snapshot_map()=={}
        assert idx.update()['checked']==0
        with pytest.raises(RefsIndexError): idx.files('example')


def test_secret_binary_symlink_and_oversized_coverage(tmp_path):
    repo=make_repo(tmp_path/'repo',{'ok.py':'x=1\n','.env':'API_KEY=not-for-index\n',
        'key.pem':'-----BEGIN PRIVATE KEY-----\nxxx\n','binary.bin':b'\x00\x01',
        'huge.py':'x'*1000})
    with setup_index(tmp_path,repo,settings=IndexSettings(max_file_bytes=500)) as idx:
        idx.update();files=idx.files('example')
        reasons={f['path']:f['reason'] for f in files}
        assert reasons['.env']=='excluded_path'
        assert reasons['key.pem']=='secret_material'
        assert reasons['binary.bin']=='binary'
        assert reasons['huge.py']=='too_large'
        assert idx.status()['repositories'][0]['coverage']['excluded_files']==4


def test_managed_remote_local_fixture(tmp_path,repo):
    with Index(tmp_path/'state') as idx:
        idx.register('managed',url=str(repo),allow_local_remote=True,ref='refs/heads/main')
        out=idx.update();assert out['changed']==1
        assert git(repo,'status','--porcelain')==''


def test_writer_lock_excludes_second_writer(tmp_path):
    with WriterLock(tmp_path/'lock'):
        with pytest.raises(RefsIndexError,match='WRITER_BUSY'):
            with WriterLock(tmp_path/'lock'): pass
    with WriterLock(tmp_path/'lock'): pass


def test_unchanged_blob_parse_cache_shared_across_repos(tmp_path):
    a=make_repo(tmp_path/'a',{'x.py':'def same():\n    return 7\n'})
    b=make_repo(tmp_path/'b',{'x.py':'def same():\n    return 7\n'})
    m=CountingEmbedder()
    with Index(tmp_path/'state',embedding=m) as idx:
        idx.register('a',path=str(a));idx.register('b',path=str(b))
        out=idx.update();assert out['changed']==2
        count=idx.store.conn.execute('select count(*) from units').fetchone()[0]
        assert m.items==count


def test_repo_identifier_and_rebinding(tmp_path,repo):
    with Index(tmp_path/'state') as idx:
        with pytest.raises(RefsIndexError): idx.register('../bad',path=str(repo))
        idx.register('a',path=str(repo));idx.register('a',path=str(repo))
        other=make_repo(tmp_path/'other')
        with pytest.raises(RefsIndexError,match='ALREADY_BOUND'):idx.register('a',path=str(other))


def test_snapshot_pin_retains_deleted_content(tmp_path,repo):
    with setup_index(tmp_path,repo) as idx:
        idx.update();snap=idx.snapshot_map()['example'];original=idx.files('example',snapshot_id=snap)
        f=next(f for f in original if f['path']=='src/client.py')
        (repo/'src/client.py').unlink();commit(repo);idx.update()
        assert b'search_issues' in idx.cache.get(f['content_hash'])
        assert idx.files('example',snapshot_id=snap)==original


def test_rebuild_reprocesses_and_refuses_invalid_vectors(tmp_path,repo):
    model=CountingEmbedder()
    with setup_index(tmp_path,repo,model) as idx:
        idx.update();count=model.items
        out=idx.update(rebuild=True)
        assert out['files_read']>0 and model.items>count
        assert out['failed']==0


def test_partial_inventory_success_and_error(tmp_path,repo):
    with setup_index(tmp_path,repo) as idx:
        idx.register('missing',path=str(tmp_path/'does-not-exist'))
        out=idx.update()
        assert out['changed']==1 and out['failed']==1 and out['state']=='partial'
        assert 'example' in idx.snapshot_map() and 'missing' not in idx.snapshot_map()
