from pathlib import Path
import importlib.util,json,socket

ROOT=Path(__file__).resolve().parents[1]

def test_public_inventory_is_explicitly_unverified_and_contains_100_unique_candidates():
    p=ROOT/'bench'/'public_repositories.json'
    assert p.is_file(),'public benchmark inventory not implemented'
    data=json.loads(p.read_text())
    assert data['status']=='candidate_urls_not_downloaded_or_validated'
    repos=data['repositories'];assert len(repos)==100 and len({r['url'] for r in repos})==100
    assert all(r['url'].startswith('https://github.com/') for r in repos)


def test_blocked_public_preflight_does_not_claim_attempted_clones():
    p=ROOT/'bench'/'public.py'
    assert p.is_file(),'public benchmark runner not implemented'
    spec=importlib.util.spec_from_file_location('refs_public',p);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    def blocked(*args,**kwargs):raise socket.gaierror('controlled fixture, not the actual network')
    out=module.preflight('github.com',resolver=blocked)
    assert out['status']=='blocked' and out['repositories_cloned']==0
    assert out['git_repositories_attempted']==0
    assert out['reason']=='dns_resolution_failed'
