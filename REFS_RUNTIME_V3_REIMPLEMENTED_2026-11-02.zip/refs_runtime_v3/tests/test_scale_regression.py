"""Operation-budget regression for many-repository scope filtering, not a wall-clock assertion."""
import pytest
from refs.core import Runtime
from refs.chunks import chunk_file
from refs.store import digest


def test_100_repository_scope_does_not_multiply_fts_candidate_probes(tmp_path):
    with Runtime(tmp_path/'state') as r:
        for i in range(100):
            rid=f'repo-{i:03}'
            r.register(rid,path=str(tmp_path/rid))
            raw=''.join(f'def common_workload_{i}_{j}(x):\n    return x + {i*100+j}\n\n' for j in range(30)).encode()
            h=r.cache.put(raw);pk=digest([h,'fixture'])
            r.store.put_parse(pk,h,chunk_file('m.py',raw))
            oid=__import__('hashlib').sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
            r.store.publish(rid,'0'*40,'fixture',h,[dict(path='m.py',git_oid=oid,content_hash=h,parse_key=pk,
                size=len(raw),mode='100644',status='indexed',reason='')],dict(total_files=1,indexed_files=1),
                dict(body='fixture',paths=['m.py']))
        instructions=0
        def guard():
            nonlocal instructions
            instructions+=1000
            return int(instructions>700000)
        r.store.conn.set_progress_handler(guard,1000)
        try:
            out=r.search('common_workload',limit=5)
            assert out['results']
        finally:r.store.conn.set_progress_handler(None,0)
        assert instructions<=700000
