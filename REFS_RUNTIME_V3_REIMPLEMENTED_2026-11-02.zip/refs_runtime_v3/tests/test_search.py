import json
from pathlib import Path
import pytest
from conftest import make_repo,commit,git
from helpers import CountingEmbedder
from refs.core import Runtime
from refs.errors import RefsError
from refs.indexer import IndexSettings
from refs.retrieval import rrf


def runtime(tmp_path,repo,embedding=None,**kwargs):
    r=Runtime(tmp_path/'state',embedding=embedding,**kwargs);r.register('r',path=str(repo));r.update();return r


def test_lexical_search_and_evidence(repo,tmp_path):
    with runtime(tmp_path,repo) as r:
        out=r.search('search_issues')
        assert out['results'] and out['retrieval_mode']=='lexical_only'
        hit=out['results'][0];source=r.evidence(hit['evidence_id'])
        assert 'def search_issues' in source['text']
        assert source['commit']==git(repo,'rev-parse','HEAD')
        assert source['verification']=='bytes_verified'


def test_small_function_not_in_readme(tmp_path):
    p=make_repo(tmp_path/'repo',{'README.md':'Unrelated accounting project\n',
        'deep/misc.py':'def refresh_access_token():\n    return "rotate token"\n'})
    with runtime(tmp_path,p) as r:
        assert any(h['path']=='deep/misc.py' for h in r.search('refresh_access_token')['results'])


def test_korean_aliases_are_explicit_not_fake_semantics(tmp_path):
    p=make_repo(tmp_path/'repo',{'thermal.py':'def temperature_step(power, resistance):\n    """thermal heat resistance model"""\n    return power * resistance\n'})
    with runtime(tmp_path,p) as r:
        out=r.search('열저항 온도 모델')
        assert out['results']
        assert 'thermal' in out['query_terms']
        assert out['retrieval_mode']=='lexical_only'


def test_exact_result_survives_rank_fusion():
    assert rrf({'a':['x','x','y'],'b':['y']})[0]['id']=='y'
    assert rrf({'a':['x','x']})==rrf({'a':['x']})


@pytest.mark.parametrize('query',['" OR *','x" OR 1=1 --','{}[]():','jira AND NOT xyz'])
def test_fts_query_not_interpreted_as_program(repo,tmp_path,query):
    with runtime(tmp_path,repo) as r:
        out=r.search(query);assert out['status'] in {'ok','no_match'}


def test_session_pinned_across_update(repo,tmp_path):
    with runtime(tmp_path,repo) as r:
        first=r.search('search_issues');old=first['results'][0]['evidence_id']
        commit(repo,{'src/client.py':'def completely_different():\n    return 0\n'});r.update()
        assert 'search_issues' in r.evidence(old)['text']
        follow=r.search('search_issues',session_id=first['session_id'])
        assert any('search_issues' in h['symbol'] for h in follow['results'])
        assert follow['manifest_id']==first['manifest_id']
        fresh=r.search('completely_different')
        assert fresh['manifest_id']!=first['manifest_id']


def test_disabled_scope_applies_to_old_evidence(repo,tmp_path):
    with runtime(tmp_path,repo) as r:
        out=r.search('search_issues');eid=out['results'][0]['evidence_id'];r.set_enabled('r',False)
        with pytest.raises(RefsError):r.evidence(eid)
        with pytest.raises(RefsError):r.search('jira',session_id=out['session_id'])
        assert r.search('jira')['results']==[]


def test_unknown_evidence_rejected(repo,tmp_path):
    with runtime(tmp_path,repo) as r:
        with pytest.raises(RefsError):r.evidence('../../secret')


def test_whole_file_scan_crosses_chunk_boundaries(tmp_path):
    content='a'*63+'needle_after_boundary'+'z'*63+'\n'
    p=make_repo(tmp_path/'repo',{'data.txt':content})
    with runtime(tmp_path,p,settings=IndexSettings(chunk_chars=64)) as r:
        out=r.scan(['needle_after_boundary'])
        assert out['total_matches']==1
        assert out['coverage']['scope_scan_complete']
        assert out['coverage']['semantic_completeness']=='not_proven'


def test_all_scan_pagination_not_topk(tmp_path):
    p=make_repo(tmp_path/'repo',{f'src/f{i:03}.py':f'endpoint = "jira.issue/{i}"\n' for i in range(37)})
    with runtime(tmp_path,p) as r:
        out=r.scan(['jira.issue'],limit=7)
        ids=[x['evidence_id'] for x in out['results']]
        assert out['total_matches']==37
        while out['next_cursor']:
            out=r.scan(cursor=out['next_cursor'],limit=7)
            ids.extend(x['evidence_id'] for x in out['results'])
        assert len(ids)==37 and len(set(ids))==37


def test_scan_cursor_tampering_rejected(repo,tmp_path):
    with runtime(tmp_path,repo) as r:
        out=r.scan(['jira','Jira','jql'],limit=1)
        assert out['next_cursor']
        with pytest.raises(RefsError):r.scan(cursor=out['next_cursor']+'x')


def test_scan_budget_not_claimed_complete(tmp_path):
    p=make_repo(tmp_path/'repo',{'a.txt':'needle '*100})
    with runtime(tmp_path,p) as r:
        out=r.scan(['needle'],max_matches=3)
        assert out['total_matches']==3
        assert out['status']=='partial' and not out['coverage']['scope_scan_complete']


def test_jira_detector_separates_docs_and_test(tmp_path):
    p=make_repo(tmp_path/'repo',{'README.md':'jira example\n','tests/test_mock.py':'fake = "jira"\n',
        'api.py':'def query():\n    return client.get("/rest/api/2/search")\n'})
    with runtime(tmp_path,p) as r:
        out=r.scan(detector='jira')
        kinds={x['classification'] for x in out['results']}
        assert {'docs_only','test_only','source_candidate'}<=kinds
        assert all(x.get('execution_verified',False) is False for x in out['results'])


def test_evidence_file_pagination(tmp_path):
    p=make_repo(tmp_path/'repo',{'m.py':'\n'.join(f'x{i}={i}' for i in range(300))+'\n'})
    with runtime(tmp_path,p) as r:
        out=r.search('x100');eid=out['results'][0]['evidence_id']
        first=r.evidence(eid,start_line=1,line_limit=10)
        assert first['returned_line_start']==1 and first['returned_line_end']==10
        assert first['next_start_line']==11 and first['total_lines']==300
        second=r.evidence(eid,start_line=11,line_limit=10)
        assert 'x10=10' in second['text']


def test_compare_old_and_new(repo,tmp_path):
    with runtime(tmp_path,repo) as r:
        a=r.search('search_issues')['results'][0]['evidence_id']
        commit(repo,{'src/client.py':'def search_issues(jql):\n    return "NEW SEARCH"\n'});r.update()
        b=r.search('search_issues')['results'][0]['evidence_id']
        diff=r.compare(a,b)
        assert 'NEW SEARCH' in diff['diff'] and diff['execution_performed'] is False


def test_trace_labels_candidates(tmp_path):
    p=make_repo(tmp_path/'repo',{'a.py':'def helper(x):\n    return x\n\ndef run(x):\n    return helper(x)\n'})
    with runtime(tmp_path,p) as r:
        eid=r.search('run')['results'][0]['evidence_id']
        trace=r.trace(eid)
        assert any(e['target']=='helper' for e in trace['relations'])
        assert all(e['resolution']!='runtime_observed' for e in trace['relations'])


def test_query_embedding_cached(repo,tmp_path):
    model=CountingEmbedder()
    with runtime(tmp_path,repo,model) as r:
        r.search('some query');n=model.items
        out=r.search('some query')
        assert model.items==n and out['query_embedding_cache_hit']
        assert out['retrieval_mode']=='hybrid'


def test_model_outage_returns_labelled_lexical_results(repo,tmp_path):
    model=CountingEmbedder()
    with runtime(tmp_path,repo,model) as r:
        model.fail=True;out=r.search('search issues')
        assert out['results'] and out['retrieval_mode']=='lexical_fallback'
        assert out['warnings']


def test_verified_read_detects_cache_corruption(repo,tmp_path):
    with runtime(tmp_path,repo) as r:
        first=r.search('search_issues');eid=first['results'][0]['evidence_id']
        ev=r.store.one('select * from evidence where evidence_id=?',(eid,))
        r.cache.path(ev['content_hash']).write_bytes(b'corrupt')
        out=r.search('search_issues',depth='verified')
        bad=[x for x in out['results'] if x['evidence_id']==eid]
        assert bad and bad[0]['verification']=='unavailable'


def test_scope_limits_results(tmp_path):
    a=make_repo(tmp_path/'a',{'a.py':'def same():\n    return 1\n'})
    b=make_repo(tmp_path/'b',{'b.py':'def same():\n    return 2\n'})
    with Runtime(tmp_path/'state') as r:
        r.register('a',path=str(a));r.register('b',path=str(b));r.update()
        out=r.search('same',repo_ids=['b'])
        assert out['results'] and {x['repo_id'] for x in out['results']}=={'b'}
