from pathlib import Path
import subprocess,sys,json


def test_recorded_command_preserves_exit_code_and_output(tmp_path):
    script=Path(__file__).resolve().parents[1]/'scripts'/'run_recorded.py'
    assert script.is_file(),'recorded runner not implemented'
    prefix=tmp_path/'failed-check'
    out=subprocess.run([sys.executable,str(script),'--prefix',str(prefix),'--',sys.executable,'-c',
                        'print("intentional failure"); raise SystemExit(7)'],capture_output=True)
    assert out.returncode==7
    result=json.loads(prefix.with_suffix('.json').read_text())
    assert result['returncode']==7 and result['status']=='failed'
    assert result['duration_seconds']>=0
    assert 'intentional failure' in prefix.with_suffix('.log').read_text()
