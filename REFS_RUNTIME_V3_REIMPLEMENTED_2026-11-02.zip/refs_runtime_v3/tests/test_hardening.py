import json
from dataclasses import replace
import pytest
from refs.providers import ChatProvider, ProviderConfig
from refs.core import Runtime
from refs.store import digest,dumps,now
from refs import retrieval
from conftest import make_repo


def test_llm_generation_settings_invalidate_only_llm_fingerprint():
    c=ProviderConfig(endpoint='https://models.example.invalid/chat',model='internal',revision='r1')
    assert ChatProvider(c).fingerprint!=ChatProvider(replace(c,max_output_tokens=4096)).fingerprint
    assert ChatProvider(c).fingerprint!=ChatProvider(replace(c,json_output=True)).fingerprint
    assert c.fingerprint==replace(c,max_output_tokens=4096).fingerprint


def test_scan_discloses_excluded_file_policy(tmp_path):
    p=make_repo(tmp_path/'repo',{'a.py':'def jira_query():\n    return 1\n','.env':'TOKEN=not-a-real-secret\n'})
    with Runtime(tmp_path/'state') as r:
        r.register('r',path=str(p));r.update();out=r.scan(['jira'])
        assert out['coverage']['excluded_files']==1
        assert out['coverage']['tracked_files']==2
        assert out['coverage']['excluded_reasons']['excluded_path']==1
        assert out['coverage']['scope_scan_complete'] is True
        assert out['coverage']['coverage_basis']=='indexed_eligible_text_only'


def test_stale_notes_do_not_consume_candidate_limit(tmp_path):
    p=make_repo(tmp_path/'repo',{'m.py':'def current():\n    return 1\n'})
    with Runtime(tmp_path/'state') as r:
        r.register('r',path=str(p));r.update();eid=r.search('current')['results'][0]['evidence_id']
        snap=r.snapshot_map()['r'];tree=r.store.one('select tree_digest from snapshots where snapshot_id=?',(snap,))['tree_digest']
        for i in range(90):
            valid=i==89
            body='specialclaim' if not valid else 'specialclaim '+('context '*100)
            r.store.conn.execute('''INSERT INTO notes(note_id,repo_id,snapshot_id,kind,question,body,payload_json,evidence_json,
                dependencies_json,model_fp,state,input_hash,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)''',
                (f'n{i}','r',snap,'knowledge','q',body,'{}',dumps([eid]),dumps({'r':tree if valid else 'old-tree'}),'fixture',
                 'active' if valid else 'stale',digest(body),now()))
        rows=retrieval._notes(r,{'r':snap},['specialclaim'],5)
        assert len(rows)==1 and rows[0]['note_id']=='n89'


def test_unindexed_repository_prevents_no_match_completeness_claim(tmp_path):
    with Runtime(tmp_path/'state') as r:
        r.register('missing',path=str(tmp_path/'missing'))
        out=r.search('jira')
        assert out['status']=='partial'
        assert out['coverage']['scope_search_complete'] is False


def test_all_scan_page_has_followup_session_pinned_to_original_snapshot(tmp_path):
    from conftest import commit
    p=make_repo(tmp_path/'repo',{'m.py':'def old_jira():\n    return "jira"\n'})
    with Runtime(tmp_path/'state') as r:
        r.register('r',path=str(p));r.update()
        page=r.scan(['jira'])
        assert page['session_id']
        commit(p,{'m.py':'def new_version():\n    return 0\n'});r.update()
        follow=r.search('old_jira',session_id=page['session_id'])
        assert any(x['symbol']=='old_jira' for x in follow['results'])
