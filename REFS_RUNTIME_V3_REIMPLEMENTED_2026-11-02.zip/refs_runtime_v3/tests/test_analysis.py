import json
from types import SimpleNamespace
import pytest
from conftest import make_repo,commit
from refs.core import Runtime
from refs.indexer import IndexSettings
from refs.errors import RefsError

class CitingLLM:
    """Wire contract fixture, not a generative model or a semantic quality evaluation."""
    fingerprint='fixture-chat-v1'
    def __init__(self,budget=12000,change=None):
        self.config=SimpleNamespace(max_input_chars=budget)
        self.calls=[];self.change=change
    def complete(self,messages):
        assert sum(len(m['content']) for m in messages)<=self.config.max_input_chars
        self.calls.append(messages)
        data=json.loads(messages[-1]['content']);source=data['sources'][0]
        result={'claims':[{'statement':'Rare calibration capability for thermomechanical experiments',
             'kind':'knowledge','epistemic':'model_inferred',
             'citations':[{'evidence_id':source['evidence_id'],'quote':source['text'][:60]}]}],
             'unknowns':['Execution has not been performed.']}
        if self.change:self.change(result,source)
        return json.dumps(result)


def setup(tmp_path,llm=None,body=None,chunk_chars=3000):
    repo=make_repo(tmp_path/'repo',{'thermal.py':body or 'def step(T, P, dt, C, R, Ta):\n    """thermal model, temperature delta"""\n    return T + dt/C * (P-(T-Ta)/R)\n',
                                'README.md':'A model package\n','pyproject.toml':'[project]\nname="fixture"\n',
                                'tests/test_step.py':'from thermal import step\n\ndef test_step():\n    assert step(1,0,1,1,1,1)==1\n'})
    r=Runtime(tmp_path/'state',llm=llm,settings=IndexSettings(chunk_chars=chunk_chars));r.register('thermal',path=str(repo));r.update()
    eid=r.search('huge' if body and 'def huge' in body else 'step')['results'][0]['evidence_id'];return r,repo,eid


def test_no_llm_returns_usable_context_pack(tmp_path):
    with setup(tmp_path)[0] as r:
        eid=r.search('step')['results'][0]['evidence_id']
        out=r.analyze('수식은 무엇인가?', [eid])
        assert out['mode']=='context_only' and not out['llm_called']
        assert out['sources'] and 'return T' in out['sources'][0]['text']
        assert out['claims']==[]


def test_citations_saved_and_searchable(tmp_path):
    llm=CitingLLM();r,repo,eid=setup(tmp_path,llm)
    with r:
        out=r.analyze('계산의 의미',[eid])
        assert out['status']=='ok' and out['reference_validation']=='passed'
        assert out['semantic_entailment']=='not_verified'
        assert out['note_id']
        found=r.search('thermomechanical')
        assert any(x['record_type']=='knowledge' for x in found['results'])
        assert all(x['execution_verified'] is False for x in found['results'])


def test_same_analysis_reuses_cache(tmp_path):
    llm=CitingLLM();r,_,eid=setup(tmp_path,llm)
    with r:
        a=r.analyze('same',[eid]);n=len(llm.calls);b=r.analyze('same',[eid])
        assert len(llm.calls)==n and b['cache_hit'] and a['note_id']==b['note_id']


def test_invented_evidence_rejected(tmp_path):
    llm=CitingLLM(change=lambda r,s:r['claims'][0]['citations'][0].update(evidence_id='invented'))
    r,_,eid=setup(tmp_path,llm)
    with r:
        with pytest.raises(RefsError,match='CITATION'):r.analyze('q',[eid])
        assert r.store.conn.execute('select count(*) from notes').fetchone()[0]==0


def test_invented_quote_rejected(tmp_path):
    llm=CitingLLM(change=lambda r,s:r['claims'][0]['citations'][0].update(quote='not in the source'))
    r,_,eid=setup(tmp_path,llm)
    with r:
        with pytest.raises(RefsError,match='QUOTE'):r.analyze('q',[eid])


@pytest.mark.parametrize('epistemic',['execution_verified','policy_normative','owner_asserted'])
def test_llm_cannot_promote_authority(tmp_path,epistemic):
    llm=CitingLLM(change=lambda r,s:r['claims'][0].update(epistemic=epistemic))
    r,_,eid=setup(tmp_path,llm)
    with r:
        with pytest.raises(RefsError):r.analyze('q',[eid])


def test_llm_cannot_insert_execution_verified_field(tmp_path):
    llm=CitingLLM(change=lambda r,s:r['claims'][0].update(execution_verified=True))
    r,_,eid=setup(tmp_path,llm)
    with r:
        with pytest.raises(RefsError):r.analyze('q',[eid])


def test_long_evidence_split_without_silent_loss(tmp_path):
    body='def huge():\n'+''.join(f'    value_{i} = {i}\n' for i in range(240))+'    return value_1\n'
    llm=CitingLLM(budget=2200);r,_,eid=setup(tmp_path,llm,body=body,chunk_chars=8000)
    with r:
        out=r.analyze('explain',[eid],max_model_calls=30)
        assert len(llm.calls)>1
        assert out['coverage']['source_characters_sent']==len(r.evidence(eid,max_chars=200000)['text'])
        assert out['coverage']['omitted_parts']==0


def test_analysis_budget_reports_partial(tmp_path):
    body='def huge():\n'+''.join(f'    value_{i} = {i}\n' for i in range(240))
    llm=CitingLLM(budget=2200);r,_,eid=setup(tmp_path,llm,body=body,chunk_chars=8000)
    with r:
        out=r.analyze('explain',[eid],max_model_calls=1)
        assert out['status']=='partial' and out['coverage']['omitted_parts']>0


def test_update_marks_generated_notes_stale(tmp_path):
    llm=CitingLLM();r,repo,eid=setup(tmp_path,llm)
    with r:
        out=r.analyze('q',[eid]);commit(repo,{'new_module.py':'new = True\n'});r.update()
        assert r.store.one('select state from notes where note_id=?',(out['note_id'],))['state']=='stale'
        assert not any(x['record_type']=='knowledge' for x in r.search('thermomechanical')['results'])


def test_project_summary_coverage_explicit(tmp_path):
    llm=CitingLLM();r,_,_=setup(tmp_path,llm)
    with r:
        out=r.summarize('thermal',max_sources=2)
        assert out['coverage']['selected_sources']<=2
        assert out['coverage']['total_available_units']>=out['coverage']['selected_sources']
        assert out['scope']=='repository_summary'


def test_prepare_use_does_not_execute_source(tmp_path):
    r,_,eid=setup(tmp_path)
    with r:
        out=r.prepare_use(eid,goal='use in a simulator')
        assert out['execution_performed'] is False
        assert out['readiness']=='reference_only'
        assert out['entrypoint']=='step'
        assert any(f['path']=='pyproject.toml' for f in out['dependency_evidence'])
        assert out['missing_conditions']


def test_formula_literal_must_appear_in_source(tmp_path):
    def bad(result,source):
        result['claims'][0].update(kind='formula',details={'representation':'code_expression','expression':'T ** 4 + 999'})
    r,_,eid=setup(tmp_path,CitingLLM(change=bad))
    with r:
        with pytest.raises(RefsError,match='CODE_EXPRESSION'):r.analyze('equation',[eid])


def test_note_embedding_failure_does_not_lose_validated_analysis(tmp_path):
    from helpers import CountingEmbedder
    model=CountingEmbedder();llm=CitingLLM();r,_,eid=setup(tmp_path,llm)
    with r:
        r.embedding=model;model.fail=True
        out=r.analyze('q',[eid])
        assert out['note_id'] and 'NOTE_EMBEDDING_PENDING' in out['warnings']
        count=len(llm.calls);model.fail=False
        again=r.analyze('q',[eid])
        assert len(llm.calls)==count and again['cache_hit']
        assert r.store.conn.execute('select count(*) from note_embeddings').fetchone()[0]>0


def test_cross_repository_notes_not_exposed_after_disable(tmp_path):
    llm=CitingLLM()
    a=make_repo(tmp_path/'a',{'a.py':'def alpha():\n    return 1\n'})
    b=make_repo(tmp_path/'b',{'b.py':'def beta():\n    return 2\n'})
    with Runtime(tmp_path/'state',llm=llm) as r:
        r.register('a',path=str(a));r.register('b',path=str(b));r.update()
        ids=[r.search('alpha')['results'][0]['evidence_id'],r.search('beta')['results'][0]['evidence_id']]
        out=r.analyze('compare',ids)
        assert out['note_id']
        r.set_enabled('b',False)
        assert not any(h['record_type']=='knowledge' for h in r.search('thermomechanical')['results'])


def test_summary_vectors_participate_in_retrieval(tmp_path):
    from helpers import CountingEmbedder
    model=CountingEmbedder();llm=CitingLLM();r,_,eid=setup(tmp_path,llm)
    with r:
        r.embedding=model;r.update();r.analyze('q',[eid])
        out=r.search('thermomechanical')
        assert out['coverage']['dense_note_segments_scanned']>0


def test_llm_answer_does_not_repeat_entire_source_context(tmp_path):
    r,_,eid=setup(tmp_path,CitingLLM())
    with r:
        out=r.analyze('explain',[eid])
        assert out['source_payload']=='references_only'
        assert all('text' not in source and source['characters']>0 for source in out['sources'])
        assert out['claims'][0]['citations'][0]['quote']
        assert r.evidence(out['sources'][0]['evidence_id'])['text']
