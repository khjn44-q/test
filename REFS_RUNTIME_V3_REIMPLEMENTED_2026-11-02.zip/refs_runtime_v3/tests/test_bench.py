"""A benchmark must disclose corpus provenance and verify useful invariants."""
from pathlib import Path
import importlib.util

ROOT=Path(__file__).resolve().parents[1]

def load_bench():
    path=ROOT/'bench'/'scale.py'
    assert path.is_file(), 'S7 benchmark runner not implemented'
    spec=importlib.util.spec_from_file_location('scale_bench',path)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module

def test_synthetic_benchmark_uses_real_git_and_verifies_mutations(tmp_path):
    report=load_bench().run_benchmark(tmp_path,repositories=4,files_per_repo=3,functions_per_file=2,
                                    query_repeats=3,embedding_dimensions=8)
    assert report['corpus']['provenance']=='synthetic_local_git'
    assert report['corpus']['repositories']==4
    assert report['corpus']['public_repositories']==0
    assert report['initial']['checked']==4
    assert report['initial']['failed']==0
    assert report['no_op']['vectors_created']==0
    assert report['no_op']['files_read']==0
    assert report['mutation']['changed_repositories']==4
    assert report['mutation']['old_evidence_still_valid']
    assert report['mutation']['unchanged_vectors_reused']
    assert report['known_gold']['exact_hit_at_5']==1.0
    assert report['known_gold']['all_scan_repo_recall']==1.0
    assert report['semantic_quality_measured'] is False
    assert report['embedding']['kind']=='deterministic_fixture_not_llm'
    assert report['timings']['warm_search_ms']['sample_count']>=3
    assert report['physical_source_directories_unchanged_by_indexer']
