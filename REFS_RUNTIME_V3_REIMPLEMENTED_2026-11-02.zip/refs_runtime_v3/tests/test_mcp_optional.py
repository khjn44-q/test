"""Only runs with the real official SDK installed; never substitute a fake SDK for this test."""
import asyncio
import pytest
mcp=pytest.importorskip('mcp',reason='Official MCP SDK not installed; integration unverified in this environment.')
from refs.config import load_config
from refs.mcp_server import create_server


def test_real_official_sdk_in_memory(tmp_path):
    from mcp import Client
    server=create_server(load_config(home=tmp_path/'state'))
    async def run():
        async with Client(server) as client:
            result=await client.call_tool('refs_index_status',{})
            assert result.structured_content['repositories']==[]
    asyncio.run(run())
