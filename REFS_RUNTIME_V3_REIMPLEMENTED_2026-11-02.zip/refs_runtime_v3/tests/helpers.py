import hashlib
import math
class CountingEmbedder:
    """Deterministic synthetic vectors for mechanics tests; NOT a language model."""
    def __init__(self, fingerprint='synthetic-space-v1', dimensions=8):
        self.fingerprint=fingerprint;self.dimensions=dimensions;self.calls=[];self.fail=False
    def embed(self,texts,role='document'):
        if self.fail: raise RuntimeError('synthetic model outage')
        self.calls.append((role,list(texts)))
        vectors=[]
        for t in texts:
            raw=hashlib.sha256((role+t).encode()).digest()
            v=[(raw[i%len(raw)]-127)/128 for i in range(self.dimensions)]
            norm=math.hypot(*v);vectors.append([x/norm for x in v])
        return vectors
    @property
    def items(self): return sum(len(t) for _,t in self.calls)
