#!/usr/bin/env python3
"""Reproducible 100+ *synthetic* local Git scale experiment, never a public/semantic benchmark.

No generated repository code is executed. Git writes are confined to the chosen new work directory.
Use --work-dir on a scratch disk; the script does not delete the experiment or user repositories.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import sqlite3
import statistics
import struct
import subprocess
import sys
import tempfile
import time

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
from refs.core import Runtime
from refs.indexer import IndexSettings
from refs.store import now


def git(path,*args):
    env=dict(os.environ,GIT_CONFIG_GLOBAL=os.devnull,GIT_CONFIG_NOSYSTEM='1',GIT_TERMINAL_PROMPT='0')
    process=subprocess.run(['git','-c','core.hooksPath='+os.devnull,'-C',str(path),*args],
                           capture_output=True,env=env,timeout=60)
    if process.returncode:raise RuntimeError('SYNTHETIC_GIT_OPERATION_FAILED:'+args[0])
    return process.stdout.decode().strip()


def commit(path,message):
    git(path,'add','-A')
    git(path,'-c','user.name=Synthetic Benchmark','-c','user.email=benchmark@example.invalid',
        'commit','-q','-m',message)
    return git(path,'rev-parse','HEAD')


class FixtureEmbedding:
    """Hash-based normalized vectors test storage/IO, NOT multilingual or code semantics."""
    def __init__(self,dimensions):
        self.dimensions=dimensions;self.fingerprint=f'SYNTHETIC-SHAKE-fixture-{dimensions}-v1'
        self.items=0;self.requests=0
    def embed(self,texts,role='document'):
        self.requests+=1;self.items+=len(texts);out=[]
        for text in texts:
            raw=hashlib.shake_256((role+'\n'+text).encode()).digest(self.dimensions*2)
            vals=[(x-32768)/32768 for x in struct.unpack('<'+'H'*self.dimensions,raw)]
            norm=math.hypot(*vals);out.append([x/norm for x in vals])
        return out


def percentiles(values):
    values=sorted(values)
    def pick(p):return values[max(0,math.ceil(p*len(values))-1)] if values else None
    return {'sample_count':len(values),'p50':pick(.5),'p95':pick(.95),'min':values[0] if values else None,
            'max':values[-1] if values else None,'mean':statistics.mean(values) if values else None}


def create_corpus(root,repositories,files_per_repo,functions_per_file):
    source=root/'repositories'
    if source.exists():raise ValueError('BENCHMARK_REPOSITORY_DIRECTORY_MUST_NOT_EXIST')
    source.mkdir(parents=True)
    records=[];source_bytes=0;tracked_files=0
    for ridx in range(repositories):
        rid=f'synthetic-{ridx:03d}';repo=source/rid;repo.mkdir()
        git(repo,'init','-q','-b','main')
        (repo/'src').mkdir();(repo/'tests').mkdir()
        (repo/'README.md').write_text(f'# Synthetic module {ridx}\nThis is generated benchmark data, not public or company code.\n',encoding='utf-8')
        for fidx in range(files_per_repo):
            text=f'"""Synthetic repository {ridx}, module {fidx}; unique workload parameters."""\n'
            for op in range(functions_per_file):
                unique=(ridx+1)*7919+(fidx+1)*101+op
                text+=f'\ndef bench_r{ridx:03d}_f{fidx:03d}_op{op}(value, scale=1.0):\n'
                text+=f'    """Deterministic transform family {unique}; not a production algorithm."""\n'
                text+=f'    adjusted = value * scale + {unique}\n    return adjusted / {op+2}.0\n'
            # CRLF and Unicode path coverage are independent of the source semantics.
            ending='\r\n' if fidx%9==0 else '\n'
            name=f'계산_{fidx:03d}.py' if fidx%11==0 else f'module_{fidx:03d}.py'
            (repo/'src'/name).write_bytes(text.replace('\n',ending).encode())
        if ridx%3==0:
            (repo/'src'/'jira_client.py').write_text(
                f'"""Synthetic Jira request adapter {ridx}; no real server."""\n'
                f'def query_issues_{ridx}(transport, jql):\n'
                '    return transport.get("/rest/api/2/search", params={"jql": jql})\n',encoding='utf-8')
        else:
            (repo/'docs').mkdir()
            (repo/'docs'/'unimplemented.md').write_text(f'Jira integration is NOT implemented in synthetic module {ridx}.\n',encoding='utf-8')
        (repo/'src'/'thermal.py').write_text(
            f'"""Synthetic thermal illustration {ridx}; not a calibrated SSD model."""\n'
            'def thermal_step(T, P, dt, C, R, Ta):\n'
            '    """Illustrative forward Euler thermal resistance model."""\n'
            '    return T + dt / C * (P - (T-Ta) / R)\n',encoding='utf-8')
        (repo/'tests'/'test_example.py').write_text(f'def test_placeholder_{ridx}():\n    assert {ridx} == {ridx}\n',encoding='utf-8')
        (repo/'.env').write_text('NOT_A_SECRET=EXCLUDED_FIXTURE\n',encoding='utf-8')
        sha=commit(repo,'generated benchmark baseline')
        paths=[p for p in repo.rglob('*') if p.is_file() and '.git' not in p.relative_to(repo).parts]
        source_bytes+=sum(p.stat().st_size for p in paths);tracked_files+=len(paths)
        records.append({'repo_id':rid,'path':str(repo),'initial_commit':sha})
    return records,source_bytes,tracked_files


def run_benchmark(work_dir,*,repositories=120,files_per_repo=40,functions_per_file=8,
                  query_repeats=12,embedding_dimensions=256):
    if not 4<=repositories<=1000 or not 1<=files_per_repo<=1000 or not 1<=functions_per_file<=100:
        raise ValueError('INVALID_BENCHMARK_SIZE')
    if not 2<=query_repeats<=200 or not 0<=embedding_dimensions<=4096:raise ValueError('INVALID_BENCHMARK_OPTIONS')
    root=Path(work_dir).resolve();root.mkdir(parents=True,exist_ok=True)
    source_digest=hashlib.sha256(b''.join(p.relative_to(ROOT).as_posix().encode()+p.read_bytes() for p in sorted((ROOT/'src').rglob('*.py')))).hexdigest()
    started=now();start=time.perf_counter()
    def progress(stage):print(json.dumps({'stage':stage,'elapsed_s':round(time.perf_counter()-start,3)}),file=sys.stderr,flush=True)
    progress('create_synthetic_git_repositories')
    records,source_bytes,tracked_files=create_corpus(root,repositories,files_per_repo,functions_per_file)
    creation_s=time.perf_counter()-start
    model=FixtureEmbedding(embedding_dimensions) if embedding_dimensions else None
    with Runtime(root/'runtime',settings=IndexSettings(chunk_chars=3000,embedding_batch_items=64)) as runtime:
        for item in records:runtime.register(item['repo_id'],path=item['path'])
        progress('initial_lexical_index')
        initial=runtime.update()
        progress('lexical_queries')
        if initial['failed']:raise AssertionError('INITIAL_BENCHMARK_INDEX_FAILURE')
        if any(git(Path(r['path']),'status','--porcelain') for r in records):raise AssertionError('INDEXER_MODIFIED_SOURCE')
        query_ids=sorted(set([0,repositories//3,repositories//2,repositories-1]))
        exact_queries=[f'bench_r{i:03d}_f000_op0' for i in query_ids]
        exact_correct=0;lexical_times=[];first_lexical=None;old_id=None;old_bytes=None
        for query in exact_queries:
            t=time.perf_counter();out=runtime.search(query,limit=5,depth='verified');elapsed=(time.perf_counter()-t)*1000
            if first_lexical is None:first_lexical=elapsed
            exact_correct+=any(r['symbol']==query for r in out['results'])
            if query==exact_queries[0]:
                old_id=next(r['evidence_id'] for r in out['results'] if r['symbol']==query)
                old_bytes=runtime.evidence(old_id)['text']
        for i in range(query_repeats):
            query=exact_queries[i%len(exact_queries)] if i%2==0 else '열저항 온도 수식'
            t=time.perf_counter();runtime.search(query,limit=10);lexical_times.append((time.perf_counter()-t)*1000)
        # File-based all search must not count docs-only mentions as API-use proof.
        progress('whole_file_scan')
        scan=runtime.scan(['/rest/api/2/search'],limit=500,max_seconds=600,max_matches=1000000)
        found=set(r['repo_id'] for r in scan['results']);cursor=scan['next_cursor']
        while cursor:
            page=runtime.scan(cursor=cursor,limit=500);found.update(r['repo_id'] for r in page['results']);cursor=page['next_cursor']
        expected={f'synthetic-{i:03d}' for i in range(repositories) if i%3==0}
        if not scan['coverage']['scope_scan_complete'] or found!=expected:raise AssertionError('ALL_SCAN_GOLD_MISMATCH')
        runtime.embedding=model
        progress('embedding_backfill_fixture_vectors')
        backfill=runtime.update() if model else None
        progress('hybrid_queries')
        if backfill and (backfill['failed'] or backfill['files_read']):raise AssertionError('VECTOR_BACKFILL_REPARSED_OR_FAILED')
        query_times=[];first_hybrid=None
        if model:
            dense_queries=['thermal resistance model','Jira search issue data','calculation transform scale','열저항 온도 수식']
            for i in range(query_repeats):
                query=dense_queries[i%len(dense_queries)]
                t=time.perf_counter();out=runtime.search(query,limit=10);elapsed=(time.perf_counter()-t)*1000
                if out['retrieval_mode']!='hybrid':raise AssertionError('HYBRID_PATH_NOT_USED')
                if first_hybrid is None:first_hybrid=elapsed
                query_times.append(elapsed)
        progress('no_op_update')
        no_op=runtime.update()
        if no_op['files_read'] or no_op['vectors_created']:raise AssertionError('NO_OP_RECOMPUTED')
        # Four different mutation kinds, the remaining 116 repos (default) remain unchanged.
        a=Path(records[0]['path']);target=a/'src'/'계산_000.py'
        target.rename(a/'src'/'renamed_same_bytes.py');commit(a,'rename without content changes')
        b=Path(records[1]['path']);target=b/'src'/'계산_000.py'
        target.write_bytes(target.read_bytes().replace(b'return adjusted / 2.0',b'return adjusted / 7.0',1));commit(b,'single expression change')
        c=Path(records[2]['path']);(c/'src'/'계산_000.py').unlink();commit(c,'delete source')
        d=Path(records[3]['path']);(d/'src'/'added.py').write_text('def newly_added_function():\n    return 9001\n',encoding='utf-8');commit(d,'add source')
        progress('mutation_update')
        mutation=runtime.update()
        if mutation['failed'] or mutation['changed']!=4:raise AssertionError('MUTATION_UPDATE_FAILURE')
        renamed=next(r for r in mutation['results'] if r['repo_id']==records[0]['repo_id'])
        if renamed['vectors_created']:raise AssertionError('RENAME_REEMBEDDED')
        old_valid=runtime.evidence(old_id)['text']==old_bytes
        stat=runtime.status()
        active_counts=runtime.store.one('''SELECT count(*) AS occurrences,sum(f.size) AS repeated_source_bytes
          FROM units u JOIN snapshot_files f ON f.parse_key=u.parse_key JOIN repositories r ON r.active_snapshot=f.snapshot_id WHERE f.status='indexed' ''')
        runtime.store.conn.execute('PRAGMA wal_checkpoint(TRUNCATE)')
        dbbytes=runtime.store.path.stat().st_size
        immutable=all(not git(Path(r['path']),'status','--porcelain') for r in records)
        stages={k:{a:b for a,b in value.items() if a!='results'} for k,value in [('initial',initial),('no_op',no_op),('mutation_update',mutation)]}
        if backfill:stages['embedding_backfill']={a:b for a,b in backfill.items() if a!='results'}
        progress('prepare_report')
        report={
          'schema_version':'1.0','runtime_source_digest':source_digest,'started_at':started,'finished_at':now(),'elapsed_seconds':time.perf_counter()-start,
          'corpus':{'provenance':'synthetic_local_git','repositories':repositories,'public_repositories':0,
                    'tracked_files':tracked_files,'source_bytes':source_bytes,'files_per_repo_base':files_per_repo,
                    'functions_per_base_file':functions_per_file,'unique_units_total':stat['units'],
                    'active_unit_occurrences':active_counts['occurrences'],'creation_seconds':creation_s},
          'environment':{'os':platform.platform(),'python':sys.version,'sqlite':sqlite3.sqlite_version,
                         'git':git(root,'--version'),'cpu_count':os.cpu_count(),
                         'openblas_num_threads':os.environ.get('OPENBLAS_NUM_THREADS','unset')},
          'embedding':{'kind':'deterministic_fixture_not_llm' if model else 'disabled','dimensions':embedding_dimensions,
                       'items':model.items if model else 0,'requests':model.requests if model else 0,
                       'actual_endpoint_latency_measured':False},
          'semantic_quality_measured':False,'timings':{'first_lexical_search_ms':first_lexical,
                    'warm_lexical_search_ms':percentiles(lexical_times),'first_hybrid_search_ms':first_hybrid,
                    'warm_search_ms':percentiles(query_times or lexical_times),'all_scan_ms':scan['coverage']['elapsed_ms']},
          'known_gold':{'exact_queries':len(exact_queries),'exact_hit_at_5':exact_correct/len(exact_queries),
                        'all_scan_expected_repositories':len(expected),'all_scan_found_repositories':len(found),
                        'all_scan_repo_recall':len(found & expected)/len(expected),
                        'note':'Known generated identities and literal API routes only; not natural-language semantic recall.'},
          'mutation':{'changed_repositories':mutation['changed'],'old_evidence_still_valid':old_valid,
                      'rename_vectors_created':renamed['vectors_created'],
                      'unchanged_vectors_reused':(mutation['vectors_reused']>0 if model else True)},
          'physical_source_directories_unchanged_by_indexer':immutable,
          'storage':{'database_bytes':dbbytes,'blob_cache_bytes':sum(p.stat().st_size for p in (root/'runtime'/'blobs').rglob('*') if p.is_file())},
          'limits':['Synthetic source distribution is not a substitute for 100 public or internal real-world repositories.',
                    'Warm timings include local SQLite and deterministic fixture embedding; no real model service latency.',
                    'No business API or generated repository code was executed.'],**stages}
        try:
            import resource
            report['environment']['process_peak_rss_kib']=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
            report['environment']['rss_unit_note']='Linux KiB; macOS reports bytes. Not full child process memory.'
        except ImportError:pass
    (root/'report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    return report


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--work-dir');p.add_argument('--output',required=True)
    p.add_argument('--repositories',type=int,default=120);p.add_argument('--files',type=int,default=40)
    p.add_argument('--functions',type=int,default=8);p.add_argument('--queries',type=int,default=12)
    p.add_argument('--dimensions',type=int,default=256)
    a=p.parse_args();work=a.work_dir or tempfile.mkdtemp(prefix='refs-synthetic-scale-')
    report=run_benchmark(work,repositories=a.repositories,files_per_repo=a.files,functions_per_file=a.functions,
                         query_repeats=a.queries,embedding_dimensions=a.dimensions)
    output=Path(a.output);output.parent.mkdir(parents=True,exist_ok=True)
    output.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'status':'completed','provenance':report['corpus']['provenance'],
                      'repositories':a.repositories,'report':str(output),'work_dir':work},ensure_ascii=False))

if __name__=='__main__':main()
