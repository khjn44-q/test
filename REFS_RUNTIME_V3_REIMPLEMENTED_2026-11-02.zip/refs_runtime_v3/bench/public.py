#!/usr/bin/env python3
"""Opt-in public Git ingestion experiment. Preflight-only by default; no code installation/execution.

The inventory is 100 candidate URLs, not a claim of successful public-repository evaluation.
With --execute, reads only the selected ref into a managed shallow Git cache. Source licenses
remain with each repository. Size/time policies can yield explicit partial results.
"""
from __future__ import annotations
import argparse,json,os,shutil,socket,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'src'))
from refs.config import load_config,open_runtime
from refs.store import now


def preflight(host,resolver=None):
    result={'host':host,'checked_at':now(),'status':'reachable_dns_only','reason':None,
            'git_repositories_attempted':0,'repositories_cloned':0}
    try:(resolver or socket.getaddrinfo)(host,443,type=socket.SOCK_STREAM)
    except OSError:result.update(status='blocked',reason='dns_resolution_failed')
    return result


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--inventory',default=str(ROOT/'bench'/'public_repositories.json'))
    p.add_argument('--output',required=True);p.add_argument('--config');p.add_argument('--home',required=True)
    p.add_argument('--execute',action='store_true');p.add_argument('--limit',type=int,default=100)
    p.add_argument('--minimum-free-gib',type=float,default=5)
    a=p.parse_args()
    if not 1<=a.limit<=1000:p.error('limit must be 1..1000')
    data=json.loads(Path(a.inventory).read_text(encoding='utf-8'));repos=data['repositories'][:a.limit]
    check=preflight('github.com')
    report={'experiment':'public_git_ingestion','started_at':now(),'requested_repositories':len(repos),
            'preflight':check,'status':'not_executed','git_repositories_attempted':0,'repositories_indexed':0,
            'semantic_quality_measured':False,'results':[]}
    if check['status']=='blocked':report.update(status='blocked',reason=check['reason'])
    elif not a.execute:report.update(status='preflight_only',reason='Pass --execute to allow remote Git reads.')
    else:
        config=load_config(a.config,a.home)
        with open_runtime(config) as runtime:
            for repo in repos:
                if not repo['url'].startswith('https://github.com/'):raise ValueError('public runner only accepts explicit github.com HTTPS candidates')
                if shutil.disk_usage(runtime.home).free<a.minimum_free_gib*1024**3:
                    report.update(status='partial',reason='disk_budget_before_next_repository');break
                runtime.register(**repo);report['git_repositories_attempted']+=1
                receipt=runtime.update([repo['repo_id']])
                report['results'].append(receipt)
                if receipt['failed']==0:report['repositories_indexed']+=1
                Path(a.output).parent.mkdir(parents=True,exist_ok=True)
                Path(a.output).write_text(json.dumps(report,indent=2),encoding='utf-8')
            else:report['status']='completed' if report['repositories_indexed']==len(repos) else 'partial'
            report['catalog_status']=runtime.status()
    report['finished_at']=now()
    report['limitations']=['No source code or package installation is executed.',
        'Successful ingestion is not a natural-language retrieval quality score.',
        'The disk budget is checked between repos, not a hard per-fetch OS disk quota.',
        'DNS-only success does not establish Git authorization or TLS availability.']
    output=Path(a.output);output.parent.mkdir(parents=True,exist_ok=True)
    output.write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({'status':report['status'],'attempted':report['git_repositories_attempted'],
                      'indexed':report['repositories_indexed'],'report':str(output)}))
    return 0 if report['status'] in {'completed','preflight_only'} else 4
if __name__=='__main__':raise SystemExit(main())
