# Execution ledger — docs/PLAN.md

## S0 완료
- 실제 파일 확인: 구 TypeScript 설계 ZIP 존재, 분실 Python runtime/ZIP 없음.
- 새 작업 디렉터리 refs_runtime_v3를 만들고 원본 설계 문서와 SHA256 보존.
- 사용자 허용 범위에 따라 별도 확인 대기 없이 inline 구현.
- 독립 subagent 없음. 자체 리뷰와 실제 테스트를 분리해 기록.
- Ruling: QMD/로컬 모델 필수 의존 제거, Python SQLite+사내 HTTP 모델. 사용자 자원 제약 반영.
- Ruling: 전체 DB 복제 대신 repo별 immutable snapshot mapping + SQLite transaction. 100+ repo update 비용 절약.
- Ruling: 공식 MCP SDK는 선택 의존. 설치 불가이면 core와 CLI 검증을 진행하되 SDK end-to-end는 미검증으로 남김.
- Network probe: github/raw/pypi DNS 실패 및 container download 실패. 공개 100개 clone은 현 시점 실행 불가; 실패 기록과 재현 스크립트 제공 예정.
- Preflight: source IDs → catalog → retrieval → analysis 인자를 아래 구현에서 통일. snapshot map은 session에 고정하고 enable/disable은 조회시 현재 조건 적용.

## S1 완료
- 25개 source/chunk/cache 테스트: red 25 실패 → green 25 통과.
- Git batch reader, blob OID와 내용 hash 검증, SHA-256 Git fixture, dirty tree 분리, UTF8/CRLF lossless chunk, Python AST 및 명시 text fallback 구현.
- 원본 git status 무변경 및 managed local fetch 동작을 실제 임시 Git으로 검사.

## S2 완료
- 19개 실제 loopback HTTP provider 계약 시험 추가, 누적 44 통과.
- 배치·응답 index 정렬·L2 정규화·NaN/zero/dimension 거부·429 제한 retry·400 미재시도·redirect 거부·응답 크기·환경변수 인증 검사.
- 실제 사내 모델 품질 시험은 아님. 테스트 서버는 고정 vector/chat 응답으로 통신 계약만 검증.

## S3 완료
- 17개 인덱싱·snapshot·writer 회귀 추가, 누적 61 통과.
- SQLite FTS5/immutable snapshots/shared parse & vector cache, repo별 atomic pointer publication.
- no-op 0 reads/reembed, rename vector 재사용, 삭제/신규파일, 모델 장애·SQL abort rollback, 모델 space 변경, disabled scope, 실제 managed Git fetch를 검증.
- 일부 repo 실패는 partial receipt로 남기고 나머지 repo를 계속 처리한다. 전사 동시 스냅샷처럼 표시하지 않는다.

## S4 완료
- 검색/전체스캔/세션/근거/trace/diff 23개 추가, 누적 84 통과.
- query embedding 캐시, bounded-memory dense exact scan, exact/FTS/vector RRF, Korean aliases(embedding 품질 아님).
- full-file literal scan + HMAC cursor + partial budget 상태. Python syntax callsite와 target 해석 수준을 구분.
- 고정 session 검색, update 후 이전 evidence, disable 후 이전 evidence 접근 차단 확인.

## S5 완료
- LLM 분석·정확 인용·요약·재사용 계획 18개 추가, 누적 102 통과.
- 모델이 임의 evidence/quote/authority를 만드는 경우 거부. 인용 검증은 의미적 entailment 검증과 구분.
- 긴 source를 불변 span으로 분할, 호출 예산 미달은 partial. 요약 vector 실패 시 검증된 내용을 보존하고 다음 호출에서 embedding만 재시도.
- 원문과 생성 노트 둘 다 lexical/dense 후보 경로에 연결. cross-repo 노트는 모든 dependency scope를 충족해야 표시.
- Ruling: 생성 노트 invalidation은 현재 source repo tree 단위로 보수적으로 적용한다. 미해석 helper/config 변경을 놓치지 않기 위함이며, 미세 dependency 최적화는 현장 평가 후 가능.
- S5 초기 2개 실패는 테스트 fixture가 huge 함수 대신 step 테스트를 선택한 문제였다. 선택 근거를 바로잡은 후 분할/partial 조건을 검증했다.

## S6 완료
- CLI subprocess/공통 tool dispatcher/config/명시 resume 12개 검사 추가. 누적 114 통과, 공식 MCP SDK 통합 1개 skip.
- CLI는 JSON stdout, 오류 분리, 모델 probe 명시 실행, repo 목록 import·상태·update/rebuild·검색·전체스캔·근거·분석·요약·사용계획 제공.
- stdio MCP 어댑터는 공식 SDK v2의 MCPServer API를 사용한다. SDK 설치 불가로 실제 protocol integration은 미검증이며 자체 JSON-RPC로 대체하지 않았다.
- Ruling: 공개 SDK v2 문서를 기준으로 optional dependency를 mcp>=2,<3로 변경. 회사 승인 버전의 API가 다르면 mcp_server.py 한 파일에서만 조정.

## S7 규모 시험 및 효율 보완
- 120개 합성 **실제 local Git 저장소**, 5,400 tracked files(약 7.5MB), 약 77,440 source units를 생성하여 index/search/scan/update 실행. 실제 공개 Git 120개가 아니다.
- 최초 시도에서 다중 snapshot IN 조건이 각 FTS 후보마다 120개 index probe를 만드는 SQL 병목 발견. SQLite VM budget regression을 red→green으로 추가하고 membership 조건을 pre-limit filter로 유지하면서 반복 probe 제거.
- dense scan은 모든 후보의 전체 코드 text를 읽는 대신 얇은 vector/identity row를 읽고 상위 후보만 본문 조회. chunk byte map은 array로 메모리 절감.
- stale note가 top-k를 먼저 점유하던 문제: all-of source tree 조건을 LIMIT 전 적용. note vector stream 메모리도 bounded 처리.
- LLM output config fingerprint, 전체 scan 제외 범위, all scan 후속 pinned session, unindexed scope partial 처리 추가.
- strong exact identifier hit는 모델 네트워크와 dense scan 생략. summaries_only profile은 원문 lexical/whole-file 검색을 유지하며 raw dense만 비활성화. 기본 all_text 유지.
- managed fetch는 기본 depth=1로 전체 history 다운로드 방지(원본 변경 없음). 최초 large-blob 다운로드의 hard disk quota까지 보장하지 않는다.
- LLM 분석 응답은 full source를 반복 전송하지 않고 references+quote 중심 반환; LLM 미설정은 실제 source context pack 제공.
- 공개 100개 후보 목록과 opt-in 실행기를 제공. 실제 DNS probe 실패로 public100 execution은 blocked/attempted=0/indexed=0. 합성 시험으로 대체 성공이라고 주장하지 않음.
- 초기 scale 실행 2개는 도구 실행 제한/병목으로 중단되었다. 부분 DB/중간 receipt는 최종 성공 증거가 아니다. 이후 run_recorded wrapper로 실제 완료와 exit code를 기록했다.
- 진행 중 짧은 loopback/contract suite와 최초 scale 준비가 겹쳤다. 최종 benchmark는 단독 재실행하여 기록할 계획.

## S8 시작
- 백업은 SQLite backup API와 참조 blob hash 검증으로 수행. 살아 있는 WAL 파일의 일반 복사는 하지 않는다.
- 코드 전체·설정 예시·설계·현장 tuning/handoff·개별 지원 한계·패키지 무결성을 새 ZIP에 포함한다.
- S8 중간 리뷰: update --summarize에서 LLM 미설정/실패가 전체 성공 exit 0으로 보이던 문제를 regression으로 재현하고 index_state와 overall partial을 분리. 명시 doctor probe 실패도 partial 처리.
- S8 자체 리뷰에서 MCP wrapper의 locals()가 closure 변수 call까지 인자로 전달하는 결함을 발견. 실제 Runtime+registry-only test로 실패를 재현하고 모든 wrapper를 명시 인자 dict로 교체했다. 이 unit test는 공식 MCP protocol/client 통합 시험을 대신하지 않는다.

## S8 최종 로컬 검증
- release-suite: 142 passed / 1 skipped / exit0, 실제 부모 process line coverage86% 수준. subprocess CLI 미계측이며 제품 완성률이 아니다.
- 최종 scale120-final 단독 재실행 exit0, source digest 일치. 120repo/5,400files/7.5MB/77,440initial units, 모의1024d. 공개100 DNS blocked 별도.
- 새 venv에 배포 wheel을 `--no-index --no-deps`로 설치 후 source folder/PYTHONPATH 없는 CLI 실행. 고정 원문·dirty tree·no-op·commit update·옛 evidence·scan·reuse plan 통과.
- 실제 source와 wheel 모든 Python module bytes를 비교하는 회귀 추가. docs 링크·config loader·DDL도 검사.
- 현장 튜닝/모델 어댑터/하네스/보안·운영/100+ 실자료 인수 기준을 문서화. Skill은 초안으로만 표기.
- 다음: 후보 ZIP 추출·설치 검사 후 최종 manifest/CRC/sha 재검증하여 ZIP 하나만 전달한다.
- 후보 ZIP 실제 생성→163개 파일 CRC/sha 검사→새 폴더 추출→추출 wheel을 또 다른 clean venv에 offline설치→21개 CLI/Git 명령 exit0 검증 완료. candidate-extracted-install.json에 기록.
- ZIP 전달은 현재 실재하는 새 이름을 사용한다. 최종 ZIP hash는 self-reference를 피하기 위해 ZIP 밖 최종검사 결과로 확인한다.
