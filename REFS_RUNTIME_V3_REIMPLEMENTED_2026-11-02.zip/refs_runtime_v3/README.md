# REFS Runtime 0.3 — 사내 Git 기술 자산 검색·원문·재사용

**새 재구현이다. 분실된 이전 구현을 복구한 파일이 아니다.** 이전 설계의 요구를 유지하되 Python·SQLite·사내 모델 서비스에 맞춰 다시 작성했다.

100개 이상 읽기 전용 Git에서 관련 함수·문서·수식·사용법을 찾고, 고정 커밋의 원문으로 내려가며, 기존 코딩 하네스가 활용하도록 근거를 제공한다. UI·QMD·별도 DB 서버·로컬 모델 다운로드가 필요하지 않다.

## 먼저 볼 파일

1. [HANDOFF_KO.md](HANDOFF_KO.md): 설치·사내 환경 연결·미완료 경계.
2. [docs/DESIGN.md](docs/DESIGN.md): 현재 설계. `provenance/`의 옛 TypeScript/QMD 안보다 우선한다.
3. [docs/PLAN.md](docs/PLAN.md), [WORKLOG.md](WORKLOG.md): 작업 순서와 실제 실행 기록.
4. [verification/FINAL_REPORT.md](verification/FINAL_REPORT.md): 실행 증거, 120개 합성 Git 실험, 공개 100개 실험의 차단 상태.
5. [docs/IMPLEMENTATION_STATUS.md](docs/IMPLEMENTATION_STATUS.md), [docs/PERFORMANCE.md](docs/PERFORMANCE.md): 구현/미지원 경계와 규모 측정.
6. [docs/TUNING_GUIDE.md](docs/TUNING_GUIDE.md): 사내 LLM/개발자가 조정할 값과 검증 기준.

## 제공하는 것과 제공하지 않는 것

| 제공 | 경계 |
|---|---|
| 커밋 고정 Git 객체 읽기·원문 hash 검증 | 원본 checkout 수정/push 없음 |
| SQLite FTS5, 정확 식별자, 선택적 dense 검색 | dense는 exact scan; 대규모 ANN 서비스 아님 |
| 수동 전체/개별 증분 갱신, 무변경·rename cache | repo별 원자 게시; 전사 동시 시점 transaction 아님 |
| 전체 파일 literal/detector 조사와 pagination | 의미상 전사 모든 사용처 발견을 증명하지 않음 |
| Python AST, 다른 텍스트 언어 fallback | 전언어 타입 해석/완전 호출 그래프 없음 |
| 사내 LLM 근거 기반 요약·분석·수식 표현 | 인용 검사는 의미·물리 정확성 인증이 아님 |
| CLI + 공식 SDK v2용 MCP 어댑터 | MCP SDK 실연동은 이 환경에서 미검증 |
| 재사용 계획과 entrypoint/의존성/테스트 후보 | API 직접 실행·임의 셸·패키지 설치는 하네스 책임 |
| 사용자별 로컬 설치 | 중앙 다중 사용자 ACL/SSO 없음 |

**LLM은 읽을 수 있는 요약을 생성한다. 임베딩 모델은 요약/원문을 검색용 벡터로 만든다.** 둘을 동일 기능으로 취급하지 않는다.

## 빠른 시작: 외부 접속 없는 설치

Python 3.11+ 및 Git이 필요하다. 먼저 압축을 푼 폴더에서 실행한다.

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install --no-index --no-deps .\dist\engineering_refs-0.3.0-py3-none-any.whl
.\.venv\Scripts\python.exe -m refs --home F:\REFS_DATA doctor
.\.venv\Scripts\python.exe -m refs init-config --output refs.local.json
```

Linux에서는 `.venv/bin/python`을 사용한다. 활성화 스크립트나 PowerShell execution policy 변경은 필수가 아니다. 모델을 설정하지 않아도 Git·문자열 검색·원문·전체 스캔은 동작한다. 의미 검색이나 LLM 요약을 수행했다고 표시하지 않는다.

회사 Git 목록을 `examples/repos.example.json` 형식으로 작성한 뒤:

```powershell
.\.venv\Scripts\python.exe -m refs --config refs.local.json repo import repos.company.json
.\.venv\Scripts\python.exe -m refs --config refs.local.json update --all
.\.venv\Scripts\python.exe -m refs --config refs.local.json search "Jira 이슈 조회" --depth verified
.\.venv\Scripts\python.exe -m refs --config refs.local.json scan --detector jira --limit 50
```

`refs.local.json`의 home은 **프로그램 폴더와 별도의 데이터 폴더**로 지정한다. private index·토큰·회사 주소를 공개 GitHub에 commit하지 않는다.

## 모델을 연결한 권장 최초 처리

[모델 연결 계약](docs/MODEL_ADAPTERS.md)을 읽고 회사 endpoint/model/revision/dimensions/인증 환경변수를 채운다.

```text
refs --config refs.company.json doctor --probe-models
refs --config refs.company.json update --all --summarize
refs --config refs.company.json search "SSD 열저항 기반 온도 계산" --depth verified
refs --config refs.company.json evidence <실제 반환된 evidence_id>
refs --config refs.company.json analyze "이산식, 단위, 초기조건과 모르는 점을 설명" --evidence <실제 ID>
```

대량 원문 벡터화 비용이 크면 `index.embedding_scope = "summaries_only"`를 평가한다. raw lexical·전체 스캔은 그대로 남고 원문 dense만 생략한다. 기본값 `all_text`를 무조건 바꾸라는 뜻은 아니다.

## 시험/실험

```text
python -m pytest -q
python bench/scale.py --repositories 120 --files 40 --functions 8 --dimensions 1024 --queries 12 --output scale.json
python bench/public.py --home ./public-experiment --output public.json
```

마지막 명령은 preflight만 한다. 실제 공개 Git 읽기를 허용할 때 `--execute`를 붙인다. `bench/public_repositories.json`은 **100개 미검증 후보 URL 목록**이며 다운로드 성공 목록이 아니다. 이 환경에서는 DNS 제한으로 공개100 실험이 차단되었다.

## 배포 검증

```text
python scripts/verify_bundle.py <전달받은 ZIP 경로>
```

이 검사는 ZIP CRC, 경로 안전성, 모든 파일의 SHA-256/크기, 누락·추가 파일을 확인한다. 라이브러리 의미 정확성·기업 보안 승인을 대신하지 않는다.
