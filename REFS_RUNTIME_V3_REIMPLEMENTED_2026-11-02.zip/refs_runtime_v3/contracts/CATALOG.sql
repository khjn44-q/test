-- Generated from src/refs/store.py SCHEMA; schema user_version=1.
CREATE TABLE meta(key TEXT PRIMARY KEY,value TEXT NOT NULL);
CREATE TABLE repositories(
 repo_id TEXT PRIMARY KEY,location TEXT NOT NULL,source_kind TEXT NOT NULL CHECK(source_kind IN ('local','remote')),
 ref TEXT NOT NULL,web_url TEXT NOT NULL DEFAULT '',allow_local_remote INTEGER NOT NULL DEFAULT 0,
 enabled INTEGER NOT NULL DEFAULT 1 CHECK(enabled IN (0,1)),active_snapshot TEXT,
 last_check TEXT,last_error TEXT);
CREATE TABLE snapshots(
 snapshot_id TEXT PRIMARY KEY,repo_id TEXT NOT NULL REFERENCES repositories(repo_id),
 commit_oid TEXT NOT NULL,pipeline_fp TEXT NOT NULL,tree_digest TEXT NOT NULL,
 created_at TEXT NOT NULL,coverage_json TEXT NOT NULL);
CREATE TABLE parses(parse_key TEXT PRIMARY KEY,content_hash TEXT NOT NULL,parser TEXT NOT NULL,
 relations_json TEXT NOT NULL,warnings_json TEXT NOT NULL);
CREATE TABLE units(
 rowid INTEGER PRIMARY KEY,unit_id TEXT NOT NULL UNIQUE,parse_key TEXT NOT NULL REFERENCES parses(parse_key),
 ordinal INTEGER NOT NULL,byte_start INTEGER NOT NULL,byte_end INTEGER NOT NULL,
 line_start INTEGER NOT NULL,line_end INTEGER NOT NULL,symbol TEXT NOT NULL,kind TEXT NOT NULL,
 resolution TEXT NOT NULL,text TEXT NOT NULL,search_text TEXT NOT NULL,payload TEXT NOT NULL,input_hash TEXT NOT NULL,
 CHECK(byte_start>=0 AND byte_end>=byte_start),CHECK(line_start>=1 AND line_end>=line_start),
 UNIQUE(parse_key,ordinal));
CREATE INDEX unit_parse ON units(parse_key);
CREATE INDEX unit_symbol ON units(symbol);
CREATE VIRTUAL TABLE units_fts USING fts5(symbol,search_text,content='units',content_rowid='rowid',tokenize='unicode61 remove_diacritics 2');
CREATE TRIGGER unit_ai AFTER INSERT ON units BEGIN INSERT INTO units_fts(rowid,symbol,search_text) VALUES(new.rowid,new.symbol,new.search_text); END;
CREATE TRIGGER unit_ad AFTER DELETE ON units BEGIN INSERT INTO units_fts(units_fts,rowid,symbol,search_text) VALUES('delete',old.rowid,old.symbol,old.search_text); END;
CREATE TABLE snapshot_files(
 snapshot_id TEXT NOT NULL REFERENCES snapshots(snapshot_id),path TEXT NOT NULL,
 git_oid TEXT NOT NULL,content_hash TEXT,parse_key TEXT REFERENCES parses(parse_key),
 size INTEGER NOT NULL,mode TEXT NOT NULL,status TEXT NOT NULL,reason TEXT NOT NULL,
 PRIMARY KEY(snapshot_id,path));
CREATE INDEX file_parse ON snapshot_files(parse_key,snapshot_id);
CREATE TABLE cards(rowid INTEGER PRIMARY KEY,snapshot_id TEXT NOT NULL UNIQUE REFERENCES snapshots(snapshot_id),
 repo_id TEXT NOT NULL,body TEXT NOT NULL,evidence_paths_json TEXT NOT NULL);
CREATE VIRTUAL TABLE cards_fts USING fts5(body,content='cards',content_rowid='rowid');
CREATE TRIGGER cards_ai AFTER INSERT ON cards BEGIN INSERT INTO cards_fts(rowid,body) VALUES(new.rowid,new.body); END;
CREATE TABLE embeddings(space TEXT NOT NULL,role TEXT NOT NULL,input_hash TEXT NOT NULL,
 dimensions INTEGER NOT NULL,vector BLOB NOT NULL,created_at TEXT NOT NULL,
 PRIMARY KEY(space,role,input_hash));
CREATE TABLE evidence(
 evidence_id TEXT PRIMARY KEY,repo_id TEXT NOT NULL REFERENCES repositories(repo_id),
 snapshot_id TEXT NOT NULL REFERENCES snapshots(snapshot_id),path TEXT NOT NULL,
 unit_id TEXT,content_hash TEXT NOT NULL,git_oid TEXT NOT NULL,
 byte_start INTEGER NOT NULL,byte_end INTEGER NOT NULL,line_start INTEGER NOT NULL,line_end INTEGER NOT NULL,
 created_at TEXT NOT NULL);
CREATE INDEX evidence_snapshot ON evidence(snapshot_id,path);
CREATE TABLE sessions(session_id TEXT PRIMARY KEY,query TEXT NOT NULL,snapshots_json TEXT NOT NULL,
 results_json TEXT NOT NULL,created_at TEXT NOT NULL,expires_at REAL NOT NULL);
CREATE TABLE notes(rowid INTEGER PRIMARY KEY,note_id TEXT NOT NULL UNIQUE,repo_id TEXT NOT NULL,
 snapshot_id TEXT NOT NULL,kind TEXT NOT NULL,question TEXT NOT NULL,body TEXT NOT NULL,
 payload_json TEXT NOT NULL,evidence_json TEXT NOT NULL,dependencies_json TEXT NOT NULL,
 model_fp TEXT NOT NULL,state TEXT NOT NULL CHECK(state IN ('active','stale')),
 input_hash TEXT NOT NULL,created_at TEXT NOT NULL);
CREATE VIRTUAL TABLE notes_fts USING fts5(body,content='notes',content_rowid='rowid');
CREATE TRIGGER notes_ai AFTER INSERT ON notes BEGIN INSERT INTO notes_fts(rowid,body) VALUES(new.rowid,new.body); END;
CREATE TABLE note_repositories(note_id TEXT NOT NULL,repo_id TEXT NOT NULL,PRIMARY KEY(note_id,repo_id));
CREATE INDEX notes_by_repo ON note_repositories(repo_id);
CREATE TABLE note_embeddings(note_id TEXT NOT NULL,space TEXT NOT NULL,input_hash TEXT NOT NULL,PRIMARY KEY(note_id,space,input_hash));
CREATE TABLE jobs(job_id TEXT PRIMARY KEY,state TEXT NOT NULL,started_at TEXT NOT NULL,finished_at TEXT,
 repos_json TEXT NOT NULL,result_json TEXT NOT NULL,cancel_requested INTEGER NOT NULL DEFAULT 0);
CREATE TABLE scan_runs(scan_id TEXT PRIMARY KEY,scope_json TEXT NOT NULL,patterns_json TEXT NOT NULL,
 state TEXT NOT NULL,coverage_json TEXT NOT NULL,created_at TEXT NOT NULL);
CREATE TABLE scan_matches(scan_id TEXT NOT NULL REFERENCES scan_runs(scan_id),position INTEGER NOT NULL,
 repo_id TEXT NOT NULL,evidence_id TEXT NOT NULL,payload_json TEXT NOT NULL,PRIMARY KEY(scan_id,position));
