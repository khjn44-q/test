# REFS Runtime API / CLI / MCP 계약

버전: Python package 0.3.0, wire `schema_version="3.0"`, config schema_version=3, SQLite user_version=1. 서로 다른 버전 축이다. 의미 변경 시 wire와 문서를 갱신한다.

## 공통 규칙

- 기본 API는 `Runtime(home, embedding=None, llm=None, settings=IndexSettings())` context manager다.
- config global 인자는 CLI 하위 명령 **앞**에 둔다. `python -m refs --config file.json search "질문"`.
- stdout JSON 1개, help는 text. 비밀이 포함될 수 있는 exception 본문은 출력하지 않는다.
- exit0 완료/정상 no_match, exit4 partial/cancelled, exit2 주로 잘못된 입력·설정·도메인 오류, exit5 시스템 오류, exit130 중단. state/status/warnings를 함께 읽는다.
- 빈 결과와 실패는 다르다. unindexed repo가 있으면 검색은 partial이다. 모델 실패의 lexical fallback은 mode/warnings에 남는다.
- CLI/MCP가 공통 core를 사용한다. stdio 요청 스키마는 공식 SDK가 tool signature에서 만든다.

## 메서드와 도구

| Python Runtime | CLI | MCP/dispatcher |
|---|---|---|
| register(id,path=... 또는 url=...,ref='HEAD',web_url='') | repo add / repo import | 인덱스 운영은 기본 CLI |
| set_enabled(id,bool) | repo enable / disable | 기본 미노출 |
| update(repo_ids=None,fetch=True,rebuild=False,plan=False) | update / rebuild | refs_update (명시 enable 시) |
| search(query,repo_ids=None,session_id=None,limit=10,depth='fast') | search (ranked) | refs_search는 find wrapper 사용 |
| find(query,breadth='ranked',depth='fast',...) | search --breadth ... --depth ... | refs_search |
| scan(patterns=None,detector=None,...,cursor=None,limit=50) | scan | refs_scan |
| evidence(id,start_line=None,line_limit=120,start_byte=None,max_chars=16000) | evidence | refs_read_evidence |
| trace(id,direction='out',limit=100) | trace | refs_trace |
| compare(a,b,max_chars=32000) | compare | refs_compare |
| analyze(question,evidence_ids,max_sources=32,max_model_calls=8) | analyze | refs_analyze |
| summarize(repo_id,max_sources=24,max_model_calls=8) | summarize | refs_summarize |
| prepare_use(evidence_id,goal='...') | prepare-use | refs_prepare_use |
| status() | status | refs_index_status |

`call` 예: `refs --config cfg.json call refs_search --args '{"query":"Jira 조회","depth":"verified"}'`. PowerShell/쉘별 quoting은 해당 shell에 맞게 한다. 비밀 payload를 argv에 넣지 않는다.

## SearchResponse

fields: status(ok/no_match/partial), retrieval_mode(lexical_only/lexical_fallback/hybrid/exact_identifier), session_id,parent_session_id,manifest_id,depth,breadth,query_terms,coverage,freshness,warnings,timings_ms,results.

각 결과: repo_id,snapshot_id,commit,path,symbol,kind,unit_id,evidence_id,evidence_ids,record_type(source/knowledge),note_id,snippet,score,ranks,verification,resolution,exact_identifier,source_url,execution_verified=false,semantic_entailment=not_verified.

RRF score는 정렬 신호이며 성공 확률·신뢰도 %가 아니다. verified는 원문 bytes를 확인하는 것이지 코드의 모든 기능을 실행 검증한 것이 아니다. 생성 note의 quote validation과 의미 entailment는 구분한다.

ranked 후보 cap은 bounded이며 exhaustive로 쓰면 안 된다. exact identifier hit는 semantic 호출 없이 반환 가능하다. `embedding_scope=summaries_only`는 raw dense를 생략하지만 raw lexical/scan은 유지한다.

## Whole-file ScanResponse

literal patterns(최대64개, 각512자) 또는 detector=jira/thermal. 사용자 regex 실행이 아니라 escaped literal의 case-insensitive matching이다. 중복 pattern(span)은 한 match로 묶는다.

run 결과: scan_id,session_id,manifest_id,patterns,total_matches,results,coverage,next_cursor,freshness. cursor는 run+offset HMAC이며 다음 page 요청은 patterns/scope/session을 다시 전달하지 않는다.

coverage: tracked_files,excluded_files,excluded_reasons,eligible_files/scanned_files,eligible_bytes/scanned_bytes/read_bytes,failed_files,registered_in_scope,indexed_repositories,scope_scan_complete,semantic_completeness=not_proven,stopped_reason.

scope는 indexed eligible text only. LFS/바이너리/제외·미지원 encoding 범위가 포함됐다고 말하지 않는다. 기본 budget 100000 matches/120초/1GiB 읽기. budget 초과는 partial, 결과를 잃지 않게 저장한 페이지까지 읽는다. budget으로 중단된 scan의 나머지 파일 checkpoint-resume은 아직 없다. 새로운 scan에 더 적절한 scope/budget을 지정해야 한다.

`find(...breadth='all')`은 Jira 질문은 내장 detector, 나머지는 추출한 literal terms를 사용한다. 자연어만으로 모든 도메인의 완벽한 scanner를 자동 생성하지 않는다. 정확한 전체 질문에는 명시 patterns를 선호한다.

## EvidenceResponse

commit,path,git_blob_oid,content_sha256,evidence_byte_start/end,evidence_line_start/end,returned_byte_start/end,returned_line_start/end,total_lines,text,verification=bytes_verified,is_active_snapshot,truncated,next_byte,next_start_line,source_url.

byte span은 UTF8 원문 기준 [start,end), line은1-based inclusive. CRLF/BOM을 보존한다. 전체 파일/후속 범위는 returned bounds를 사용한다. cached hash와 Git blob header 포함 OID를 검증한다. 권한(현재 local enable 상태)을 출력 직전에 재검사한다.

## AnalyzeResponse

LLM 없으면 mode=context_only, source_payload=full_context, 실제 원문 pack, claims=[]이며 LLM 해석을 했다고 말하지 않는다.

LLM 있으면 mode=llm_grounded, source_payload=references_only, sources에는 ID/path/commit/repo/characters만 포함한다. 원문은 evidence 도구로 읽는다. claims에는 정확 quote와 근거ID, epistemic, optional details, reference_validation, semantic_entailment, execution_verified=false가 있다.

coverage는 요청 source,선택 source,omitted,분할part,전송 character,model calls를 보여준다. 유효 JSON/quote가 실패하면 근거 없는 결과를 저장하지 않는다. note embedding만 실패하면 유효 analysis를 보존하고 NOTE_EMBEDDING_PENDING을 반환한다. 동일 분석 재요청에서는 LLM 재호출 없이 embedding만 재시도할 수 있다.

## Deep의 한계와 이어가기

`find(depth='deep')`은 첫 결과에서 최대8 evidence·4model calls까지 해석한다. 나머지가 있으면 partial/deep_coverage/경고를 명시한다. 자동으로 모든 저장소에 무제한 에이전트를 돌리지 않는다. 더 깊은 탐색은 scan pagination→evidence/trace→analyze를 선택적으로 반복한다. 하네스는 이미 요청된 all/deep을 중간 FAST 응답에서 끝내지 않되, 남은 budget을 숨기지 않는다.

## Update와 resume

update --all: 모든 enabled repo의 지정 ref 확인 후 변경만 처리. no-op은 source read/reparse/reembed 0. 모델 space가 새로 생기면 source 재파싱 없이 vector backfill.

rebuild: 원문 재확인/재분할 시도와 vector 재생성. 같은 parser fingerprint의 immutable parse 객체는 재사용할 수 있다. parser 의미가 바뀌면 반드시 PARSER_VERSION을 바꾼다. rebuild만으로 같은 version의 과거 원문 계약을 덮어쓰지 않는다.

`update --resume <job>`은 성공 repo를 건너뛰고 실패/미처리 repo의 **현재 ref를 다시 resolve**한다. 과거 head를 그대로 replay하는 의미가 아니다. job에 프로세스가 실제 살아 있는지는 OS에서 확인한다. kill -9 후 DB의 running은 실행 증명이 아니다.

## 데이터베이스 계약

[CATALOG.sql](CATALOG.sql)은 현재 Store.SCHEMA에서 추출한 참고 DDL이다. runtime migration의 정본은 store.py다. SQL은 hash 관계/모델 entailment/회사 ACL을 자동 증명하지 않는다. notes/sessions/history는 private 운영 데이터이고 자동 GC는 후속 작업이다.
