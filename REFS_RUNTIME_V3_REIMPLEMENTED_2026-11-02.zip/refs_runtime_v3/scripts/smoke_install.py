#!/usr/bin/env python3
"""Install the bundled wheel into a fresh venv and exercise CLI without source-tree imports.

Creates only a new temporary directory (or a user-selected nonexistent directory).
Uses a synthetic local Git repository; never downloads packages or runs indexed source.
"""
from __future__ import annotations
import argparse,hashlib,json,os,platform,subprocess,sys,tempfile,time,venv
from pathlib import Path

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--wheel',required=True);p.add_argument('--output',required=True);p.add_argument('--work-dir')
    a=p.parse_args();wheel=Path(a.wheel).resolve();output=Path(a.output).resolve()
    if not wheel.is_file():raise FileNotFoundError(wheel)
    if a.work_dir:
        work=Path(a.work_dir).resolve();work.mkdir(parents=True,exist_ok=False)
    else:work=Path(tempfile.mkdtemp(prefix='refs-wheel-smoke-'))
    env=dict(os.environ);env.pop('PYTHONPATH',None);env.pop('PYTHONHOME',None)
    env.update(PIP_NO_INDEX='1',PIP_DISABLE_PIP_VERSION_CHECK='1',GIT_CONFIG_GLOBAL=os.devnull,GIT_CONFIG_NOSYSTEM='1',GIT_TERMINAL_PROMPT='0')
    commands=[];start=time.perf_counter()
    result={'status':'running','wheel_sha256':hashlib.sha256(wheel.read_bytes()).hexdigest(),'platform':platform.platform(),
            'python':sys.version,'work_dir':str(work),'commands':commands,'network_packages_downloaded':False,
            'scope':'fresh-venv CLI and synthetic Git only; no real model/MCP/Windows claim'}
    def run(argv,expected=0,cwd=None):
        cp=subprocess.run([str(x) for x in argv],cwd=cwd or work,env=env,capture_output=True,text=True,encoding='utf-8',timeout=120)
        commands.append({'argv':[str(x) for x in argv],'returncode':cp.returncode,'stdout':cp.stdout,'stderr':cp.stderr})
        if cp.returncode!=expected:raise AssertionError('COMMAND_FAILED: '+str(argv[0]))
        return cp.stdout
    try:
        venv.EnvBuilder(with_pip=True).create(work/'venv')
        python=work/'venv'/('Scripts/python.exe' if os.name=='nt' else 'bin/python')
        run([python,'-m','pip','install','--no-index','--no-deps',wheel])
        installed=json.loads(run([python,'-c','import refs,sys,json;print(json.dumps({"module":refs.__file__,"prefix":sys.prefix}))']))
        if not Path(installed['module']).resolve().is_relative_to(work/'venv'):raise AssertionError('SOURCE_TREE_IMPORT_LEAK')
        result['installed_module']=installed['module']
        repo=work/'synthetic-repo';repo.mkdir()
        def git(*args):return run(['git','-c','core.hooksPath='+os.devnull,'-C',repo,*args])
        git('init','-q','-b','main')
        source=repo/'열 계산.py';source.write_bytes(b'def stable_formula(T, P, dt, C):\r\n    return T + P * dt / C\r\n')
        git('add','-A');git('-c','user.name=REFS Smoke','-c','user.email=smoke@example.invalid','commit','-q','-m','baseline')
        def refs(*args,expected=0):return json.loads(run([python,'-m','refs','--home',work/'data',*args],expected))
        refs('doctor');refs('repo','add','smoke','--path',repo);first=refs('update','--all')
        assert first['changed']==1
        hits=refs('search','stable_formula','--depth','verified');eid=hits['results'][0]['evidence_id']
        original=refs('evidence',eid)['text'];assert 'P * dt / C' in original
        source.write_text('def stable_formula(T, P, dt, C):\n    return 999\n',encoding='utf-8')
        assert refs('evidence',eid)['text']==original
        noop=refs('update','--all');assert noop['files_read']==0 and noop['vectors_created']==0
        git('add','-A');git('-c','user.name=REFS Smoke','-c','user.email=smoke@example.invalid','commit','-q','-m','changed')
        changed=refs('update','--all');assert changed['changed']==1
        newer=refs('search','stable_formula','--depth','verified')['results'][0]['evidence_id']
        assert newer!=eid and '999' in refs('evidence',newer)['text']
        assert refs('evidence',eid)['text']==original
        scan=refs('scan','--pattern','return 999');assert scan['total_matches']==1 and scan['coverage']['scope_scan_complete']
        prep=refs('prepare-use',newer);assert prep['execution_performed'] is False
        assert git('status','--porcelain').strip()==''
        result.update(status='passed',checks={'isolated_wheel_import':True,'offline_install':True,'git_index':True,
            'pinned_dirty_tree':True,'no_op_zero_read':True,'incremental_commit':True,'old_evidence_preserved':True,
            'whole_file_scan':True,'reuse_plan_no_execution':True,'source_tree_clean':True})
    except Exception as error:
        result.update(status='failed',error_type=type(error).__name__,error=str(error))
    result.update(duration_seconds=time.perf_counter()-start)
    output.parent.mkdir(parents=True,exist_ok=True);output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'status':result['status'],'report':str(output),'commands':len(commands)}));return 0 if result['status']=='passed' else 1
if __name__=='__main__':raise SystemExit(main())
