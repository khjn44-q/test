#!/usr/bin/env python3
"""Consistent catalog + referenced immutable blobs backup; original Git is never changed.

Run with the updater stopped. Destination must not exist. Backups contain private source
and embeddings and require the same protection as the index. No tokens are exported.
Managed Git fetch cache/config are not bundled; they are rebuildable/environment-specific.
"""
from __future__ import annotations
import argparse,hashlib,json,os,sqlite3,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path.insert(0,str(ROOT/'src'))
from refs.cache import BlobCache
from refs.store import WriterLock,now


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--home',required=True);p.add_argument('--destination',required=True)
    a=p.parse_args();home=Path(a.home).expanduser().resolve();dest=Path(a.destination).expanduser().resolve()
    if dest==home or home in dest.parents:raise ValueError('BACKUP_MUST_BE_OUTSIDE_SOURCE_HOME')
    if dest.exists():raise FileExistsError('BACKUP_DESTINATION_EXISTS')
    if not (home/'catalog.sqlite3').is_file():raise FileNotFoundError('CATALOG_NOT_FOUND')
    dest.mkdir(parents=True,mode=0o700)
    try:
        with WriterLock(home/'writer.lock'):
            original=sqlite3.connect((home/'catalog.sqlite3').as_uri()+'?mode=ro',uri=True)
            output=sqlite3.connect(dest/'catalog.sqlite3')
            try:original.backup(output)
            finally:original.close();output.close()
            check=sqlite3.connect(dest/'catalog.sqlite3')
            try:
                if check.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise RuntimeError('BACKUP_DATABASE_CORRUPT')
                hashes={x[0] for x in check.execute('SELECT DISTINCT content_hash FROM snapshot_files WHERE content_hash IS NOT NULL')}
            finally:check.close()
            src=BlobCache(home/'blobs');target=BlobCache(dest/'blobs')
            for h in sorted(hashes):
                if target.put(src.get(h))!=h:raise RuntimeError('BACKUP_HASH_MISMATCH')
        if os.name!='nt':os.chmod(dest/'catalog.sqlite3',0o600)
        result={'status':'verified','created_at':now(),'copied_blobs':len(hashes),
                'catalog_sha256':hashlib.sha256((dest/'catalog.sqlite3').read_bytes()).hexdigest(),
                'private_data':True,'source_git_modified':False,
                'restore_note':'Stop REFS before restoring into an empty data directory. Reconfigure endpoints/credentials separately.'}
        (dest/'BACKUP_MANIFEST.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
        print(json.dumps(result));return 0
    except BaseException:
        (dest/'INCOMPLETE_BACKUP').write_text('Backup did not complete; do not use as a verified restore point.',encoding='utf-8')
        raise
if __name__=='__main__':raise SystemExit(main())
