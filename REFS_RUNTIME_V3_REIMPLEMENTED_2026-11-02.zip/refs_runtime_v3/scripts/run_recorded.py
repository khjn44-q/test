#!/usr/bin/env python3
"""Run one foreground verification command and record its actual outcome.

Never pass credentials as argv: the command is intentionally saved in the receipt.
This script does not schedule work or claim success before the child terminates.
"""
from __future__ import annotations
import argparse,datetime,json,os,platform,subprocess,sys,time
from pathlib import Path

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--prefix',required=True);p.add_argument('command',nargs=argparse.REMAINDER)
    args=p.parse_args();command=args.command
    if command and command[0]=='--':command=command[1:]
    if not command:p.error('a command is required after --')
    prefix=Path(args.prefix);prefix.parent.mkdir(parents=True,exist_ok=True)
    log=prefix.with_suffix('.log');receipt=prefix.with_suffix('.json')
    now=lambda:datetime.datetime.now(datetime.timezone.utc).isoformat()
    result={'command':command,'cwd':str(Path.cwd()),'started_at':now(),'status':'running',
            'python':sys.version,'platform':platform.platform(),'returncode':None}
    receipt.write_text(json.dumps(result,indent=2),encoding='utf-8');start=time.perf_counter()
    try:
        with log.open('w',encoding='utf-8') as stream:
            completed=subprocess.run(command,stdout=stream,stderr=subprocess.STDOUT,check=False)
        result.update(returncode=completed.returncode,status='passed' if completed.returncode==0 else 'failed')
    except KeyboardInterrupt:result.update(returncode=130,status='interrupted')
    except OSError as error:result.update(returncode=127,status='launch_failed',error_type=type(error).__name__)
    result.update(finished_at=now(),duration_seconds=time.perf_counter()-start)
    receipt.write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps({'status':result['status'],'returncode':result['returncode'],'receipt':str(receipt)}))
    return result['returncode']
if __name__=='__main__':raise SystemExit(main())
