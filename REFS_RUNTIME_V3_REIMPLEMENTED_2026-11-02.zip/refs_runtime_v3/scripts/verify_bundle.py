#!/usr/bin/env python3
"""Verify every declared file and reject undeclared/unsafe ZIP members before extraction."""
from __future__ import annotations
import argparse,hashlib,json,stat,zipfile
from pathlib import Path,PurePosixPath

def _safe(name):
    p=PurePosixPath(name)
    if p.is_absolute() or '..' in p.parts or '\\' in name or not name or ':' in p.parts[0]:
        raise ValueError('UNSAFE_ARCHIVE_PATH')
    return p

def verify_zip(path):
    path=Path(path)
    with zipfile.ZipFile(path) as archive:
        infos=archive.infolist();names=[x.filename for x in infos]
        if len(names)!=len(set(names)):raise ValueError('DUPLICATE_ARCHIVE_MEMBER')
        for info in infos:
            _safe(info.filename)
            if stat.S_ISLNK(info.external_attr>>16):raise ValueError('SYMLINK_ARCHIVE_MEMBER')
        if sum(x.file_size for x in infos)>1024**3:raise ValueError('UNEXPECTED_BUNDLE_SIZE')
        if archive.testzip() is not None:raise ValueError('ZIP_CRC_ERROR')
        manifests=[name for name in names if name.endswith('/MANIFEST.json') and len(PurePosixPath(name).parts)==2]
        if len(manifests)!=1:raise ValueError('SINGLE_ROOT_MANIFEST_REQUIRED')
        manifest_name=manifests[0];root=manifest_name.rsplit('/',1)[0]+'/'
        manifest=json.loads(archive.read(manifest_name))
        if manifest.get('schema_version')!=1:raise ValueError('UNSUPPORTED_MANIFEST')
        expected={manifest_name};total=0
        for item in manifest['files']:
            _safe(item['path']);name=root+item['path']
            if name in expected:raise ValueError('DUPLICATE_MANIFEST_PATH')
            expected.add(name)
            body=archive.read(name)
            if len(body)!=item['bytes'] or hashlib.sha256(body).hexdigest()!=item['sha256']:
                raise ValueError('CONTENT_DIGEST_MISMATCH:'+item['path'])
            total+=len(body)
        files={x.filename for x in infos if not x.is_dir()}
        if files!=expected:raise ValueError('UNDECLARED_OR_MISSING_FILES')
    return {'status':'verified','files_verified':len(manifest['files']),'uncompressed_bytes':total,
            'archive_bytes':path.stat().st_size,'archive_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
            'crc_checked':True,'manifest':manifest_name}

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('zip');a=p.parse_args()
    print(json.dumps(verify_zip(a.zip),indent=2));return 0
if __name__=='__main__':raise SystemExit(main())
