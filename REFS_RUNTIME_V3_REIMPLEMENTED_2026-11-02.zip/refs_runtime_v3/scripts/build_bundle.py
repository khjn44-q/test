#!/usr/bin/env python3
"""Build the single release ZIP from an explicit project allowlist, then verify all members."""
from __future__ import annotations
import argparse,hashlib,importlib.util,json,os,tempfile,zipfile
from pathlib import Path

ROOT_FILES={'README.md','HANDOFF_KO.md','WORKLOG.md','NOTICE.md','pyproject.toml','.gitignore'}
ROOT_DIRS={'src','tests','docs','contracts','examples','skills','scripts','bench','provenance','verification','dist'}
SKIP_PARTS={'.git','.venv','venv','__pycache__','.pytest_cache','build'}
REQUIRED={'README.md','HANDOFF_KO.md','pyproject.toml','docs/DESIGN.md','docs/PLAN.md',
          'verification/FINAL_REPORT.md','src/refs/__init__.py','dist/engineering_refs-0.3.0-py3-none-any.whl'}

def _verify(path):
    spec=importlib.util.spec_from_file_location('refs_release_verifier',Path(__file__).with_name('verify_bundle.py'))
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return module.verify_zip(path)

def build_bundle(root,output):
    root=Path(root).resolve();output=Path(output).resolve()
    missing=sorted(p for p in REQUIRED if not (root/p).is_file())
    if missing:raise ValueError('MISSING_REQUIRED: '+', '.join(missing))
    selected=[]
    for path in sorted(root.rglob('*')):
        rel=path.relative_to(root);parts=rel.parts
        if any(p in SKIP_PARTS or p.endswith('.egg-info') for p in parts):continue
        if not (rel.as_posix() in ROOT_FILES or len(parts)>1 and parts[0] in ROOT_DIRS):continue
        if path.is_symlink():raise ValueError('SYMLINK_RELEASE_SOURCE:'+rel.as_posix())
        if not path.is_file():continue
        if path.name.startswith('.env') or path.suffix in {'.pyc','.pyo','.sqlite','.sqlite3','.db','.bin'}:continue
        if path.name=='active-verification-jobs.json':continue
        if parts[0]=='dist' and path.suffix!='.whl':continue
        selected.append((rel.as_posix(),path.read_bytes()))
    manifest={'schema_version':1,'product':'REFS Runtime','version':'0.3.0',
              'origin':'new_reimplementation_not_recovered_source',
              'files':[{'path':name,'bytes':len(body),'sha256':hashlib.sha256(body).hexdigest()} for name,body in selected]}
    output.parent.mkdir(parents=True,exist_ok=True)
    fd,tmp=tempfile.mkstemp(prefix='refs-release-',suffix='.zip',dir=output.parent);os.close(fd)
    try:
        with zipfile.ZipFile(tmp,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
            for name,body in selected:z.writestr('refs_runtime_v3/'+name,body)
            z.writestr('refs_runtime_v3/MANIFEST.json',json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
        report=_verify(tmp)
        os.replace(tmp,output)
        if report['archive_sha256']!=hashlib.sha256(output.read_bytes()).hexdigest():raise ValueError('PUBLISHED_ARCHIVE_CHANGED')
        report['output']=str(output)
        return report
    finally:
        if os.path.exists(tmp):os.unlink(tmp)

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--root',default=str(Path(__file__).resolve().parents[1]));p.add_argument('--output',required=True)
    a=p.parse_args();print(json.dumps(build_bundle(a.root,a.output),ensure_ascii=False,indent=2));return 0
if __name__=='__main__':raise SystemExit(main())
