# REFS Runtime 0.3 사내 인수인계

## 0. 정본과 현재 상태

이 ZIP은 **새로 작성한 Python/SQLite 구현**이다. 이전에 존재하지 않았던 `REFS_IMPLEMENTATION_2026-11-02.zip`의 복구본이라고 취급하지 않는다. 정본 우선순위는 `src/` 실제 동작 → 이 문서와 `docs/` → `tests/`/현재 검증 보고서다. `provenance/INPUT_*`는 이전 설계의 근거만 보관하며 TypeScript/QMD/local model 구성을 다시 강제하지 않는다.

실제 테스트는 [FINAL_REPORT](verification/FINAL_REPORT.md)를 기준으로 한다. 구현 존재, 합성 시험 통과, 실제 사내 모델 품질, 사용자 acceptance를 구분한다. 공개 100개 repo 검증이나 Windows/MCP 현장 검증을 완료했다고 보고하지 않는다.

## 1. 사내 작업자가 처음 할 일

1. ZIP을 새로운 프로그램 폴더에 풀고 `scripts/verify_bundle.py`로 받은 ZIP 무결성을 확인한다.
2. Python 3.11 이상, Git, Python SQLite FTS5를 확인한다. 기본 코어에는 pip 외부 runtime dependency가 없다.
3. 포함된 wheel을 `--no-index --no-deps`로 별도 venv에 설치한다. 예시는 README에 있다.
4. `python -m refs --home <별도 데이터 폴더> doctor`를 실행한다.
5. 승인된 Git 목록과 모델 설정을 작성한다. Git 읽기 권한이 이미 있다는 사용자 사실을 다시 설문하지 말고 필요한 경로·ref만 연결한다.
6. 전체 Git 목록(100개 이상)을 등록하고 `update --all --plan`으로 변화를 확인한 뒤 `update --all`을 수행한다.
7. 모델 probe 성공 후 `update --all --summarize`로 원문 벡터와 사전 요약을 구성한다. 같은 원문은 재사용된다. 요청한 summary가 실패하면 전체 결과는 partial이며 index_state는 별도로 표시된다.
8. 실제 질문의 정답 source를 정해 [FIELD_ACCEPTANCE](docs/FIELD_ACCEPTANCE.md)를 수행한다. 사내 결과를 기존 합성 benchmark와 섞지 않는다.

이 과정에서 회사 토큰·private 주소·소스 원문을 외부 채팅/공개 Git에 붙이지 않는다. 모델 연결 실패를 외부 API 자동 우회로 해결하지 않는다.

## 2. 프로그램과 데이터의 분리

```text
프로그램 폴더/          # ZIP의 src/docs/tests/scripts/dist
회사 전용 데이터 폴더/
  catalog.sqlite3      # metadata, FTS, vectors, notes, sessions, jobs
  blobs/               # hash-addressed compressed verified raw source
  git/<repo>.git/      # remote 등록을 위한 managed bare fetch cache
  writer.lock          # OS writer lock; 남아 있는 파일 자체는 stale lock이 아님
```

프로그램 제거 때 원본 Git과 데이터 폴더를 자동 삭제하지 않는다. 데이터는 private source와 embedding을 포함하므로 회사 저장·백업 정책의 적용 대상이다. 이 버전에는 자동 GC·보존기간별 삭제·중앙 ACL 동기화가 없다.

## 3. 실제 Git 연결

목록은 JSON 또는 한 줄당 URL/기존 로컬 경로다. 명시적인 ID와 ref를 가진 JSON을 권장한다.

```json
{"repositories":[
  {"repo_id":"project-a","url":"https://git.example.invalid/group/project-a.git","ref":"HEAD","web_url":"https://git.example.invalid/group/project-a/-/blob/{commit}/{path}"},
  {"repo_id":"project-b","path":"F:/CompanyRepos/project-b","ref":"HEAD"}
]}
```

위 주소는 예시다. 실제 host routing을 확인해 `web_url`을 채운다. Git credential helper/SSH/사내 CA는 기존 승인 설정을 사용한다. HTTPS URL에 password/token을 넣으면 거부한다. remote는 https/ssh, local-remote는 합성 시험용 명시 플래그일 때만 허용한다.

- `--path`: 현재 로컬 repo의 지정 ref를 읽기만 한다. **원격 fetch/pull을 대신하지 않는다.** 사용자가 clone을 갱신하거나 관리형 `--url`을 사용한다.
- `--url`: 관리형 bare cache에 지정 ref만 fetch한다. 기본 `index.fetch_depth=1`, source repo/checkout은 변경하지 않는다. 과거 evidence는 blob cache로 보존한다.
- shallow를 지원하지 않는 호스트는 오류를 보고한다. 필요한 경우 `fetch_depth=0`(무제한 history)을 승인·용량 검토 후 선택한다. 자동으로 큰 full history를 가져오지 않는다.
- 동일 ID를 다른 source/ref에 재바인딩하지 않는다. 새 ID로 등록하거나 별도의 검토된 migration을 수행한다.
- 목록에서 빠졌다고 기존 등록을 자동 삭제하지 않는다. 필요 시 `repo disable <id>`를 명시 실행한다.

## 4. 회사 모델을 연결하는 최소 수정 범위

대부분은 `refs.company.json`과 환경변수 설정으로 끝난다. [MODEL_ADAPTERS](docs/MODEL_ADAPTERS.md)의 wire contract를 대조한다.

임베딩 API가 `model,input → data[index,embedding]` 또는 `vectors` 응답이면 기본 어댑터를 사용한다. chat API가 `model,messages → choices[0].message.content`면 기본 LLM 어댑터를 사용한다. 경로 이름은 제한하지 않지만 HTTPS와 인증 정책을 확인한다.

다른 wire format이면 `src/refs/providers.py`를 무작정 전체 수정하지 말고 내부 전용 어댑터 파일을 하나 추가한다. 다음 인터페이스를 지킨다.

```python
class CorporateEmbedding:
    fingerprint: str
    dimensions: int
    def embed(self, texts: list[str], role: str = "document") -> list[list[float]]: ...

class CorporateChat:
    fingerprint: str
    config: object  # max_input_chars 필수
    def complete(self, messages: list[dict[str, str]]) -> str: ...
```

`Runtime(home, embedding=..., llm=...)`에 연결하고 config factory의 생성 부분만 바꾼다. fingerprint는 진짜 모델 revision·차원·query/document 전처리·보안 domain을 반영한다. 인증 토큰/배치 크기/timeout은 의미 공간을 바꾸지 않는다. LLM 출력 설정은 별도 fingerprint로 관리한다.

**임베딩과 LLM은 다른 역할이다.** 임베딩 모델로 자연어 요약문을 생성하려 하지 않는다. 사내 서비스를 사용할 수 없는 동안에도 raw/lexical/원문 경로를 먼저 검사할 수 있지만 의미 검색 완료라고 보고하지 않는다.

## 5. 가장 먼저 검증할 실사용 흐름

### A. Jira 전체 조사

`scan --detector jira --limit 100` 후 `next_cursor`가 없을 때까지 이어 읽는다. 결과는 source_candidate/docs_only/test_only/dependency_only이며 **Jira 실제 API 사용 확정은 아니다**. 호출부→wrapper→인증→JQL→페이지네이션을 evidence/trace/analyze로 확인한다. scan의 source line, commit, 전체 제외 범위를 보고한다.

검색 결과의 `session_id`로 후속 search를 하면 같은 snapshot을 유지한다. 업데이트 뒤 최신 조사를 하려면 session 없이 새 search/scan을 시작한다.

### B. SSD 열 모델

자연어 hybrid 검색으로 계산 후보를 찾는다. 원문 수식, 이산화/단위/초기·경계조건/parameter loader/test를 별도로 읽는다. `analyze`의 formula 표현은 `code_expression`과 `symbolic_reconstruction`을 구별하며 미확인 단위·실측 정확도는 unknown으로 남긴다.

Python은 AST 탐색이 가능하고, C/C++ 등은 text fallback으로 source search/read/LLM 해석을 제공한다. 그 언어의 정확한 호출 그래프가 필요하면 [EXTENSION_GUIDE](docs/EXTENSION_GUIDE.md)의 parser/SCIP 작업을 추가한다. 그 작업을 단순 endpoint tuning만으로 완료할 수 있다고 보장하지 않는다.

### C. 재사용

`prepare-use <evidence_id>`는 entrypoint, dependency manifest, test/example 후보와 미확인 조건을 반환한다. 현재 `readiness=reference_only`다. 실제 API 인증·SDK 설치·실행·코드 편집은 기존 하네스에서 수행하며, 실제 성공 증거 없이 ready/execution_verified로 올리지 않는다.

## 6. 하네스 연결

CLI는 어디서든 승인된 프로세스를 실행할 수 있는 하네스가 사용한다. `refs call <tool> --args '<JSON>'`도 제공한다. 도구 이름과 출력은 [API](contracts/API.md)에 있다.

MCP가 필요하면 승인 wheelhouse에서 공식 Python SDK v2를 설치하고 `refs mcp`를 실행한다. 기본 도구는 읽기/분석용이며 `--allow-update`를 지정했을 때만 update 도구를 노출한다. 실제 SDK와 사용하는 하네스에서 `tests/test_mcp_optional.py` 및 실제 stdio smoke를 실행해야 한다. 이 환경에서는 SDK 미설치로 이 검증이 skipped다.

OMP 전용 extension을 구현했다고 주장하지 않는다. `skills/internal-refs/SKILL.md`는 설치 초안이며 실제 자동 trigger는 하네스에 맞춰 시험한다. Cloud chat이 회사 PC의 stdio에 직접 접근할 수 있다고 가정하지 않는다. 사내 승인 remote bridge는 별도 보안/배포 작업이다.

## 7. 후속 구현자의 작업 우선순위

- **F0 환경 계약**: 회사 Python/SQLite/Git, approved model endpoint와 tokenization, TLS/CA, offline install, 100+ 목록 등록.
- **F1 실제 품질**: 실제 정답 30개 이상으로 raw lexical vs summary dense vs raw dense 비교. hit/recall/원문 정확도/수식 검증/실제 재사용 시간을 분리.
- **F2 부족한 언어·분석**: 주요 C/C++/Java/TS parser 또는 기존 SCIP import가 실제 실패를 개선하는 경우에만 추가. source identity/byte mapping은 유지.
- **F3 대규모 최적화**: dense exact가 p95/메모리 목표를 넘을 때 승인된 vector backend를 어댑터로 교체. 먼저 summaries_only profile과 실제 chunk 수를 확인한다.
- **F4 운영 보완**: cache GC/retention/remote auth lease, 실제 하네스 Skill activation, 필요한 API operation binding·실행 receipt.
- **F5 중앙 배포/UI**: 실제 수요가 있을 때만. 로컬 검증을 전사 ACL 승인으로 대신하지 않는다.

F0/F1은 현장 인수의 필수이며, F2~F4 중 사용 목적에 필수인 항목도 Acceptance에 포함한다. 남은 것이 전부 미세 조정뿐이라고 단정하지 않는다.

## 8. 절대 바꾸지 말 것

원본 Git 읽기 전용, commit/blob/hash/span, snapshot pinning, model-space separation, 전체 scan coverage, 권한/enable 재검사, 모델 출력 권위 분리, update/rebuild 구분, secret 참조 방식을 보존한다. 품질을 위해 이를 생략하지 않는다. 성능 수치나 테스트 수를 제품 완료율로 환산하지 않는다.

## 9. 바로 전달할 지시

> 이 ZIP의 HANDOFF_KO.md, docs/DESIGN.md, docs/PLAN.md, verification/FINAL_REPORT.md를 읽고 현재 Python 구현을 보존하라. 분실된 이전 구현의 복구본이 아니며 provenance/의 QMD/TypeScript 안을 다시 구현하지 마라. 회사 모델·Git·Windows·하네스 계약을 연결하고 실제 질문/정답으로 평가하라. tests를 실제 실행하고 미검증 영역은 별도로 표시하라. 새 플랫폼/UI보다 현재 source→search→evidence→update→reuse 흐름의 현장 실패를 우선 해결하라. 변경한 설정·모델·코드와 실제 결과를 짧은 checkpoint에 남겨라.
